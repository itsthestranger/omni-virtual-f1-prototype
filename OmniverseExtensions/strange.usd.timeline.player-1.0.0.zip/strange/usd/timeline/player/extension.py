import omni.ext
import omni.ui as ui
import omni.timeline

# Any class derived from `omni.ext.IExt` in top level module (defined in `python.modules` of `extension.toml`) will be
# instantiated when extension gets enabled and `on_startup(ext_id)` will be called. Later when extension gets disabled
# on_shutdown() is called.
class StrangeUsdTimelinePlayerExtension(omni.ext.IExt):
    # ext_id is current extension id. It can be used with extension manager to query additional information, like where
    # this extension is located on filesystem.
    def on_startup(self, ext_id):
        print("[strange.usd.timeline.player] strange usd timeline player startup")

        self._count = 0

        self._window = ui.Window("Play/Pause Animation", width=300, height=300)
        with self._window.frame:
            with ui.VStack():
                # get the stage:
                stage = omni.usd.get_context().get_stage()

                if stage is not None:
                    # get a reference to the timeline
                    timeline = omni.timeline.get_timeline_interface()
                    
                    with ui.VStack():
                        def on_click():
                            # get activate Boolean Attribute reference
                            activate = stage.GetPrimAtPath('/World').GetAttribute('activate')
                            if activate.Get():
                                print("activate: True")
                            else:
                                print("activate: False")

                            if activate.Get():
                                if timeline.is_playing():
                                    timeline.pause()
                                    activate.Set(False)
                            else:
                                if not timeline.is_playing():
                                    timeline.play()
                                    activate.Set(True)

                        ui.Button('Play', clicked_fn=on_click)
                        ui.Button('Pause', clicked_fn=on_click)

    def on_shutdown(self):
        print("[strange.usd.timeline.player] strange usd timeline player shutdown")
