var searchData=
[
  ['inputformat_5fbgra_5f8sb_593',['InputFormat_BGRA_8SB',['../namespacenvtt.html#a7ea4cd82d5104d66e14f5524442c5f5ea2fcc1076f7eb98eb300757660fa8de07',1,'nvtt']]],
  ['inputformat_5fbgra_5f8ub_594',['InputFormat_BGRA_8UB',['../namespacenvtt.html#a7ea4cd82d5104d66e14f5524442c5f5eaf8b3af0719535e2e45599d0b20a463d2',1,'nvtt']]],
  ['inputformat_5fr_5f32f_595',['InputFormat_R_32F',['../namespacenvtt.html#a7ea4cd82d5104d66e14f5524442c5f5ea7d8245786e1f39d2a9b8fb6baa2005c8',1,'nvtt']]],
  ['inputformat_5frgba_5f16f_596',['InputFormat_RGBA_16F',['../namespacenvtt.html#a7ea4cd82d5104d66e14f5524442c5f5ea351131926eee5bf0c0d0ed706699e2f0',1,'nvtt']]],
  ['inputformat_5frgba_5f32f_597',['InputFormat_RGBA_32F',['../namespacenvtt.html#a7ea4cd82d5104d66e14f5524442c5f5ea5c06b40c2edcfb0c948ebdc003c55a17',1,'nvtt']]]
];
