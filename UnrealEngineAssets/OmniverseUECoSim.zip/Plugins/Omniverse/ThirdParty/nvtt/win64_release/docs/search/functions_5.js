var searchData=
[
  ['face_373',['face',['../structnvtt_1_1_cube_surface.html#af2b7a5e56036b8bc37efd7ffb642d1df',1,'nvtt::CubeSurface::face(int face)'],['../structnvtt_1_1_cube_surface.html#a66dc572010b1459c6931c2ef2eb1826e',1,'nvtt::CubeSurface::face(int face) const']]],
  ['fastresample_374',['fastResample',['../structnvtt_1_1_cube_surface.html#a34947e247a7eb76336172d54e567cfbf',1,'nvtt::CubeSurface']]],
  ['fill_375',['fill',['../structnvtt_1_1_surface.html#a9dbd1c849660a8e7569ea474254c4369',1,'nvtt::Surface']]],
  ['flipx_376',['flipX',['../structnvtt_1_1_surface.html#a23b4256fa96b9b81e4bc2af448ffaaaf',1,'nvtt::Surface']]],
  ['flipy_377',['flipY',['../structnvtt_1_1_surface.html#a2e38455acfeb3ca4a8219ed944355a66',1,'nvtt::Surface']]],
  ['flipz_378',['flipZ',['../structnvtt_1_1_surface.html#a79d83939e62ac19b2aae843eec0354fa',1,'nvtt::Surface']]],
  ['fold_379',['fold',['../structnvtt_1_1_cube_surface.html#a8a976fe40f64e61cf3a563c0040daf11',1,'nvtt::CubeSurface']]],
  ['fromlogscale_380',['fromLogScale',['../structnvtt_1_1_surface.html#a86ab44e1c6517847018f2402c914260a',1,'nvtt::Surface']]],
  ['fromluvw_381',['fromLUVW',['../structnvtt_1_1_surface.html#a44e3a7cbb1ab51b47ba7897563de5323',1,'nvtt::Surface']]],
  ['fromrgbe_382',['fromRGBE',['../structnvtt_1_1_surface.html#ac739fbfff5eb5237ca7d3635477681cc',1,'nvtt::Surface']]],
  ['fromrgbm_383',['fromRGBM',['../structnvtt_1_1_surface.html#a37ee98276a237caf39437f5aa64730e0',1,'nvtt::Surface']]],
  ['fromycocg_384',['fromYCoCg',['../structnvtt_1_1_surface.html#a04bb71ed43deb8454491d554ac2e3145',1,'nvtt::Surface']]]
];
