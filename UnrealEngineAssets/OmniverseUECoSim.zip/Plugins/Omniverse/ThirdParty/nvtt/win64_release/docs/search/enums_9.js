var searchData=
[
  ['resizefilter_529',['ResizeFilter',['../namespacenvtt.html#a3607100ce561fdaa3859abd0f05878c7',1,'nvtt']]],
  ['roundmode_530',['RoundMode',['../namespacenvtt.html#a673a22796ec42ae50e14ab1ed6906bd5',1,'nvtt']]]
];
