var searchData=
[
  ['height_143',['height',['../structnvtt_1_1_ref_image.html#ad6ee4973727b7c5093ebc073741914ce',1,'nvtt::RefImage::height()'],['../structnvtt_1_1_surface.html#a059d6eadb470e5b4209ad12e7c73309e',1,'nvtt::Surface::height() const']]],
  ['histogram_144',['histogram',['../structnvtt_1_1_surface.html#a315247163465480bfc38c9a63a4f4e3a',1,'nvtt::Surface::histogram()'],['../namespacenvtt.html#a3181d618054f0b1591e01a342136b6b7',1,'nvtt::histogram(const Surface &amp;img, int width, int height, TimingContext *tc=0)'],['../namespacenvtt.html#a2b39014308319e64f6cb72ee5b0219fe',1,'nvtt::histogram(const Surface &amp;img, float minRange, float maxRange, int width, int height, TimingContext *tc=0)']]]
];
