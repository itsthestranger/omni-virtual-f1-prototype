var searchData=
[
  ['edgelength_365',['edgeLength',['../structnvtt_1_1_cube_surface.html#a0c9bd9e7c47ed7d8c4a74c6762299aa0',1,'nvtt::CubeSurface']]],
  ['enablecudaacceleration_366',['enableCudaAcceleration',['../structnvtt_1_1_context.html#a8191fdc9c711b060013edccd0162f02f',1,'nvtt::Context']]],
  ['enabletiming_367',['enableTiming',['../structnvtt_1_1_context.html#a9da3d5a2b7f4adcdf6e74f73f8dfff55',1,'nvtt::Context']]],
  ['endimage_368',['endImage',['../structnvtt_1_1_output_handler.html#a887a2d54d3101f540b5a41d21e2da56a',1,'nvtt::OutputHandler']]],
  ['error_369',['error',['../structnvtt_1_1_error_handler.html#a7ce72a6fb89743f9a42ef0dcfb284d71',1,'nvtt::ErrorHandler']]],
  ['errorstring_370',['errorString',['../namespacenvtt.html#aa1ae97a643706ccf2940c94e3ca622fd',1,'nvtt']]],
  ['estimatesize_371',['estimateSize',['../structnvtt_1_1_context.html#a6ab9514249cdd941594d510179e3d883',1,'nvtt::Context::estimateSize(const Surface &amp;img, int mipmapCount, const CompressionOptions &amp;compressionOptions) const'],['../structnvtt_1_1_context.html#aeaf581c39759fa50cd3b6fa66c314d7b',1,'nvtt::Context::estimateSize(const CubeSurface &amp;cube, int mipmapCount, const CompressionOptions &amp;compressionOptions) const'],['../structnvtt_1_1_context.html#a85b9dca67659a9f3c81f179cd52b46e0',1,'nvtt::Context::estimateSize(int w, int h, int d, int mipmapCount, const CompressionOptions &amp;compressionOptions) const']]],
  ['expandnormals_372',['expandNormals',['../structnvtt_1_1_surface.html#a4259f830dd7fb302b2320f2bdc798193',1,'nvtt::Surface']]]
];
