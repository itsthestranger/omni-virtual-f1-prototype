var searchData=
[
  ['d3d9format_50',['d3d9Format',['../structnvtt_1_1_compression_options.html#a8f9ed2a569d47cfbaab30f1abac801d5',1,'nvtt::CompressionOptions']]],
  ['data_51',['data',['../structnvtt_1_1_ref_image.html#a28f7946a03f3887f191c097025fcc916',1,'nvtt::RefImage::data()'],['../structnvtt_1_1_surface.html#a7d00fffaca7a69457c4db0a8af28fcd2',1,'nvtt::Surface::data() const'],['../structnvtt_1_1_surface.html#a09a9830d99707456c59a9b0658a33f5f',1,'nvtt::Surface::data()']]],
  ['demultiplyalpha_52',['demultiplyAlpha',['../structnvtt_1_1_surface.html#a907f237e7825d33836d253f21fca2274',1,'nvtt::Surface']]],
  ['depth_53',['depth',['../structnvtt_1_1_ref_image.html#af8ba0b4ec841b4cbc70132c84ab94ffb',1,'nvtt::RefImage::depth()'],['../structnvtt_1_1_surface.html#a6ceabda2b08248eecbe991b708ae52fb',1,'nvtt::Surface::depth()']]],
  ['diff_54',['diff',['../namespacenvtt.html#a1781708d38918b6eda9165fb5f9c10c1',1,'nvtt']]]
];
