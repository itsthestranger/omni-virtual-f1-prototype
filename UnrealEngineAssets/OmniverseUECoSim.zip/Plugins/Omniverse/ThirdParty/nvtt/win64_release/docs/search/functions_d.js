var searchData=
[
  ['quantize_431',['quantize',['../structnvtt_1_1_context.html#aac1189075fe40fb8ef47dee2013715a8',1,'nvtt::Context::quantize()'],['../structnvtt_1_1_surface.html#ad4fd978431757e6b3f4c1e6e114ffc40',1,'nvtt::Surface::quantize()']]]
];
