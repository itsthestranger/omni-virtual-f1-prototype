var searchData=
[
  ['nvtt_5fapi_628',['NVTT_API',['../nvtt__lowlevel_8h.html#a888e0c50df09fc78a88844abfbf23f97',1,'nvtt_lowlevel.h']]],
  ['nvtt_5fdeclare_5fpimpl_629',['NVTT_DECLARE_PIMPL',['../nvtt_8h.html#ac0ed68c6810fc9391ef89d0966f25f8e',1,'nvtt.h']]],
  ['nvtt_5fforbid_5fcopy_630',['NVTT_FORBID_COPY',['../nvtt_8h.html#a2b1d11be0d8d3505e483210be7a44b62',1,'nvtt.h']]],
  ['nvtt_5fversion_631',['NVTT_VERSION',['../nvtt_8h.html#a1bb7cc2a37e13e5ebbd30921af48a789',1,'nvtt.h']]]
];
