// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SWidget.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Views/STableViewBase.h"
#include "Framework/Commands/UICommandList.h"
#include "Misc/TextFilter.h"
#include "Misc/IFilter.h"
#include "Misc/FilterCollection.h"
#include "Templates/MaxSizeof.h"
#include "OmniverseLayerDataSource.h"

struct FOmniverseTreeItemID
{
public:
	FOmniverseTreeItemID() : Type(EType::Null), CachedHash(0) {}

	FOmniverseTreeItemID(const UOmniverseLayer* InLayer) : Type(EType::Layer)
	{
		new (Data) FString(InLayer->FullPath);
		CachedHash = CalculateTypeHash();
	}

	FOmniverseTreeItemID(const UOmniversePrim* InPrim) : Type(EType::Prim)
	{
		new (Data) FString(InPrim->FullPath);
		CachedHash = CalculateTypeHash();
	}

	FOmniverseTreeItemID(const FOmniverseTreeItemID& Other)
	{
		*this = Other;
	}

	FOmniverseTreeItemID& operator=(const FOmniverseTreeItemID& Other)
	{
		Type = Other.Type;
		new (Data) FString(Other.GetAsPathRef());

		CachedHash = CalculateTypeHash();
		return *this;
	}

	FOmniverseTreeItemID(FOmniverseTreeItemID&& Other)
	{
		*this = MoveTemp(Other);
	}
	FOmniverseTreeItemID& operator=(FOmniverseTreeItemID&& Other)
	{
		FMemory::Memswap(this, &Other, sizeof(FOmniverseTreeItemID));
		return *this;
	}

	~FOmniverseTreeItemID()
	{
		GetAsPathRef().~FString();
	}

	friend bool operator==(const FOmniverseTreeItemID& One, const FOmniverseTreeItemID& Other)
	{
		return One.Type == Other.Type && One.CachedHash == Other.CachedHash && One.Compare(Other);
	}

	friend bool operator!=(const FOmniverseTreeItemID& One, const FOmniverseTreeItemID& Other)
	{
		return One.Type != Other.Type || One.CachedHash != Other.CachedHash || !One.Compare(Other);
	}

	uint32 CalculateTypeHash() const
	{
		uint32 Hash = GetTypeHash(GetAsPathRef());

		return HashCombine((uint8)Type, Hash);
	}

	friend uint32 GetTypeHash(const FOmniverseTreeItemID& ItemID)
	{
		return ItemID.CachedHash;
	}

private:
	FString & GetAsPathRef() const { return *reinterpret_cast<FString*>(Data); }

	bool Compare(const FOmniverseTreeItemID& Other) const
	{
		if (Type == EType::Null) return true;

		return GetAsPathRef() == Other.GetAsPathRef();
	}

	enum class EType : uint8 { Layer, Prim, Null };
	EType Type;

	uint32 CachedHash;
	static const uint32 MaxSize = sizeof(FString);
	mutable uint8 Data[MaxSize];
};

#define OMNIVERSE_TREE_ITEM_VIEW_MODEL_TYPE(TYPE, BASE) \
	static const FString& GetTypeId() { static FString Type = TEXT(#TYPE); return Type; } \
	virtual bool IsOfTypeImpl(const FString& Type) const override { return GetTypeId() == Type || BASE::IsOfTypeImpl(Type); }

class IOmniverseTreeItemViewModel;
typedef TFilterCollection<const TSharedPtr<IOmniverseTreeItemViewModel>&> LayerFilterCollection;
typedef IFilter<const TSharedPtr<IOmniverseTreeItemViewModel>&> LayerFilter;
class FOmniverseTreeSharedData
{
public:
	FOmniverseTreeSharedData() : Filters(MakeShareable(new LayerFilterCollection))
	{
		Filters->OnChanged().AddRaw(this, &FOmniverseTreeSharedData::FilterChangedInternal);
	}

	~FOmniverseTreeSharedData()
	{
		Filters->OnChanged().RemoveAll(this);
	}

	void SetCopyItems(const TArray<TWeakPtr<IOmniverseTreeItemViewModel>>& InCopyItems)
	{
		CopyItems = InCopyItems;
	}

	TArray<TWeakPtr<IOmniverseTreeItemViewModel>> GetCopyItems() const
	{
		return CopyItems;
	}

	DECLARE_EVENT(FOmniverseTreeSharedData, FOnPreLayerDataSourceChanged);
	FOnPreLayerDataSourceChanged& OnPreLayerDataSourceChanged()
	{
		return PreLayerDataSourceChanged;
	}

	DECLARE_EVENT(FOmniverseTreeSharedData, FOnPostLayerDataSourceChanged);
	FOnPostLayerDataSourceChanged& OnPostLayerDataSourceChanged()
	{
		return PostLayerDataSourceChanged;
	}

	void SetLayerDataSource(const TSharedPtr<IOmniverseLayerDataSource>& InLayerDataSource)
	{
		OnPreLayerDataSourceChanged().Broadcast();
		LayerDataSource = InLayerDataSource;
		OnPostLayerDataSourceChanged().Broadcast();
	}

	TSharedPtr<IOmniverseLayerDataSource> GetLayerDataSource() const
	{
		return LayerDataSource;
	}

	DECLARE_EVENT(FOmniverseTreeSharedData, FOnFilterChanged);
	FOnFilterChanged& OnFilterChanged()
	{
		return FilterChanged;
	}

	DECLARE_EVENT(FOmniverseTreeSharedData, FOnPostFilterChanged);
	FOnPostFilterChanged& OnPostFilterChanged()
	{
		return PostFilterChanged;
	}

	bool PassesAllFilters(const TSharedPtr<IOmniverseTreeItemViewModel>& Item)
	{
		return Filters->PassesAllFilters(Item);
	}

	void AddFilter(const TSharedRef<LayerFilter>& InFilter)
	{
		Filters->Add(InFilter);
	}

	void RemoveFilter(const TSharedRef<LayerFilter>& InFilter)
	{
		Filters->Remove(InFilter);
	}

private:
	void FilterChangedInternal()
	{
		OnFilterChanged().Broadcast();
		OnPostFilterChanged().Broadcast();
	}

	TArray<TWeakPtr<IOmniverseTreeItemViewModel>> CopyItems;
	TSharedPtr<IOmniverseLayerDataSource> LayerDataSource;
	FOnPreLayerDataSourceChanged PreLayerDataSourceChanged;
	FOnPostLayerDataSourceChanged PostLayerDataSourceChanged;
	const TSharedRef<LayerFilterCollection> Filters;
	FOnFilterChanged FilterChanged;
	FOnPostFilterChanged PostFilterChanged;
};

class IOmniverseTreeItemViewModel : public TSharedFromThis<IOmniverseTreeItemViewModel>
{
protected:
	IOmniverseTreeItemViewModel(const TSharedRef<FOmniverseTreeSharedData>& InSharedPtr) : Parent(nullptr), SharedData(InSharedPtr)
	{
		SharedData->OnFilterChanged().AddRaw(this, &IOmniverseTreeItemViewModel::OnFilterChanged);
	}

	virtual ~IOmniverseTreeItemViewModel()
	{
		SharedData->OnFilterChanged().RemoveAll(this);
	}

	virtual bool IsOfTypeImpl(const FString& Type) const
	{
		return false;
	}

	void OnFilterChanged()
	{
		FilteredChildren.Empty();
		for (auto ChildViewModel : AllChildren)
		{
			if (ChildViewModel->PassesAllFilters())
				FilteredChildren.Add(ChildViewModel);
		}
	}

	mutable TWeakPtr<IOmniverseTreeItemViewModel> Parent;

	mutable TArray<TSharedPtr<IOmniverseTreeItemViewModel>> AllChildren;

	mutable TArray<TSharedPtr<IOmniverseTreeItemViewModel>> FilteredChildren;

	mutable TSharedRef<FOmniverseTreeSharedData> SharedData;

public:
	TSharedPtr<IOmniverseTreeItemViewModel> GetParent() const
	{
		return Parent.Pin();
	}

	void AddChild(const TSharedPtr<IOmniverseTreeItemViewModel>& Child)
	{
		Child->Parent = AsShared();
		if(Child->PassesAllFilters())
			FilteredChildren.Add(Child);
		AllChildren.Add(Child);
	}

	void RemoveChild(const TSharedPtr<IOmniverseTreeItemViewModel>& Child)
	{
		if (FilteredChildren.Remove(Child) || AllChildren.Remove(Child))
		{
			Child->Parent = nullptr;
		}
	}

	template <class PREDICATE_CLASS>
	void RemoveAllChild(const PREDICATE_CLASS& Predicate)
	{
		AllChildren.RemoveAll(Predicate);
		FilteredChildren.RemoveAll(Predicate);
	}

	void EmptyAllChild()
	{
		AllChildren.Empty();
		FilteredChildren.Empty();
	}

	TSharedRef<FOmniverseTreeSharedData> GetSharedData() const
	{
		return SharedData;
	}

	// If it or any of its children passes the filter
	bool PassesAllFilters()
	{
		bool Passed = false;
		if (SharedData->PassesAllFilters(AsShared()))
		{
			Passed = true;
		}
		else
		{
			for (auto Child : AllChildren)
			{
				if (Child->PassesAllFilters())
				{
					Passed = true;
					break;
				}
			}
		}

		return Passed;
	}

	FORCEINLINE const TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& GetChildren() const
	{
		return FilteredChildren;
	}

	template <class PREDICATE_CLASS>
	void SortChildren(const PREDICATE_CLASS& Predicate)
	{
		FilteredChildren.Sort(Predicate);
	}

public:
	/** Check if this can cast safely to the specified template type */
	template<class TType> bool IsOfType() const
	{
		return IsOfTypeImpl(TType::GetTypeId());
	}

public:
	virtual FOmniverseTreeItemID GetID() const = 0;

	virtual FString GetDisplayString() const = 0;

	virtual FText GetDisplayText() const = 0;

	virtual FText GetToolTipText() const = 0;

	virtual FName GetDisplayName() const = 0;

	virtual int32 GetTypeSortPriority() const = 0;

	virtual void OnExpansionChanged() {};

	virtual void SetVisible(bool Visibility) = 0;

	virtual bool IsVisible() const = 0;

	virtual bool CanEdit() const = 0;

	virtual void ToggleVisibility() = 0;



	virtual bool CanBeMoved() const = 0;

	virtual TSharedRef<ITableRow> GenerateRowWidget(const TSharedRef<STableViewBase>& OwnerTable, const TAttribute<FText>& InHighlightText) = 0;

	virtual TSharedPtr<SWidget> ConstructContextMenu() const = 0;

	virtual TSharedRef<FUICommandList> GetCommandList() const = 0;
};