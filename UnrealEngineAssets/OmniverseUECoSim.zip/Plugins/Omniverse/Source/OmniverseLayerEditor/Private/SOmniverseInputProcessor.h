// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "Modules/ModuleManager.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Application/IInputProcessor.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Editor.h"
#include "Editor/LevelEditor/Public/LevelEditor.h"
#include "IOmniverseTreeItemViewModel.h"

class SOmniverseLayerBrowser;
class SOmniverseInputProcessor : public IInputProcessor, public TSharedFromThis<SOmniverseInputProcessor>
{
public:

	static TSharedPtr<SOmniverseInputProcessor> Create(SOmniverseLayerBrowser* InLayerBrowser)
	{
		TSharedPtr<SOmniverseInputProcessor> InputProcessor = MakeShareable(new SOmniverseInputProcessor(InLayerBrowser));
		InputProcessor->Initialize();

		return InputProcessor;
	}

	virtual void Tick(const float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor> Cursor) override;

	virtual bool HandleKeyDownEvent(FSlateApplication& SlateApp, const FKeyEvent& InKeyEvent) override;

	/** Mouse button press */
	virtual bool HandleMouseButtonDownEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent) override;

	/** Mouse button release */
	virtual bool HandleMouseButtonUpEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent) override;

private:
	SOmniverseInputProcessor(SOmniverseLayerBrowser* InLayerBrowser)
		: LayerBrowser(InLayerBrowser)
	{
	}

	void Initialize();

	void OnDismissNoLayersNotification();

	void OnDismissLayerMutedNotification();

	void OnDismissLayerLockedNotification();

	void OnActivate();

	void OnLayersChanged(ELayersEventType EventType, UOmniverseLayer* InLayer, UOmniversePrim* InPrim);

	void OnLayerDataSourceChanged();

	bool UpdateNotificationItem();

	SOmniverseLayerBrowser* LayerBrowser;

	TSharedPtr<SNotificationItem> LayerLockedNotificationItem;

	TSharedPtr<SNotificationItem> NoLayerSelectedNotificationItem;

	TSharedPtr<SNotificationItem> LayerMutedNotificationItem;

	bool ButtonDownIsInViewport;
};