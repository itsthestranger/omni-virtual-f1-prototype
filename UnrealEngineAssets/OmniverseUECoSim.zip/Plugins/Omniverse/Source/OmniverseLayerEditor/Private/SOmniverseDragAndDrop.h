// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "Input/DragAndDrop.h"
#include "Styling/SlateBrush.h"
#include "Layout/Visibility.h"
#include "IOmniverseTreeItemViewModel.h"
#include "OmniverseLayerItemViewModel.h"
#include "OmniversePrimItemViewModel.h"

namespace OmniverseDragAndDrop
{
	struct FDragDropPayload
	{
		FDragDropPayload();

		FDragDropPayload(const TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& InDraggedItems);

		TArray<TWeakPtr<const FOmniverseLayerItemViewModel>> Layers;
	};

	struct FLayerDragDropOp : public FDragDropOperation
	{
		DRAG_DROP_OPERATOR_TYPE(FLayerDragDropOp, FDragDropOperation);

		FLayerDragDropOp(const FDragDropPayload& DraggedObjects);

		using FDragDropOperation::Construct;

		void ResetTooltip()
		{
			OverrideText = FText();
		}

		void SetTooltip(FText InOverrideText, const FSlateBrush* InOverrideIcon)
		{
			OverrideText = InOverrideText;
			OverrideIcon = InOverrideIcon;
		}

		FDragDropPayload GetPayLoad()
		{
			return Payload;
		}

		virtual TSharedPtr<SWidget> GetDefaultDecorator() const override;

	private:

		EVisibility GetOverrideVisibility() const;
		EVisibility GetDefaultVisibility() const;

		FText OverrideText;
		FText GetOverrideText() const { return OverrideText; }

		const FSlateBrush* OverrideIcon;
		const FSlateBrush* GetOverrideIcon() const { return OverrideIcon; }

		FDragDropPayload Payload;
	};

	TSharedPtr<FDragDropOperation> CreateDragDropOperation(const TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& InListItems);
}
