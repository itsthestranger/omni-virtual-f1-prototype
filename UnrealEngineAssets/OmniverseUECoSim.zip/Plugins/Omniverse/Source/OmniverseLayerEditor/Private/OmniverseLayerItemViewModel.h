// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"
#include "EditorUndoClient.h"
#include "OmniverseLayerDataSource.h"
#include "IOmniverseTreeItemViewModel.h"

class FOmniversePrimItemViewModel;
class FOmniverseLayerItemCollectionViewModel;
class FOmniverseLayerItemViewModel : public IOmniverseTreeItemViewModel
{
public:
	OMNIVERSE_TREE_ITEM_VIEW_MODEL_TYPE(FOmniverseLayerItemViewModel, IOmniverseTreeItemViewModel)

	virtual ~FOmniverseLayerItemViewModel();

	static TSharedRef<FOmniverseLayerItemViewModel> Create(FOmniverseLayerItemCollectionViewModel* CollectionViewModel, UOmniverseLayer* InLayer,
		const TSharedRef<FOmniverseTreeSharedData>& InSharedData)
	{
		TSharedRef<FOmniverseLayerItemViewModel> NewLayer(new FOmniverseLayerItemViewModel(CollectionViewModel, InLayer,
			InSharedData));
		NewLayer->Initialize();

		return NewLayer;
	}

	DECLARE_EVENT(FOmniverseLayerItemViewModel, FOnLayerVisibilityChanged);
	FOnLayerVisibilityChanged& OnLayerVisibilityChanged() { return LayerVisibilityChanged; }

public:
	virtual FOmniverseTreeItemID GetID() const override;

	virtual FString GetDisplayString() const override;

	virtual FText GetDisplayText() const override;

	virtual FText GetToolTipText() const override;

	virtual FName GetDisplayName() const override;

	virtual int32 GetTypeSortPriority() const override;

	virtual bool CanBeMoved() const override;

	virtual void SetVisible(bool Visibility) override;

	virtual bool IsVisible() const override;

	virtual bool CanEdit() const override;

	virtual void ToggleVisibility() override;

	virtual TSharedRef<ITableRow> GenerateRowWidget(const TSharedRef<STableViewBase>& OwnerTable,
		const TAttribute<FText>& InHighlightText);

	virtual TSharedPtr<SWidget> ConstructContextMenu() const;

	virtual TSharedRef<FUICommandList> GetCommandList() const;

	void MoveTo(UOmniverseLayer* InTargetLayer) const;

	void SetDataSource(UOmniverseLayer* InLayer);

	void SetPrimDataSource(UOmniversePrim* InPrim);

	void Lock();

	void Unlock();

	bool IsLocked() const;

	UOmniverseLayer* GetDataSource() const;

	void Register(TSharedPtr<FOmniversePrimItemViewModel> PrimViewModel);
	void Unregister(TSharedPtr<FOmniversePrimItemViewModel> PrimViewModel);

private:
	FOmniverseLayerItemViewModel(FOmniverseLayerItemCollectionViewModel* CollectionViewModel, UOmniverseLayer* InLayer,
		const TSharedRef<FOmniverseTreeSharedData>& InSharedData);

	void Initialize();

	void BindCommands();

	void UpdateDisplayList();

	void SortFilteredLayers();

	void ReloadLayer_Executed();

	bool ReloadLayer_CanExecute() const;

	void SaveLayer_Executed();

	bool SaveLayer_CanExecute() const;

	void DeleteLayer_Executed();

	bool DeleteLayer_CanExecute() const;

	void AddSelectionToLayer_Executed();

	bool AddSelectionToLayer_CanExecute() const;

	//void SelectObjectsInLayer_Executed();

	//bool SelectObjectsInLayer_CanExecute() const;

	void Deactivate_Executed();

	bool Deactivate_CanExecute() const;

	void Activate_Executed();

	bool Activate_CanExecute() const;

	void MergeLayers_Executed();

	bool MergeLayers_CanExecute() const;

	void MergeVisible_Executed();

	bool MergeVisible_CanExecute() const;

	void MergeDown_Executed();

	bool MergeDown_CanExecute() const;

	void SetAuthoringLayer_Executed();

	bool SetAuthoringLayer_CanExecute() const;


private:
	FOmniverseLayerItemCollectionViewModel* CollectionViewModel;

	UOmniverseLayer* Layer;

	FOmniverseTreeItemID ID;

	const TSharedRef<FUICommandList> CommandList;

	TMap<FString, TSharedPtr<FOmniversePrimItemViewModel>> AllPrimsChildViewModels;
	TMap<FString, TSharedPtr<FOmniverseLayerItemViewModel>> AllLayersChildViewModels;

	TMap<UOmniversePrim*, TSharedPtr<FOmniversePrimItemViewModel>> AllPrimViewModels;

	FOnLayerVisibilityChanged LayerVisibilityChanged;
};
