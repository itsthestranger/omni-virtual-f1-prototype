// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SOmniverseTreeLayerItemRow.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Views/SListView.h"
#include "EditorStyleSet.h"
#include "DragAndDrop/ActorDragDropGraphEdOp.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "SOmniverseLayersTreeView.h"
#include "SOmniverseDragAndDrop.h"
#include "SOmniverseLayerBrowserStyle.h"
#include "OmniverseNotificationHelper.h"

struct SOmniverseLayerItemLabel : public SCompoundWidget
{
	SLATE_BEGIN_ARGS(SOmniverseLayerItemLabel) {}
	SLATE_END_ARGS()

	~SOmniverseLayerItemLabel()
	{
	}

	void Construct(const FArguments& InArgs, const TSharedPtr<FOmniverseLayerItemViewModel>& LayerItem,
		const SOmniverseTreeLayerItemRow& InRow,
		const TAttribute<FText>& InHighlightText)
	{
		HighlightText = InHighlightText;
		TreeItemPtr = LayerItem;
		if (TreeItemPtr.IsValid())
		{
			FString ItemToolTip = TreeItemPtr.Pin()->GetDataSource()->FullPath;
			ChildSlot
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(0.0f, 0.0f, 6.0f, 0.0f)
				[
					SNew(SBox)
					.WidthOverride(16.0f)
					.HeightOverride(16.0f)
					[
						SNew(SImage)
						.Image(FAppStyle::GetBrush(TEXT("Layer.Icon16x")))
					.ColorAndOpacity(FSlateColor::UseForeground())
					]
				]
				+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				.VAlign(VAlign_Center)
				[
					SAssignNew(InlineTextBlock, SInlineEditableTextBlock)
					.Font(FAppStyle::GetFontStyle("LayersView.LayerNameFont"))
					.Text(TreeItemPtr.Pin().Get(), &FOmniverseLayerItemViewModel::GetDisplayText)
					.ColorAndOpacity(this, &SOmniverseLayerItemLabel::GetColorAndOpacity)
					.HighlightText(HighlightText)
					.ToolTipText(FText::FromString(ItemToolTip))
					.IsSelected(FIsSelected::CreateSP(&InRow, &SOmniverseTreeLayerItemRow::IsSelectedExclusively))
					.IsReadOnly(true)
				]
			];
		}
	}

private:
	FSlateColor GetColorAndOpacity() const
	{
		if (!FSlateApplication::Get().IsDragDropping())
		{
			if (TreeItemPtr.Pin()->IsVisible())
				return FSlateColor::UseForeground();
			else
				return FLinearColor(0.30f, 0.30f, 0.30f);
		}

		bool bCanAcceptDrop = false;
		TSharedPtr<FDragDropOperation> DragDropOp = FSlateApplication::Get().GetDragDroppingContent();

		if (DragDropOp.IsValid() && DragDropOp->IsOfType<OmniverseDragAndDrop::FLayerDragDropOp>())
			bCanAcceptDrop = true;

		return (bCanAcceptDrop) ? FSlateColor::UseForeground() : FLinearColor(0.30f, 0.30f, 0.30f);
	}

private:
	TWeakPtr<FOmniverseLayerItemViewModel> TreeItemPtr;
	TAttribute<FText> HighlightText;

	TSharedPtr<SInlineEditableTextBlock> InlineTextBlock;
};

void SOmniverseTreeLayerItemRow::Construct(const FArguments& InArgs, const TSharedRef<IOmniverseTreeItemViewModel>& InViewModel,
	const TSharedRef<STableViewBase>& InOwnerTableView)
{
	ViewModel = StaticCastSharedRef<FOmniverseLayerItemViewModel>(InViewModel);
	UpdateVisibility();
	ViewModel->OnLayerVisibilityChanged().AddSP(this, &SOmniverseTreeLayerItemRow::UpdateVisibility);

	HighlightText = InArgs._HighlightText;
	WeakTreeView = StaticCastSharedRef<SOmniverseLayersTreeView>(InOwnerTableView);

	auto Args = FSuperRowType::FArguments()
		.Style(&FAppStyle::Get().GetWidgetStyle<FTableRowStyle>("SceneOutliner.TableViewRow"));
	Args.OnDragDetected_Static(SOmniverseLayersTreeView::OnCustomizedDragDetected, WeakTreeView);
	SMultiColumnTableRow<TSharedPtr<IOmniverseTreeItemViewModel>>::Construct(Args, InOwnerTableView);
}

SOmniverseTreeLayerItemRow::~SOmniverseTreeLayerItemRow()
{
}

TSharedRef<SWidget> SOmniverseTreeLayerItemRow::GenerateWidgetForColumn(const FName& ColumnID)
{
	TSharedRef<SWidget> TableRowContent = SNullWidget::NullWidget;
	if (ColumnID == OmniverseLayersView::ColumnID_LayerLabel)
	{
		TableRowContent = SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(6, 0, 2, 0)
			[
				SNew(SExpanderArrow, SharedThis(this)).IndentAmount(12)
			]
			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			[
				SNew(SOmniverseLayerItemLabel, ViewModel, *this, HighlightText)
			];
	}
	else if (ColumnID == OmniverseLayersView::ColumnID_Visibility)
	{
		// Only Sub Layers in root layer can toggle visibility
		if (!ViewModel->GetDataSource()->bRootLayer && ViewModel->GetDataSource()->RootLayerType == ERootLayerType::Root)
		{

			TableRowContent =
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.MaxWidth(24)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				[
					SAssignNew(VisibilityButton, SButton)
					.ContentPadding(0)
					.ButtonStyle(FAppStyle::Get(), "NoBorder")
					.OnClicked(this, &SOmniverseTreeLayerItemRow::OnToggleVisibility)
					.ToolTipText(FText::FromString("Toggle Layer Local Visibility"))
					.IsEnabled_Raw(this, &SOmniverseTreeLayerItemRow::IsLocalVisibilityEnabled)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Content()
					[
						SNew(SImage)
						.Image(this, &SOmniverseTreeLayerItemRow::GetLocalVisibilityBrushForLayer)
					]
				]
				+ SHorizontalBox::Slot()
				.MaxWidth(24)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				[
					SAssignNew(VisibilityButton, SButton)
					.ContentPadding(0)
					.ButtonStyle(FAppStyle::Get(), "NoBorder")
					.OnClicked(this, &SOmniverseTreeLayerItemRow::OnToggleVisibility)
					.ToolTipText(FText::FromString("Toggle Layer Global Visibility"))
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.IsEnabled_Raw(this, &SOmniverseTreeLayerItemRow::IsGlobalVisibilityEnabled)
					.Content()
					[
						SNew(SImage)
						.Image(this, &SOmniverseTreeLayerItemRow::GetGlobalVisibilityBrushForLayer)
					]
				]
				+ SHorizontalBox::Slot()
				.MaxWidth(24)
				.HAlign(HAlign_Center)
				.VAlign(VAlign_Center)
				[
					SAssignNew(LockButton, SButton)
					.ContentPadding(0)
					.ButtonStyle(FAppStyle::Get(), "NoBorder")
					.OnClicked(this, &SOmniverseTreeLayerItemRow::OnLockChanged)
					.ToolTipText(this, &SOmniverseTreeLayerItemRow::GetToolTipTextForLockButton)
					.HAlign(HAlign_Center)
					.Content()
					[
						SNew(SImage)
						.Image(this, &SOmniverseTreeLayerItemRow::GetLockBrushForLayer)
					]
				];
		}
	}

	return TableRowContent;
}

void SOmniverseTreeLayerItemRow::OnDragLeave(const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<OmniverseDragAndDrop::FLayerDragDropOp> DragActorOp =
		DragDropEvent.GetOperationAs<OmniverseDragAndDrop::FLayerDragDropOp>();
	if (DragActorOp.IsValid())
		DragActorOp->ResetTooltip();
}

FReply SOmniverseTreeLayerItemRow::OnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<OmniverseDragAndDrop::FLayerDragDropOp> DragActorOp =
		DragDropEvent.GetOperationAs<OmniverseDragAndDrop::FLayerDragDropOp>();
	if (!DragActorOp.IsValid() || DragActorOp->GetPayLoad().Layers.Num() != 1)
		return FReply::Unhandled();
	else
	{
		auto DraggedItems = DragActorOp->GetPayLoad().Layers;
		if (ViewModel->GetDataSource()->bRootLayer)
			DragActorOp->SetTooltip(FText::FromString(TEXT("Cannot move to root layer position")),
				FAppStyle::GetBrush(TEXT("Graph.ConnectorFeedback.Error")));
		else if (DraggedItems[0].IsValid() && DraggedItems[0].Pin()->CanBeMoved())
			DragActorOp->SetTooltip(FText::FromString(TEXT("Move layer to this position")),
				FAppStyle::GetBrush(TEXT("Graph.ConnectorFeedback.OK")));
		else
			DragActorOp->SetTooltip(FText::FromString(TEXT("Root layer cannot be moved")),
				FAppStyle::GetBrush(TEXT("Graph.ConnectorFeedback.Error")));

		return FReply::Handled();
	}
}

FReply SOmniverseTreeLayerItemRow::OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<OmniverseDragAndDrop::FLayerDragDropOp> DragActorOp =
		DragDropEvent.GetOperationAs<OmniverseDragAndDrop::FLayerDragDropOp>();
	if (!DragActorOp.IsValid() || DragActorOp->GetPayLoad().Layers.Num() != 1)
		return FReply::Unhandled();
	else
	{
		auto DraggedItems = DragActorOp->GetPayLoad().Layers;
		if (DraggedItems[0].IsValid() && DraggedItems[0].Pin()->CanBeMoved() && !ViewModel->GetDataSource()->bRootLayer)
			DraggedItems[0].Pin()->MoveTo(ViewModel->GetDataSource());

		return FReply::Handled();
	}
}

FReply SOmniverseTreeLayerItemRow::OnLockChanged()
{
	if (ViewModel->IsLocked())
	{
		ViewModel->Unlock();
	}
	else
	{
		ViewModel->Lock();
	}

	return FReply::Handled();
}

const FSlateBrush * SOmniverseTreeLayerItemRow::GetGlobalVisibilityBrushForLayer() const
{
	if (bGlobalVisibility)
	{
		return IsHovered() ? FAppStyle::GetBrush("Level.VisibleHighlightIcon16x") :
			FAppStyle::GetBrush("Level.VisibleIcon16x");
	}
	else
	{
		return IsHovered() ? FAppStyle::GetBrush("Level.NotVisibleHighlightIcon16x") :
			FAppStyle::GetBrush("Level.NotVisibleIcon16x");
	}
}

const FSlateBrush * SOmniverseTreeLayerItemRow::GetLockBrushForLayer() const
{
	auto DataSource = ViewModel->GetDataSource();
	if (DataSource->bLocked)
	{
		return FOmniverseLayerBrowserStyle::Get()->GetBrush(
			TEXT("OmniverseLayerBrowser.State.MyLocked"));
	}
	else
	{
		return FOmniverseLayerBrowserStyle::Get()->GetBrush(
			TEXT("OmniverseLayerBrowser.State.Unlocked"));
	}
}

FText SOmniverseTreeLayerItemRow::GetToolTipTextForLockButton() const
{
	auto DataSource = ViewModel->GetDataSource();
	if (DataSource->bAuthor)
	{
		return FText::FromString("Cannot lock current Authoring Layer");
	}

	if (DataSource->bLocked)
	{
		return FText::FromString("Unlock Layer");
	}
	else
	{
		return FText::FromString("Lock Layer");
	}
}

const FSlateBrush* SOmniverseTreeLayerItemRow::GetLocalVisibilityBrushForLayer() const
{
	if (bLocalVisibility)
	{
		return IsHovered() ? FAppStyle::GetBrush("Level.VisibleHighlightIcon16x") :
			FAppStyle::GetBrush("Level.VisibleIcon16x");
	}
	else
	{
		return IsHovered() ? FAppStyle::GetBrush("Level.NotVisibleHighlightIcon16x") :
			FAppStyle::GetBrush("Level.NotVisibleIcon16x");
	}
}
