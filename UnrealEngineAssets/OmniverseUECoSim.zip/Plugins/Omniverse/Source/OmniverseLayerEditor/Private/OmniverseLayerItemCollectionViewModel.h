// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/UICommandList.h"
#include "EditorUndoClient.h"
#include "OmniverseLayerDataSource.h"
#include "IOmniverseTreeItemViewModel.h"

class FOmniverseLayerItemViewModel;
class FOmniverseLayerItemCollectionViewModel : public TSharedFromThis<FOmniverseLayerItemCollectionViewModel>, public FEditorUndoClient
{
public:
	virtual ~FOmniverseLayerItemCollectionViewModel();

	static TSharedPtr<FOmniverseLayerItemCollectionViewModel> Create(const TSharedRef<FOmniverseTreeSharedData>& InSharedData)
	{
		TSharedPtr<FOmniverseLayerItemCollectionViewModel> LayersView(new FOmniverseLayerItemCollectionViewModel(InSharedData));
		LayersView->Initialize();

		return LayersView;
	}

public:
	TSharedRef<FOmniverseTreeSharedData> GetSharedData() const
	{
		return SharedData;
	}

	TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& GetRootItems();

	TSharedPtr<FOmniverseLayerItemViewModel> GetSelectedLayer() const;

	void SetSelectedLayer(const TSharedPtr<FOmniverseLayerItemViewModel>& InLayer);

	void SetAuthoredLayer(const TSharedPtr<FOmniverseLayerItemViewModel>& InLayer);

	void DeleteSelectedLayer();

	void Register(TSharedPtr<FOmniverseLayerItemViewModel> LayerViewModel);
	void Unregister(TSharedPtr<FOmniverseLayerItemViewModel> LayerViewModel);

	DECLARE_EVENT(FOmniverseLayerItemCollectionViewModel, FOnLayersChanged);
	FOnLayersChanged& OnLayersChanged() { return LayersChanged; }

	DECLARE_EVENT(FOmniverseLayerItemCollectionViewModel, FOnSelectedLayerChanged);
	FOnSelectedLayerChanged& OnSelectedLayerChanged() { return SelectedLayerChanged; }

	DECLARE_EVENT(FOmniverseLayerItemCollectionViewModel, FOnRenameRequested);
	FOnRenameRequested& OnRenameRequested() { return RenameRequested; }

	DECLARE_EVENT(FOmniverseLayerItemCollectionViewModel, FOnFilterLayerChanged);
	FOnFilterLayerChanged& OnFilterLayerChanged() { return FilterLayerChanged; }


private:
	FOmniverseLayerItemCollectionViewModel(const TSharedRef<FOmniverseTreeSharedData>& InSharedData);

	void Initialize();

	void OnFilterChanged();

	void OnLayersEventReceived(ELayersEventType EventType, UOmniverseLayer* InLayer, UOmniversePrim* InPrim);

	void OnPreLayerDataSourceChanged();

	void OnPostLayerDataSourceChanged();

	void OnResetLayers();

	void OnChangeLayer(UOmniverseLayer* InLayer);

	void OnChangePrim(UOmniverseLayer* InLayer, UOmniversePrim* InPrim);

	void DestructivelyPurgeInvalidViewModels(TArray<UOmniverseLayer*>& InLayers);

	void RefreshFilteredLayers();

	void SortFilteredLayers();

	FName GenerateUniqueLayerName() const;

private:
	/** All layers shown in the LayersView */
	TArray<TSharedPtr<IOmniverseTreeItemViewModel>> FilteredLayerViewModels;

	/** All layers managed by the LayersView */
	TArray<TSharedPtr<FOmniverseLayerItemViewModel>> RootLayerViewModels;

	/** Currently selected Layer */
	TSharedPtr<FOmniverseLayerItemViewModel> SelectedLayer;

	/**	Broadcasts whenever one or more layers changes */
	FOnLayersChanged LayersChanged;

	/**	Broadcasts whenever Selected layer changed */
	FOnSelectedLayerChanged SelectedLayerChanged;

	/**	Broadcasts whenever a rename is requested on the selected layers */
	FOnRenameRequested RenameRequested;

	/**	Broadcasts whenever filtered layer changed */
	FOnFilterLayerChanged FilterLayerChanged;

	TSharedRef<FOmniverseTreeSharedData> SharedData;

	TMap<UOmniverseLayer*, TArray<TSharedPtr<FOmniverseLayerItemViewModel>>> AllLayerViewModels;

	bool bSelectionInitialized;
};

