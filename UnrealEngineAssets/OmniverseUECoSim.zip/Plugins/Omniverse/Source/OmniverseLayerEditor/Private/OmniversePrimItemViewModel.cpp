// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniversePrimItemViewModel.h"
#include "Editor.h"
#include "Editor/EditorEngine.h"
#include "ScopedTransaction.h"
#include "Misc/DelegateFilter.h"
#include "Framework/MultiBox/MultiBoxExtender.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Framework/Commands/UICommandList.h"
#include "SOmniverseTreePrimItemRow.h"
#include "OmniverseLayerBrowserCommands.h"
#include "OmniverseStageActor.h"
#include "OmniversePxr.h"
#include "OmniverseLayerItemViewModel.h"

FOmniversePrimItemViewModel::FOmniversePrimItemViewModel(FOmniverseLayerItemViewModel* InLayerViewModel, UOmniverseLayer* InLayer, UOmniversePrim* InPrim, const TSharedRef<FOmniverseTreeSharedData>& InSharedData)
	: IOmniverseTreeItemViewModel(InSharedData)
	, LayerViewModel(InLayerViewModel)
	, Layer(InLayer)
	, Prim(InPrim)
	, ID(InPrim)
	, CommandList(MakeShareable(new FUICommandList))
{
}

void FOmniversePrimItemViewModel::Initialize()
{
	BindCommands();
	SetDataSource(Layer, Prim);
}

void FOmniversePrimItemViewModel::BindCommands()
{
	const FOmniverseLayerBrowserCommands& Commands = FOmniverseLayerBrowserCommands::Get();
	FUICommandList& ActionList = *CommandList;

	ActionList.MapAction(Commands.SelectSingleActor,
		FExecuteAction::CreateSP(this, &FOmniversePrimItemViewModel::SelectSingleActor_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniversePrimItemViewModel::SelectSingleActor_CanExecute));

	ActionList.MapAction(Commands.DeletePrim,
		FExecuteAction::CreateSP(this, &FOmniversePrimItemViewModel::DeleteSinglePrim_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniversePrimItemViewModel::DeleteSinglePrim_CanExecute));

	ActionList.MapAction(Commands.DeleteDelta,
		FExecuteAction::CreateSP(this, &FOmniversePrimItemViewModel::DeleteSinglePrim_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniversePrimItemViewModel::DeleteSinglePrim_CanExecute));
}

void FOmniversePrimItemViewModel::SelectSingleActor_Executed()
{
	SharedData->GetLayerDataSource()->SelectSingleActor(Prim);
}

bool FOmniversePrimItemViewModel::SelectSingleActor_CanExecute() const
{
	return SharedData->GetLayerDataSource() && IsVisible();
}

bool FOmniversePrimItemViewModel::DeleteSinglePrim_CanExecute() const
{
	return CanEdit() && SharedData->GetLayerDataSource() && IsVisible();
}

void FOmniversePrimItemViewModel::DeleteSinglePrim_Executed() const
{
	if (SharedData->GetLayerDataSource())
	{
		SharedData->GetLayerDataSource()->DeleteSinglePrim(Prim);
	}
}

FOmniverseTreeItemID FOmniversePrimItemViewModel::GetID() const
{
	return ID;
}

FString FOmniversePrimItemViewModel::GetDisplayString() const
{
	return Prim->Name;
}

FText FOmniversePrimItemViewModel::GetDisplayText() const
{
	return FText::FromString(Prim->Name);
}

FText FOmniversePrimItemViewModel::GetToolTipText() const
{
	return FText::FromString(Prim->FullPath);
}

FName FOmniversePrimItemViewModel::GetDisplayName() const
{
	return FName(*Prim->Name);
}

int32 FOmniversePrimItemViewModel::GetTypeSortPriority() const
{
	return int32();
}

FOmniversePrimItemViewModel::~FOmniversePrimItemViewModel()
{
	AllChildViewModels.Reset();
	Layer = nullptr;
	Prim = nullptr;
	LayerViewModel = nullptr;
}

bool FOmniversePrimItemViewModel::IsVisible() const
{
	if (GetParent())
		return GetParent()->IsVisible();

	return true;
}

void FOmniversePrimItemViewModel::ToggleVisibility()
{
	if (GetParent())
		GetParent()->ToggleVisibility();
}

TSharedRef<ITableRow> FOmniversePrimItemViewModel::GenerateRowWidget(const TSharedRef<STableViewBase>& OwnerTable,
	const TAttribute<FText>& InHighlightText)
{
	return SNew(SOmniverseTreePrimItemRow, StaticCastSharedRef<FOmniversePrimItemViewModel>(AsShared()), OwnerTable)
		.HighlightText(InHighlightText);
}

TSharedPtr<SWidget> FOmniversePrimItemViewModel::ConstructContextMenu() const
{
	const FOmniverseLayerBrowserCommands& Commands = FOmniverseLayerBrowserCommands::Get();
	TArray<TSharedPtr<FExtender>> Extenders;
	TSharedPtr<FExtender> MenuExtender = FExtender::Combine(Extenders);
	FMenuBuilder MenuBuilder(true, CommandList, MenuExtender);
	{
		//MenuBuilder.BeginSection("OmniversePrimBasic");
		//{
		//	MenuBuilder.AddMenuEntry(Commands.CopyPrim);
		//	MenuBuilder.AddMenuEntry(Commands.PastePrim);
		//}
		//MenuBuilder.EndSection();

		MenuBuilder.BeginSection("OmniversePrimDelete");
		{
			if (Prim->bOver)
			{
				MenuBuilder.AddMenuEntry(Commands.DeleteDelta);
			}
			else
			{
				MenuBuilder.AddMenuEntry(Commands.DeletePrim);
			}
		}
		MenuBuilder.EndSection();
	}

	return MenuBuilder.MakeWidget();
}

TSharedRef<FUICommandList> FOmniversePrimItemViewModel::GetCommandList() const
{
	return CommandList;
}

bool FOmniversePrimItemViewModel::CanBeMoved() const
{
	return false;
}

bool FOmniversePrimItemViewModel::CanEdit() const
{
	if (GetParent())
	{
		return GetParent()->CanEdit();
	}

	return false;
}

void FOmniversePrimItemViewModel::SetVisible(bool Visibility)
{
	if (GetParent())
		GetParent()->SetVisible(Visibility);
}

void FOmniversePrimItemViewModel::SetDataSource(UOmniverseLayer* InLayer, UOmniversePrim* InPrim)
{
	Layer = InLayer;
	Prim = InPrim;

	if (Prim->Children.Num() == 0)
	{
		for (auto Pair : AllChildViewModels)
		{
			LayerViewModel->Unregister(Pair.Value);
		}
		AllChildViewModels.Reset();
	}
	else
	{
		auto LayerDataSource = SharedData->GetLayerDataSource();
		TMap<FString, TObjectPtr<UOmniversePrim>> Prims = Prim->Children;
		TArray<FString> ToRemove;
		for (auto ViewModel : AllChildViewModels)
		{
			if (Prims.Find(ViewModel.Key))
			{
				auto PrimData = Prims[ViewModel.Key];
				Prims.Remove(ViewModel.Key);
				ViewModel.Value->SetDataSource(InLayer, PrimData);
			}
			else
			{
				ToRemove.Add(ViewModel.Key);
			}
		}
		for (auto Key : ToRemove)
		{
			LayerViewModel->Unregister(AllChildViewModels[Key]);
			AllChildViewModels.Remove(Key);
		}

		for (auto Pair : Prims)
		{
			if (Pair.Value)
			{
				TSharedPtr<FOmniversePrimItemViewModel> PrimViewModel = FOmniversePrimItemViewModel::Create(LayerViewModel, Layer, Pair.Value, SharedData);
				LayerViewModel->Register(PrimViewModel);
				AllChildViewModels.Add(Pair.Key, PrimViewModel);
			}
		}
	}

	UpdateDisplayList();
}

UOmniversePrim* FOmniversePrimItemViewModel::GetDataSource() const
{
	return Prim;
}

void FOmniversePrimItemViewModel::UpdateDisplayList()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (!LayerDataSource)
	{
		return;
	}

	TArray<TSharedPtr<FOmniversePrimItemViewModel>> DisplayChildViewModels;
	for (auto PrimViewModelPair : AllChildViewModels)
	{
		DisplayChildViewModels.Add(PrimViewModelPair.Value);
	}

	EmptyAllChild();
	for (auto ChildViewModel : DisplayChildViewModels)
	{
		AddChild(ChildViewModel);
	}
}