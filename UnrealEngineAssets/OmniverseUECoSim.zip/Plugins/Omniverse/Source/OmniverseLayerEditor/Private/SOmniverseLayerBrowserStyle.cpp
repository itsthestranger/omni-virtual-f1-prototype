// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SOmniverseLayerBrowserStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Styling/SlateTypes.h"
#include "Styling/CoreStyle.h"
#include "EditorStyleSet.h"
#include "Interfaces/IPluginManager.h"
#include "SlateOptMacros.h"
#include "Misc/Paths.h"

#define IMAGE_PLUGIN_BRUSH(RelativePath, ...) FSlateImageBrush(FOmniverseLayerBrowserStyle::InContent(RelativePath, ".png"), __VA_ARGS__)
#define IMAGE_BRUSH(RelativePath, ...) FSlateImageBrush(StyleSet->RootToContentDir(RelativePath, TEXT(".png")), __VA_ARGS__)

TSharedPtr< FSlateStyleSet> FOmniverseLayerBrowserStyle::StyleSet = nullptr;
TSharedPtr<class ISlateStyle> FOmniverseLayerBrowserStyle::Get() { return StyleSet; }

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION

void FOmniverseLayerBrowserStyle::Initialize()
{
	// Const icon sizes
	const FVector2D Icon16x16(16.0f, 16.0f);
	const FVector2D Icon64x64(64.0f, 64.0f);
	const FVector2D Icon38x24(38.0f, 24.0f);

	// Only register once
	if (StyleSet.IsValid())
	{
		return;
	}

	StyleSet = MakeShareable(new FSlateStyleSet(GetStyleSetName()));
	StyleSet->SetContentRoot(FPaths::EngineContentDir() / TEXT("Editor/Slate"));
	StyleSet->SetCoreContentRoot(FPaths::EngineContentDir() / TEXT("Slate"));

	const FTextBlockStyle& NormalText = FAppStyle::Get().GetWidgetStyle<FTextBlockStyle>("NormalText");

	{
		StyleSet->Set("OmniverseLayerBrowser.PrimLabel.Small", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/Prim_16x"), Icon16x16));
		StyleSet->Set("OmniverseLayerBrowser.PrimLabel.Large", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/Prim_64x"), Icon64x64));

		StyleSet->Set("OmniverseLayerBrowser.DeltaPrim.Small", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/DeltaPrim_16x"), Icon16x16));
		StyleSet->Set("OmniverseLayerBrowser.ReferencePrim.Small", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/ReferencePrim_16x"), Icon16x16));
		StyleSet->Set("OmniverseLayerBrowser.PayloadPrim.Small", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/PayloadPrim_16x"), Icon16x16));

		StyleSet->Set("OmniverseLayerBrowser.State.Local", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/MuteLocal"), Icon38x24));
		StyleSet->Set("OmniverseLayerBrowser.State.Global", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/MuteGlobal"), Icon38x24));

		StyleSet->Set("OmniverseLayerBrowser.State.Unlocked", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/Unlocked"), Icon16x16));
		StyleSet->Set("OmniverseLayerBrowser.State.MyLocked", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/MyLocked"), Icon16x16));
		StyleSet->Set("OmniverseLayerBrowser.State.OtherLocked", new IMAGE_PLUGIN_BRUSH(TEXT("Editor/Icons/OtherLocked"), Icon16x16));
	}

	FSlateStyleRegistry::RegisterSlateStyle(*StyleSet);
}

void FOmniverseLayerBrowserStyle::Shutdown()
{
	if (StyleSet.IsValid())
	{
		FSlateStyleRegistry::UnRegisterSlateStyle(*StyleSet.Get());
		ensure(StyleSet.IsUnique());
		StyleSet.Reset();
	}
}

FName FOmniverseLayerBrowserStyle::GetStyleSetName()
{
	static FName PaperStyleName(TEXT("OmniverseLayersStyle"));
	return PaperStyleName;
}

FString FOmniverseLayerBrowserStyle::InContent(const FString & RelativePath, const ANSICHAR * Extension)
{
	static FString ContentDir = IPluginManager::Get().FindPlugin(TEXT("Omniverse"))->GetContentDir();
	return (ContentDir / RelativePath) + Extension;
}

END_SLATE_FUNCTION_BUILD_OPTIMIZATION

#undef IMAGE_PLUGIN_BRUSH
#undef IMAGE_BRUSH
