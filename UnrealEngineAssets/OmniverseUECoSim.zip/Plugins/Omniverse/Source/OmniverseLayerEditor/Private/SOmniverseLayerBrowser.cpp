// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SOmniverseLayerBrowser.h"
#include "Modules/ModuleManager.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Application/IInputProcessor.h"
#include "Editor.h"
#include "Editor/LevelEditor/Public/LevelEditor.h"
#include "IAssetViewport.h"
#include "Framework/MultiBox/MultiBoxExtender.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "OmniverseLayerDataSource.h"
#include "OmniverseLayerItemViewModel.h"
#include "OmniversePrimItemViewModel.h"
#include "SOmniverseLayerBrowserStyle.h"
#include "OmniverseLayerBrowserCommands.h"

#include "Widgets/Input/SSearchBox.h"

SOmniverseLayerBrowser::~SOmniverseLayerBrowser()
{
	LayerCollectionViewModel->OnLayersChanged().RemoveAll(this);
	LayerCollectionViewModel->OnRenameRequested().RemoveAll(this);
	IOmniverseLayerDataSource::OnLayerDataSourceChanged().RemoveAll(this);
	FSlateApplication::Get().UnregisterInputPreProcessor(InputProcessor);
}

void SOmniverseLayerBrowser::Construct(const FArguments& InArgs)
{
	auto LayerDataSource = IOmniverseLayerDataSource::GetCurrentLayerDataSource();
	SharedData = MakeShareable(new FOmniverseTreeSharedData);
	SharedData->SetLayerDataSource(LayerDataSource);
	IOmniverseLayerDataSource::OnLayerDataSourceChanged().AddSP(this, &SOmniverseLayerBrowser::OnLayerDataSourceChanged);
	SearchBoxLayerFilter = MakeShareable(new LayerTextFilter(LayerTextFilter::FItemToStringArray::CreateSP(this, &SOmniverseLayerBrowser::TransformLayerToString)));
	SharedData->AddFilter(SearchBoxLayerFilter.ToSharedRef());
	LayerCollectionViewModel = FOmniverseLayerItemCollectionViewModel::Create(SharedData.ToSharedRef());
	LayerCollectionViewModel->OnRenameRequested().AddSP(this, &SOmniverseLayerBrowser::OnRenameRequested);
	InputProcessor = SOmniverseInputProcessor::Create(this);
	FSlateApplication::Get().RegisterInputPreProcessor(InputProcessor);

	//////////////////////////////////////////////////////////////////////////
	//	Layers View Section
	SAssignNew(LayersSection, SBorder)
		.Padding(5)
		.BorderImage(FAppStyle::GetBrush("NoBrush"))
		.Content()
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				.Padding(0, 0, 6, 0)
				[
					SAssignNew(SearchBoxPtr, SSearchBox)
					.ToolTipText(FText::FromString(TEXT("Type here to search")))
					.HintText(FText::FromString(TEXT("Search here")))
					.OnTextChanged(this, &SOmniverseLayerBrowser::OnFilterTextChanged)
				]
				+ SHorizontalBox::Slot()
				.HAlign(HAlign_Right)
				.Padding(0, 0, 6, 0)
				.AutoWidth()
				[
					SAssignNew(MutenessScopeSwitch, SCheckBox)
					.ToolTipText(FText::FromString(TEXT("Switch influence scope of muteness")))
					.IsChecked(this, &SOmniverseLayerBrowser::IsGlobalMutenessEnabled)
					.OnCheckStateChanged(this, &SOmniverseLayerBrowser::OnMutenessScopeChanged)
					.CheckedImage(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.State.Local")))
					.UncheckedImage(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.State.Global")))
					.CheckedHoveredImage(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.State.Local")))
					.UncheckedHoveredImage(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.State.Global")))
					.CheckedPressedImage(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.State.Local")))
					.UncheckedPressedImage(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.State.Global")))
				]
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0, 0, 0, 8)
			[
				SNew(SSeparator)
			]
			+ SVerticalBox::Slot()
			.FillHeight(1.0f)
			[
				SAssignNew(LayersView, SOmniverseLayersView, LayerCollectionViewModel.ToSharedRef())
				.IsEnabled(FSlateApplication::Get().GetNormalExecutionAttribute())
				.ConstructContextMenu(FOnContextMenuOpening::CreateSP(this, &SOmniverseLayerBrowser::ConstructLayerContextMenu))
				.HighlightText(SearchBoxLayerFilter.Get(), &LayerTextFilter::GetRawFilterText)
			]
		];

	//////////////////////////////////////////////////////////////////////////
	//	Layer Contents Header
	SAssignNew(LayerContentsHeader, SBorder)
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Center)
		.BorderImage(FAppStyle::GetBrush("LayerBrowser.LayerContentsQuickbarBackground"))
		.Visibility(TAttribute< EVisibility >(this, &SOmniverseLayerBrowser::GetLayerContentsHeaderVisibility))
		.Content()
		[
			SNew(SHorizontalBox)
			//+ SHorizontalBox::Slot()
			//.VAlign(VAlign_Center)
			//.HAlign(HAlign_Center)
			//.AutoWidth()
			//.Padding(FMargin(0, 0, 2, 0))
			//[
			//	SAssignNew(NewLayerButton, SButton)
			//	.ContentPadding(FMargin(2, 0, 2, 0))
			//	.ButtonStyle(FEditorStyle::Get(), "LayerBrowserButton")
			//	.OnClicked(this, &SOmniverseLayerBrowser::CreateLayer)
			//	.ForegroundColor(FSlateColor::UseForeground())
			//	.VAlign(VAlign_Center)
			//	.HAlign(HAlign_Center)
			//	.ToolTipText(FText::FromString("Create new layer"))
			//	.Content()
			//	[
			//		SNew(SHorizontalBox)
			//		+ SHorizontalBox::Slot()
			//		.AutoWidth()
			//		.HAlign(HAlign_Center)
			//		.VAlign(VAlign_Center)
			//		.Padding(0, 1, 3, 1)
			//		[
			//			SNew(SImage)
			//			.Image(this, &SOmniverseLayerBrowser::GetNewLayerButtonImageBrush)
			//			.ColorAndOpacity(this, &SOmniverseLayerBrowser::GetInvertedForegroundIfHovered)
			//		]
			//	]
			//]
			+ SHorizontalBox::Slot()
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Center)
			.AutoWidth()
			.Padding(FMargin(0, 0, 2, 0))
			[
				SAssignNew(NewLayerButton, SButton)
				.ContentPadding(FMargin(2, 0, 2, 0))
				.ButtonStyle(FAppStyle::Get(), "LayerBrowserButton")
				.OnClicked(this, &SOmniverseLayerBrowser::DeleteLayer)
				.ForegroundColor(FSlateColor::UseForeground())
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Center)
				.ToolTipText(FText::FromString("Remove selected layer"))
				.Content()
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Padding(0, 1, 3, 1)
					[
						SNew(SImage)
						.Image(this, &SOmniverseLayerBrowser::GetDeleteButtonImageBrush)
						.ColorAndOpacity(this, &SOmniverseLayerBrowser::GetInvertedForegroundIfHovered)
					]
				]
			]
		];

	//////////////////////////////////////////////////////////////////////////
	//	Layer Browser
	ChildSlot
		[
			SAssignNew(ContentAreaBox, SVerticalBox)
		];

	SetupLayersMode();

	BindCommands();
}

void SOmniverseLayerBrowser::OnMouseLeave(const FPointerEvent& MouseEvent)
{
	SCompoundWidget::OnMouseLeave(MouseEvent);

	FPointerEventHandler Hanlder = FPointerEventHandler::CreateLambda([](const FGeometry&,
		const FPointerEvent&) -> FReply {
		return FReply::Handled();
	});
	if (FModuleManager::Get().IsModuleLoaded("LevelEditor"))
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
		auto ActiveViewport = LevelEditorModule.GetFirstActiveViewport();
		if (ActiveViewport && ActiveViewport->GetViewportWidget().IsValid())
		{
			ActiveViewport->AsWidget()->SetCursor(EMouseCursor::Custom);
			ActiveViewport->AsWidget()->SetOnMouseButtonDown(Hanlder);
		}
	}
}

void SOmniverseLayerBrowser::DeleteSelectedPrims()
{
	const auto& SelectedItems = LayersView->GetSelectedItems();
	for (auto SelectedItem : SelectedItems)
	{
		if (SelectedItem->IsOfType<FOmniversePrimItemViewModel>())
		{
			auto PrimItemViewModel = StaticCastSharedPtr<FOmniversePrimItemViewModel>(SelectedItem);
			if (PrimItemViewModel->CanEdit())
			{
				GetSharedData()->GetLayerDataSource()->DeleteSinglePrim(PrimItemViewModel->GetDataSource());
			}
		}
	}
}

FReply SOmniverseLayerBrowser::DeleteLayer()
{
	LayerCollectionViewModel->DeleteSelectedLayer();

	return FReply::Handled();
}

TSharedPtr<SWidget> SOmniverseLayerBrowser::ConstructLayerContextMenu()
{
	const auto& SelectedItems = LayersView->GetSelectedItems();
	if (SelectedItems.Num() > 1 && DeletePrims_CanExecute())
	{
		const FOmniverseLayerBrowserCommands& Commands = FOmniverseLayerBrowserCommands::Get();
		TArray<TSharedPtr<FExtender>> Extenders;
		TSharedPtr<FExtender> MenuExtender = FExtender::Combine(Extenders);
		FMenuBuilder MenuBuilder(true, CommandList, MenuExtender);
		{
			MenuBuilder.AddMenuEntry(Commands.DeletePrims);
		}

		return MenuBuilder.MakeWidget();
	}
	else if (SelectedItems.Num() == 1)
		return SelectedItems[0]->ConstructContextMenu();
	else if (GetSelectedLayer())
		return GetSelectedLayer()->ConstructContextMenu();

	return nullptr;
}

void SOmniverseLayerBrowser::BindCommands()
{
	CommandList = MakeShared<FUICommandList>();
	const FOmniverseLayerBrowserCommands& Commands = FOmniverseLayerBrowserCommands::Get();
	FUICommandList& ActionList = *CommandList;

	ActionList.MapAction(Commands.DeletePrims,
		FExecuteAction::CreateSP(this, &SOmniverseLayerBrowser::DeletePrims_Executed),
		FCanExecuteAction::CreateSP(this, &SOmniverseLayerBrowser::DeletePrims_CanExecute));
}

void SOmniverseLayerBrowser::DeletePrims_Executed()
{
	DeleteSelectedPrims();
}

bool SOmniverseLayerBrowser::DeletePrims_CanExecute() const
{
	bool bIncludePrim = false;
	const auto& SelectedItems = LayersView->GetSelectedItems();
	for (auto SelectedItem : SelectedItems)
	{
		if (SelectedItem->IsOfType<FOmniversePrimItemViewModel>() && SelectedItem->CanEdit())
		{
			bIncludePrim = true;
			break;
		}
	}

	return bIncludePrim;
}

void SOmniverseLayerBrowser::OnFilterTextChanged( const FText& InNewText )
{
	SearchBoxLayerFilter->SetRawFilterText(InNewText);
	SearchBoxPtr->SetError(SearchBoxLayerFilter->GetFilterErrorText());
	if (!InNewText.IsEmpty())
		LayersView->ExpandTreeItems();
}

void SOmniverseLayerBrowser::OnLayerDataSourceChanged(const TSharedPtr<IOmniverseLayerDataSource>& InLayerDataSource)
{
	SharedData->SetLayerDataSource(InLayerDataSource);
}

ECheckBoxState SOmniverseLayerBrowser::IsGlobalMutenessEnabled() const
{
	return SharedData->GetLayerDataSource() && SharedData->GetLayerDataSource()->IsMutenessGlobal() ? ECheckBoxState::Unchecked : ECheckBoxState::Checked;
}

void SOmniverseLayerBrowser::OnMutenessScopeChanged(ECheckBoxState InState)
{
	if (SharedData->GetLayerDataSource())
	{
		SharedData->GetLayerDataSource()->SwitchMutenessScope(InState != ECheckBoxState::Checked);
	}
}
