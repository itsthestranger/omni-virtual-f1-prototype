// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseLayerItemViewModel.h"
#include "Editor/EditorEngine.h"
#include "Engine/Selection.h"
#include "Editor.h"
#include "Framework/Commands/UICommandList.h"
#include "ScopedTransaction.h"
#include "Misc/DelegateFilter.h"
#include "Framework/MultiBox/MultiBoxExtender.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "SOmniverseTreeLayerItemRow.h"
#include "OmniversePrimItemViewModel.h"
#include "OmniverseLayerBrowserCommands.h"
#include "OmniverseStageActor.h"
#include "OmniversePxr.h"
#include "OmniverseLayerItemCollectionViewModel.h"

FOmniverseLayerItemViewModel::FOmniverseLayerItemViewModel(FOmniverseLayerItemCollectionViewModel* InCollectionViewModel,
	UOmniverseLayer* InLayer,
	const TSharedRef<FOmniverseTreeSharedData>& InSharedData)
	: IOmniverseTreeItemViewModel(InSharedData)
	, CollectionViewModel(InCollectionViewModel)
	, Layer(InLayer)
	, ID(InLayer)
	, CommandList(MakeShareable(new FUICommandList))
{
}

FOmniverseLayerItemViewModel::~FOmniverseLayerItemViewModel()
{
	AllPrimsChildViewModels.Reset();
	AllLayersChildViewModels.Reset();
	AllPrimViewModels.Reset();
	CollectionViewModel = nullptr;
	Layer = nullptr;
}

void FOmniverseLayerItemViewModel::Initialize()
{
	BindCommands();
	SetDataSource(Layer);
}

void FOmniverseLayerItemViewModel::UpdateDisplayList()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (!LayerDataSource)
	{
		return;
	}

	TArray<TSharedPtr<IOmniverseTreeItemViewModel>> DisplayChildViewModels;
	for (auto PrimViewModelPair : AllPrimsChildViewModels)
	{
		DisplayChildViewModels.Add(PrimViewModelPair.Value);
	}

	TArray<FString> LayerNames;
	AllLayersChildViewModels.GenerateKeyArray(LayerNames);

	LayerNames.Sort([&](auto& Left, auto& Right)
		{
			return LayerDataSource->GetSubLayerPriority(Layer->FullPath, Left) < LayerDataSource->GetSubLayerPriority(Layer->FullPath, Right);
		});

	for (auto LayerName : LayerNames)
	{
		DisplayChildViewModels.Add(*AllLayersChildViewModels.Find(LayerName));
	}

	EmptyAllChild();
	for (auto ChildViewModel : DisplayChildViewModels)
	{
		AddChild(ChildViewModel);
	}
}

void FOmniverseLayerItemViewModel::SortFilteredLayers()
{
	struct FComparePrims
	{
		FORCEINLINE bool operator()(const TSharedPtr<IOmniverseTreeItemViewModel>& Lhs, const TSharedPtr<IOmniverseTreeItemViewModel>& Rhs) const
		{
			const auto LhsPrim = StaticCastSharedPtr<FOmniversePrimItemViewModel>(Lhs);
			const auto RhsPrim = StaticCastSharedPtr<FOmniversePrimItemViewModel>(Rhs);
			return LhsPrim->GetDisplayString().Compare(RhsPrim->GetDisplayString(), ESearchCase::IgnoreCase) < 0;
		}
	};

	SortChildren(FComparePrims());
}


FOmniverseTreeItemID FOmniverseLayerItemViewModel::GetID() const
{
	return ID;
}

FString FOmniverseLayerItemViewModel::GetDisplayString() const
{
	if (!Layer->IsValid())
		return FString();

	FString Display = Layer->Name.ToString() + (Layer->bAuthor ? TEXT(" (Authoring Layer)") : TEXT(""));
	return Display;
}

FText FOmniverseLayerItemViewModel::GetDisplayText() const
{
	if (!Layer->IsValid())
		return FText();

	FString Display = Layer->Name.ToString() + (Layer->bAuthor ? TEXT(" (Authoring Layer)") : TEXT(""));
	return FText::FromName(*Display);
}

FText FOmniverseLayerItemViewModel::GetToolTipText() const
{
	if (!Layer->IsValid())
		return FText();

	return FText::FromString(Layer->FullPath);
}

FName FOmniverseLayerItemViewModel::GetDisplayName() const
{
	if (!Layer->IsValid())
		return FName();

	return Layer->Name;
}

int32 FOmniverseLayerItemViewModel::GetTypeSortPriority() const
{
	if (!Layer->IsValid())
		return INVALID_LAYER;

	return Layer->bRootLayer ? 0x7fffffff : 0;
}

bool FOmniverseLayerItemViewModel::IsVisible() const
{
	if (!Layer->IsValid())
		return false;

	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		if (LayerDataSource->IsMutenessGlobal())
		{
			return !Layer->bGlobalMuted;
		}
		else
		{
			return !Layer->bMuted;
		}
	}

	return false;
}

bool FOmniverseLayerItemViewModel::CanEdit() const
{
	if (!Layer->IsValid())
		return false;

	return !Layer->bLocked;
}

void FOmniverseLayerItemViewModel::ToggleVisibility()
{
	if (!Layer->IsValid())
		return;

	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		if (LayerDataSource->ToggleLayerVisibility(Layer))
		{
			OnLayerVisibilityChanged().Broadcast();
		}
	}
}

TSharedRef<ITableRow> FOmniverseLayerItemViewModel::GenerateRowWidget(const TSharedRef<STableViewBase>& OwnerTable,
	const TAttribute<FText>& InHighlightText)
{
	return SNew(SOmniverseTreeLayerItemRow, StaticCastSharedRef<FOmniverseLayerItemViewModel>(AsShared()), OwnerTable)
		.HighlightText(InHighlightText);
}

TSharedPtr<SWidget> FOmniverseLayerItemViewModel::ConstructContextMenu() const
{
	const FOmniverseLayerBrowserCommands& Commands = FOmniverseLayerBrowserCommands::Get();
	FMenuBuilder MenuBuilder(true, CommandList);
	{
		MenuBuilder.BeginSection("OmniverseLayerActions");
		{
			MenuBuilder.AddMenuEntry(Commands.SetAuthoringLayer);
			if (Layer->RootLayerType == ERootLayerType::Root)
			{
				MenuBuilder.AddMenuSeparator();
				MenuBuilder.AddMenuEntry(Commands.SaveLayer);
				MenuBuilder.AddMenuEntry(Commands.ReloadLayer);
				if (!Layer->bRootLayer)
				{
					MenuBuilder.AddMenuEntry(Commands.DeleteLayer);
					MenuBuilder.AddMenuSeparator();
					MenuBuilder.AddMenuEntry(Commands.Deactivate);
					MenuBuilder.AddMenuEntry(Commands.Activate);
				}
			}
		}
		MenuBuilder.EndSection();
	}

	return MenuBuilder.MakeWidget();
}

TSharedRef<FUICommandList> FOmniverseLayerItemViewModel::GetCommandList() const
{
	return CommandList;
}

bool FOmniverseLayerItemViewModel::CanBeMoved() const
{
	if (!Layer->IsValid())
		return false;

	return !Layer->bRootLayer;
}

void FOmniverseLayerItemViewModel::SetVisible(bool Visibility)
{
	if (!Layer->IsValid() && Layer->bRootLayer)
		return;

	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
		LayerDataSource->SetLayerVisibility(Layer, Visibility);
}

void FOmniverseLayerItemViewModel::MoveTo(UOmniverseLayer* InTargetLayer) const
{
	if (!Layer->IsValid() && Layer->bRootLayer)
		return;

	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
		LayerDataSource->AttachLayer(Layer, InTargetLayer);
}

void FOmniverseLayerItemViewModel::SetPrimDataSource(UOmniversePrim* InPrim)
{
	auto PrimViewModel = AllPrimViewModels.Find(InPrim);
	if (PrimViewModel)
	{
		(*PrimViewModel)->SetDataSource(Layer, InPrim);
	}
}

void FOmniverseLayerItemViewModel::SetDataSource(UOmniverseLayer* InLayer)
{
	Layer = InLayer;
	OnLayerVisibilityChanged().Broadcast();

	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (Layer->RootPrims.Num() == 0)
	{
		for (auto Pair : AllPrimsChildViewModels)
		{
			Unregister(Pair.Value);
		}
		AllPrimsChildViewModels.Reset();
	}
	else
	{
		TMap<FString, TObjectPtr<UOmniversePrim>> Prims = Layer->RootPrims;
		TArray<FString> ToRemove;
		for (auto ViewModel : AllPrimsChildViewModels)
		{
			if (Prims.Find(ViewModel.Key))
			{
				auto PrimData = Prims[ViewModel.Key];
				Prims.Remove(ViewModel.Key);
				ViewModel.Value->SetDataSource(InLayer, PrimData);
			}
			else
			{
				ToRemove.Add(ViewModel.Key);
			}
		}
		for (auto Key : ToRemove)
		{
			Unregister(AllPrimsChildViewModels[Key]);
			AllPrimsChildViewModels.Remove(Key);
		}

		for (auto Pair : Prims)
		{
			if (Pair.Value)
			{
				TSharedPtr<FOmniversePrimItemViewModel> PrimViewModel = FOmniversePrimItemViewModel::Create(this, Layer, Pair.Value, SharedData);
				Register(PrimViewModel);
				AllPrimsChildViewModels.Add(Pair.Key, PrimViewModel);
			}
		}
	}

	if (Layer->SubLayers.Num() == 0)
	{
		for (auto Pair : AllLayersChildViewModels)
		{
			CollectionViewModel->Unregister(Pair.Value);
		}
		AllLayersChildViewModels.Reset();
	}
	else
	{
		TMap<FString, TObjectPtr<UOmniverseLayer>> Layers = Layer->SubLayers;
		TArray<FString> ToRemove;
		for (auto ViewModel : AllLayersChildViewModels)
		{
			if (Layers.Find(ViewModel.Key))
			{
				auto LayerData = Layers[ViewModel.Key];
				Layers.Remove(ViewModel.Key);
				ViewModel.Value->SetDataSource(LayerData);
			}
			else
			{
				ToRemove.Add(ViewModel.Key);
			}
		}
		for (auto Key : ToRemove)
		{
			CollectionViewModel->Unregister(AllLayersChildViewModels[Key]);
			AllLayersChildViewModels.Remove(Key);
		}

		for (auto Pair : Layers)
		{
			if (Pair.Value)
			{
				TSharedPtr<FOmniverseLayerItemViewModel> LayerViewModel = FOmniverseLayerItemViewModel::Create(CollectionViewModel, Pair.Value, SharedData);
				CollectionViewModel->Register(LayerViewModel);
				AllLayersChildViewModels.Add(Pair.Key, LayerViewModel);
			}
		}
	}

	UpdateDisplayList();
}

void FOmniverseLayerItemViewModel::Lock()
{
	if (!Layer->IsValid())
	{
		return;
	}

	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->LockLayer(Layer);
	}
}

void FOmniverseLayerItemViewModel::Unlock()
{
	if (!Layer->IsValid())
	{
		return;
	}

	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->UnlockLayer(Layer);
	}
}

bool FOmniverseLayerItemViewModel::IsLocked() const
{
	return Layer->bLocked;
}

UOmniverseLayer* FOmniverseLayerItemViewModel::GetDataSource() const
{
	return Layer;
}

void FOmniverseLayerItemViewModel::BindCommands()
{
	const FOmniverseLayerBrowserCommands& Commands = FOmniverseLayerBrowserCommands::Get();
	FUICommandList& ActionList = *CommandList;

//	ActionList.MapAction(Commands.RenameLayer,
//		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::RenameLayer_Executed),
//		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::RenameLayer_CanExecute));

//	ActionList.MapAction(Commands.DuplicateLayer,
//		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::DuplicateLayer_Executed),
//		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::DuplicateLayer_CanExecute));

	ActionList.MapAction(Commands.SaveLayer,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::SaveLayer_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::SaveLayer_CanExecute));

	ActionList.MapAction(Commands.ReloadLayer,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::ReloadLayer_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::ReloadLayer_CanExecute));

	ActionList.MapAction(Commands.DeleteLayer,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::DeleteLayer_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::DeleteLayer_CanExecute));

	ActionList.MapAction(Commands.AddSelectionToLayer,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::AddSelectionToLayer_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::AddSelectionToLayer_CanExecute));

	//ActionList.MapAction(Commands.SelectObjectsInLayer,
	//	FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::SelectObjectsInLayer_Executed),
	//	FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::SelectObjectsInLayer_CanExecute));

	ActionList.MapAction(Commands.Deactivate,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::Deactivate_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::Deactivate_CanExecute));


	ActionList.MapAction(Commands.Activate,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::Activate_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::Activate_CanExecute));

	ActionList.MapAction(Commands.MergeLayers,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::MergeLayers_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::MergeLayers_CanExecute));

	ActionList.MapAction(Commands.MergeVisible,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::MergeVisible_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::MergeVisible_CanExecute));

	ActionList.MapAction(Commands.MergeDown,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::MergeDown_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::MergeDown_CanExecute));

	ActionList.MapAction(Commands.SetAuthoringLayer,
		FExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::SetAuthoringLayer_Executed),
		FCanExecuteAction::CreateSP(this, &FOmniverseLayerItemViewModel::SetAuthoringLayer_CanExecute));
}

void FOmniverseLayerItemViewModel::SaveLayer_Executed()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->SaveLayer(Layer);
	}
}

bool FOmniverseLayerItemViewModel::SaveLayer_CanExecute() const
{
	return CanEdit() && SharedData->GetLayerDataSource() && Layer->IsValid();
}

void FOmniverseLayerItemViewModel::ReloadLayer_Executed()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->ReloadLayer(Layer);
	}
}

bool FOmniverseLayerItemViewModel::ReloadLayer_CanExecute() const
{
	return CanEdit() && SharedData->GetLayerDataSource() && Layer->IsValid();
}

void FOmniverseLayerItemViewModel::DeleteLayer_Executed()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource && GetParent() && GetParent()->IsOfType<FOmniverseLayerItemViewModel>())
	{
		auto ParentLayer = StaticCastSharedPtr<FOmniverseLayerItemViewModel>(GetParent());	
		LayerDataSource->DeleteLayer(ParentLayer->GetDataSource(), Layer);
	}
}

bool FOmniverseLayerItemViewModel::DeleteLayer_CanExecute() const
{
	return CanEdit() && SharedData->GetLayerDataSource() && Layer->IsValid() && !Layer->bRootLayer;
}

void FOmniverseLayerItemViewModel::AddSelectionToLayer_Executed()
{
}

bool FOmniverseLayerItemViewModel::AddSelectionToLayer_CanExecute() const
{
	if (!Layer->IsValid())
		return false;
	USelection* SelectedActors = GEditor->GetSelectedActors();
	for (FSelectionIterator Iter(*SelectedActors); Iter; ++Iter)
	{
		AActor* Actor = Cast<AActor>(*Iter);
		if (Actor)
		{
			return true;
		}
	}
	return false;
}

//void FOmniverseLayerItemViewModel::SelectObjectsInLayer_Executed()
//{
//	SharedData->GetLayerDataSource()->SelectAllActorsOfLayer(Layer);
//}
//
//bool FOmniverseLayerItemViewModel::SelectObjectsInLayer_CanExecute() const
//{
//	return SharedData->GetLayerDataSource() && Layer.IsValid();
//}

void FOmniverseLayerItemViewModel::Deactivate_Executed()
{
	ToggleVisibility();
}

bool FOmniverseLayerItemViewModel::Deactivate_CanExecute() const
{
	return SharedData->GetLayerDataSource() && IsVisible() && !Layer->bRootLayer;
}

void FOmniverseLayerItemViewModel::Activate_Executed()
{
	ToggleVisibility();
}

bool FOmniverseLayerItemViewModel::Activate_CanExecute() const
{
	return SharedData->GetLayerDataSource() && !IsVisible();
}

void FOmniverseLayerItemViewModel::MergeLayers_Executed()
{

}

bool FOmniverseLayerItemViewModel::MergeLayers_CanExecute() const
{
	return SharedData->GetLayerDataSource() && Layer->IsValid();
}

void FOmniverseLayerItemViewModel::MergeVisible_Executed()
{

}

bool FOmniverseLayerItemViewModel::MergeVisible_CanExecute() const
{
	return SharedData->GetLayerDataSource() && Layer->IsValid() && !Layer->bRootLayer;
}

void FOmniverseLayerItemViewModel::MergeDown_Executed()
{

}

bool FOmniverseLayerItemViewModel::MergeDown_CanExecute() const
{
	return SharedData->GetLayerDataSource() && Layer->IsValid() && !Layer->bRootLayer;
}

void FOmniverseLayerItemViewModel::SetAuthoringLayer_Executed()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->AuthorLayer(Layer);
	}
}

bool FOmniverseLayerItemViewModel::SetAuthoringLayer_CanExecute() const
{
	return CanEdit() && SharedData->GetLayerDataSource() && Layer->IsValid();
}

void FOmniverseLayerItemViewModel::Register(TSharedPtr<FOmniversePrimItemViewModel> PrimViewModel)
{
	AllPrimViewModels.Add(PrimViewModel->GetDataSource(), PrimViewModel);
}

void FOmniverseLayerItemViewModel::Unregister(TSharedPtr<FOmniversePrimItemViewModel> PrimViewModel)
{
	for (auto Child : PrimViewModel->GetChildren())
	{
		if (Child->IsOfType<FOmniversePrimItemViewModel>())
		{
			Unregister(StaticCastSharedPtr<FOmniversePrimItemViewModel>(Child));
		}
	}

	AllPrimViewModels.Remove(PrimViewModel->GetDataSource());
}
