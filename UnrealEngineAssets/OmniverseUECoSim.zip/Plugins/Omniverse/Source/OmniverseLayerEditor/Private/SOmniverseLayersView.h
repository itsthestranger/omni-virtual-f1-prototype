// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "Misc/Attribute.h"
#include "Layout/Visibility.h"
#include "Input/Reply.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Views/SHeaderRow.h"
#include "DragAndDrop/ActorDragDropGraphEdOp.h"
#include "Widgets/Views/STableViewBase.h"
#include "Widgets/Views/STableRow.h"
#include "SOmniverseLayersTreeView.h"
#include "IOmniverseTreeItemViewModel.h"

#define LOCTEXT_NAMESPACE "LayersView"

class SOmniverseLayersView : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SOmniverseLayersView) {}
		SLATE_ATTRIBUTE(FText, HighlightText)
		SLATE_ARGUMENT(FOnContextMenuOpening, ConstructContextMenu)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, const TSharedRef<FOmniverseLayerItemCollectionViewModel>& InViewModel)
	{
		ChildSlot
		[
			SNew(SVerticalBox)
			+SVerticalBox::Slot()
			.FillHeight(1.0f)
			[
				SAssignNew(ListView, SOmniverseLayersTreeView, InViewModel, InArgs._HighlightText, InArgs._ConstructContextMenu)
			]
		];
	}

	void ExpandTreeItems()
	{
		ListView->ExpandAllItems();
	}

	TArray<TSharedPtr<IOmniverseTreeItemViewModel>> GetSelectedItems()
	{
		return ListView->GetCachedSelectedItems();
	}

	bool IsSelectedItemsFromSameLayer(TSharedPtr<FOmniverseLayerItemViewModel>* LayerItem)
	{
		return ListView->IsSelectedItemsFromSameLayer(LayerItem);
	}

	void RequestRenameOnSelectedLayer()
	{
		ListView->RequestRenameOnSelectedLayer();
	}

protected:
	virtual bool SupportsKeyboardFocus() const override
	{
		return true;
	}

private:
	TSharedPtr<SOmniverseLayersTreeView> ListView;
};

#undef LOCTEXT_NAMESPACE
