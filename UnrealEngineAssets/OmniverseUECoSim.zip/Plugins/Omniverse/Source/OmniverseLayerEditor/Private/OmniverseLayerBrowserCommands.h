// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "InputCoreTypes.h"
#include "Framework/Commands/InputChord.h"
#include "Framework/Commands/Commands.h"
#include "EditorStyleSet.h"

#define LOCTEXT_NAMESPACE "LayersViewCommands"

class FOmniverseLayerBrowserCommands : public TCommands<FOmniverseLayerBrowserCommands>
{
public:
	FOmniverseLayerBrowserCommands() : TCommands<FOmniverseLayerBrowserCommands>
	(
		"OmniverseLayersView", // Context name
		FText::FromString(TEXT("Omniverse Layers")),
		"LevelEditor", // Parent
		FAppStyle::GetAppStyleSetName()
	)
	{
	}
	
	virtual void RegisterCommands() override
	{
		//UI_COMMAND(DuplicateLayer, "Duplicate Layer", "Create a copy of a selected Layer .", EUserInterfaceActionType::Button, FInputChord());
		//UI_COMMAND(CopyPrim, "Copy", "Copy prim.", EUserInterfaceActionType::Button, FInputChord());
		//UI_COMMAND(PastePrim, "Paste", "Paste prim to this layer.", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(DeletePrim, "Delete", "Delete the selected prim.", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(DeleteDelta, "Delete Delta", "Delete the selected delta change.", EUserInterfaceActionType::Button, FInputChord());

		UI_COMMAND(DeletePrims, "Delete All", "Delete selected prims.", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(ReloadLayer, "Reload Layer", "Reload the selected layer.", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(SaveLayer, "Save Layer", "Save the selected layer.", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(DeleteLayer, "Remove Layer", "Remove the selected layer.", EUserInterfaceActionType::Button, FInputChord());
		//UI_COMMAND(RenameLayer, "Rename", "Rename this layer.", EUserInterfaceActionType::Button, FInputChord());

		UI_COMMAND(AddSelectionToLayer, "Add Selection to Layer", "Add selection to layer", EUserInterfaceActionType::Button, FInputChord());
		//UI_COMMAND(SelectObjectsInLayer, "Select objects in Layer", "Selects all objects in the viewport that have a delta change in the current Layer", EUserInterfaceActionType::Button, FInputChord());

		UI_COMMAND(Deactivate, "Deactivate", "Turn off all prim changes in that layer", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(Activate, "Activate", "Activate the selected layers", EUserInterfaceActionType::Button, FInputChord());

		UI_COMMAND(MergeLayers, "Merge Layers", "Flatten all layers to the background layer.", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(MergeVisible, "Merge Visible", "Flatten all layers that are active.", EUserInterfaceActionType::Button, FInputChord());	
		UI_COMMAND(MergeDown, "Merge Down", "Merge a Layer down one level.", EUserInterfaceActionType::Button, FInputChord());

		UI_COMMAND(SelectSingleActor, "Select Actor", "Select single actor", EUserInterfaceActionType::Button, FInputChord());
		UI_COMMAND(SetAuthoringLayer, "Set Authoring Layer", "Set authoring layer", EUserInterfaceActionType::Button, FInputChord());
	}

public:

	/** create a copy of a selected Layer  */
	//TSharedPtr<FUICommandInfo> DuplicateLayer;

	/** Delete the selected prim */
	TSharedPtr<FUICommandInfo> DeletePrim;

	/** Delete the selected delta change */
	TSharedPtr<FUICommandInfo> DeleteDelta;

	/** Delete the selected prims */
	TSharedPtr<FUICommandInfo> DeletePrims;

	/** Reload the selected Layer */
	TSharedPtr<FUICommandInfo> ReloadLayer;

	/** Save the selected Layer */
	TSharedPtr<FUICommandInfo> SaveLayer;

	/** Permanently remove the selected Layer */
	TSharedPtr<FUICommandInfo> DeleteLayer;

	/** Rename layer */
	//TSharedPtr<FUICommandInfo> RenameLayer;

	/** Add Selection to Layer */
	TSharedPtr<FUICommandInfo> AddSelectionToLayer;

	/** Selects all objects in the viewport that have a delta change in the current Layer */
	TSharedPtr<FUICommandInfo> SelectObjectsInLayer;

	/** Turn off all delta changes in that Layer */
	TSharedPtr<FUICommandInfo> Deactivate;

	/** Turn on all delta changes in a Layer */
	TSharedPtr<FUICommandInfo> Activate;

	/** Flatten all layers to the background Layer */
	TSharedPtr<FUICommandInfo> MergeLayers;

	/** Flatten all layers that are active */
	TSharedPtr<FUICommandInfo> MergeVisible;

	/** Merge a Layer down one level */
	TSharedPtr<FUICommandInfo> MergeDown;

	/** Select single actor **/
	TSharedPtr<FUICommandInfo> SelectSingleActor;

	/** Set authoring layer **/
	TSharedPtr<FUICommandInfo> SetAuthoringLayer;
};

#undef LOCTEXT_NAMESPACE
