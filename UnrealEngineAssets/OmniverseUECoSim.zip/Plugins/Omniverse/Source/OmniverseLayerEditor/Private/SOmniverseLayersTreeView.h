// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/Views/STreeView.h"
#include "IOmniverseTreeItemViewModel.h"
#include "OmniverseLayerItemCollectionViewModel.h"

class SOmniverseLayersTreeView : public STreeView<TSharedPtr<IOmniverseTreeItemViewModel>>
{
public:
	SOmniverseLayersTreeView() : bUpdatingSelection(false) {}

	~SOmniverseLayersTreeView();

	void Construct(const SOmniverseLayersTreeView::FArguments& InArgs,
		const TSharedPtr<FOmniverseLayerItemCollectionViewModel>& InViewModel,
		const TAttribute<FText>& InHighlightText,
		FOnContextMenuOpening InConstructContextMenu);

	void RequestRenameOnSelectedLayer();

	void ExpandAllItems();

	void ExpandRootItems();

	TSharedPtr<FOmniverseLayerItemCollectionViewModel> GetViewModel()
	{
		return ViewModel;
	}

	TArray<TSharedPtr<IOmniverseTreeItemViewModel>> GetCachedSelectedItems()
	{
		return SelectedTreeItems;
	}

	bool IsSelectedItemsFromSameLayer(TSharedPtr<FOmniverseLayerItemViewModel>* LayerItem);

	// Drag and Drop support functions
	static FReply OnCustomizedDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent, TWeakPtr<SOmniverseLayersTreeView> Table);

private:
	static TSharedPtr<FDragDropOperation> CreateDragDropOperation(const TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& InListItems);

	void OnItemExpansionChanged(TSharedPtr<IOmniverseTreeItemViewModel> TreeItem, bool bIsExpanded) const;

	void OnGetChildren(TSharedPtr<IOmniverseTreeItemViewModel> InParent,
		TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& OutChildren);

	void SetItemExpansionRecursive(TSharedPtr<IOmniverseTreeItemViewModel> Model, bool bInExpansionState);

	void OnSelectionChanged(const TSharedPtr<IOmniverseTreeItemViewModel> Item, ESelectInfo::Type SelectInfo);

	void OnListViewMouseButtonDoubleClick(const TSharedPtr<IOmniverseTreeItemViewModel> Item);

	TSharedRef<ITableRow> OnGenerateRowDefault(const TSharedPtr<IOmniverseTreeItemViewModel> Item, const TSharedRef<STableViewBase>& OwnerTable);

	void OnItemScrolledIntoView(TSharedPtr<IOmniverseTreeItemViewModel> LayerItem, const TSharedPtr<ITableRow>& Widget);

	void RequestRefresh();

	void UpdateSelection();

	TSharedPtr<FOmniverseLayerItemViewModel> GetLayerViewModel(const TSharedPtr<IOmniverseTreeItemViewModel>& ViewModel);

private:
	bool bUpdatingSelection;

	TSharedPtr<FOmniverseLayerItemCollectionViewModel> ViewModel;

	TArray<TSharedPtr<IOmniverseTreeItemViewModel>> SelectedTreeItems;

	TSharedPtr<FOmniverseLayerItemViewModel> SelectedLayer;

	TWeakPtr<IOmniverseTreeItemViewModel> RequestedRenameLayer;

	TAttribute<FText> HighlightText;
};