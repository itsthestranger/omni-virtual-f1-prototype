// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"
#include "EditorUndoClient.h"
#include "OmniverseLayerDataSource.h"
#include "IOmniverseTreeItemViewModel.h"

class AActor;
class UEditorEngine;

class FOmniversePrimItemViewModel : public IOmniverseTreeItemViewModel
{
public:
	OMNIVERSE_TREE_ITEM_VIEW_MODEL_TYPE(FOmniversePrimItemViewModel, IOmniverseTreeItemViewModel)

	virtual ~FOmniversePrimItemViewModel();

	static TSharedRef<FOmniversePrimItemViewModel> Create(class FOmniverseLayerItemViewModel* LayerViewModel, UOmniverseLayer* InLayer, UOmniversePrim* InPrim, const TSharedRef<FOmniverseTreeSharedData>& InSharedData)
	{
		TSharedRef<FOmniversePrimItemViewModel> NewLayer(new FOmniversePrimItemViewModel(LayerViewModel, InLayer, InPrim, InSharedData));
		NewLayer->Initialize();

		return NewLayer;
	}

public:
	virtual FOmniverseTreeItemID GetID() const override;

	virtual FString GetDisplayString() const override;

	virtual FText GetDisplayText() const override;

	virtual FText GetToolTipText() const override;

	virtual FName GetDisplayName() const override;

	virtual int32 GetTypeSortPriority() const override;

	virtual bool CanBeMoved() const override;

	virtual bool CanEdit() const override;

	virtual void SetVisible(bool Visibility) override;

	virtual bool IsVisible() const override;

	virtual void ToggleVisibility() override;

	virtual TSharedRef<ITableRow> GenerateRowWidget(const TSharedRef<STableViewBase>& OwnerTable,
		const TAttribute<FText>& InHighlightText);

	virtual TSharedPtr<SWidget> ConstructContextMenu() const;

	virtual TSharedRef<FUICommandList> GetCommandList() const;

	void SetDataSource(UOmniverseLayer* InLayer, UOmniversePrim* InPrim);

	UOmniversePrim* GetDataSource() const;

private:
	FOmniversePrimItemViewModel(class FOmniverseLayerItemViewModel* LayerViewModel, UOmniverseLayer* InLayer, UOmniversePrim* InPrim, const TSharedRef<FOmniverseTreeSharedData>& InSharedData);

	void Initialize();

	void BindCommands();

	void SelectSingleActor_Executed();

	bool SelectSingleActor_CanExecute() const;

	bool DeleteSinglePrim_CanExecute() const;

	void DeleteSinglePrim_Executed() const;

	void UpdateDisplayList();

private:
	class FOmniverseLayerItemViewModel* LayerViewModel;

	UOmniverseLayer* Layer;

	UOmniversePrim* Prim;

	FOmniverseTreeItemID ID;

	const TSharedRef<FUICommandList> CommandList;

	TMap<FString, TSharedPtr<FOmniversePrimItemViewModel>> AllChildViewModels;
};
