// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "SlateFwd.h"
#include "Misc/Attribute.h"
#include "Styling/SlateColor.h"
#include "Input/Reply.h"
#include "Widgets/SWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableViewBase.h"
#include "Widgets/Views/STableRow.h"
#include "SOmniverseTreeRowCommon.h"
#include "OmniverseLayerItemViewModel.h"
#include "IOmniverseTreeItemViewModel.h"

class SButton;
class SOmniverseLayersTreeView;
class SOmniverseTreeLayerItemRow : public SMultiColumnTableRow<TSharedPtr<IOmniverseTreeItemViewModel>>
{
public:

	SLATE_BEGIN_ARGS(SOmniverseTreeLayerItemRow){}
		SLATE_ATTRIBUTE(FText, HighlightText)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, const TSharedRef<IOmniverseTreeItemViewModel>& InViewModel,
		const TSharedRef<STableViewBase>& InOwnerTableView);

	~SOmniverseTreeLayerItemRow();

protected:
	virtual TSharedRef<SWidget> GenerateWidgetForColumn(const FName& ColumnID) override;

	virtual void OnDragLeave(const FDragDropEvent& DragDropEvent) override;

	virtual FReply OnDragOver(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;

	virtual FReply OnDrop(const FGeometry& MyGeometry, const FDragDropEvent& DragDropEvent) override;


private:
	void UpdateVisibility()
	{
		bGlobalVisibility = !ViewModel->GetDataSource()->bGlobalMuted;
		bLocalVisibility = !ViewModel->GetDataSource()->bMuted;
	}

	FReply OnToggleVisibility()
	{
		ViewModel->ToggleVisibility();
		UpdateVisibility();

		return FReply::Handled();
	}

	bool IsLocalVisibilityEnabled() const
	{
		return !ViewModel->GetSharedData()->GetLayerDataSource()->IsMutenessGlobal() && !ViewModel->GetDataSource()->bAuthor;
	}

	bool IsGlobalVisibilityEnabled() const
	{
		return ViewModel->GetSharedData()->GetLayerDataSource()->IsMutenessGlobal() && !ViewModel->GetDataSource()->bAuthor;
	}

	const FSlateBrush* GetLocalVisibilityBrushForLayer() const;

	const FSlateBrush* GetGlobalVisibilityBrushForLayer() const;

	const FSlateBrush* GetLockBrushForLayer() const;

	FText GetToolTipTextForLockButton() const;

	FReply OnLockChanged();

	ECheckBoxState IsLocked() const
	{
		return bLocked ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
	}

private:

	/** The view this row attached to **/
	TWeakPtr<SOmniverseLayersTreeView> WeakTreeView;

	/** The data model of this layer */
	TSharedPtr<FOmniverseLayerItemViewModel> ViewModel;

	/**	The visibility button for the layer */
	TSharedPtr<SButton> VisibilityButton;

	TSharedPtr<SButton> LockButton;

	/** The string to highlight on any text contained in the row widget */
	TAttribute<FText> HighlightText;

	/** Handle to the registered EnterEditingMode delegate */
	FDelegateHandle EnterEditingModeDelegateHandle;

	bool bLocalVisibility = true;
	bool bGlobalVisibility = true;
	bool bLocked = false;
};

