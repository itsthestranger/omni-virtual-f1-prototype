// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseLayerEditorModule.h"
#include "Widgets/SWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Docking/SDockTab.h"
#include "Editor.h"
#include "Modules/ModuleManager.h"
#include "Editor/WorkspaceMenuStructure/Public/WorkspaceMenuStructure.h"
#include "Editor/WorkspaceMenuStructure/Public/WorkspaceMenuStructureModule.h"
#include "Framework/Docking/TabManager.h"
#include "LevelEditor/Public/LevelEditor.h"
#include "SOmniverseLayerBrowser.h"
#include "OmniverseLayerDataSource.h"
#include "OmniverseLayerBrowserCommands.h"
#include "SOmniverseLayerBrowserStyle.h"

IMPLEMENT_MODULE(FOmniverseLayerEditorModule, OmniverseLayerEditor);

const FName OmnvierseLayerEditorTabName(TEXT("Omniverse Layers"));

static TSharedRef<SDockTab> SpawnLevelEditorTab(const FSpawnTabArgs & Args)
{
	FOmniverseLayerEditorModule& LayersModule = FModuleManager::LoadModuleChecked<FOmniverseLayerEditorModule>("OmniverseLayerEditor");
	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		.Label(FText::FromName(OmnvierseLayerEditorTabName))
		[
			SNew(SBorder)
			.Padding(0)
			.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
			[
				SNew(SOmniverseLayerBrowser)
			]
		];
}

void FOmniverseLayerEditorModule::StartupModule()
{
	FOmniverseLayerBrowserCommands::Register();
	FOmniverseLayerBrowserStyle::Initialize();

	const IWorkspaceMenuStructure& MenuStructure = WorkspaceMenu::GetMenuStructure();
	{
		const FSlateIcon LayersIcon(FAppStyle::GetAppStyleSetName(), "LevelEditor.Tabs.Layers");
		FGlobalTabmanager::Get()->RegisterNomadTabSpawner(OmnvierseLayerEditorTabName, FOnSpawnTab::CreateStatic(SpawnLevelEditorTab))
			.SetDisplayName(FText::FromString(TEXT("Omniverse Layers")))
			.SetTooltipText(FText::FromString(TEXT("Open Omniverse layers tab.")))
			.SetGroup(MenuStructure.GetLevelEditorCategory())
			.SetIcon(LayersIcon);
	}
}

void FOmniverseLayerEditorModule::ShutdownModule()
{
	FOmniverseLayerBrowserCommands::Unregister();
	FOmniverseLayerBrowserStyle::Shutdown();

	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(OmnvierseLayerEditorTabName);
}
