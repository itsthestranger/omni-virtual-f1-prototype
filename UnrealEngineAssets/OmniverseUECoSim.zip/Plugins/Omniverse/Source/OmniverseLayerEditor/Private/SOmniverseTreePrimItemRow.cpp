// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SOmniverseTreePrimItemRow.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Views/SListView.h"
#include "EditorStyleSet.h"
#include "DragAndDrop/ActorDragDropGraphEdOp.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "SOmniverseLayersTreeView.h"
#include "SOmniverseDragAndDrop.h"
#include "SOmniverseLayerBrowserStyle.h"

struct SOmniversePrimItemLabel : public SCompoundWidget
{
	SLATE_BEGIN_ARGS(SOmniversePrimItemLabel) {}
	SLATE_END_ARGS()

	~SOmniversePrimItemLabel()
	{
	}

	TSharedRef<SImage> CreatePrimIcon()
	{
		if (TreeItemPtr.IsValid())
		{
			auto ViewModel = TreeItemPtr.Pin();
			if (ViewModel->GetDataSource()->bIsReference)
			{
				return SNew(SImage)
					.Image(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.ReferencePrim.Small")))
					.ColorAndOpacity(FSlateColor::UseForeground());
			}
			else if (ViewModel->GetDataSource()->bIsPayload)
			{
				return SNew(SImage)
					.Image(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.PayloadPrim.Small")))
					.ColorAndOpacity(FSlateColor::UseForeground());
			}
			else if (ViewModel->GetDataSource()->bOver)
			{
				return SNew(SImage)
					.Image(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.DeltaPrim.Small")))
					.ColorAndOpacity(FSlateColor::UseForeground());
			}
			else
			{
				return SNew(SImage)
					.Image(FOmniverseLayerBrowserStyle::Get()->GetBrush(
						TEXT("OmniverseLayerBrowser.PrimLabel.Small")))
					.ColorAndOpacity(FSlateColor::UseForeground());
			}
		}
		else
		{
			return SNew(SImage);
		}
	}

	void Construct(const FArguments& InArgs, const TSharedPtr<FOmniversePrimItemViewModel>& LayerItem,
		const SOmniverseTreePrimItemRow& InRow,
		const TAttribute<FText>& InHighlightText)
	{
		HighlightText = InHighlightText;
		TreeItemPtr = LayerItem;
		if (TreeItemPtr.IsValid())
		{
			ChildSlot
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(0.0f, 0.0f, 6.0f, 0.0f)
					[
						SNew(SBox)
						.WidthOverride(16.0f)
						.HeightOverride(16.0f)
						[
							CreatePrimIcon()
						]
					]
					+ SHorizontalBox::Slot()
					.FillWidth(1.0f)
					.VAlign(VAlign_Center)
					[
						SAssignNew(InlineTextBlock, SInlineEditableTextBlock)
						.Font(FAppStyle::GetFontStyle("LayersView.LayerNameFont"))
						.Text(TreeItemPtr.Pin().Get(), &FOmniversePrimItemViewModel::GetDisplayText)
						.ToolTipText(TreeItemPtr.Pin().Get(), &FOmniversePrimItemViewModel::GetToolTipText)
						.ColorAndOpacity(this, &SOmniversePrimItemLabel::GetColorAndOpacity)
						.HighlightText(HighlightText)
						.IsReadOnly(true)
						.IsSelected(FIsSelected::CreateSP(&InRow, &SOmniverseTreePrimItemRow::IsSelectedExclusively))
					]
				];
		}
	}

private:
	FSlateColor GetColorAndOpacity() const
	{
		if (!FSlateApplication::Get().IsDragDropping())
		{
			if (TreeItemPtr.Pin()->IsVisible())
				return FSlateColor::UseForeground();
			else
				return FLinearColor(0.30f, 0.30f, 0.30f);
		}

		bool bCanAcceptDrop = false;
		TSharedPtr<FDragDropOperation> DragDropOp = FSlateApplication::Get().GetDragDroppingContent();

		if (DragDropOp.IsValid() && DragDropOp->IsOfType<OmniverseDragAndDrop::FLayerDragDropOp>())
			bCanAcceptDrop = true;

		return (bCanAcceptDrop) ? FSlateColor::UseForeground() : FLinearColor(0.30f, 0.30f, 0.30f);
	}

private:
	TWeakPtr<FOmniversePrimItemViewModel> TreeItemPtr;

	TAttribute<FText> HighlightText;

	TSharedPtr<SInlineEditableTextBlock> InlineTextBlock;
};

void SOmniverseTreePrimItemRow::Construct(const FArguments& InArgs, const TSharedRef<IOmniverseTreeItemViewModel>& InViewModel,
	const TSharedRef<STableViewBase>& InOwnerTableView)
{
	ViewModel = StaticCastSharedRef<FOmniversePrimItemViewModel>(InViewModel);
	HighlightText = InArgs._HighlightText;
	WeakTreeView = StaticCastSharedRef<SOmniverseLayersTreeView>(InOwnerTableView);

	auto Args = FSuperRowType::FArguments()
		.Style(&FAppStyle::Get().GetWidgetStyle<FTableRowStyle>("SceneOutliner.TableViewRow"));
	SMultiColumnTableRow<TSharedPtr<IOmniverseTreeItemViewModel>>::Construct(Args, InOwnerTableView);
}

SOmniverseTreePrimItemRow::~SOmniverseTreePrimItemRow()
{
}

TSharedRef<SWidget> SOmniverseTreePrimItemRow::GenerateWidgetForColumn(const FName& ColumnID)
{
	TSharedRef<SWidget> TableRowContent = SNullWidget::NullWidget;;
	if (ColumnID == OmniverseLayersView::ColumnID_LayerLabel)
	{
		TableRowContent = SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(14, 0, 2, 0)
			[
				SNew(SExpanderArrow, SharedThis(this)).IndentAmount(12)
			]
			+ SHorizontalBox::Slot()
			.FillWidth(1.0f)
			[
				SNew(SOmniversePrimItemLabel, ViewModel, *this, HighlightText)
			];
	}

	return TableRowContent;
}
