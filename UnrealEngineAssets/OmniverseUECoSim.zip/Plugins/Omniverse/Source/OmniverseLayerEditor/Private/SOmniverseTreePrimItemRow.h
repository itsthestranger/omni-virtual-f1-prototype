// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "SlateFwd.h"
#include "Misc/Attribute.h"
#include "Styling/SlateColor.h"
#include "Input/Reply.h"
#include "Widgets/SWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Views/STableViewBase.h"
#include "Widgets/Views/STableRow.h"
#include "SOmniverseTreeRowCommon.h"
#include "OmniversePrimItemViewModel.h"

class SButton;
class SOmniverseLayersTreeView;
class SOmniverseTreePrimItemRow : public SMultiColumnTableRow<TSharedPtr<IOmniverseTreeItemViewModel>>
{
public:
	SLATE_BEGIN_ARGS(SOmniverseTreePrimItemRow){}
		SLATE_ATTRIBUTE(FText, HighlightText)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs, const TSharedRef<IOmniverseTreeItemViewModel>& InViewModel,
		const TSharedRef<STableViewBase>& InOwnerTableView);

	~SOmniverseTreePrimItemRow();

protected:
	virtual TSharedRef<SWidget> GenerateWidgetForColumn(const FName& ColumnID) override;

private:
	FReply OnToggleVisibility()
	{
		ViewModel->ToggleVisibility();
		return FReply::Handled();
	}

private:
	/** The view this row attached to **/
	TWeakPtr<SOmniverseLayersTreeView> WeakTreeView;

	/** The data model of this layer */
	TSharedPtr<FOmniversePrimItemViewModel> ViewModel;

	/**	The visibility button for the layer */
	TSharedPtr<SButton> VisibilityButton;

	/** The string to highlight on any text contained in the row widget */
	TAttribute<FText> HighlightText;
};

