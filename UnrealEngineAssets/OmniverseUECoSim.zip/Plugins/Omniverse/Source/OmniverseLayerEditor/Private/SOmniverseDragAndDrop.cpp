// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SOmniverseDragAndDrop.h"
#include "Widgets/SBoxPanel.h"
#include "EditorStyleSet.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Text/STextBlock.h"

namespace OmniverseDragAndDrop
{
	FDragDropPayload::FDragDropPayload()
	{
	}

	FDragDropPayload::FDragDropPayload(const TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& InDraggedItems)
	{
		for (auto Item : InDraggedItems)
		{
			if (Item->IsOfType<FOmniverseLayerItemViewModel>())
			{
				auto LayerItem = StaticCastSharedPtr<FOmniverseLayerItemViewModel>(Item);
				Layers.Add(LayerItem);
			}
		}
	}

	FLayerDragDropOp::FLayerDragDropOp(const FDragDropPayload& DraggedObjects)
		: OverrideText(),
		Payload(DraggedObjects)
	{
	}

	EVisibility FLayerDragDropOp::GetOverrideVisibility() const
	{
		return OverrideText.IsEmpty() ? EVisibility::Collapsed : EVisibility::Visible;
	}

	EVisibility FLayerDragDropOp::GetDefaultVisibility() const
	{
		return OverrideText.IsEmpty() ? EVisibility::Visible : EVisibility::Collapsed;
	}

	TSharedPtr<SWidget> FLayerDragDropOp::GetDefaultDecorator() const
	{
		TSharedRef<SVerticalBox> VerticalBox = SNew(SVerticalBox);

		VerticalBox->AddSlot()
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("Graph.ConnectorFeedback.Border"))
			.Visibility(this, &FLayerDragDropOp::GetOverrideVisibility)
			.Content()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(0.0f, 0.0f, 3.0f, 0.0f)
				[
					SNew(SImage)
					.Image(this, &FLayerDragDropOp::GetOverrideIcon)
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					SNew(STextBlock)
					.Text(this, &FLayerDragDropOp::GetOverrideText)
				]
			]
		];

		return VerticalBox;
	}

	TSharedPtr<FDragDropOperation> CreateDragDropOperation(const TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& InListItems)
	{
		FDragDropPayload DraggedObjects(InListItems);
		TSharedPtr<FLayerDragDropOp> Op = MakeShareable(new FLayerDragDropOp(DraggedObjects));
		Op->Construct();
		return Op;
	}
}