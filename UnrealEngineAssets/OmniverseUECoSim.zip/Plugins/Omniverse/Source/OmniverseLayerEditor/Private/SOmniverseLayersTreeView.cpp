// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SOmniverseLayersTreeView.h"
#include "SOmniverseDragAndDrop.h"
#include "OmniverseLayerBrowserCommands.h"
#include "SOmniverseTreeRowCommon.h"

SOmniverseLayersTreeView::~SOmniverseLayersTreeView()
{
	ViewModel->OnLayersChanged().RemoveAll(this);
	ViewModel->GetSharedData()->OnPostFilterChanged().RemoveAll(this);
	ViewModel->OnSelectedLayerChanged().RemoveAll(this);
}

void SOmniverseLayersTreeView::Construct(const SOmniverseLayersTreeView::FArguments& InArgs,
	const TSharedPtr<FOmniverseLayerItemCollectionViewModel>& InViewModel, const TAttribute<FText>& InHighlightText,
	FOnContextMenuOpening InConstructContextMenu)
{
	ViewModel = InViewModel;
	HighlightText = InHighlightText;

	TSharedRef<SHeaderRow> HeaderRowWidget =
		SNew(SHeaderRow)
		.Visibility(EVisibility::Visible)

		/** LayerName label column */
		+ SHeaderRow::Column(OmniverseLayersView::ColumnID_LayerLabel)
		.DefaultLabel(FText::FromString(TEXT("Name")))

		/** Layer visibility column */
		+ SHeaderRow::Column(OmniverseLayersView::ColumnID_Visibility)
		.DefaultLabel(FText::FromString(TEXT("Local/Global/Locked")))
		.ToolTipText(FText::FromString("Local/Global visibility of layer and if it's locked"));

	FOnGenerateRow OnGenerateRowDelegate = FOnGenerateRow::CreateSP(this, &SOmniverseLayersTreeView::OnGenerateRowDefault);
	auto Args = SOmniverseLayersTreeView::FArguments(InArgs)

		// Called when an item is expanded or collapsed
		.OnExpansionChanged(this, &SOmniverseLayersTreeView::OnItemExpansionChanged)

		// Called to child items for any given parent item
		.OnGetChildren(this, &SOmniverseLayersTreeView::OnGetChildren)

		// Called when an item is expanded or collapsed with the shift-key pressed down
		.OnSetExpansionRecursive(this, &SOmniverseLayersTreeView::SetItemExpansionRecursive)

		.SelectionMode(ESelectionMode::Multi)

		// Point the tree to our array of root-level items.  Whenever this changes, we'll call RequestTreeRefresh()
		.TreeItemsSource(&InViewModel->GetRootItems())

		// Don't click selection on click
		.ClearSelectionOnClick(false)

		// Find out when the user selects something in the tree
		.OnSelectionChanged(this, &SOmniverseLayersTreeView::OnSelectionChanged)

		// Called when the user double-clicks with LMB on an item in the list
		.OnMouseButtonDoubleClick(this, &SOmniverseLayersTreeView::OnListViewMouseButtonDoubleClick)

		// Generates the actual widget for a tree item
		.OnGenerateRow(OnGenerateRowDelegate)

		// Use the level viewport context menu as the right click menu for list items
		.OnContextMenuOpening(InConstructContextMenu)

		// Header for the tree
		.HeaderRow(HeaderRowWidget)

		// Items scrolled into view
		.OnItemScrolledIntoView(this, &SOmniverseLayersTreeView::OnItemScrolledIntoView);

	STreeView<TSharedPtr<IOmniverseTreeItemViewModel>>::Construct(Args);
	ViewModel->GetSharedData()->OnPostFilterChanged().AddSP(this, &SOmniverseLayersTreeView::RequestTreeRefresh);
	ViewModel->OnLayersChanged().AddSP(this, &SOmniverseLayersTreeView::RequestRefresh);
	ViewModel->OnSelectedLayerChanged().AddSP(this, &SOmniverseLayersTreeView::UpdateSelection);
	ViewModel->OnFilterLayerChanged().AddSP(this, &SOmniverseLayersTreeView::ExpandRootItems);
	UpdateSelection();
}

void SOmniverseLayersTreeView::RequestRenameOnSelectedLayer()
{
	if (GetNumItemsSelected() == 1)
	{
		RequestedRenameLayer = GetSelectedItems()[0];
		RequestScrollIntoView(GetSelectedItems()[0]);
	}
}

void SOmniverseLayersTreeView::ExpandRootItems()
{
	for (const auto& Item : ViewModel->GetRootItems())
	{
		SetItemExpansion(Item, true);
	}
}

void SOmniverseLayersTreeView::ExpandAllItems()
{
	for (const auto& Item : ViewModel->GetRootItems())
	{
		SetItemExpansionRecursive(Item, true);
	}
}

bool SOmniverseLayersTreeView::IsSelectedItemsFromSameLayer(TSharedPtr<FOmniverseLayerItemViewModel>* LayerItem)
{
	if (SelectedTreeItems.Num() > 0)
	{
		const auto& FirstItem = SelectedTreeItems[0];
		TSharedPtr<IOmniverseTreeItemViewModel> FirstLayerItem = GetLayerViewModel(FirstItem);

		bool bAllFromSameLayer = true;
		for (int32 i = 1; i < SelectedTreeItems.Num(); i++)
		{
			TSharedPtr<IOmniverseTreeItemViewModel> SelectedLayerItem = GetLayerViewModel(SelectedTreeItems[i]);
			if (FirstLayerItem != SelectedLayerItem)
			{
				bAllFromSameLayer = false;
				break;
			}
		}

		if (bAllFromSameLayer && LayerItem)
			*LayerItem = StaticCastSharedPtr<FOmniverseLayerItemViewModel>(FirstLayerItem);
		return bAllFromSameLayer;
	}

	return false;
}

FReply SOmniverseLayersTreeView::OnCustomizedDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent, TWeakPtr<SOmniverseLayersTreeView> Table)
{
	auto TablePtr = Table.Pin();
	if (TablePtr.IsValid() && MouseEvent.IsMouseButtonDown(EKeys::LeftMouseButton) && TablePtr->GetSelectedItems().Num() == 1)
	{
		auto Operation = CreateDragDropOperation(TablePtr->GetSelectedItems());
		if (Operation.IsValid())
		{
			return FReply::Handled().BeginDragDrop(Operation.ToSharedRef());
		}
	}

	return FReply::Unhandled();
}

TSharedPtr<FDragDropOperation> SOmniverseLayersTreeView::CreateDragDropOperation(const TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& InListItems)
{
	OmniverseDragAndDrop::FDragDropPayload DraggedObjects(InListItems);
	TSharedPtr<FDragDropOperation> Op = OmniverseDragAndDrop::CreateDragDropOperation(InListItems);

	return Op;
}

void SOmniverseLayersTreeView::OnItemExpansionChanged(TSharedPtr<IOmniverseTreeItemViewModel> TreeItem, bool bIsExpanded) const
{
}

void SOmniverseLayersTreeView::OnGetChildren(TSharedPtr<IOmniverseTreeItemViewModel> InParent, TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& OutChildren)
{
	for (auto& Child : InParent->GetChildren())
	{
		check(Child.IsValid());
		OutChildren.Add(Child);
	}
}

void SOmniverseLayersTreeView::SetItemExpansionRecursive(TSharedPtr<IOmniverseTreeItemViewModel> Model, bool bInExpansionState)
{
	TArray<TSharedPtr<IOmniverseTreeItemViewModel>> Queue;
	Queue.Add(Model);
	while(Queue.Num() != 0)
	{
		auto Item = Queue.Pop();
		SetItemExpansion(Item, bInExpansionState);
		for (auto Child : Item->GetChildren())
			Queue.Add(Child);
	}
}

void SOmniverseLayersTreeView::OnSelectionChanged(const TSharedPtr<IOmniverseTreeItemViewModel> Item, ESelectInfo::Type SelectInfo)
{
	if (bUpdatingSelection)
	{
		return;
	}

	if (GetSelectedItems().Num() > 0)
	{
		SelectedTreeItems = GetSelectedItems();
		if (SelectedTreeItems.Num() == 1)
		{
			if (SelectedTreeItems[0]->IsOfType<FOmniversePrimItemViewModel>())
			{
				FOmniverseLayerBrowserCommands Commands = FOmniverseLayerBrowserCommands::Get();
				Item->GetCommandList()->TryExecuteAction(Commands.SelectSingleActor.ToSharedRef());
				ViewModel->SetSelectedLayer(nullptr);
			}
			else
			{
				auto LayerItem = GetLayerViewModel(SelectedTreeItems[0]);
				ViewModel->SetSelectedLayer(LayerItem);
			}
		}
		else
		{
			TArray<UOmniversePrim*> SelectedPrims;
			for (auto SelectedItem : SelectedTreeItems)
			{
				if (SelectedItem->IsOfType<FOmniversePrimItemViewModel>())
				{
					auto PrimItem = StaticCastSharedPtr<FOmniversePrimItemViewModel>(SelectedItem);
					SelectedPrims.Add(PrimItem->GetDataSource());
				}
			}
			ViewModel->GetSharedData()->GetLayerDataSource()->SelectAllActors(SelectedPrims);
			ViewModel->SetSelectedLayer(nullptr);
		}
	}
	else
	{
		ViewModel->SetSelectedLayer(nullptr);
		UpdateSelection();
	}
}

void SOmniverseLayersTreeView::OnListViewMouseButtonDoubleClick(const TSharedPtr<IOmniverseTreeItemViewModel> Item)
{
	if (Item->IsOfType<FOmniverseLayerItemViewModel>())
	{
		auto LayerItem = GetLayerViewModel(Item);
		ViewModel->SetAuthoredLayer(LayerItem);
	}
	else if(Item->IsOfType<FOmniversePrimItemViewModel>())
	{
		
	}
}

TSharedRef<ITableRow> SOmniverseLayersTreeView::OnGenerateRowDefault(const TSharedPtr<IOmniverseTreeItemViewModel> Item,
	const TSharedRef<STableViewBase>& OwnerTable)
{
	return Item->GenerateRowWidget(OwnerTable, HighlightText);
}

void SOmniverseLayersTreeView::OnItemScrolledIntoView(TSharedPtr<IOmniverseTreeItemViewModel> LayerItem, const TSharedPtr<ITableRow>& Widget)
{
}

void SOmniverseLayersTreeView::RequestRefresh()
{
	RequestTreeRefresh();
}

void SOmniverseLayersTreeView::UpdateSelection()
{
	if (bUpdatingSelection)
	{
		return;
	}

	bUpdatingSelection = true;
	if (SelectedLayer && SelectedLayer != ViewModel->GetSelectedLayer())
	{
		SetItemSelection(SelectedLayer, false);
		SelectedTreeItems.Remove(SelectedLayer);
	}
	SelectedLayer = ViewModel->GetSelectedLayer();
	if (SelectedLayer)
	{
		SetItemSelection(SelectedLayer, true);
		TArray<TSharedPtr<IOmniverseTreeItemViewModel>> RemoveItems;
		for (const auto TreeItem : SelectedTreeItems)
		{
			if (TreeItem->IsOfType<FOmniversePrimItemViewModel>())
			{
				auto LayerItem = GetLayerViewModel(TreeItem);
				if (LayerItem == SelectedLayer)
				{
					SetItemSelection(TreeItem, true);
				}
				else
				{
					SetItemSelection(TreeItem, false);
					RemoveItems.Add(TreeItem);
				}
			}
		}

		for (const auto TreeItem : RemoveItems)
		{
			SelectedTreeItems.Remove(TreeItem);
		}
	}

	//if (!SelectedLayer && SelectedTreeItems.Num() == 0 && ViewModel->GetRootItems().Num() > 0)
	//{
	//	auto FirstItem = ViewModel->GetRootItems()[0];
	//	if (FirstItem->IsOfType<FOmniverseLayerItemViewModel>())
	//	{
	//		auto LayerItem = StaticCastSharedPtr<FOmniverseLayerItemViewModel>(FirstItem);
	//		SelectedLayer = LayerItem;
	//		SelectedItems.Add(LayerItem);
	//		ViewModel->SetSelectedLayer(LayerItem);
	//		SetItemSelection(LayerItem, true);
	//	}
	//}
		
	bUpdatingSelection = false;
}

TSharedPtr<FOmniverseLayerItemViewModel> SOmniverseLayersTreeView::GetLayerViewModel(const TSharedPtr<IOmniverseTreeItemViewModel>& InViewModel)
{
	auto ItemViewModel = InViewModel;
	if (ItemViewModel->IsOfType<FOmniverseLayerItemViewModel>())
	{
		return StaticCastSharedPtr<FOmniverseLayerItemViewModel>(ItemViewModel);
	}
	else
	{
		while (ItemViewModel && ItemViewModel->IsOfType<FOmniversePrimItemViewModel>())
			ItemViewModel = ItemViewModel->GetParent();
		return StaticCastSharedPtr<FOmniverseLayerItemViewModel>(ItemViewModel);
	}
}

