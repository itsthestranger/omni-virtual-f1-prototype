// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SOmniverseInputProcessor.h"
#include "IAssetViewport.h"
#include "OmniverseLayerItemViewModel.h"
#include "OmniversePrimItemViewModel.h"
#include "SOmniverseLayerBrowser.h"
#include "OmniverseConnectionHelper.h"

void SOmniverseInputProcessor::Tick(const float DeltaTime, FSlateApplication & SlateApp, TSharedRef<ICursor> Cursor)
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	auto ActiveViewport = LevelEditorModule.GetFirstActiveViewport();
	auto SharedData = LayerBrowser->GetSharedData();
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource && LayerDataSource->GetAuthoringLayer())
	{
		OnDismissNoLayersNotification();
		OnDismissLayerMutedNotification();
		if (!LayerDataSource->GetAuthoringLayer()->bLocked)
		{
			OnDismissLayerLockedNotification();
		}
	}
}

bool SOmniverseInputProcessor::HandleKeyDownEvent(FSlateApplication & SlateApp, const FKeyEvent & InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::Delete && LayerBrowser->IsHovered())
	{
		LayerBrowser->DeleteSelectedPrims();

		return true;
	}

	return false;
}

bool SOmniverseInputProcessor::HandleMouseButtonDownEvent(FSlateApplication & SlateApp, const FPointerEvent & MouseEvent)
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	auto ActiveViewport = LevelEditorModule.GetFirstActiveViewport();
	if (ActiveViewport.IsValid() && ActiveViewport->AsWidget()->IsHovered())
	{
		ButtonDownIsInViewport = true;
		UpdateNotificationItem();
	}

	return false;
}

bool SOmniverseInputProcessor::HandleMouseButtonUpEvent(FSlateApplication & SlateApp, const FPointerEvent & MouseEvent)
{
	if (!ButtonDownIsInViewport)
	{
		FVector2D CursorPos = FSlateApplication::Get().GetCursorPos();
		auto WidgetsUnderMouse = FSlateApplication::Get().LocateWindowUnderMouse(CursorPos, FSlateApplication::Get().GetInteractiveTopLevelWindows()).Widgets;
		if (WidgetsUnderMouse.Num() > 0)
		{
			FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
			auto ActiveViewport = LevelEditorModule.GetFirstActiveViewport();
			auto Widget = WidgetsUnderMouse.Last().Widget;
			if (ActiveViewport.IsValid() && Widget == ActiveViewport->GetViewportWidget())
			{
				bool bUpdated = UpdateNotificationItem();
				if (bUpdated && FSlateApplication::Get().IsDragDropping())
				{
					FSlateApplication::Get().CancelDragDrop();
					return true;
				}
			}
		}
	}

	ButtonDownIsInViewport = false;
	return false;
}

void SOmniverseInputProcessor::Initialize()
{
	auto SharedData = LayerBrowser->GetSharedData();
	if (SharedData->GetLayerDataSource())
		SharedData->GetLayerDataSource()->OnLayersChanged().AddSP(this, &SOmniverseInputProcessor::OnLayersChanged);

	OnDismissNoLayersNotification();
	OnDismissLayerMutedNotification();
	OnDismissLayerLockedNotification();
}

void SOmniverseInputProcessor::OnDismissNoLayersNotification()
{
	if (NoLayerSelectedNotificationItem.IsValid())
	{
		NoLayerSelectedNotificationItem->Fadeout();
		NoLayerSelectedNotificationItem.Reset();
	}
}

void SOmniverseInputProcessor::OnDismissLayerMutedNotification()
{
	if (LayerMutedNotificationItem.IsValid())
	{
		LayerMutedNotificationItem->Fadeout();
		LayerMutedNotificationItem.Reset();
	}
}

void SOmniverseInputProcessor::OnDismissLayerLockedNotification()
{
	if (LayerLockedNotificationItem.IsValid())
	{
		LayerLockedNotificationItem->Fadeout();
		LayerLockedNotificationItem.Reset();
	}
}

void SOmniverseInputProcessor::OnActivate()
{
	if (LayerBrowser->GetSelectedLayer())
	{
		LayerBrowser->GetSelectedLayer()->SetVisible(true);
		LayerBrowser->SetSelectedLayer(LayerBrowser->GetSelectedLayer());
	}

	if (LayerMutedNotificationItem.IsValid())
	{
		LayerMutedNotificationItem->ExpireAndFadeout();
		LayerMutedNotificationItem.Reset();
	}
}

void SOmniverseInputProcessor::OnLayersChanged(ELayersEventType EventType, UOmniverseLayer* InLayer, UOmniversePrim* InPrim)
{
	auto SharedData = LayerBrowser->GetSharedData();
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource && LayerDataSource->GetAuthoringLayer())
	{
		OnDismissNoLayersNotification();
		OnDismissLayerMutedNotification();
		OnDismissLayerLockedNotification();
	}
}

void SOmniverseInputProcessor::OnLayerDataSourceChanged()
{
	Initialize();
}

bool SOmniverseInputProcessor::UpdateNotificationItem()
{
	auto SharedData = LayerBrowser->GetSharedData();
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource && LayerDataSource->NumLayers() > 0)
	{
		if (!LayerDataSource->GetAuthoringLayer())
		{
			if (!LayerBrowser->GetSelectedLayer())
			{
				OnDismissLayerMutedNotification();
				if (!NoLayerSelectedNotificationItem.IsValid())
				{
					FNotificationInfo Info(FText::GetEmpty());
					Info.bFireAndForget = false;
					Info.ExpireDuration = 0;
					Info.FadeOutDuration = 0.1f;
					Info.ButtonDetails.Add(FNotificationButtonInfo(
						FText::FromString("Dismiss"),
						FText(),
						FSimpleDelegate::CreateSP(this, &SOmniverseInputProcessor::OnDismissNoLayersNotification),
						SNotificationItem::CS_Fail
					));

					NoLayerSelectedNotificationItem = FSlateNotificationManager::Get().AddNotification(Info);
				}

				NoLayerSelectedNotificationItem->SetCompletionState(SNotificationItem::CS_Fail);
				NoLayerSelectedNotificationItem->SetText(FText::FromString("Any changes to layers will not take effect"
					" because no layers are selected."));
			}
			else
			{
				OnDismissNoLayersNotification();
				if (!LayerMutedNotificationItem.IsValid())
				{
					FNotificationInfo Info(FText::GetEmpty());
					Info.bFireAndForget = false;
					Info.ExpireDuration = 0;
					Info.FadeOutDuration = 0.1f;
					Info.ButtonDetails.Add(FNotificationButtonInfo(
						FText::FromString("Dismiss"),
						FText(),
						FSimpleDelegate::CreateSP(this, &SOmniverseInputProcessor::OnDismissLayerMutedNotification),
						SNotificationItem::CS_Fail
					));
					Info.ButtonDetails.Add(FNotificationButtonInfo(
						FText::FromString("Activate"),
						FText(),
						FSimpleDelegate::CreateSP(this, &SOmniverseInputProcessor::OnActivate),
						SNotificationItem::CS_Fail
					));

					LayerMutedNotificationItem = FSlateNotificationManager::Get().AddNotification(Info);
				}

				LayerMutedNotificationItem->SetCompletionState(SNotificationItem::CS_Fail);
				LayerMutedNotificationItem->SetText(FText::FromString("Could not work in an deactivated Layer. Would you like to activate this Layer?"));
			}

			return true;
		}
	}

	return false;
}
