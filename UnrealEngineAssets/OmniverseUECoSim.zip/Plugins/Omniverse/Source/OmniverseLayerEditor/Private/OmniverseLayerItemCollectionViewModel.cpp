// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseLayerItemCollectionViewModel.h"
#include "Editor/EditorEngine.h"
#include "Misc/FilterCollection.h"
#include "ScopedTransaction.h"
#include "OmniverseLayerItemViewModel.h"
#include "OmniversePrimItemViewModel.h"
#include "Framework/Commands/GenericCommands.h"

FOmniverseLayerItemCollectionViewModel::FOmniverseLayerItemCollectionViewModel(const TSharedRef<FOmniverseTreeSharedData>& InSharedData)
	: SharedData(InSharedData)
{
}

FOmniverseLayerItemCollectionViewModel::~FOmniverseLayerItemCollectionViewModel()
{
	SharedData->OnFilterChanged().RemoveAll(this);
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if(LayerDataSource)
		LayerDataSource->OnLayersChanged().RemoveAll(this);
}

void FOmniverseLayerItemCollectionViewModel::Initialize()
{
	bSelectionInitialized = false;
	SharedData->OnFilterChanged().RemoveAll(this);
	SharedData->OnFilterChanged().AddSP(this, &FOmniverseLayerItemCollectionViewModel::OnFilterChanged);
	SharedData->OnPreLayerDataSourceChanged().AddSP(this, &FOmniverseLayerItemCollectionViewModel::OnPreLayerDataSourceChanged);
	SharedData->OnPostLayerDataSourceChanged().AddSP(this, &FOmniverseLayerItemCollectionViewModel::OnPostLayerDataSourceChanged);
	OnPostLayerDataSourceChanged();
}

TArray<TSharedPtr<IOmniverseTreeItemViewModel>>& FOmniverseLayerItemCollectionViewModel::GetRootItems()
{ 
	return FilteredLayerViewModels;
}

TSharedPtr<FOmniverseLayerItemViewModel> FOmniverseLayerItemCollectionViewModel::GetSelectedLayer() const
{ 
	return SelectedLayer;
}

void FOmniverseLayerItemCollectionViewModel::SetSelectedLayer(const TSharedPtr<FOmniverseLayerItemViewModel>& InLayer)
{
	if (SelectedLayer != InLayer)
	{
		SelectedLayer = InLayer;

		OnSelectedLayerChanged().Broadcast();
	}
}

void FOmniverseLayerItemCollectionViewModel::SetAuthoredLayer(const TSharedPtr<FOmniverseLayerItemViewModel>& InLayer)
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		if (InLayer)
		{
			LayerDataSource->AuthorLayer(InLayer->GetDataSource());
		}
		else
		{
			LayerDataSource->AuthorLayer(nullptr);
		}
	}
}

void FOmniverseLayerItemCollectionViewModel::OnFilterChanged()
{
	RefreshFilteredLayers();
}

void FOmniverseLayerItemCollectionViewModel::OnLayersEventReceived(ELayersEventType EventType, UOmniverseLayer* InLayer, UOmniversePrim* InPrim)
{
	switch(EventType)
	{
	case ELayersEventType::LayerChanged:
		OnChangeLayer(InLayer);
		break;
	case ELayersEventType::PrimChanged:
		if (InPrim == nullptr)
		{
			// It's a root prim change
			OnChangeLayer(InLayer);
		}
		else
		{
			OnChangePrim(InLayer, InPrim);
		}
		break;

	case ELayersEventType::Reset:
	default:
		// TODO: handle fine-grained event to avoid reduant refresh
		OnResetLayers();
	}
}

void FOmniverseLayerItemCollectionViewModel::OnPreLayerDataSourceChanged()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->OnLayersChanged().RemoveAll(this);
	}
}

void FOmniverseLayerItemCollectionViewModel::OnPostLayerDataSourceChanged()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->OnLayersChanged().RemoveAll(this);
		LayerDataSource->OnLayersChanged().AddSP(this,
			&FOmniverseLayerItemCollectionViewModel::OnLayersEventReceived);
	}
	OnResetLayers();
}

void FOmniverseLayerItemCollectionViewModel::OnResetLayers()
{
	TArray<UOmniverseLayer*> ActualLayers;
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource)
	{
		LayerDataSource->AddAllLayersTo(ActualLayers);
	}

	DestructivelyPurgeInvalidViewModels(ActualLayers);

	//Rebuild the filtered layers list
	RefreshFilteredLayers();

	OnLayersChanged().Broadcast();
}

void FOmniverseLayerItemCollectionViewModel::OnChangeLayer(UOmniverseLayer* InLayer)
{
	auto ViewModels = AllLayerViewModels.Find(InLayer);
	if (ViewModels)
	{
		for (auto ViewModel : *ViewModels)
		{
			ViewModel->SetDataSource(InLayer);
		}

		OnLayersChanged().Broadcast();
	}
}

void FOmniverseLayerItemCollectionViewModel::OnChangePrim(UOmniverseLayer* InLayer, UOmniversePrim* InPrim)
{
	auto ViewModels = AllLayerViewModels.Find(InLayer);
	if (ViewModels)
	{
		for (auto ViewModel : *ViewModels)
		{
			ViewModel->SetPrimDataSource(InPrim);
		}

		OnLayersChanged().Broadcast();
	}
}

void FOmniverseLayerItemCollectionViewModel::DestructivelyPurgeInvalidViewModels(TArray<UOmniverseLayer*>& InLayers)
{
	if (InLayers.Num() == 0)
	{
		for (auto ViewModel : RootLayerViewModels)
		{
			Unregister(ViewModel);
		}
		RootLayerViewModels.Reset();
		SelectedLayer.Reset();
	}
	else
	{
		for (int LayerIndex = RootLayerViewModels.Num() - 1; LayerIndex >= 0; --LayerIndex)
		{
			const auto LayerViewModel = RootLayerViewModels[LayerIndex];
			const auto Layer = LayerViewModel->GetDataSource();

			//Remove any viewmodels with invalid datasources or whose datasources 
			//are no longer in the master list of layers
			bool bHasViewModel = false;
			for (int32 Index = 0; Index < InLayers.Num(); ++Index)
			{
				if (Layer->IsValid() && (InLayers[Index]->FullPath == Layer->FullPath))
				{
					// Update data source
					bHasViewModel = true;
					LayerViewModel->SetDataSource(InLayers[Index]);
					InLayers.RemoveAt(Index);
					break;
				}
			}

			if (!bHasViewModel)
			{
				Unregister(RootLayerViewModels[LayerIndex]);
				RootLayerViewModels.RemoveAt(LayerIndex);
			}
		}

		for (auto Layer : InLayers)
		{
			const TSharedRef<FOmniverseLayerItemViewModel> NewLayerViewModel = FOmniverseLayerItemViewModel::Create(this, Layer, SharedData);
			Register(NewLayerViewModel);
			RootLayerViewModels.Add(NewLayerViewModel);
		}
	}
}

void FOmniverseLayerItemCollectionViewModel::DeleteSelectedLayer()
{
	auto LayerDataSource = SharedData->GetLayerDataSource();
	if (LayerDataSource && SelectedLayer && SelectedLayer->CanEdit() && !SelectedLayer->GetDataSource()->bRootLayer)
	{
		if (SelectedLayer->GetParent() && SelectedLayer->GetParent()->IsOfType<FOmniverseLayerItemViewModel>())
		{
			auto ParentLayer = StaticCastSharedPtr<FOmniverseLayerItemViewModel>(SelectedLayer->GetParent());
			LayerDataSource->DeleteLayer(ParentLayer->GetDataSource(), SelectedLayer->GetDataSource());
		}
	}
}

void FOmniverseLayerItemCollectionViewModel::RefreshFilteredLayers()
{
	FilteredLayerViewModels.Empty();

	for(auto LayerIt = RootLayerViewModels.CreateIterator(); LayerIt; ++LayerIt)
	{
		const auto LayerViewModel = *LayerIt;
		if (LayerViewModel->PassesAllFilters())
		{
			FilteredLayerViewModels.Add(LayerViewModel);
		}
	}

	SortFilteredLayers();
	if (FilteredLayerViewModels.Num() > 0)
	{
		FilterLayerChanged.Broadcast();
	}
}

void FOmniverseLayerItemCollectionViewModel::SortFilteredLayers()
{
	struct FCompareLayers
	{
		FORCEINLINE bool operator()(const TSharedPtr<IOmniverseTreeItemViewModel>& Lhs, const TSharedPtr<IOmniverseTreeItemViewModel>& Rhs) const
		{
			const auto LhsLayer = StaticCastSharedPtr<FOmniverseLayerItemViewModel>(Lhs);
			const auto RhsLayer = StaticCastSharedPtr<FOmniverseLayerItemViewModel>(Rhs);
			return LhsLayer->GetTypeSortPriority() > RhsLayer->GetTypeSortPriority();
		}
	};

	FilteredLayerViewModels.Sort(FCompareLayers());
}

FName FOmniverseLayerItemCollectionViewModel::GenerateUniqueLayerName() const
{
	return FName(*FString::Printf(TEXT("Layer%d"), SharedData->GetLayerDataSource()->NumLayers() + 1));
}

void FOmniverseLayerItemCollectionViewModel::Register(TSharedPtr<FOmniverseLayerItemViewModel> LayerViewModel)
{
	auto ViewArrays = AllLayerViewModels.Find(LayerViewModel->GetDataSource());
	if (ViewArrays)
	{
		ViewArrays->Add(LayerViewModel);
	}
	else
	{
		AllLayerViewModels.Add(LayerViewModel->GetDataSource(), { LayerViewModel });
	}
}

void FOmniverseLayerItemCollectionViewModel::Unregister(TSharedPtr<FOmniverseLayerItemViewModel> LayerViewModel)
{
	auto ViewArrays = AllLayerViewModels.Find(LayerViewModel->GetDataSource());
	if (ViewArrays)
	{
		int32 Index = ViewArrays->Find(LayerViewModel);
		if (Index != INDEX_NONE)
		{
			ViewArrays->RemoveAt(Index);
		}
		if (ViewArrays->Num() == 0)
		{
			AllLayerViewModels.Remove(LayerViewModel->GetDataSource());
		}
	}
}