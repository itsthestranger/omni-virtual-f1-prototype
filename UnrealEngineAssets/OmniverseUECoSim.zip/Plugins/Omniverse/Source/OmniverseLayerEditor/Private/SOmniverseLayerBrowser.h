// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "InputCoreTypes.h"
#include "Layout/Visibility.h"
#include "Styling/SlateColor.h"
#include "Layout/Geometry.h"
#include "Input/Reply.h"
#include "Widgets/SWidget.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "EditorStyleSet.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Layout/SSeparator.h"
#include "Misc/TextFilter.h"
#include "DragAndDrop/ActorDragDropGraphEdOp.h"
#include "OmniverseLayerDataSource.h"
#include "SOmniverseInputProcessor.h"
#include "SOmniverseLayersView.h"

typedef TTextFilter<const TSharedPtr<IOmniverseTreeItemViewModel>&> LayerTextFilter;

class SOmniverseLayerBrowser : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SOmniverseLayerBrowser) {}
	SLATE_END_ARGS()

	~SOmniverseLayerBrowser();

	void Construct(const FArguments& InArgs);

	virtual void OnMouseLeave(const FPointerEvent& MouseEvent) override;

	TSharedPtr<FOmniverseLayerItemViewModel> GetSelectedLayer() const
	{
		return LayerCollectionViewModel->GetSelectedLayer();
	}

	void SetSelectedLayer(const TSharedPtr<FOmniverseLayerItemViewModel>& Layer)
	{
		LayerCollectionViewModel->SetSelectedLayer(Layer);
	}

	TSharedRef<FOmniverseTreeSharedData> GetSharedData() const
	{
		return SharedData.ToSharedRef();
	}

	void DeleteSelectedPrims();

private:
	FSlateColor GetInvertedForegroundIfHovered() const
	{
		//static const FName InvertedForegroundName("InvertedForeground");
		//bool Hovered = (NewLayerButton.IsValid() && (NewLayerButton->IsHovered() || NewLayerButton->IsPressed()))
		//	|| (DeleteLayerButton.IsValid() && (DeleteLayerButton->IsHovered() || DeleteLayerButton->IsPressed()));
		return FSlateColor::UseForeground();
	}

	const FSlateBrush* GetNewLayerButtonImageBrush() const
	{
		static const FName NewLayerButtonBrush("LevelEditor.NewLevel");
		return FAppStyle::GetBrush(NewLayerButtonBrush);
	}

	const FSlateBrush* GetDeleteButtonImageBrush() const
	{
		static const FName DeleteLayerButtonBrush("LevelScript.Delete");
		return FAppStyle::GetBrush(DeleteLayerButtonBrush);
	}

	EVisibility GetLayerContentsHeaderVisibility() const
	{
		return EVisibility::Visible;
	}

	FReply DeleteLayer();

	void SetupLayersMode() 
	{
		ContentAreaBox->ClearChildren();
		ContentAreaBox->AddSlot()
		.FillHeight(1.0f)
		[
			LayersSection.ToSharedRef()
		];

		// Separator
		ContentAreaBox->AddSlot()
		.AutoHeight()
		.Padding(0, 0, 0, 1)
		[
			SNew(SSeparator)
		];

		ContentAreaBox->AddSlot()
		.AutoHeight()
		.VAlign(VAlign_Bottom)
		.MaxHeight(64)
		[
			LayerContentsHeader.ToSharedRef()
		];
	}

	void TransformLayerToString(const TSharedPtr<IOmniverseTreeItemViewModel>& Layer, OUT TArray<FString>& OutSearchStrings) const
	{
		if(!Layer.IsValid())
		{
			return;
		}

		OutSearchStrings.Add(Layer->GetDisplayString());
	}
	
	/** Callback when layers want to be renamed */
	void OnRenameRequested()
	{
		LayersView->RequestRenameOnSelectedLayer();
	}

	TSharedPtr<SWidget> ConstructLayerContextMenu();

	void OnFilterTextChanged(const FText& InNewText);

	void OnLayerDataSourceChanged(const TSharedPtr<IOmniverseLayerDataSource>& InLayerDataSource);

	void OnMutenessScopeChanged(ECheckBoxState InState);
	ECheckBoxState IsGlobalMutenessEnabled() const;

	void BindCommands();

	void DeletePrims_Executed();

	bool DeletePrims_CanExecute() const;

private:
	TSharedPtr<SButton> NewLayerButton;

	TSharedPtr<SButton> DeleteLayerButton;

	TSharedPtr<SVerticalBox> ContentAreaBox;

	TSharedPtr<SBorder> LayersSection;

	TSharedPtr<SBorder> LayerContentsHeader;

	TSharedPtr<class SSearchBox> SearchBoxPtr;

	TSharedPtr<class SCheckBox> MutenessScopeSwitch;

	TSharedPtr<LayerTextFilter> SearchBoxLayerFilter;

	TSharedPtr<FOmniverseLayerItemCollectionViewModel> LayerCollectionViewModel;

	TSharedPtr<SOmniverseLayersView> LayersView;

	TSharedPtr<FOmniverseTreeSharedData> SharedData;

	TSharedPtr<SOmniverseInputProcessor> InputProcessor;

	TSharedPtr<FUICommandList> CommandList;
};
