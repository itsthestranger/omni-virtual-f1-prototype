// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleInterface.h"
#include "Framework/Commands/UICommandList.h"
#include "Framework/MultiBox/MultiBoxExtender.h"
#include "OmniverseLayerDataSource.h"
#include "Modules/ModuleManager.h"

class FOmniverseLayerEditorModule : public IModuleInterface
{
public:

	virtual void StartupModule();

	virtual void ShutdownModule();

	static inline FOmniverseLayerEditorModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FOmniverseLayerEditorModule>("OmniverseLayerEditor");
	}
};
