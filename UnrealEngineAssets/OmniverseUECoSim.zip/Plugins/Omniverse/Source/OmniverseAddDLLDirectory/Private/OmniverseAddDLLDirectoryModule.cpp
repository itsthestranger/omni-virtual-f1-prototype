// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "HAL/PlatformProcess.h"
#include "GenericPlatform/GenericPlatformMisc.h"
#include "Misc/Paths.h"
#include "Modules/ModuleManager.h"
#include "Interfaces/IPluginManager.h"

class OMNIVERSEADDDLLDIRECTORY_API FOmniverseAddDLLDirectoryModule : public IModuleInterface
{
public:
	virtual void StartupModule() override
	{
#ifdef _WIN64
#ifdef _DEBUG
		const FString Config = "win64_debug";
#else
		const FString Config = "win64_release";
#endif
#endif
		const FString BaseDir = IPluginManager::Get().FindPlugin("Omniverse")->GetBaseDir() / "ThirdParty";

		FPlatformProcess::AddDllDirectory(*(BaseDir / "omni_client_library" / Config / "release"));
		FPlatformProcess::AddDllDirectory(*(BaseDir / "usd" / Config / "lib"));
		FPlatformProcess::AddDllDirectory(*(BaseDir / "omni_usd_resolver" / Config / "release"));

#if WITH_USD_PHYSICS
		FPlatformProcess::AddDllDirectory(*(BaseDir / "usd_ext_physics" / Config / "lib"));

		// Set the PXR_PLUGINPATH_NAME environment variable so that the Physics/PhysX schema plugin info files can be found by USD
		FString PluginPaths;
		PluginPaths += FPaths::ConvertRelativePathToFull(BaseDir) / "usd_ext_physics" / Config / "share/usd/plugins/PhysxSchema/resources;";
		PluginPaths += FPaths::ConvertRelativePathToFull(BaseDir) / "usd_ext_physics" / Config / "share/usd/plugins/UsdPhysics/resources";
		PluginPaths.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);
		FPlatformMisc::SetEnvironmentVar(TEXT("PXR_PLUGINPATH_NAME"), *PluginPaths);
#endif //WITH_USD_PHYSICS
	}

	virtual void ShutdownModule() override
	{
	}
};

IMPLEMENT_MODULE(FOmniverseAddDLLDirectoryModule, OmniverseAddDLLDirectory)
