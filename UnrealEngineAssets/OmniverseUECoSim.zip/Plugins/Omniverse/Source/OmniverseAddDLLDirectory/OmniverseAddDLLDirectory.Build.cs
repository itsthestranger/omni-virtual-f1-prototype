// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

using System.IO;

namespace UnrealBuildTool.Rules
{
	public class OmniverseAddDLLDirectory : ModuleRules
	{
		public OmniverseAddDLLDirectory(ReadOnlyTargetRules Target) : base(Target)
		{
			PrivateDependencyModuleNames.Add("Core");
			PrivateDependencyModuleNames.Add("Projects");
			PublicDefinitions.Add("WITH_USD_PHYSICS=0");
		}
	}
}
