// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

using System.IO;

namespace UnrealBuildTool.Rules
{
	public class OmniverseUSD : ModuleRules
	{		
        public OmniverseUSD(ReadOnlyTargetRules Target) : base(Target)
		{
			bUseRTTI = true;    // For USD
			PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;    // For game module
			bEnableExceptions = true;   // For game build

            PrivateIncludePathModuleNames.AddRange(
                new string[] {
                "Foliage",
                }
            );

            PrivateDependencyModuleNames.AddRange(
				new string[]
				{
					"Core",
					"Engine",
					"CoreUObject",
					"OmniverseRuntime",
					"MeshDescription",
					"RenderCore",
					"DerivedDataCache",
					"SlateCore",
                    "MeshUtilitiesCommon",
                    "MeshUtilities",
                    "Landscape",
					"StaticMeshDescription",
					"MaterialBaking",
                    "LevelSequence",
                    "MovieScene",
                    "MovieSceneTracks",
					"AnimGraphRuntime",
					"ActorSequence",
					"Projects",
					"UnrealUSDWrapper",
					"USDClasses",
					"USDUtilities"
				}
			);

			AddEngineThirdPartyPrivateStaticDependencies(Target, "MikkTSpace");

			if (Target.Type == TargetType.Editor)
			{
				PrivateDependencyModuleNames.AddRange(
					new string[]
					{
						"RawMesh",
						"MeshDescriptionOperations",
						"UnrealEd",
						"EditorFramework",
						"CinematicCamera",
                        "LevelEditor",
                        "LevelSequenceEditor",
                        "Sequencer",
						"ContentBrowser",
					}
				);
			}

			PublicDefinitions.Add("WITH_USD_PHYSICS=0");
			// Uncomment below if settings WITH_USD_PHYSICS=1
			//string UsdExtPhyscisPath = Path.Combine(ModuleDirectory, "../../ThirdParty/usd_ext_physics/win64_release");
			//PrivateIncludePaths.Add(Path.Combine(UsdExtPhyscisPath, "include"));
			//foreach(var LibName in new string[] { "physxSchema", "usdPhysics" })
			//{
			//	var FileName = LibName + ".lib";
			//	PublicAdditionalLibraries.Add(Path.Combine(UsdExtPhyscisPath, "lib", FileName));
			//}
		}
	}
}