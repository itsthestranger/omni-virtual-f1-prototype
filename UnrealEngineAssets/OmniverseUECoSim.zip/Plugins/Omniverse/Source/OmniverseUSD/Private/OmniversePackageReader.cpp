// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniversePackageReader.h"
#include "OmniversePxr.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseFileHandle.h"

bool FOmniversePackageReader::FileExists(const FString& InPath, const FString& InMask)
{
	pxr::ArResolver& resolver = pxr::ArGetResolver();
	auto PackageFullPath = InPath + "[" + InMask + "]";

#if !defined(AR_VERSION) || AR_VERSION < 2
	auto Asset = resolver.OpenAsset(TCHAR_TO_UTF8(*PackageFullPath));
#else
	auto Asset = resolver.OpenAsset(pxr::ArResolvedPath(TCHAR_TO_UTF8(*PackageFullPath)));
#endif // AR_VERSION < 2

	if (Asset && Asset->GetSize() > 0)
	{
		return true;
	}

	FString FullPath = InPath;
	if (!InMask.IsEmpty())
	{
		FullPath = InPath / InMask;
	}
	FOmniverseListFileResult FileResult;
	bool bFound = FOmniverseConnectionHelper::ListFileSync(FullPath, FileResult);

	return bFound;
}
	
IFileHandle* FOmniversePackageReader::OpenRead(const FString& InPath)
{
	if (InPath.StartsWith(PackageRoot, ESearchCase::CaseSensitive))
	{
		auto PackageFullPath = InPath;
		PackageFullPath.RemoveAt(PackageRoot.Len());
		PackageFullPath.InsertAt(PackageRoot.Len(), "[");
		PackageFullPath.Append("]");
		pxr::ArResolver& resolver = pxr::ArGetResolver();

#if !defined(AR_VERSION) || AR_VERSION < 2
		auto Asset = resolver.OpenAsset(TCHAR_TO_UTF8(*PackageFullPath));
#else
		auto Asset = resolver.OpenAsset(pxr::ArResolvedPath(TCHAR_TO_UTF8(*PackageFullPath)));
#endif // AR_VERSION < 2
		
		if (Asset && Asset->GetSize() > 0)
		{
			OmniClientContent Content;
			Content.buffer = new uint8[Asset->GetSize()];
			Content.size = Asset->GetSize();
			Content.free = [](void* buffer) 
			{ 
				delete (uint8*)buffer;
			};

			Asset->Read(Content.buffer, Content.size, 0);
			return new FOmniverseFileHandle(TSharedOmniContentPtr(new FOmniverseContent(Content)));
		}
	}
	else
	{
		TSharedOmniContentPtr Content;
		if (FOmniverseConnectionHelper::ReadSync(InPath, Content))
		{
			return new FOmniverseFileHandle(Content);
		}
	}

	return nullptr;

}
