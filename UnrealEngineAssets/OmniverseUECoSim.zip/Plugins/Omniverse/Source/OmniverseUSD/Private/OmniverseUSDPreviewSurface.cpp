// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "CoreMinimal.h"
#include "OmniverseUSD.h"
#include "OmniverseUSDLog.h"
#include "OmniverseUSDTokens.h"
#include "USDConverter.h"
#include "OmniverseSettings.h"
#include "OmniverseStageActor.h"
#include "OmniverseTexture.h"
#include "OmniverseAssetUserData.h"
#include "OmniversePathHelper.h"
#include "OmniverseAssetExportHelper.h"
#include "Components/MeshComponent.h"
#include "Containers/ArrayBuilder.h"
#include "Materials/MaterialInstanceConstant.h"
#include "IMaterialEditor.h"
#include "MaterialEditor/MaterialEditorInstanceConstant.h"
#include "MaterialEditorInstanceNotifier.h"
#include "USDHashGenerator.h"
#include "USDGeometryCache.h"
#include "OmniverseAssetImportHelper.h"
#include "OmniverseUSDImporterHelper.h"
#include "IOmniverseRuntimeModule.h"

void UpdateStaticParameters(class UMaterialInstanceConstant* MaterialInst, const TMap<FName, bool>* SwitchParameters, const TMap<FName, FStaticComponentMask>* ComponentMaskParameters)
{
	if (!SwitchParameters && !ComponentMaskParameters)
	{
		return;
	}

	FStaticParameterSet OutStaticParameters;
	MaterialInst->GetStaticParameterValues(OutStaticParameters);

	bool bUpdateStatic = false;

	if (SwitchParameters)
	{
		for (auto& StaticSwitchParameter : OutStaticParameters.EditorOnly.StaticSwitchParameters)
		{
			for (const TPair<FName, bool>& Pair : *SwitchParameters)
			{
				if (Pair.Key == StaticSwitchParameter.ParameterInfo.Name)
				{
					if (StaticSwitchParameter.Value != Pair.Value)
					{
						StaticSwitchParameter.Value = Pair.Value;
						StaticSwitchParameter.bOverride = Pair.Value;
						bUpdateStatic = true;
					}
				}
			}
		}
	}

	if (ComponentMaskParameters)
	{
		for (auto& StaticComponentMaskParameter : OutStaticParameters.EditorOnly.StaticComponentMaskParameters)
		{
			for (const TPair<FName, FStaticComponentMask>& Pair : *ComponentMaskParameters)
			{
				if (Pair.Key == StaticComponentMaskParameter.ParameterInfo.Name)
				{
					if (StaticComponentMaskParameter.R != Pair.Value.R
					|| StaticComponentMaskParameter.G != Pair.Value.G
					|| StaticComponentMaskParameter.B != Pair.Value.B
					|| StaticComponentMaskParameter.A != Pair.Value.A)
					{
						StaticComponentMaskParameter.R = Pair.Value.R;
						StaticComponentMaskParameter.G = Pair.Value.G;
						StaticComponentMaskParameter.B = Pair.Value.B;
						StaticComponentMaskParameter.A = Pair.Value.A;
						StaticComponentMaskParameter.bOverride = true;
						bUpdateStatic = true;
					}				
				}
			}
		}
	}

	if (bUpdateStatic)
	{
		FlushRenderingCommands();
		MaterialInst->UpdateStaticPermutation(OutStaticParameters);
	}
}

bool AOmniverseStageActor::IsPreviewSurface(UMaterialInstanceConstant* MaterialInst)
{
	UMaterial* PreviewSurfaceMaterial = LoadObject<UMaterial>(nullptr, TEXT("/Omniverse/PreviewSurfaceMaterial"));

	return (MaterialInst->Parent && PreviewSurfaceMaterial == MaterialInst->Parent);
}

bool AOmniverseStageActor::LoadPreviewSurface(UMeshComponent* Component, int32 SlotIndex, const pxr::UsdGeomMesh& USDMesh, const pxr::UsdShadeShader& ShadeShader)
{
	if (!ShadeShader)
	{
		return false;
	}

	FString ShaderPath = ShadeShader.GetPath().GetText();

	auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(ShaderPath));
	if (Object && Object->IsValid())
	{
		if (Component)
		{
			SetMaterial(*Component, SlotIndex, Cast<UMaterialInstanceConstant>(Object->Get()));
		}
		return true;
	}

	auto USDMaterial = FindShadeMaterial(ShadeShader.GetPrim());
	if (!USDMaterial)
	{
		return false;
	}

	FString MaterialName = USDMaterial.GetPrim().GetName().GetText();
	FString Key;
	if (HasValidImportStage())
	{
		Key = FUSDHashGenerator::ComputeSHAHash(USDMaterial).ToString();
	}
	UMaterialInstanceConstant* MaterialInst = nullptr;
	MaterialName = GetUniqueImportName(Key, MaterialName);
	UE_LOG(LogOmniverseUsd, Log, TEXT("Loading preview surface material [%s]"), *MaterialName);
	if (HasValidImportStage())
	{
		MaterialInst = Cast<UMaterialInstanceConstant>(FUSDGeometryCache::Find(Key));
	}
	if (MaterialInst == nullptr)
	{
		MaterialInst = LoadImportObject<UMaterialInstanceConstant>(ImportType::Material, MaterialName);	
		if (MaterialInst == nullptr)
		{
			MaterialInst = NewObject<UMaterialInstanceConstant>(GetAssetPackage(ImportType::Material, MaterialName), GetAssetName(MaterialName), GetAssetFlag());
			if (!MaterialInst)
			{
				return false;
			}

			UMaterial* PreviewSurfaceMaterial = LoadObject<UMaterial>(nullptr, TEXT("/Omniverse/PreviewSurfaceMaterial"));
			MaterialInst->SetParentEditorOnly(PreviewSurfaceMaterial);

			// collect UVSets map for the current geometry mesh.
			TMap<FString, int32> UVSets;
			if (USDMesh)
			{
				int32 UVCount = 0;
				auto Primvars = pxr::UsdGeomPrimvarsAPI(USDMesh).GetPrimvars();
				for (auto Iter = Primvars.begin(); Iter != Primvars.end(); ++Iter)
				{
					auto PrimVar = *Iter;

					// Texture UV
					if (PrimVar.GetTypeName().GetCPPTypeName().compare(pxr::SdfValueTypeNames->Float2Array.GetCPPTypeName()) == 0)
					{
						const pxr::UsdAttribute& Attr = PrimVar.GetAttr();
						pxr::VtValue CustomData = Attr.GetCustomDataByKey(pxr::TfToken("Maya"));

						int32 UVIndex = -1;
						if (!CustomData.IsEmpty() && CustomData.IsHolding<pxr::VtDictionary>()) {
							pxr::VtDictionary NewDict = CustomData.UncheckedGet<pxr::VtDictionary>();
							pxr::VtDictionary::iterator Itor = NewDict.find("UVSetIndex");
							if (Itor != NewDict.end())
							{
								UVIndex = Itor->second.Get<int32>();
							}
						}

						// If can't find custom index, still use the output index.
						if (UVIndex < 0)
						{
							UVIndex = UVCount++;
						}

						UVSets.Add(PrimVar.GetBaseName().GetText(), UVIndex);
					}
				}
			}

			FOmniverseUSDImporterHelper::UpdatePreviewSurfaceInputs(MaterialInst, ShadeShader, &UVSets,
			[&](const FString& PrimName)
			{
				USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(PrimName), MaterialInst);
			},
			[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
			{
				CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
			},
			[&](FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
			{
				LoadOmniTexture(TexturePath, OutTexture, OutOmniTexture);
			},
			[&](UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
			{
				PostLoadOmniTexture(InTextureAsset, InTexture, OverrideSRGB);
			});

			MaterialInst->PostEditChange();
			MaterialInst->MarkPackageDirty();
			if (HasValidImportStage())
			{
				FOmniverseAssetImportHelper::UpdateAssetImportData(MaterialInst, ImportUSDSourceFile, ShaderPath);		
				FAssetRegistryModule::AssetCreated(MaterialInst);
			}
		}

		if (HasValidImportStage())
		{
			FUSDGeometryCache::Add(Key, MaterialInst);
		}
	}

	if (MaterialInst)
	{
		USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(ShaderPath), MaterialInst);
		if (Component)
		{
			SetMaterial(*Component, SlotIndex, MaterialInst);
		}
	}

	return true;
}

void FUSDExporter::ExportPreviewSurface(const pxr::UsdStageRefPtr& Stage, UMaterialInstance& MaterialInst, pxr::UsdShadeShader& ShadeShader)
{
	if (!ShadeShader)
	{
		return;
	}

	const TArray<FString> PSInputNames = TArrayBuilder<FString>()
		.Add(FString(TEXT("diffuseColor")))
		.Add(FString(TEXT("emissiveColor")))
		.Add(FString(TEXT("useSpecularWorkflow")))
		.Add(FString(TEXT("specularColor")))
		.Add(FString(TEXT("metallic")))
		.Add(FString(TEXT("roughness")))
		.Add(FString(TEXT("clearcoat")))
		.Add(FString(TEXT("clearcoatRoughness")))
		.Add(FString(TEXT("opacity")))
		.Add(FString(TEXT("opacityThreshold")))
		.Add(FString(TEXT("ior")))
		.Add(FString(TEXT("normal")))
		.Add(FString(TEXT("displacement")))
		.Add(FString(TEXT("occlusion")));

	const TArray<pxr::SdfValueTypeName> PSInputTypes = TArrayBuilder<pxr::SdfValueTypeName>()
		.Add(pxr::SdfValueTypeNames->Color3f) //diffuseColor
		.Add(pxr::SdfValueTypeNames->Color3f) //emissiveColor
		.Add(pxr::SdfValueTypeNames->Int) //useSpecularWorkflow
		.Add(pxr::SdfValueTypeNames->Color3f) //specularColor
		.Add(pxr::SdfValueTypeNames->Float) //metallic
		.Add(pxr::SdfValueTypeNames->Float) //roughness
		.Add(pxr::SdfValueTypeNames->Float) //clearcoat
		.Add(pxr::SdfValueTypeNames->Float) //clearcoatRoughness
		.Add(pxr::SdfValueTypeNames->Float) //opacity
		.Add(pxr::SdfValueTypeNames->Float) //opacityThreshold
		.Add(pxr::SdfValueTypeNames->Float) //ior
		.Add(pxr::SdfValueTypeNames->Normal3f) //normal
		.Add(pxr::SdfValueTypeNames->Float) //displacement
		.Add(pxr::SdfValueTypeNames->Float); //occlusion

	const auto ShaderID = GetUSDValue<pxr::TfToken>(ShadeShader.GetIdAttr());
	if (ShaderID == USDTokens.previewSurface)
	{
		for (auto ScalarParameter : MaterialInst.ScalarParameterValues)
		{
			for (int32 InputIndex = 0 ; InputIndex < PSInputNames.Num(); ++InputIndex)
			{
				auto InputName = PSInputNames[InputIndex];
				FString ScalarInputName = ScalarParameter.ParameterInfo.Name.ToString();
				if (ScalarInputName.StartsWith(InputName))
				{
					FString Property = ScalarInputName.RightChop(InputName.Len());
					if (Property.IsEmpty())
					{
						float TextureEnabled;
						if (MaterialInst.GetScalarParameterValue(*(ScalarInputName + TEXT("Texture")), TextureEnabled) && TextureEnabled == 0.0f)
						{
							auto Input = ShadeShader.GetInput(pxr::TfToken(TCHAR_TO_ANSI(*InputName)));
							if (Input && Input.HasConnectedSource())
							{
								Input.DisconnectSource();
							}
							ExportParameter<float>(PSInputTypes[InputIndex], InputName, ShadeShader, ScalarParameter.ParameterValue);
						}
					}
				}
			}
		}
	
		for (auto VectorParameter : MaterialInst.VectorParameterValues)
		{
			for (int32 InputIndex = 0 ; InputIndex < PSInputNames.Num(); ++InputIndex)
			{
				auto InputName = PSInputNames[InputIndex];
				FString VectorInputName = VectorParameter.ParameterInfo.Name.ToString();
				if (VectorInputName.StartsWith(InputName))
				{	
					FString Property = VectorInputName.RightChop(InputName.Len());				
					if (Property.IsEmpty())
					{
						float TextureEnabled;
						if (MaterialInst.GetScalarParameterValue(*(VectorInputName + TEXT("Texture")), TextureEnabled) && TextureEnabled == 0.0f)
						{
							auto Input = ShadeShader.GetInput(pxr::TfToken(TCHAR_TO_ANSI(*InputName)));
							if (Input && Input.HasConnectedSource())
							{
								Input.DisconnectSource();
							}
							ExportParameter<pxr::GfVec4f>(PSInputTypes[InputIndex], InputName, ShadeShader, LinearColorToVec(VectorParameter.ParameterValue));
						}
					}
				}
			}
		}
	
		for (auto TextureParameter : MaterialInst.TextureParameterValues)
		{
			UTexture* Texture = TextureParameter.ParameterValue;
			if (Texture)
			{
				for (int32 InputIndex = 0 ; InputIndex < PSInputNames.Num(); ++InputIndex)
				{
					auto InputName = PSInputNames[InputIndex];
					FString TextureInputName = TextureParameter.ParameterInfo.Name.ToString();
					if (TextureInputName.StartsWith(InputName))
					{
						FString Property = TextureInputName.RightChop(InputName.Len());
						if (Property.IsEmpty())
						{
							float TextureEnabled;
							if (!MaterialInst.GetScalarParameterValue(*(TextureInputName + TEXT("Texture")), TextureEnabled))
							{
								continue;
							}

							if (TextureEnabled == 0.0f)
							{
								continue;
							}

							FString TexturePath;		
							UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(Texture->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
							if (OmniverseAssetUserData && OmniverseAssetUserData->OmniAsset)
							{
								UOmniverseTexture* OmniverseTexture = CastChecked<UOmniverseTexture>(OmniverseAssetUserData->OmniAsset);
								TexturePath = MakeAssetPathRelative(OmniverseTexture->GetOmniPath(), *Stage).c_str();
							}
							// Do not upload the texture from mdl and omniverse content, they meant empty texture for mdl
							else if (IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled() && Texture->GetOutermost() != GetTransientPackage() && !Texture->GetOutermost()->GetName().StartsWith(TEXT("/MDL/")) && !Texture->GetOutermost()->GetName().StartsWith(TEXT("/Omniverse/")))
							{
								// Need uploading UE4 texture to server
								FString TextureFileName = FOmniverseAssetExportHelper::GetTextureFileName(Texture);
								auto LayerPath = (*Stage).GetEditTarget().GetLayer()->GetRealPath().c_str();
								FString OmniPath = FPaths::GetPath(LayerPath) / TextureFileName;
								TexturePath = TEXT("./") + TextureFileName;				
								FOmniverseAssetExportHelper::ExportTextureToPath(Texture, OmniPath);
							}

							auto PropertyInput = ShadeShader.GetInput(pxr::TfToken(TCHAR_TO_ANSI(*TextureInputName)));
							if (!PropertyInput)
							{
								PropertyInput = ShadeShader.CreateInput(pxr::TfToken(TCHAR_TO_ANSI(*TextureInputName)), PSInputTypes[InputIndex]);
							}

							pxr::UsdShadeShader TextureShader;
							if (PropertyInput && PropertyInput.HasConnectedSource())
							{
								pxr::UsdShadeConnectableAPI Source;
								pxr::TfToken SourceName;
								pxr::UsdShadeAttributeType SourceType;
								PropertyInput.GetConnectedSource(&Source, &SourceName, &SourceType);
								TextureShader = pxr::UsdShadeShader(Source);
							}
							else // Can't find texture shader, create one
							{
								auto TextureShaderPath = ShadeShader.GetPath().GetParentPath().AppendElementString(pxr::TfMakeValidIdentifier(TCHAR_TO_ANSI(*(TextureInputName+TEXT("Tex")))));
								TextureShader = pxr::UsdShadeShader::Define(Stage, TextureShaderPath);
							}
				
							if (TextureShader)
							{
								// ID
								TextureShader.SetShaderId(USDTokens.uvTexture);

								// File
								auto FileInput = TextureShader.GetInput(USDTokens.file);
								if (!FileInput)
								{
									FileInput = TextureShader.CreateInput(USDTokens.file, pxr::SdfValueTypeNames->Asset);
								}
								FileInput.Set(pxr::SdfAssetPath(TCHAR_TO_ANSI(*TexturePath)));

								// ColorSpace
								auto ColorSpaceInput = TextureShader.GetInput(USDTokens.sourceColorSpace);
								if (!ColorSpaceInput)
								{
									ColorSpaceInput = TextureShader.CreateInput(USDTokens.sourceColorSpace, pxr::SdfValueTypeNames->Token);										
								}							
								ColorSpaceInput.Set(Texture->SRGB ? USDTokens.sRGB : USDTokens.raw);

								// Scale
								FLinearColor TextureScale;
								if (MaterialInst.GetVectorParameterValue(*(TextureInputName + TEXT("TextureScale")), TextureScale))
								{
									auto ScaleInput = TextureShader.GetInput(pxr::TfToken("scale"));
									if (!ScaleInput)
									{
										ScaleInput = TextureShader.CreateInput(pxr::TfToken("scale"), pxr::SdfValueTypeNames->Float4);
									}
									ScaleInput.Set(LinearColorToVec(TextureScale));
								}

								// Bias
								FLinearColor TextureBias;
								if (MaterialInst.GetVectorParameterValue(*(TextureInputName + TEXT("TextureBias")), TextureBias))
								{
									auto BiasInput = TextureShader.GetInput(pxr::TfToken("bias"));
									if (!BiasInput)
									{
										BiasInput = TextureShader.CreateInput(pxr::TfToken("bias"), pxr::SdfValueTypeNames->Float4);
									}
									BiasInput.Set(LinearColorToVec(TextureBias));
								}

								// ST
								float TextureUV;
								if (MaterialInst.GetScalarParameterValue(*(TextureInputName + TEXT("UV")), TextureUV))
								{
									auto STInput = TextureShader.GetInput(USDTokens.st);

									if (!STInput)
									{
										STInput = TextureShader.CreateInput(USDTokens.st, pxr::SdfValueTypeNames->Float2);
									}

									pxr::UsdShadeShader STShader;
									if (STInput && STInput.HasConnectedSource())
									{
										pxr::UsdShadeConnectableAPI Source;
										pxr::TfToken SourceName;
										pxr::UsdShadeAttributeType SourceType;
										STInput.GetConnectedSource(&Source, &SourceName, &SourceType);
										STShader = pxr::UsdShadeShader(Source);
									}
									else // Can't find st shader, create one
									{
										FString STShaderName = TextureUV != 0.0f ? TEXT("PrimvarSt1") : TEXT("PrimvarSt");
										auto STShaderPath = ShadeShader.GetPath().GetParentPath().AppendElementString(pxr::TfMakeValidIdentifier(TCHAR_TO_ANSI(*STShaderName)));
										STShader = pxr::UsdShadeShader::Define(Stage, STShaderPath);
									}

									if (STShader)
									{
										STShader.SetShaderId(pxr::TfToken("UsdPrimvarReader_float2"));

										// varname
										auto VarnameInput = STShader.GetInput(USDTokens.varname);
										if (!VarnameInput)
										{
											VarnameInput = STShader.CreateInput(USDTokens.varname, pxr::SdfValueTypeNames->Token);
										}
										FString UVSetName = pxr::UsdUtilsGetPrimaryUVSetName().GetText();
										VarnameInput.Set(TextureUV == 1.0f ? pxr::TfToken(TCHAR_TO_ANSI(*(UVSetName + TEXT("1")))) : pxr::UsdUtilsGetPrimaryUVSetName());

										// st output
										auto Output = STShader.GetOutput(USDTokens.result);
										if (!Output)
										{
											Output = STShader.CreateOutput(USDTokens.result, pxr::SdfValueTypeNames->Float2);
										}

										if (Output)
										{
											STInput.ConnectToSource(Output);
										}
									}
								}

								// Output
								pxr::UsdShadeOutput Output;
								float TextureMask;
								if (MaterialInst.GetScalarParameterValue(*(TextureInputName + TEXT("Mask")), TextureMask))
								{								
									if (TextureMask == 1.0f)
									{
										Output = TextureShader.GetOutput(pxr::TfToken("g"));
										if (!Output)
										{
											Output = TextureShader.CreateOutput(pxr::TfToken("g"), pxr::SdfValueTypeNames->Float);
										}
									}
									else if (TextureMask == 2.0f)
									{
										Output = TextureShader.GetOutput(pxr::TfToken("b"));
										if (!Output)
										{
											Output = TextureShader.CreateOutput(pxr::TfToken("b"), pxr::SdfValueTypeNames->Float);
										}
									}
									else if (TextureMask == 3.0f)
									{
										Output = TextureShader.GetOutput(pxr::TfToken("a"));
										if (!Output)
										{
											Output = TextureShader.CreateOutput(pxr::TfToken("a"), pxr::SdfValueTypeNames->Float);
										}
									}
									else
									{
										Output = TextureShader.GetOutput(pxr::TfToken("r"));
										if (!Output)
										{
											Output = TextureShader.CreateOutput(pxr::TfToken("r"), pxr::SdfValueTypeNames->Float);
										}
									}								
								}
								else
								{
									Output = TextureShader.GetOutput(pxr::TfToken("rgb"));
									if (!Output)
									{
										Output = TextureShader.CreateOutput(pxr::TfToken("rgb"), pxr::SdfValueTypeNames->Float3);
									}
								}

								if (Output)
								{
									PropertyInput.ConnectToSource(Output);
								}
							}
						}
					}
				}
			}
		}
	}
}