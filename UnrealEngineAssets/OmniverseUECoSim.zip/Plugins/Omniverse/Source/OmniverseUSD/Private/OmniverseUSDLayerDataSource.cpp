// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseUSDLayerDataSource.h"
#include "Misc/Paths.h"
#include "Misc/MessageDialog.h"
#include "EngineUtils.h"
#include "Engine/World.h"
#include "Engine/Selection.h"
#include "OmniverseStageActor.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseNotificationHelper.h"
#include "IOmniverseCollaboration.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseUSDLog.h"
#include "OmniversePathHelper.h"
#include "USDConverter.h"
#include "GenericPlatform/GenericPlatformProcess.h"
#include <pxr/usd/sdf/layerUtils.h>

#if WITH_EDITOR
#include "ScopedTransaction.h"
#include "Editor/EditorEngine.h"
#include "Editor/TransBuffer.h"
#include "OmniverseTransaction.h"

extern UNREALED_API class UEditorEngine* GEditor;
#endif

#define OMNI_ROOT_LAYER 0xFFFFFFFF

FOmniverseUSDLayerDataSource::FOmniverseUSDLayerDataSource(pxr::UsdStageRefPtr USDStage)
	: /*USDStage(USDStage), */bInApplyingLayerState(false), bInMemoryStage(false)
{
	// Setup transaction
    TransactionObject.Reset(NewObject<UOmniverseTransaction>(GetTransientPackage(), NAME_None, EObjectFlags::RF_Transactional));
}

void FOmniverseUSDLayerDataSource::Initialize()
{
	bGlobalMuteness = false;
	AuthoringLayerData = nullptr;
}

void FOmniverseUSDLayerDataSource::ReleaseData(UOmniverseLayer* Layer, UOmniversePrim* Prim)
{
	if (Prim && Prim->IsValidLowLevel())
	{
		for (auto Pair : Prim->Children)
		{
			ReleaseData(Layer, Pair.Value);
		}
		Prim->Children.Reset();
		Prim->RemoveFromRoot();
		Layer->SubPrims.Remove(Prim->FullPath);
	}
}

void FOmniverseUSDLayerDataSource::ReleaseData(UOmniverseLayer* Layer)
{
	if (Layer && Layer->IsValidLowLevel())
	{
		for (auto SubLayer : Layer->SubLayers)
		{
			ReleaseData(SubLayer.Value);
		}
		Layer->SubLayers.Reset();

		for (auto SubPrim : Layer->SubPrims)
		{
			SubPrim.Value->RemoveFromRoot();
		}
		Layer->SubPrims.Reset();

		Layer->RemoveFromRoot();
	}
}

void FOmniverseUSDLayerDataSource::ResetInternal()
{
	ReleaseData(RootLayerData);
	RootLayerData = nullptr;
	
	ReleaseData(SessionLayerData);
	SessionLayerData = nullptr;

	AuthoringLayerData = nullptr;
}

TSharedPtr<FOmniverseUSDLayerDataSource> FOmniverseUSDLayerDataSource::Create(pxr::UsdStageRefPtr USDStage)
{
	auto DataSource = TSharedPtr<FOmniverseUSDLayerDataSource>(new FOmniverseUSDLayerDataSource(USDStage));
	DataSource->Initialize();
	
	return DataSource;
}

void FOmniverseUSDLayerDataSource::Reset()
{
	ResetInternal();
	CloseUnderneathOperationNotification();
	Initialize();
	OnLayersChanged().Broadcast(ELayersEventType::Reset, nullptr, nullptr);
}

FOmniverseUSDLayerDataSource::~FOmniverseUSDLayerDataSource()
{
    ResetInternal();
}

bool FOmniverseUSDLayerDataSource::SetLayerVisibility(UOmniverseLayer* OmniverseLayer, bool Visible)
{
	if (!OmniverseLayer->bRootLayer)
	{
		return SetLayerVisibilityInternal(OmniverseLayer, Visible);
	}

	return false;
}

bool FOmniverseUSDLayerDataSource::ToggleLayerVisibility(UOmniverseLayer* OmniverseLayer)
{
	if (!OmniverseLayer->bRootLayer)
	{
		return ToggleLayerVisibilityInternal(OmniverseLayer);
	}

	return false;
}

void FOmniverseUSDLayerDataSource::AddAllLayersTo(TArray<UOmniverseLayer*>& OutLayers)
{
	if(!StageCtrl)
	{
		return;
	}

	ResetInternal();

	RootLayerData = CreateLayerFrom(StageCtrl->GetRemoteRootLayer()->GetIdentifier(), ERootLayerType::Root, true);
	CreateSublayerFrom(RootLayerData);
	SessionLayerData = CreateLayerFrom(StageCtrl->GetSessionLayer()->GetIdentifier(), ERootLayerType::Session, true);
	CreateSublayerFrom(SessionLayerData);

	OutLayers.Add(RootLayerData);
	OutLayers.Add(SessionLayerData);

	RefreshAuthorLayer();
}

UOmniverseLayer* FOmniverseUSDLayerDataSource::GetAuthoringLayer() const
{
	return AuthoringLayerData;
}

bool FOmniverseUSDLayerDataSource::DeleteLayer(UOmniverseLayer* ParentOmniverseLayer, UOmniverseLayer* OmniverseLayer)
{
	if (!OmniverseLayer->bRootLayer)
	{
		if (IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled())
		{
			FOmniverseNotificationHelper::NotifyError(TEXT("Cannot remove sublayers in live-syncing mode."));	
			return false;
		}

		bool bDeleteLayer = true;
		auto subLayer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*OmniverseLayer->FullPath));
		if (subLayer && !subLayer->IsEmpty())
		{
			FText MessageTitle = FText::FromString(TEXT("Remove layer"));
			EAppReturnType::Type UserChoice = FMessageDialog::Open(EAppMsgType::OkCancel, EAppReturnType::Cancel, FText::Format(FText::FromString("Layer '{0}' is not empty. Do you want to remove this layer from stage?"), FText::FromName(OmniverseLayer->Name)), &MessageTitle);
			bDeleteLayer = (UserChoice == EAppReturnType::Ok);
		}
		
		if (bDeleteLayer)
		{
			if (OmniverseLayer->bAuthor)
			{
				AuthorRootLayer();
			}

			return DeleteLayerInternal(OmniverseLayer->RootLayerType, ParentOmniverseLayer->FullPath, OmniverseLayer->FullPath);
		}
	}
	
	return false;
}

bool FOmniverseUSDLayerDataSource::AttachLayer(UOmniverseLayer* OmniverseLayer, UOmniverseLayer* TargetLayer)
{
	if (!OmniverseLayer->bRootLayer)
	{
		if (OmniverseLayer->RootLayerType == TargetLayer->RootLayerType)
		{

		}
	}

	return false;
}

bool FOmniverseUSDLayerDataSource::SaveLayer(UOmniverseLayer* OmniverseLayer)
{
	auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*OmniverseLayer->FullPath));
	if (Layer)
	{
		Layer->Save();
		OmniverseLayer->bDirty = false;
		return true;
	}

	return false;
}

bool FOmniverseUSDLayerDataSource::ReloadLayer(UOmniverseLayer* OmniverseLayer)
{
	bool bReload = true;
	if (OmniverseLayer->bDirty)
	{
		FText MessageTitle = FText::FromString(TEXT("Reload layer"));
		EAppReturnType::Type UserChoice = FMessageDialog::Open(EAppMsgType::OkCancel, EAppReturnType::Cancel, FText::Format(FText::FromString("Layer '{0}' has unsaved changes. Do you want to reload this layer?"), FText::FromName(OmniverseLayer->Name)), &MessageTitle);

		bReload = (UserChoice == EAppReturnType::Ok);
	}

	if (bReload)
	{
		auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*OmniverseLayer->FullPath));
		if (Layer)
		{
			Layer->Reload();

			std::set<std::string> LayersFromPayloadOrReference;
			for (auto Pair : OmniverseLayer->SubPrims)
			{
				if (Pair.Value->bIsPayload || Pair.Value->bIsReference)
				{
					auto PrimSpec = Layer->GetPrimAtPath(pxr::SdfPath(TCHAR_TO_UTF8(*(Pair.Value->FullPath))));
					if (PrimSpec)
					{
						if (PrimSpec->HasPayloads())
						{
							pxr::SdfPayloadsProxy PayloadsProxy = PrimSpec->GetPayloadList();
							for (auto UsdPayload : PayloadsProxy.GetAddedOrExplicitItems())
							{
								std::string AssetPath = UsdPayload.GetAssetPath();
								LayersFromPayloadOrReference.insert(Layer->ComputeAbsolutePath(AssetPath));
							}
						}

						if (PrimSpec->HasReferences())
						{
							pxr::SdfReferencesProxy ReferencesProxy = PrimSpec->GetReferenceList();
							for (auto UsdReference : ReferencesProxy.GetAddedOrExplicitItems())
							{
								std::string AssetPath = UsdReference.GetAssetPath();
								LayersFromPayloadOrReference.insert(Layer->ComputeAbsolutePath(AssetPath));
							}
						}
					}
				}
			}

			for (auto AbsolutePath : LayersFromPayloadOrReference)
			{
				auto RefLayer = pxr::SdfLayer::FindOrOpen(AbsolutePath);
				OmniUsdStageCtrl::ReloadAllRelatedLayers(RefLayer);
			}

			OmniverseLayer->bDirty = false;
			return true;
		}
	}
	
	return false;
}

bool FOmniverseUSDLayerDataSource::AuthorRootLayer()
{
	if (IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled())
	{
		return false;
	}
	return AuthorLayerInternal(ERootLayerType::Root);
}

bool FOmniverseUSDLayerDataSource::AuthorLayer(UOmniverseLayer* OmniverseLayer)
{
	if (IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled())
	{
		return false;
	}

	if (OmniverseLayer)
	{
		auto EditTgtLayer = StageCtrl->GetStage()->GetEditTarget().GetLayer();
		if(!EditTgtLayer || OmniverseLayer->FullPath != EditTgtLayer->GetIdentifier().c_str())
		{
			return AuthorLayerInternal(OmniverseLayer->RootLayerType, OmniverseLayer->FullPath);
		}
		else
		{
			if ((StageCtrl->IsSubLayerLocked(TCHAR_TO_UTF8(*OmniverseLayer->FullPath)) || !StageCtrl->GetSubLayerVisibility(TCHAR_TO_UTF8(*OmniverseLayer->FullPath), bGlobalMuteness)))
			{
				return AuthorLayerInternal(ERootLayerType::Root);
			}
		}
	}
	else
	{
		return AuthorLayerInternal(ERootLayerType::Root);
	}

	return true;
}

bool FOmniverseUSDLayerDataSource::LockLayer(UOmniverseLayer* OmniverseLayer)
{
	if (!OmniverseLayer->bRootLayer)
	{
		if (OmniverseLayer->bAuthor)
		{
			return false;
		}

		OnPreLayersChanged().Broadcast(ELayersEventType::LayerChanged);
		StageCtrl->SetSubLayerLocked(TCHAR_TO_UTF8(*OmniverseLayer->FullPath), true);
		OmniverseLayer->bLocked = true;
		OnPostLayersChanged().Broadcast(ELayersEventType::LayerChanged);

		RefreshAuthorLayer();

		return true;
	}

	return false;
}

bool FOmniverseUSDLayerDataSource::UnlockLayer(UOmniverseLayer* OmniverseLayer)
{
	if (!OmniverseLayer->bRootLayer)
	{
		if (OmniverseLayer->bAuthor)
		{
			return false;
		}

		OnPreLayersChanged().Broadcast(ELayersEventType::LayerChanged);
		StageCtrl->SetSubLayerLocked(TCHAR_TO_UTF8(*OmniverseLayer->FullPath), false);
		OmniverseLayer->bLocked = false;
		OnPostLayersChanged().Broadcast(ELayersEventType::LayerChanged);

		return true;
	}

	return false;
}

void FOmniverseUSDLayerDataSource::SelectSingleActor(UOmniversePrim* Prim)
{
#if WITH_EDITOR
	SelectAllActors({ Prim });
#endif
}

void FOmniverseUSDLayerDataSource::SelectAllActors(const TArray<UOmniversePrim*>& Prims)
{
#if WITH_EDITOR
	auto World = GEditor->GetEditorWorldContext().World();
	auto StageActor = AOmniverseStageActor::Find(*World);
	if (StageActor)
	{
		const FScopedTransaction Transaction(FText::FromString(TEXT("Select Actors")));
		GEditor->SelectNone(false, true);

		GEditor->GetSelectedActors()->BeginBatchSelectOperation();

		for (auto Prim : Prims)
		{
			auto PrimPath = pxr::SdfPath(TCHAR_TO_ANSI(*Prim->FullPath));
			const auto ActorComponent = StageActor->FindObjectFromPath<UActorComponent>(PrimPath);
			if (ActorComponent && ActorComponent->GetOwner())
			{
				auto Actor = ActorComponent->GetOwner();
				GEditor->GetSelectedActors()->Modify();
				GEditor->SelectActor(Actor, true, false, true);
			}
		}

		GEditor->GetSelectedActors()->EndBatchSelectOperation();
		GEditor->NoteSelectionChange();
	}
#endif
}

bool FOmniverseUSDLayerDataSource::DeleteSinglePrim(UOmniversePrim* Prim)
{
	//auto UsdPrim = StageCtrl->GetStage()->GetPrimAtPath(pxr::SdfPath(TCHAR_TO_ANSI(*Prim.FullPath)));
	//if (UsdPrim && OmniUsdStageCtrl::IsAncestralPrim(UsdPrim))
	//{
	//	FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot remove ancestral prim %s"), *Prim.FullPath));		
	//	return true;
	//}

	OnPreLayersChanged().Broadcast(ELayersEventType::PrimChanged);
	
	UOmniverseLayer* ChangedLayer = FindLayer(Prim->LayerFullPath);

	if (ChangedLayer)
	{
		if (DeleteSinglePrimInternal(ChangedLayer, Prim))
		{
		}
	}

	OnPostLayersChanged().Broadcast(ELayersEventType::PrimChanged);

	return true;
}

void FOmniverseUSDLayerDataSource::SwitchMutenessScope(bool bGlobal)
{
	bGlobalMuteness = bGlobal;
	if (StageCtrl)
	{
		auto SubLayerPaths = StageCtrl->GetSublayerIdentifiers();
		for(int32 Index = 0; Index < SubLayerPaths.Num(); ++Index)
		{
			OnPreLayersChanged().Broadcast(ELayersEventType::LayerChanged);
			std::string Identifier = TCHAR_TO_UTF8(*SubLayerPaths[Index]);
			StageCtrl->SetSubLayerVisibility(Identifier, StageCtrl->GetSubLayerVisibility(Identifier, bGlobalMuteness), bGlobalMuteness);
			OnPostLayersChanged().Broadcast(ELayersEventType::LayerChanged);

			RefreshAuthorLayer();
		}
	}
}

bool FOmniverseUSDLayerDataSource::IsMutenessGlobal() const
{
	return bGlobalMuteness;
}

size_t FOmniverseUSDLayerDataSource::NumLayers() const
{
	return StageCtrl ? StageCtrl->GetRemoteRootLayer()->GetSubLayerPaths().size() : 0;
}

int32 FOmniverseUSDLayerDataSource::GetSubLayerPriority(const FString& LayerPath, const FString& SubLayerPath) const
{
	return StageCtrl ? StageCtrl->GetSublayerPriority(LayerPath, SubLayerPath) : INDEX_NONE;
}

void FOmniverseUSDLayerDataSource::CloseUnderneathOperationNotification()
{
	if (UnderneathOperationNotification.IsValid())
	{
		UnderneathOperationNotification.Pin()->SetCompletionState(SNotificationItem::CS_None);
		UnderneathOperationNotification.Pin()->ExpireAndFadeout();
		UnderneathOperationNotification.Reset();
	}
}

void FOmniverseUSDLayerDataSource::NotifyPrimChange(const FString & Prim)
{
	if(UnderneathOperationNotification.IsValid())
	{
		return;
	}

	auto Layer = OmniUsdStageCtrl::HasOverriddenInStrongerLayer(StageCtrl->GetStage(), pxr::SdfPath(TCHAR_TO_ANSI(*Prim)));
	if (Layer)
	{
		FString Text = FString::Printf(TEXT("WARNING: Overridden in a stronger layer (%s)."), *FPaths::GetCleanFilename(Layer->GetIdentifier().c_str()));
		UnderneathOperationNotification = FOmniverseNotificationHelper::ShowInstantNotification(Text, SNotificationItem::CS_None, 0.0f, 0.5f, true,
			FSimpleDelegate::CreateLambda(
				[this]()
				{
					CloseUnderneathOperationNotification();
				}
		));
	}
}

void FOmniverseUSDLayerDataSource::UpdatePrim(const FString& LayerPath, const FString& PrimPath)
{
	auto Layer = FindLayer(LayerPath);
	if (Layer)
	{
		auto Prim = Layer->SubPrims.Find(PrimPath);
		auto LayerHandle = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*LayerPath));
		auto SdfPrimPath = pxr::SdfPath(TCHAR_TO_UTF8(*PrimPath));
		if (Prim == nullptr)
		{

			auto NewPrim = CreatePrimFrom(LayerHandle, SdfPrimPath);
			Layer->SubPrims.Add(PrimPath, NewPrim);
			auto SdfParentPath = SdfPrimPath.GetParentPath();
			if (SdfParentPath == pxr::SdfPath::AbsoluteRootPath())
			{
				Layer->RootPrims.Add(PrimPath, NewPrim);
				OnLayersChanged().Broadcast(ELayersEventType::PrimChanged, Layer, nullptr);
			}
			else
			{
				auto ParentPrim = Layer->SubPrims.Find(SdfParentPath.GetText());
				if (ParentPrim)
				{
					(*ParentPrim)->Children.Add(PrimPath, NewPrim);
					OnLayersChanged().Broadcast(ELayersEventType::PrimChanged, Layer, (*ParentPrim));
				}
			}
		}
		else
		{
			UpdatePrimFrom(*Prim, LayerHandle, SdfPrimPath);
		}
	}
}

void FOmniverseUSDLayerDataSource::RemovePrim(const FString& LayerPath, const FString& PrimPath)
{
	auto Layer = FindLayer(LayerPath);
	if (Layer)
	{
		auto Prim = Layer->SubPrims.Find(PrimPath);
		if (Prim)
		{
			// Get parent prim
			ReleaseData(Layer, *Prim);
			auto SdfPrimPath = pxr::SdfPath(TCHAR_TO_UTF8(*PrimPath));
			auto SdfParentPath = SdfPrimPath.GetParentPath();
			if (SdfParentPath == pxr::SdfPath::AbsoluteRootPath())
			{
				Layer->RootPrims.Remove(PrimPath);
				OnLayersChanged().Broadcast(ELayersEventType::PrimChanged, Layer, nullptr);
			}
			else
			{
				auto ParentPrim = Layer->SubPrims.Find(SdfParentPath.GetText());
				if (ParentPrim)
				{
					(*ParentPrim)->Children.Remove(PrimPath);
					OnLayersChanged().Broadcast(ELayersEventType::PrimChanged, Layer, (*ParentPrim));
				}
			}
		}
	}
}

void FOmniverseUSDLayerDataSource::UpdateSublayer(const FString& LayerPath, const FString& SublayerPath)
{
	auto Layer = FindLayer(LayerPath);
	if (Layer)
	{
		OnLayersChanged().Broadcast(ELayersEventType::LayerChanged, Layer, nullptr);
	}
}

void FOmniverseUSDLayerDataSource::AddSublayer(const FString& LayerPath, const FString& SublayerPath)
{
	auto Layer = FindLayer(LayerPath);
	if (Layer)
	{
		pxr::SdfLayerRefPtr USDParentLayer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*LayerPath));
		if (USDParentLayer)
		{
			auto SubLayerIdentifier = pxr::SdfComputeAssetPathRelativeToLayer(USDParentLayer, TCHAR_TO_UTF8(*SublayerPath));

			auto NewSubLayer = FindLayer(SubLayerIdentifier.c_str());
			if (!NewSubLayer)
			{
				NewSubLayer = CreateLayerFrom(SubLayerIdentifier, Layer->RootLayerType, false);
				if (NewSubLayer)
				{
					Layer->SubLayers.Add(NewSubLayer->FullPath, NewSubLayer);
					CreateSublayerFrom(NewSubLayer);
				}
			}
			else
			{
				Layer->SubLayers.Add(NewSubLayer->FullPath, NewSubLayer);
			}
			OnLayersChanged().Broadcast(ELayersEventType::LayerChanged, Layer, nullptr);
		}
	}
}

void FOmniverseUSDLayerDataSource::RemoveSublayer(const FString& LayerPath, const FString& SublayerPath)
{
	auto Layer = FindLayer(LayerPath);
	if (Layer)
	{
		pxr::SdfLayerRefPtr USDParentLayer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*LayerPath));
		if (USDParentLayer)
		{
			auto SubLayerIdentifier = pxr::SdfComputeAssetPathRelativeToLayer(USDParentLayer, TCHAR_TO_UTF8(*SublayerPath));

			auto SubLayer = Layer->SubLayers.Find(SubLayerIdentifier.c_str());
			if (SubLayer)
			{
				Layer->SubLayers.Remove(SubLayerIdentifier.c_str());
				ReleaseData(*SubLayer);
				OnLayersChanged().Broadcast(ELayersEventType::LayerChanged, Layer, nullptr);
			}
		}
	}
}

void FOmniverseUSDLayerDataSource::SetLayerDirty(const FString& LayerPath, bool bDirty)
{
	auto Layer = FindLayer(LayerPath);
	if (Layer)
	{
		Layer->bDirty = bDirty;
	}
}

bool FOmniverseUSDLayerDataSource::SaveTo(FUSDLayersSerialization & Serialization)
{
	if(!StageCtrl)
	{
		return false;
	}

	Serialization.USDSublayers.Empty();

	std::vector<std::string> SubLayerPaths = StageCtrl->GetRemoteRootLayer()->GetSubLayerPaths();

	std::string RootLayerContent;
	pxr::UsdStageRefPtr TempStage = pxr::UsdStage::CreateInMemory();
	pxr::UsdGeomSetStageUpAxis(TempStage, pxr::UsdGeomTokens->z);
	pxr::SdfCopySpec(StageCtrl->GetRemoteRootLayer(), pxr::SdfPath("/"), TempStage->GetRootLayer(), pxr::SdfPath("/"));
	TempStage->GetRootLayer()->ExportToString(&RootLayerContent);
	Serialization.RootLayerContent = RootLayerContent.c_str();
	for (uint32 Index = 0; Index < SubLayerPaths.size(); ++Index)
	{
		FUSDLayerDescription LayerDescription;
		LayerDescription.LayerName = OmniUsdStageCtrl::GetSubLayerName(StageCtrl->GetRemoteRootLayer(), Index).GetText();
		LayerDescription.bMuted = StageCtrl->GetSubLayerVisibility(SubLayerPaths[Index], bGlobalMuteness);

#if PXR_VERSION >= 2102
		auto LayerHandle = pxr::SdfLayer::FindOrOpenRelativeToLayer(StageCtrl->GetRemoteRootLayer(), SubLayerPaths[Index]);
#else
		auto LayerHandle = pxr::SdfFindOrOpenRelativeToLayer(StageCtrl->GetRemoteRootLayer(), &SubLayerPaths[Index]);
#endif //PXR_VERSION >= 2102
				
		if (LayerHandle)
		{
			std::string LayerContent;
			LayerHandle->ExportToString(&LayerContent);
			LayerDescription.LayerContent = LayerContent.c_str();
		}

		Serialization.USDSublayers.Add(LayerDescription);
	}

	return true;
}

pxr::UsdStageRefPtr FOmniverseUSDLayerDataSource::CreateInMemoryStageFrom(const FUSDLayersSerialization & Serialization)
{
	pxr::UsdStageRefPtr Stage = pxr::UsdStage::CreateInMemory();
	pxr::UsdGeomSetStageUpAxis(Stage, pxr::UsdGeomTokens->z);
	if (!Serialization.RootLayerContent.IsEmpty())
	{
		Stage->GetRootLayer()->ImportFromString(TCHAR_TO_ANSI(*Serialization.RootLayerContent));
		auto SubLayerPaths = Stage->GetRootLayer()->GetSubLayerPaths();
		for (auto SubLayerContent : Serialization.USDSublayers)
		{
			auto SubLayer = pxr::SdfLayer::CreateAnonymous();
			SubLayer->ImportFromString(TCHAR_TO_ANSI(*SubLayerContent.LayerContent));
			SubLayerPaths.Insert(0, SubLayer->GetIdentifier());
			OmniUsdStageCtrl::SetSubLayerName(Stage->GetRootLayer(), 0, pxr::TfToken(TCHAR_TO_ANSI(*SubLayerContent.LayerName)));
		}
	}

	return Stage;
}

bool FOmniverseUSDLayerDataSource::RefreshUSDLayerState()
{
	return true;
}

void FOmniverseUSDLayerDataSource::CreateSublayerFrom(UOmniverseLayer* Layer)
{
	if (!Layer)
	{
		return;
	}

	pxr::SdfLayerRefPtr USDLayerHandle = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*Layer->FullPath));
	if (!USDLayerHandle)
	{
		return;
	}

	std::vector<std::string> SubLayerPaths = USDLayerHandle->GetSubLayerPaths();
	for (int32 SubLayerIndex = 0; SubLayerIndex < SubLayerPaths.size(); ++SubLayerIndex)
	{
		auto SubLayerIdentifier = pxr::SdfComputeAssetPathRelativeToLayer(USDLayerHandle, SubLayerPaths[SubLayerIndex]);

		auto NewSubLayer = FindLayer(SubLayerIdentifier.c_str());
		if (!NewSubLayer)
		{
			NewSubLayer = CreateLayerFrom(SubLayerIdentifier, Layer->RootLayerType, false);
			if (NewSubLayer)
			{
				Layer->SubLayers.Add(NewSubLayer->FullPath, NewSubLayer);
				CreateSublayerFrom(NewSubLayer);
			}
		}
		else
		{
			Layer->SubLayers.Add(NewSubLayer->FullPath, NewSubLayer);
		}
	}
}

void FOmniverseUSDLayerDataSource::UpdatePrimFrom(UOmniversePrim* Prim, const pxr::SdfLayerRefPtr& USDLayerHandle, const pxr::SdfPath& InPrimPath)
{
	auto PrimSpec = USDLayerHandle->GetPrimAtPath(InPrimPath);
	Prim->FullPath = InPrimPath.GetText();
	Prim->LayerFullPath = USDLayerHandle->GetIdentifier().c_str();
	FString PrimName = InPrimPath.GetName().c_str();
	if (auto Label = ActorNameLabelMap.Find(PrimName))
	{
		Prim->Name = *Label;
	}
	else
	{
		Prim->Name = InPrimPath.GetName().c_str();
	}

	Prim->TypeName = PrimSpec->GetTypeName().GetText();
	Prim->bIsReference = PrimSpec->HasReferences();
	Prim->bIsPayload = PrimSpec->HasPayloads();
	Prim->bOver = PrimSpec->GetSpecifier() == pxr::SdfSpecifier::SdfSpecifierOver;
}

UOmniversePrim* FOmniverseUSDLayerDataSource::CreatePrimFrom(const pxr::SdfLayerRefPtr& USDLayerHandle, const pxr::SdfPath& InPrimPath)
{
	UOmniversePrim* Prim = NewObject<UOmniversePrim>();
	Prim->AddToRoot();
	UpdatePrimFrom(Prim, USDLayerHandle, InPrimPath);
	return Prim;
}


UOmniverseLayer* FOmniverseUSDLayerDataSource::CreateLayerFrom(const std::string& Identifier, ERootLayerType Type, bool bRoot)
{
	pxr::SdfLayerRefPtr USDLayerHandle = pxr::SdfLayer::FindOrOpen(Identifier);
	if (!USDLayerHandle)
	{
		return nullptr;
	}

	bool IsAuthorLayer = false;
	auto EditTgtLayer = StageCtrl->GetStage()->GetEditTarget().GetLayer();
	if (EditTgtLayer)
	{
		IsAuthorLayer = (EditTgtLayer->GetIdentifier() == Identifier);
	}

	FString LayerDisplayName = bRoot ? (Type == ERootLayerType::Root ? TEXT("Root Layer") : TEXT("Session Layer")) : FString(FPaths::GetCleanFilename(Identifier.c_str()));
	UOmniverseLayer* NewLayer = NewObject<UOmniverseLayer>();
	NewLayer->AddToRoot();
	NewLayer->Name = FName(LayerDisplayName);
	NewLayer->RootLayerType = Type;
	NewLayer->bAuthor = IsAuthorLayer;
	NewLayer->FullPath = Identifier.c_str();

	if (bRoot)
	{
		NewLayer->bRootLayer = true;
		NewLayer->bMuted = false;
		NewLayer->bGlobalMuted = false;
		NewLayer->bLocked = false;
	}
	else
	{
		NewLayer->bRootLayer = false;
		NewLayer->bMuted = Type == ERootLayerType::Root ? !StageCtrl->GetSubLayerVisibility(Identifier, false) : false;
		NewLayer->bGlobalMuted = Type == ERootLayerType::Root ? !StageCtrl->GetSubLayerVisibility(Identifier, true) :false;
		NewLayer->bLocked = Type == ERootLayerType::Root ? StageCtrl->IsSubLayerLocked(Identifier) : false;
	}

	USDLayerHandle->Traverse(pxr::SdfPath::AbsoluteRootPath(),
		[&](const pxr::SdfPath& InPath)
		{
#if UE_BUILD_DEBUG
			auto PathText = InPath.GetString();
#endif

			auto PrimPath = InPath.GetPrimPath();
			if (!NewLayer->SubPrims.Find(PrimPath.GetText()))
			{
                if(!USDLayerHandle->GetPrimAtPath(PrimPath))
                {
                    return;
                }
					
				auto NewPrim = CreatePrimFrom(USDLayerHandle, PrimPath);
				NewLayer->SubPrims.Add(NewPrim->FullPath, NewPrim);

				if (PrimPath.GetParentPath() != pxr::SdfPath::AbsoluteRootPath())
				{
					while (1)
					{					
						auto ParentPath = PrimPath.GetParentPath();
						if (!NewLayer->SubPrims.Find(ParentPath.GetText()))
						{
							if(!USDLayerHandle->GetPrimAtPath(ParentPath))
							{
								break;
							}

							auto NewParentPrim = CreatePrimFrom(USDLayerHandle, ParentPath);
							NewLayer->SubPrims.Add(NewParentPrim->FullPath, NewParentPrim);
						}
							
						auto Parent = NewLayer->SubPrims.Find(ParentPath.GetText());
						auto Child = NewLayer->SubPrims.Find(PrimPath.GetText());
						(*Parent)->Children.Add((*Child)->FullPath, (*Child));

						PrimPath = PrimPath.GetParentPath();
						if (PrimPath.GetParentPath() == pxr::SdfPath::AbsoluteRootPath())
						{
							NewLayer->RootPrims.Add((*Parent)->FullPath, *Parent);
							break;
						}
					}
				}
				else
				{
					NewLayer->RootPrims.Add(NewPrim->FullPath, NewPrim);
				}
			}
		}
	);

	return NewLayer;
}

UOmniverseLayer* FOmniverseUSDLayerDataSource::FindLayer(const FString& LayerPath)
{
	if (SessionLayerData)
	{
		if (SessionLayerData->FullPath.Equals(LayerPath))
		{
			return SessionLayerData;
		}

		auto FoundSessionLayer = SessionLayerData->FindSubLayer(LayerPath);
		if (FoundSessionLayer)
		{
			return FoundSessionLayer;
		}
	}

	if (RootLayerData)
	{
		if (RootLayerData->FullPath.Equals(LayerPath))
		{
			return RootLayerData;
		}

		auto FoundRootLayer = RootLayerData->FindSubLayer(LayerPath);
		if (FoundRootLayer)
		{
			return FoundRootLayer;
		}
	}

	return nullptr;
}

bool FOmniverseUSDLayerDataSource::SetLayerVisibilityInternal(UOmniverseLayer* OmniverseLayer, bool bVisible)
{
	OnPreLayersChanged().Broadcast(ELayersEventType::LayerChanged);
	std::string LayerFullPath = TCHAR_TO_UTF8(*OmniverseLayer->FullPath);
	StageCtrl->SetSubLayerVisibility(LayerFullPath, bVisible, bGlobalMuteness);
	OmniverseLayer->bMuted = !StageCtrl->GetSubLayerVisibility(LayerFullPath, false);
	OmniverseLayer->bGlobalMuted = !StageCtrl->GetSubLayerVisibility(LayerFullPath, true);
	OnPostLayersChanged().Broadcast(ELayersEventType::LayerChanged);

	RefreshAuthorLayer();

	return true;
}

bool FOmniverseUSDLayerDataSource::ToggleLayerVisibilityInternal(UOmniverseLayer* OmniverseLayer)
{
	auto ToggleVisibility = [this, OmniverseLayer]()
	{
		if (OmniverseLayer->bAuthor)
		{
			return false;
		}

		OnPreLayersChanged().Broadcast(ELayersEventType::LayerChanged);
		std::string LayerFullPath = TCHAR_TO_UTF8(*OmniverseLayer->FullPath);
		bool bVisible = StageCtrl->GetSubLayerVisibility(LayerFullPath, bGlobalMuteness);
		bool bUpdated = StageCtrl->SetSubLayerVisibility(LayerFullPath, !bVisible, bGlobalMuteness);
		OmniverseLayer->bMuted = !StageCtrl->GetSubLayerVisibility(LayerFullPath, false);
		OmniverseLayer->bGlobalMuted = !StageCtrl->GetSubLayerVisibility(LayerFullPath, true);
		OnPostLayersChanged().Broadcast(ELayersEventType::LayerChanged);

		return bUpdated;
	};

	if(!ToggleVisibility())
	{
		return false;
	}

	FScopedTransaction Transaction(L"USD Layer", FText::FromString("Toggle visibility"), TransactionObject.Get());

	TransactionObject->AddTransaction(UOmniverseTransaction::FUndoDelegate::CreateLambda(
		[ToggleVisibility](UOmniverseTransaction::EUndoType UndoType)
		{
			ToggleVisibility();
		}
	));

	RefreshAuthorLayer();

	return true;
}

bool FOmniverseUSDLayerDataSource::DeleteLayerInternal(ERootLayerType Type, const FString& ParentFullPath, const FString& FullPath)
{
	struct FContext
	{
		int Index = -1;
		pxr::TfToken Name;
	};

	TSharedRef<FContext> Context = MakeShared<FContext>();

	auto DeleteLayer = [this, ParentFullPath, FullPath, Context](UOmniverseTransaction::EUndoType UndoType)
	{
		OnPreLayersChanged().Broadcast(ELayersEventType::LayerChanged);

		switch(UndoType)
		{
		case UOmniverseTransaction::EUndoType::Undo:
		{
			auto subLayer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*ParentFullPath));
			if (subLayer)
			{
				std::string relativePath = TCHAR_TO_UTF8(*FOmniversePathHelper::ComputeRelativePath(FullPath, subLayer->GetIdentifier().c_str()));
				subLayer->InsertSubLayerPath(relativePath, Context->Index);
				OmniUsdStageCtrl::SetSubLayerName(subLayer, Context->Index, Context->Name);
			}
			break;
		}
		case UOmniverseTransaction::EUndoType::Redo:
		{
			auto subLayer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*ParentFullPath));
			if (subLayer)
			{
				Context->Index = OmniUsdStageCtrl::FindSubLayerIndex(subLayer, TCHAR_TO_UTF8(*FullPath));
				if (Context->Index < 0)
				{
					return false;
				}
				Context->Name = OmniUsdStageCtrl::GetSubLayerName(subLayer, Context->Index);
				subLayer->RemoveSubLayerPath(Context->Index);
			}
			break;
		}
		}

		OnPostLayersChanged().Broadcast(ELayersEventType::LayerChanged);

		return true;
	};

	if(!DeleteLayer(UOmniverseTransaction::EUndoType::Redo))
	{
		return false;
	}

	FScopedTransaction Transaction(L"USD Layer", FText::FromString("Delete"), TransactionObject.Get());

	TransactionObject->AddTransaction(UOmniverseTransaction::FUndoDelegate::CreateLambda(
		[DeleteLayer](UOmniverseTransaction::EUndoType UndoType)
		{
			DeleteLayer(UndoType);
		}
	));

	return true;
}

bool FOmniverseUSDLayerDataSource::AuthorLayerInternal(ERootLayerType Type, const FString& FullPath)
{
	bool bUpdated = false;

	// This is hit when we try to reload the stage from the Live Edit switch
	if (!StageCtrl)
	{
		return false;
	}

	auto EditTgtLayer = StageCtrl->GetStage()->GetEditTarget().GetLayer();
	auto RootLayer = Type == ERootLayerType::Root ? StageCtrl->GetRemoteRootLayer() : StageCtrl->GetSessionLayer();

	if(!FullPath.IsEmpty())
	{
		std::string LayerFullPath = TCHAR_TO_UTF8(*FullPath);
		auto subLayer = pxr::SdfLayer::FindOrOpen(LayerFullPath);

		if (Type == ERootLayerType::Root)
		{
			if (!StageCtrl->IsSubLayerLocked(LayerFullPath) && StageCtrl->GetSubLayerVisibility(LayerFullPath, bGlobalMuteness))
			{
				if(subLayer && EditTgtLayer != subLayer)
				{
					StageCtrl->GetStage()->SetEditTarget(pxr::UsdEditTarget(subLayer));

					auto EditTgtLayer2 = StageCtrl->GetStage()->GetEditTarget().GetLayer();
					std::string test = EditTgtLayer2->GetIdentifier();
					bUpdated = true;
				}
			}
			// The current edit layer is locked, switch to edit root layer
			else if (subLayer == EditTgtLayer) 
			{
				StageCtrl->GetStage()->SetEditTarget(pxr::UsdEditTarget(RootLayer));
				bUpdated = true;		
			}
		}
		else
		{
			if(subLayer && EditTgtLayer != subLayer)
			{
				StageCtrl->GetStage()->SetEditTarget(pxr::UsdEditTarget(subLayer));
				bUpdated = true;
			}
		}
	}
	else
	{
		if (EditTgtLayer != RootLayer)
		{
			StageCtrl->GetStage()->SetEditTarget(pxr::UsdEditTarget(RootLayer));
			bUpdated = true;
		}
	}

	if (bUpdated)
	{
		RefreshAuthorLayer();
	}

	return bUpdated;
}

bool FOmniverseUSDLayerDataSource::DeleteSinglePrimInternal(UOmniverseLayer* ChangedLayer, UOmniversePrim* Prim)
{
	// Start transaction
	FScopedTransaction Transaction(L"USD Layer", FText::FromString("Delete prim"), TransactionObject.Get());

	// Collect data
	auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_ANSI(*ChangedLayer->FullPath));
	pxr::SdfPath PrimPath(TCHAR_TO_ANSI(*Prim->FullPath));

	auto DeltaLayer = pxr::SdfLayer::CreateAnonymous();
	pxr::SdfCreatePrimInLayer(DeltaLayer, PrimPath);
	pxr::SdfCopySpec(Layer, PrimPath, DeltaLayer, PrimPath);

	// Add to undo buffer
	TransactionObject->AddTransaction(UOmniverseTransaction::FUndoDelegate::CreateLambda(
		[ChangedLayer, PrimPath, DeltaLayer, this](UOmniverseTransaction::EUndoType UndoType)
		{
			OnPreLayersChanged().Broadcast(ELayersEventType::PrimChanged);
			auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_ANSI(*ChangedLayer->FullPath));
			switch(UndoType)
			{
			case UOmniverseTransaction::EUndoType::Undo:
				pxr::SdfCreatePrimInLayer(Layer, PrimPath);
				pxr::SdfCopySpec(DeltaLayer, PrimPath, Layer, PrimPath);
				break;
			case UOmniverseTransaction::EUndoType::Redo:
				auto Prim = Layer->GetPrimAtPath(PrimPath);
				if(!Prim)
				{
					break;
				}

				auto Parent = Prim->GetRealNameParent();
				if(Parent)
				{
					Parent->RemoveNameChild(Prim);
				}
				break;
			}
			OnPostLayersChanged().Broadcast(ELayersEventType::PrimChanged);
		}
	));

	auto LayerHandle = pxr::SdfLayer::FindOrOpen(TCHAR_TO_ANSI(*ChangedLayer->FullPath));
	if (LayerHandle)
	{
		PrimPath = pxr::SdfPath(TCHAR_TO_ANSI(*Prim->FullPath));
		auto PrimSpec = LayerHandle->GetPrimAtPath(PrimPath);
		if (PrimSpec)
		{
			auto Parent = PrimSpec->GetRealNameParent();
			if (Parent)
			{
				Parent->RemoveNameChild(PrimSpec);
				return true;
			}
		}
	}

	return false;
}

void FOmniverseUSDLayerDataSource::OnOmniverseMessageReceived(const FString & ChannelId, const FOmniverseMessage & OmniverseMessage)
{
}

void FOmniverseUSDLayerDataSource::RefreshAuthorLayer()
{
	if (RefreshAuthorLayerInternal())
	{
	}
}

bool FOmniverseUSDLayerDataSource::RefreshAuthorLayerInternal()
{
	if (StageCtrl && (RootLayerData || SessionLayerData))
	{
		auto EditTgtLayer = StageCtrl->GetStage()->GetEditTarget().GetLayer();
		if (EditTgtLayer)
		{
			auto LayerView = FindLayer(EditTgtLayer->GetIdentifier().c_str());
			if (LayerView)
			{
				if (AuthoringLayerData == nullptr || LayerView->FullPath != AuthoringLayerData->FullPath)
				{
					if (AuthoringLayerData)
					{
						AuthoringLayerData->bAuthor = false;
					}
					AuthoringLayerData = LayerView;
					AuthoringLayerData->bAuthor = true;
					return true;
				}
			}
		}
	}

	return false;
}

void FOmniverseUSDLayerDataSource::NotifyError(const FString& Error)
{
#if WITH_EDITOR
	FOmniverseNotificationHelper::ShowInstantNotification(Error);
#endif
	UE_LOG(LogOmniverseUsd, Error, TEXT("%s"), *Error);
}
