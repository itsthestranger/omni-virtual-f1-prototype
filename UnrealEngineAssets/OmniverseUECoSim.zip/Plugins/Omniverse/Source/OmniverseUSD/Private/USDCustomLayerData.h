// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "OmniversePxr.h"



class FUSDCustomLayerData
{
public:
	static void ResetMaxRoughness(const pxr::SdfLayerRefPtr& RootLayer);
	static void SetEditorCamera(const pxr::UsdStageRefPtr& USDStage, const FVector& CamPosition, const FVector& CamTarget);
	static void SetRenderSettings(const pxr::SdfLayerRefPtr& RootLayer, const struct FPostProcessSettings& Settings);
	static void SetLayerCustomField(const pxr::SdfLayerRefPtr& RootLayer, const std::string& LayerIdentifier, const std::string& Key, bool Value);
	
	static bool GetLayerCustomField(pxr::SdfLayerRefPtr RootLayer, const std::string& LayerIdentifier, const std::string& Key);

	static const std::string MutenessCustomKey;
	static const std::string LockedCustomKey;
};