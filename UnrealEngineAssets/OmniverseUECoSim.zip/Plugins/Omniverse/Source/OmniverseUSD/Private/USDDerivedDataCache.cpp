// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "USDDerivedDataCache.h"
#include "DerivedDataCacheInterface.h"
#include "HAL/IConsoleManager.h"
#include "Serialization/MemoryWriter.h"
#include "Serialization/MemoryReader.h"
#include "StaticMeshResources.h"
#include "Components.h"
#include "Rendering/SkeletalMeshLODImporterData.h"

namespace UsdDDCType
{
	enum Type
	{
		StaticMesh,
		SkeletalMesh,
		Invalid,
	};
}

static TAutoConsoleVariable<int32> CVarLocalMeshCache(TEXT("Omniverse.LocalMeshCache"), 1, TEXT(""));

#define USDMESH_DERIVEDDATA_VER TEXT("4A6E1CA655904B0F85968116DE33A33D")
#define USDSKELETAL_DERIVEDDATA_VER TEXT("B26A13EC6EC6416C8103F361F6AA5756")

static FString GetDDCKey(UsdDDCType::Type CachedType, const FString& USDHash)
{
	if (CVarLocalMeshCache.GetValueOnAnyThread() == 0)
	{
		return TEXT("");
	}

	FString KeyPrefix;
	switch (CachedType)
	{
	case UsdDDCType::StaticMesh:
		KeyPrefix = FString::Printf(TEXT("MeshCache_%s_%s"), USDMESH_DERIVEDDATA_VER, *USDHash);
		break;
	case UsdDDCType::SkeletalMesh:
		KeyPrefix = FString::Printf(TEXT("SkeletalCache_%s_%s"), USDSKELETAL_DERIVEDDATA_VER, *USDHash);
		break;
	}

	auto& DerivedDataCache = GetDerivedDataCacheRef();
	FString DDCVersion = FString::Printf(TEXT("wegrr6534r_%d_%d"), ENGINE_MAJOR_VERSION, ENGINE_MINOR_VERSION);
	return DerivedDataCache.BuildCacheKey(TEXT("OmniverseDerivedData"), *DDCVersion, *KeyPrefix);
}

static void operator << (FArchive& Ar, FStaticMeshBuildVertex& Vertex)
{
	Ar << Vertex.Position;
	Ar << Vertex.TangentX;
	Ar << Vertex.TangentY;
	Ar << Vertex.TangentZ;
	for (auto& UV : Vertex.UVs)
	{
		Ar << UV;
	}
	Ar << Vertex.Color;
}

void Serialize(FArchive& Ar, FStaticMeshRenderData& StaticMeshRenderData)
{
	FStaticMeshLODResources& MeshRes = StaticMeshRenderData.LODResources[0];

	auto& PositionBuffer = MeshRes.VertexBuffers.PositionVertexBuffer;
	auto& VertexBuffer = MeshRes.VertexBuffers.StaticMeshVertexBuffer;
	auto& ColorBuffer = MeshRes.VertexBuffers.ColorVertexBuffer;

	if (Ar.IsSaving())
	{
		Ar << StaticMeshRenderData.Bounds;

		int32 SectionNum = MeshRes.Sections.Num();
		Ar << SectionNum;

		for (int32 Index = 0; Index < SectionNum; ++Index)
		{
			auto& Section = MeshRes.Sections[Index];

			Ar << Section.FirstIndex;
			Ar << Section.NumTriangles;
			Ar << Section.MinVertexIndex;
			Ar << Section.MaxVertexIndex;
		}

		TArray<uint32> Indices;
		MeshRes.IndexBuffer.GetCopy(Indices);
		Ar << Indices;

		uint32 TexCoordsNum = VertexBuffer.GetNumTexCoords();
		Ar << TexCoordsNum;

		TArray<FStaticMeshBuildVertex> Vertices;
		Vertices.SetNum(VertexBuffer.GetNumVertices());
		for (uint32 Index = 0; Index < VertexBuffer.GetNumVertices(); ++Index)
		{
			auto& Vertex = Vertices[Index];

			Vertex.Position = PositionBuffer.VertexPosition(Index);

			for (uint32 UVIndex = 0; UVIndex < FMath::Min<uint32>(VertexBuffer.GetNumTexCoords(), MAX_STATIC_TEXCOORDS); ++UVIndex)
			{
				Vertex.UVs[UVIndex] = VertexBuffer.GetVertexUV(Index, UVIndex);
			}

			Vertex.TangentX = VertexBuffer.VertexTangentX(Index);
			Vertex.TangentY = VertexBuffer.VertexTangentY(Index);
			Vertex.TangentZ = VertexBuffer.VertexTangentZ(Index);

			Vertex.Color = Index < ColorBuffer.GetNumVertices() ? ColorBuffer.VertexColor(Index) : FColor::White;
		}

		Ar << Vertices;
		Ar << MeshRes.BuffersSize;
	}
	else
	{
		Ar << StaticMeshRenderData.Bounds;

		int32 SectionNum = 0;
		Ar << SectionNum;
		MeshRes.Sections.Empty();
		MeshRes.Sections.AddDefaulted(SectionNum);

		for (int32 Index = 0; Index < SectionNum; ++Index)
		{
			auto& Section = MeshRes.Sections[Index];

			Ar << Section.FirstIndex;
			Ar << Section.NumTriangles;
			Ar << Section.MinVertexIndex;
			Ar << Section.MaxVertexIndex;
		}

		TArray<uint32> Indices;
		Ar << Indices;
		MeshRes.IndexBuffer.SetIndices(Indices, EIndexBufferStride::AutoDetect);

		uint32 TexCoordsNum = 0;
		Ar << TexCoordsNum;

		TArray<FStaticMeshBuildVertex> Vertices;
		Ar << Vertices;

		PositionBuffer.Init(Vertices);
		VertexBuffer.Init(Vertices, FMath::Max<uint32>(1, TexCoordsNum));
		ColorBuffer.Init(Vertices);
		MeshRes.bHasColorVertexData = ColorBuffer.GetNumVertices() > 0;
		Ar << MeshRes.BuffersSize;
	}
}

void Serialize(FArchive& Ar, FSkeletalMeshImportData& SkeletalMeshData)
{
	Ar << SkeletalMeshData.NumTexCoords;
	Ar << SkeletalMeshData.MaxMaterialIndex;
	Ar << SkeletalMeshData.bHasVertexColors;
	Ar << SkeletalMeshData.bHasNormals;
	Ar << SkeletalMeshData.bHasTangents;
	Ar << SkeletalMeshData.Materials;
	Ar << SkeletalMeshData.Points;
	Ar << SkeletalMeshData.Wedges;
	Ar << SkeletalMeshData.Faces;
	Ar << SkeletalMeshData.RefBonesBinary;
	Ar << SkeletalMeshData.Influences;
}

void FUSDDerivedDataCache::Save(const FString& HashKey, FStaticMeshRenderData& StaticMeshRenderData)
{
	FString CacheKey = GetDDCKey(UsdDDCType::StaticMesh, HashKey);

	if (CacheKey.IsEmpty())
	{
		return;
	}

	TArray<uint8> CacheData;
	FMemoryWriter Ar(CacheData, true);

	Serialize(Ar, StaticMeshRenderData);

#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 24
	GetDerivedDataCacheRef().Put(*CacheKey, CacheData);
#else
	GetDerivedDataCacheRef().Put(*CacheKey, CacheData, TEXT("Omniverse USD Import Static Mesh"), false);
#endif
}

bool FUSDDerivedDataCache::Load(const FString& HashKey, FStaticMeshRenderData& StaticMeshRenderData)
{
	TArray<uint8> CacheData;
	FString CacheKey = GetDDCKey(UsdDDCType::StaticMesh, HashKey);

	if (CacheKey.IsEmpty())
	{
		return false;
	}

#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 24
	if (GetDerivedDataCacheRef().GetSynchronous(*CacheKey, CacheData))
#else
	if (GetDerivedDataCacheRef().GetSynchronous(*CacheKey, CacheData, TEXT("Omniverse USD Import Static Mesh")))
#endif
	{
		if (CacheData.Num() > 0)
		{
			FMemoryReader Ar(CacheData, true);
			Serialize(Ar, StaticMeshRenderData);
			return true;
		}
	}

	return false;
}

void FUSDDerivedDataCache::Save(const FString& HashKey, FSkeletalMeshImportData& SkeletalMeshData, bool& HasBlendShapes)
{
	FString CacheKey = GetDDCKey(UsdDDCType::SkeletalMesh, HashKey);
	if (CacheKey.IsEmpty())
	{
		return;
	}

	TArray<uint8> CacheData;
	FMemoryWriter Ar(CacheData, true);

	Serialize(Ar, SkeletalMeshData);
	// NOTE: UsdUtils::FBlendShapeMap can't be serialized correctly
	// The most important Vertices (TArray<FMorphTargetDelta>) haven't been serialized.
	// So we have to import blendshapes when loading
	Ar << HasBlendShapes;

#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 24
	GetDerivedDataCacheRef().Put(*CacheKey, CacheData);
#else
	GetDerivedDataCacheRef().Put(*CacheKey, CacheData, TEXT("Omniverse USD Import Skeletal Mesh"), false);
#endif
}

bool FUSDDerivedDataCache::Load(const FString& HashKey, FSkeletalMeshImportData& SkeletalMeshData, bool& HasBlendShapes)
{
	TArray<uint8> CacheData;
	FString CacheKey = GetDDCKey(UsdDDCType::SkeletalMesh, HashKey);

	if (CacheKey.IsEmpty())
	{
		return false;
	}

#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 24
	if (GetDerivedDataCacheRef().GetSynchronous(*CacheKey, CacheData))
#else
	if (GetDerivedDataCacheRef().GetSynchronous(*CacheKey, CacheData, TEXT("Omniverse USD Import Skeletal Mesh")))
#endif
	{
		if (CacheData.Num() > 0)
		{
			FMemoryReader Ar(CacheData, true);
			Serialize(Ar, SkeletalMeshData);
			Ar << HasBlendShapes;
			return true;
		}
	}

	return false;
}
