// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.
#include "USDEditDelegate.h"

void FUSDEditDelegate::HandleNotice(const pxr::SdfNotice::LayersDidChangeSentPerLayer& LayerNotice, const pxr::TfWeakPtr<pxr::SdfLayer>& Sender)
{
	if(bIgnoreNotice)
	{
		return;
	}

	Layer = Sender;
	auto Itr = LayerNotice.find(Layer);
	for(const auto& ChangeEntry : Itr->second.GetEntryList())
	{
		auto ItrChange = ChangeList.begin();
		for (; ItrChange != ChangeList.end(); ++ItrChange)
		{
			if (ItrChange->first == ChangeEntry.first)
			{
				break;
			}
		}

		if(ItrChange == ChangeList.end())
		{
			ChangeList.push_back(ChangeEntry);
			continue;
		}

		auto& AddedChange = ItrChange->second;
		const auto& NewChange = ChangeEntry.second;

		for(int I = 0; I < sizeof(pxr::SdfChangeList::Entry::_Flags); ++I)
		{
			((unsigned char*)& AddedChange.flags)[I] |= ((unsigned char*)& NewChange.flags)[I];
		}

		AddedChange.subLayerChanges.insert(AddedChange.subLayerChanges.end(), NewChange.subLayerChanges.begin(), NewChange.subLayerChanges.end());

		for(const auto& FieldChange : NewChange.infoChanged)
		{
			auto ItrField = std::find(AddedChange.infoChanged.begin(), AddedChange.infoChanged.end(), FieldChange/*.first*/);
			if(ItrField != AddedChange.infoChanged.end())
			{
				ItrField->second.second = FieldChange.second.second;
			}
			else
			{
				AddedChange.infoChanged.push_back(FieldChange);
			}
		}
	}
}

std::vector<pxr::SdfPath> FUSDEditDelegate::RevertInertEdit(pxr::UsdStage& Stage)
{
	std::vector<pxr::SdfPath> RevertedPaths;

	if(!Layer)
	{
		ChangeList.clear();

		return RevertedPaths;
	}

	bIgnoreNotice = true;

	pxr::SdfChangeBlock ChangeBlock;

	for(const auto& ChangeEntry : ChangeList)
	{
		auto& Path = ChangeEntry.first;
		const char* PathStr = Path.GetText();
		auto& Change = ChangeEntry.second;
		if(!Path.IsPrimPropertyPath())
		{
			continue;
		}

		auto PropSpec = Layer->GetPropertyAtPath(Path);
		auto Prop = Stage.GetObjectAtPath(Path).As<pxr::UsdProperty>();
		if(!PropSpec || !Prop)
		{
			continue;
		}

		// Revert if it's overridden by stronger layer
		bool bShouldRevert = false;
		auto PropStack = Prop.GetPropertyStack();
		if(PropStack.front() != PropSpec)
		{
			bShouldRevert = true;
		}
		else if(PropStack.back() != PropSpec && (Change.flags.didAddPropertyWithOnlyRequiredFields || Change.flags.didAddProperty))
		{
			// Revert if it doesn't override anything
			auto ItrBegin = ++std::find(PropStack.begin(), PropStack.end(), PropSpec);

			bool bNewFieldEdit = false;

			for(auto Field : PropSpec->ListFields())
			{
				bool bOverrideField = true;

				for(auto ItrProp = ItrBegin;
					ItrProp != PropStack.end();
					++ItrProp
					)
				{
					if(!(*ItrProp)->HasField(Field))
					{
						continue;
					}

					if(PropSpec->GetField(Field) == (*ItrProp)->GetField(Field))
					{
						bOverrideField = false;
						break;
					}
				}

				if(bOverrideField)
				{
					bNewFieldEdit = true;
					break;
				}
			}

			if(!bNewFieldEdit)
			{
				bShouldRevert = true;
			}
		}

		if(!bShouldRevert)
		{
			continue;
		}

		// Revert
		if(Change.flags.didAddPropertyWithOnlyRequiredFields || Change.flags.didAddProperty)
		{
			if(auto PrimSpec = pxr::TfDynamic_cast<pxr::SdfPrimSpecHandle>(PropSpec->GetOwner()))
			{
				PrimSpec->RemoveProperty(PropSpec);
				Layer->RemovePrimIfInert(PrimSpec);
			}
		}
		else
		{
			for(auto InfoChange : Change.infoChanged)
			{
				PropSpec->SetField(InfoChange.first, InfoChange.second.first);
			}
		}

		RevertedPaths.push_back(Path);
	}

	bIgnoreNotice = false;

	ChangeList.clear();

	return RevertedPaths;
}
