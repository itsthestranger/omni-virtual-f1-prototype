// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseEdMode.h"
#include "EngineUtils.h"

const FName FOmniverseEdMode::EdModeID("OmniverseEdMode");
FOmniverseEdMode::FOnProcessCopy FOmniverseEdMode::OnProcessCopy;
FOmniverseEdMode::FOnProcessPaste FOmniverseEdMode::OnProcessPaste;
FOmniverseEdMode::FOnProcessCut FOmniverseEdMode::OnProcessCut;
FOmniverseEdMode::FOnProcessDuplicate FOmniverseEdMode::OnProcessDuplicate;
FOmniverseEdMode::FOnProcessDelete FOmniverseEdMode::OnProcessDelete;


bool FOmniverseEdMode::ProcessEditCopy()
{
	bool Result;
	OnProcessCopy.Broadcast(Result);
	return Result;
}

bool FOmniverseEdMode::ProcessEditPaste()
{
	bool Result;
	OnProcessPaste.Broadcast(Result);
	return Result;
}

bool FOmniverseEdMode::ProcessEditDuplicate()
{
	bool Result;
	OnProcessDuplicate.Broadcast(Result);
	return Result;
}

bool FOmniverseEdMode::ProcessEditCut()
{
	bool Result;
	OnProcessCut.Broadcast(Result);
	return Result;
}

bool FOmniverseEdMode::ProcessEditDelete()
{
	bool Result;
	OnProcessDelete.Broadcast(Result);
	return Result;
}

