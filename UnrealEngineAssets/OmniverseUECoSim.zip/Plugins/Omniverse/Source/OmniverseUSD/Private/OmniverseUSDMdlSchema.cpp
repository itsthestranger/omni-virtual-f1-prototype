// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "CoreMinimal.h"
#include "OmniverseUSD.h"
#include "OmniverseUSDLog.h"
#include "USDConverter.h"
#include "OmniverseSettings.h"
#include "OmniverseStageActor.h"
#include "OmniverseMDL.h"
#include "OmniverseTexture.h"
#include "OmniverseAssetUserData.h"
#include "OmniverseAssetExportHelper.h"
#include "OmniverseNotificationHelper.h"
#include "OmniverseUSDSequenceImporter.h"
#include "OmniverseUSDTokens.h"
#include "OmniversePackageReader.h"
#include "Components/MeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/SkeletalMesh.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Extractors/TimeSamplesData.h"
#include "IMaterialEditor.h"
#include "MaterialEditor/MaterialEditorInstanceConstant.h"
#include "MaterialEditorInstanceNotifier.h"
#include "USDHashGenerator.h"
#include "USDGeometryCache.h"
#include "OmniverseAssetImportHelper.h"
#include "OmniverseUSDImporterHelper.h"
#include "IOmniverseRuntimeModule.h"

// NOTE: Texture (depending on type) might be recreated by TextureFactory, so can't use weakptr here. Or the ptr will be stale.
void AOmniverseStageActor::OverrideTextureSRGB(UTexture* Texture, bool SRGB)
{
	if (!(Texture && Texture->IsValidLowLevel()))
	{
		return;
	}

	UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(Texture->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
	if (OmniverseAssetUserData)
	{
		UOmniverseTexture* OmniTexture = CastChecked<UOmniverseTexture>(OmniverseAssetUserData->OmniAsset);
		OmniTexture->OnImageUpdated.RemoveAll(this);
	}

	if (Texture && Texture->SRGB != SRGB)
	{
		Texture->SRGB = SRGB;

		if (Texture->SRGB && Texture->CompressionSettings == TC_Normalmap)
		{
			Texture->CompressionSettings = TC_Default;
		}

		Texture->PostEditChange();
		Texture->MarkPackageDirty();
	}
}

bool AOmniverseStageActor::LoadOldMdlSchema(UMeshComponent* Component, int32 SlotIndex, const pxr::UsdShadeShader& MDLShader)
{
	if (!MDLShader)
	{
		return false;
	}

	auto BindMDLDelegates = [this](UMeshComponent& Component, UOmniverseMDL& OmniMDL, bool bNewCreated)
	{
		auto& DelegateHandles = MDLDelegateHandles.FindOrAdd(&Component);

		FDelegateHandle DelegateHandle;
		if (DelegateHandles.RemoveAndCopyValue(&OmniMDL, DelegateHandle))
		{
			OmniMDL.OnUpdated.Remove(DelegateHandle);
		}

		DelegateHandle = OmniMDL.OnUpdated.AddUObject(
			this,
			&AOmniverseStageActor::OnMDLUpdated,
			TWeakObjectPtr<USceneComponent>(&Component),
			TWeakObjectPtr<UOmniverseMDL>(&OmniMDL),
			bNewCreated
		);

		DelegateHandles.Add(&OmniMDL, DelegateHandle);
	};

	// Get UE4 material path
	auto MDLModule = MDLShader.GetPrim().GetAttribute(USDTokens.module);

	if (MDLModule.GetTypeName().GetAsToken() == pxr::SdfValueTypeNames->Asset)
	{
		// MDL stored on Omniverse
		FString OmniPath;
		{
			auto AssetPath = GetUSDValue<pxr::SdfAssetPath>(MDLModule);
			OmniPath = AssetPath.GetResolvedPath().c_str();
		}

		FString MDLMaterialName = GetUSDValue<std::string>(MDLShader.GetPrim().GetAttribute(USDTokens.name)).c_str();
		UMaterialInterface* Material = nullptr;
		if (HasValidImportStage())
		{
			FString AssetMaterialName = GetUniqueImportName(OmniPath, MDLMaterialName);
			auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(OmniPath));
			if (Object && Object->IsValid())
			{
				Material = Cast<UMaterialInterface>(Object->Get());
			}			
			Material = LoadImportObject<UMaterialInterface>(ImportType::Material, AssetMaterialName);

			FString UserName;
			FString Server;
			FString AssetPath;
			FString Branch;
			FString CheckPoint;
			FOmniversePathHelper::SplitUrlPath(OmniPath, UserName, Server, AssetPath, Branch, CheckPoint);
			AssetPath.ReplaceInline(TEXT("\\"), TEXT("/"));
			FString ModuleName = FPaths::GetPath(AssetPath) / FPaths::GetBaseFilename(AssetPath);
			int32 Colon = ModuleName.Find(TEXT(":"));
			if (Colon != INDEX_NONE)
			{
				ModuleName = ModuleName.RightChop(Colon + 1);
			}
			ModuleName.ReplaceInline(TEXT("/"), TEXT("::"));

			TArray<FString> ModulePaths;

			if (!Server.IsEmpty())
			{
				if (OmniPath.StartsWith(TEXT("omniverse://")))
				{
					ModulePaths.Add(TEXT("omniverse://") + Server + TEXT("/"));
				}
				if (OmniPath.StartsWith(TEXT("https://")))
				{
					ModulePaths.Add(TEXT("https://") + Server + TEXT("/"));
				}
				if (OmniPath.StartsWith(TEXT("http://")))
				{
					ModulePaths.Add(TEXT("http://") + Server + TEXT("/"));
				}
			}

			if (Material == nullptr)
				{
				Material = UOmniverseMDL::ImportMDL(GetAssetPackage(ImportType::Material, AssetMaterialName), ModuleName, MDLMaterialName, ModulePaths, nullptr, GetAssetName(AssetMaterialName), GetAssetFlag(), OmniPath, [&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
				{
					CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
				});
			}			
			else
			{
				UOmniverseMDL::ImportMdlParameters(ModuleName, MDLMaterialName, ModulePaths, nullptr, AssetMaterialName);
			}

			// only for importing
			if (Material)
			{
				USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(OmniPath), Material);
			}
		}
		else
		{
			auto OmniMDL = UOmniverseAsset::LoadAsset<UOmniverseMDL>(*OmniPath/*, false*/);
			if (OmniMDL && Component)
			{
				Material = OmniMDL->FindMaterial(FName(MDLMaterialName));
				if (Material == nullptr)
				{
					Material = OmniMDL->FindMaterial(FName(*FPaths::GetBaseFilename(OmniPath)));
				}
		
				BindMDLDelegates(*Component, *OmniMDL, !Material);
			}
		}

		if (Material && Component)
		{
			SetMaterial(*Component, SlotIndex, Material);
		}

		return true;
	}

	return false;
}

bool IsNodeValid(const pxr::UsdPrim& TargetPrim, const pxr::UsdPrim& SourcePrim)
{
	if (TargetPrim == SourcePrim)
	{
		return true;
	}
	else
	{
		std::vector<pxr::UsdShadeInput> Inputs;
		if (SourcePrim.IsA<pxr::UsdShadeShader>())
		{
			Inputs = pxr::UsdShadeShader(SourcePrim).GetInputs();
		}
		else if (SourcePrim.IsA<pxr::UsdShadeNodeGraph>())
		{
			Inputs = pxr::UsdShadeNodeGraph(SourcePrim).GetInputs();
		}

		for (auto Input : Inputs)
		{
			if (Input.HasConnectedSource())
			{
				pxr::UsdShadeConnectableAPI Source;
				pxr::TfToken SourceName;
				pxr::UsdShadeAttributeType SourceType;
				Input.GetConnectedSource(&Source, &SourceName, &SourceType);

				if (IsNodeValid(TargetPrim, Source.GetPrim()))
				{
					return true;
				}
			}
		}
	}

	return false;
}

bool AOmniverseStageActor::IsValidNodeFromGraph(const pxr::UsdPrim& TargetPrim, const pxr::UsdShadeMaterial& ShadeMaterial)
{
	auto SurfaceOutput = ShadeMaterial.GetSurfaceOutput();
	if (SurfaceOutput)
	{
		pxr::UsdShadeConnectableAPI Source;
		pxr::TfToken SourceName;
		pxr::UsdShadeAttributeType SourceType;

		if (SurfaceOutput.GetConnectedSource(&Source, &SourceName, &SourceType))
		{
			return IsNodeValid(TargetPrim, Source.GetPrim());
		}
	}

	return false;
}

bool AOmniverseStageActor::GetGraphNodeInputName(const pxr::UsdShadeInput& TargetInput, const pxr::UsdPrim& Prim, const pxr::TfToken& SourceName, const FString& ParentInputName, FString& OutInputName)
{
	if (Prim.IsA<pxr::UsdShadeNodeGraph>())
	{
		auto NodeGraph = pxr::UsdShadeNodeGraph(Prim);
		auto NodeOutput = NodeGraph.GetOutput(SourceName);
		auto NodeInput = NodeGraph.GetInput(SourceName);
		
		if (NodeOutput && NodeOutput.HasConnectedSource())
		{
			pxr::UsdShadeConnectableAPI OutputSource;
			pxr::TfToken OutputSourceName;
			pxr::UsdShadeAttributeType OutputSourceType;
			NodeOutput.GetConnectedSource(&OutputSource, &OutputSourceName, &OutputSourceType);

			if (GetGraphNodeInputName(TargetInput, OutputSource.GetPrim(), OutputSourceName, ParentInputName, OutInputName))
			{
				return true;
			}
		}
		else if (NodeInput && NodeInput.HasConnectedSource())
		{
			pxr::UsdShadeConnectableAPI InputSource;
			pxr::TfToken InputSourceName;
			pxr::UsdShadeAttributeType InputSourceType;
			NodeInput.GetConnectedSource(&InputSource, &InputSourceName, &InputSourceType);

			if (GetGraphNodeInputName(TargetInput, InputSource.GetPrim(), InputSourceName, ParentInputName, OutInputName))
			{
				return true;
			}
		}
		
		if (NodeInput == TargetInput)
		{
			FString DisplayName = NodeInput.GetAttr().GetDisplayName().c_str();
			OutInputName = ParentInputName.IsEmpty() ? DisplayName : ParentInputName;
			return true;
		}
	}
	else if (Prim.IsA<pxr::UsdShadeShader>())
	{
		auto ShadeShader = pxr::UsdShadeShader(Prim);
		std::vector<pxr::UsdShadeInput> Inputs = ShadeShader.GetInputs();
		for (auto Input : Inputs)
		{
			FString InputName = Input.GetBaseName().GetText();
			FString UEInputName = ParentInputName.IsEmpty() ? InputName : (ParentInputName + TEXT(".") + InputName);
			if (Input == TargetInput)
			{
				FString DisplayName = Input.GetAttr().GetDisplayName().c_str();
				OutInputName = ParentInputName.IsEmpty() ? DisplayName : UEInputName;
				return true;
			}

			if (Input.HasConnectedSource())
			{
				pxr::UsdShadeConnectableAPI InputSource;
				pxr::TfToken InputSourceName;
				pxr::UsdShadeAttributeType InputSourceType;
				Input.GetConnectedSource(&InputSource, &InputSourceName, &InputSourceType);

				if (GetGraphNodeInputName(TargetInput, InputSource.GetPrim(), InputSourceName, UEInputName, OutInputName))
				{
					return true;
				}
			}
		}
	}

	return false;
}

void AOmniverseStageActor::LoadOmniTexture(FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
{
	if (!HasValidImportStage() && FOmniversePathHelper::IsValidAbsolutePath(TexturePath))
	{
		OutTexture = UOmniverseAsset::LoadAsset<UTexture>(TexturePath);
		OutOmniTexture = UOmniverseAsset::LoadAsset<UOmniverseTexture>(TexturePath);
	}
}

void AOmniverseStageActor::PostLoadOmniTexture(UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
{
	if (InTextureAsset->bValidAsset)
	{
		OverrideTextureSRGB(InTexture, OverrideSRGB);

		if (InTextureAsset->GetOutermost()->IsDirty())
		{
			InTextureAsset->SaveToDisk();
		}
	}
	else
	{
		InTextureAsset->OnImageUpdated.AddUObject(this, &AOmniverseStageActor::OverrideTextureSRGB, InTexture, OverrideSRGB);
	}
}

void AOmniverseStageActor::CreateTextureFromBuffer(const uint8* Content, uint64 Size, const FString& FileName, class UTexture*& OutTexture)
{
	FString TextureFileName = FileName;
	if (FOmniversePathHelper::IsPackagePath(FileName))
	{
		TextureFileName = FOmniversePathHelper::GetPackagedSubPath(FileName);
	}
	FString TextureName = FPaths::GetBaseFilename(TextureFileName);
	FOmniversePathHelper::FixAssetName(TextureName);
	TextureName = GetUniqueImportName(FileName, TextureName);

	if (HasValidImportStage())
	{
		auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(FileName));
		if (Object && Object->IsValid())
		{
			OutTexture = Cast<UTexture>(Object->Get());
		}
	}
	
	if (OutTexture == nullptr)
	{
		OutTexture = LoadImportObject<UTexture>(ImportType::Texture, TextureName);
		if (OutTexture == nullptr)
		{
			OutTexture = UOmniverseTexture::CreateTextureFromBuffer(Content, Size, GetAssetPackage(ImportType::Texture, TextureName), *TextureName, GetAssetFlag(), FileName);
		}

		if (HasValidImportStage() && OutTexture)
		{
			USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(FileName), OutTexture);
		}
	}
}

void AOmniverseStageActor::UpdateGraphNodePrim(const pxr::SdfPath& Path)
{
	auto Prim = GetUSDStage()->GetPrimAtPath(Path.GetAbsoluteRootOrPrimPath());
	if (Prim && Prim.HasAPI<pxr::UsdUINodeGraphNodeAPI>())
	{
		FString Token = Path.GetName().c_str();
		if (!Token.StartsWith(TEXT("ui:nodegraph")))
		{
			// Check valid node shader
			auto USDMaterial = FindShadeMaterial(Prim);
			if (USDMaterial)
			{
				if (IsValidNodeFromGraph(Prim, USDMaterial))
				{
					// Node graph material
					pxr::UsdShadeConnectableAPI Source;
					pxr::TfToken SourceName;
					pxr::UsdShadeAttributeType SourceType;

					auto SurfaceOutput = USDMaterial.GetSurfaceOutput();
					if (SurfaceOutput.GetConnectedSource(&Source, &SourceName, &SourceType))
					{
						auto GraphShader = pxr::UsdShadeShader(Source);
						auto MaterialInst = FindObjectFromPath<UMaterialInstanceConstant>(USDMaterial.GetPath());
						if (MaterialInst)
						{
							bool bRecompile = false;
							pxr::UsdShadeInput ShaderInput = pxr::UsdShadeInput(GetUSDStage()->GetAttributeAtPath(Path));
							if (ShaderInput)
							{
								if (ShaderInput.HasConnectedSource())
								{
									bRecompile = true;
								}
								else
								{
									FString UEInputName;
									if (!GetGraphNodeInputName(ShaderInput, Source.GetPrim(), SourceName, TEXT(""), UEInputName))
									{
										bRecompile = true;

									}
									else if (!FOmniverseUSDImporterHelper::LoadMdlInput(*MaterialInst, ShaderInput, UEInputName, true, 
									[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
									{
										CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
									},
									[&](FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
									{
										LoadOmniTexture(TexturePath, OutTexture, OutOmniTexture);
									},
									[&](UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
									{
										PostLoadOmniTexture(InTextureAsset, InTexture, OverrideSRGB);
									}))
									{
										bRecompile = true;
									}
								}
							}
							else
							{
								bRecompile = true;
							}

							if (bRecompile)
							{
								FOmniverseUSDImporterHelper::LoadMaterialGraph(GraphShader, MaterialInst->GetMaterial());
								FOmniverseUSDImporterHelper::UpdateMaterialGraphInputs(GraphShader, MaterialInst, 
								[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
								{
									CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
								},
								[&](FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
								{
									LoadOmniTexture(TexturePath, OutTexture, OutOmniTexture);
								},
								[&](UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
								{
									PostLoadOmniTexture(InTextureAsset, InTexture, OverrideSRGB);
								});
							}
						}
					}
				}
			}
		}
	}
}

bool AOmniverseStageActor::LoadMdlSchema(UMeshComponent* Component, int32 SlotIndex, const pxr::UsdShadeShader& ShadeShader)
{
	if (!ShadeShader)
	{
		return false;
	}

	const auto ImplementationSource = ShadeShader.GetImplementationSource();
	if (ImplementationSource == USDTokens.sourceAsset)
	{
		FString MdlPath, MaterialName;
		bool bRelativePath = false;
		if (FOmniverseUSDImporterHelper::GetMdlPathAndName(ShadeShader, MdlPath, MaterialName, bRelativePath))
		{
			FString ShaderPath = ShadeShader.GetPath().GetText();
			auto USDMaterial = FindShadeMaterial(ShadeShader.GetPrim());
			if (!USDMaterial)
			{
				return false;
			}

			FString MaterialPrimName = USDMaterial.GetPrim().GetName().GetText();

			auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(ShaderPath));
			if (Object && Object->IsValid())
			{
				if (Component)
				{
					SetMaterial(*Component, SlotIndex, Cast<UMaterialInstanceConstant>(Object->Get()));
				}
			}
			else if (ShadeShader.GetPrim().HasAPI<pxr::UsdUINodeGraphNodeAPI>())
			{
				FString MaterialPath = USDMaterial.GetPath().GetText();
				auto Node = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(MaterialPath));
				if (Node && Node->IsValid())
				{
					if (Component)
					{
						SetMaterial(*Component, SlotIndex, Cast<UMaterialInstanceConstant>(Node->Get()));
					}
				}
				else
				{
					FString Key;
					if (HasValidImportStage())
					{
						Key = FUSDHashGenerator::ComputeSHAHash(USDMaterial).ToString();
					}
					MaterialPrimName = GetUniqueImportName(Key, MaterialPrimName);
					UE_LOG(LogOmniverseUsd, Log, TEXT("Loading material graph [%s]"), *MaterialPrimName);
					UMaterialInstanceConstant* MaterialInst = nullptr;
					if (HasValidImportStage())
					{
						MaterialInst = Cast<UMaterialInstanceConstant>(FUSDGeometryCache::Find(Key));
					}

					// NOTE: instance and material bind together for Material Graph
					if (MaterialInst == nullptr)
					{
						auto MaterialInstPrimName = MaterialPrimName + TEXT("_Instance");
						MaterialInst = LoadImportObject<UMaterialInstanceConstant>(ImportType::Material, MaterialInstPrimName);

						if (MaterialInst == nullptr)
						{
							UMaterial* Material = NewObject<UMaterial>(GetAssetPackage(ImportType::Material, MaterialPrimName), GetAssetName(MaterialPrimName), GetAssetFlag());
							if (Material)
							{
								FOmniverseUSDImporterHelper::LoadMaterialGraph(ShadeShader, Material);
							}
							else
							{
								return false;
							}

							if (HasValidImportStage())
							{
								FOmniverseAssetImportHelper::UpdateAssetImportData(Material, ImportUSDSourceFile, ShaderPath);		
								FAssetRegistryModule::AssetCreated(Material);
							}

							MaterialInst = NewObject<UMaterialInstanceConstant>(GetAssetPackage(ImportType::Material, MaterialInstPrimName), GetAssetName(MaterialInstPrimName), GetAssetFlag());
							if (MaterialInst)
							{
								MaterialInst->SetParentEditorOnly(Material);
								FOmniverseUSDImporterHelper::UpdateMaterialGraphInputs(ShadeShader, MaterialInst, 
								[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
								{
									CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
								},
								[&](FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
								{
									LoadOmniTexture(TexturePath, OutTexture, OutOmniTexture);
								},
								[&](UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
								{
									PostLoadOmniTexture(InTextureAsset, InTexture, OverrideSRGB);
								});
							}
							else
							{
								return false;
							}
							MaterialInst->PostEditChange();
							MaterialInst->MarkPackageDirty();
							if (HasValidImportStage())
							{
								FOmniverseAssetImportHelper::UpdateAssetImportData(MaterialInst, ImportUSDSourceFile, ShaderPath);
								FAssetRegistryModule::AssetCreated(MaterialInst);
							}
						}

						if (HasValidImportStage())
						{
							FUSDGeometryCache::Add(Key, MaterialInst);
						}
					}

					if (MaterialInst)
					{
						USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(MaterialPath), MaterialInst);
						if (Component)
						{
							SetMaterial(*Component, SlotIndex, MaterialInst);
						}
					}
				}
			}
			else
			{
				FString Key;
				if (HasValidImportStage())
				{
					Key = FUSDHashGenerator::ComputeSHAHash(USDMaterial).ToString();
				}
				FString InstanceName = MaterialPrimName + TEXT("_Instance");
				InstanceName = GetUniqueImportName(Key, InstanceName);
				UE_LOG(LogOmniverseUsd, Log, TEXT("Loading mdl schema material [%s]"), *MaterialPrimName);
				UMaterialInstanceConstant* InstanceDynamic = nullptr;
				if (HasValidImportStage())
				{
					InstanceDynamic = Cast<UMaterialInstanceConstant>(FUSDGeometryCache::Find(Key));
				}

				if (InstanceDynamic == nullptr)
				{
					InstanceDynamic = LoadImportObject<UMaterialInstanceConstant>(ImportType::Material, InstanceName);
					if (InstanceDynamic == nullptr)
					{
						InstanceDynamic = CreateDynamicInstanceFromMdl(Component, SlotIndex, MdlPath, bRelativePath, MaterialName, InstanceName);

						if (InstanceDynamic)
						{
							FNamedParameterTimeSamples ParameterTimeSamples;
							UpdateShadeInputs(InstanceDynamic, ShadeShader, &ParameterTimeSamples);

							InstanceDynamic->PostEditChange();
							InstanceDynamic->MarkPackageDirty();

							if (HasValidImportStage())
							{
								FAssetRegistryModule::AssetCreated(InstanceDynamic);
								FOmniverseAssetImportHelper::UpdateAssetImportData(InstanceDynamic, ImportUSDSourceFile, ShaderPath);
							}

							if (Component)
							{
								USDSequenceImporter->CreateMaterialTrack(Component, SlotIndex, ParameterTimeSamples);
							}
						}
					}

					if (HasValidImportStage())
					{
						FUSDGeometryCache::Add(Key, InstanceDynamic);						
					}
				}

				if (InstanceDynamic)
				{
					USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(ShaderPath), InstanceDynamic);
					if (Component)
					{
						SetMaterial(*Component, SlotIndex, InstanceDynamic);
					}
				}
			}
			return true;
		}
	}

	return false;
}

void LoadInputTimeSamples(const pxr::UsdShadeInput& Input, const FString& DisplayName, FNamedParameterTimeSamples* ParameterTimeSamples)
{
	if (ParameterTimeSamples)
	{
		auto Attribute = Input.GetAttr();
		std::vector<double> TimeSamples;
		Attribute.GetTimeSamples(&TimeSamples);

		if (TimeSamples.size() > 0)
		{
			FFloatTimeSamples FloatTimeSamples;
			FColorTimeSamples ColorTimeSamples;
			for(auto TimeCode : TimeSamples)
			{
				pxr::VtValue VtValue;
				if (Input.Get(&VtValue, pxr::UsdTimeCode(TimeCode)))
				{
					auto Type = VtValue.GetType();
					if (Type == pxr::SdfValueTypeNames->Float.GetType())
					{
						float Value = VtValue.Get<float>();
						FloatTimeSamples.TimeSamples.Add(TimeCode, Value);
					}
					else if (Type == pxr::SdfValueTypeNames->Int.GetType())
					{
						int32 Value = VtValue.Get<int>();
						FloatTimeSamples.TimeSamples.Add(TimeCode, (float)Value);
					}
					else if (Type == pxr::SdfValueTypeNames->Bool.GetType())
					{
						bool Value = VtValue.Get<bool>();
						FloatTimeSamples.TimeSamples.Add(TimeCode, Value ? 1.0f : 0.0f);
					}
					else if (Type == pxr::SdfValueTypeNames->Float2.GetType())
					{
						FLinearColor Value = USDConvertToLinearColor(VtValue.Get<pxr::GfVec2f>());
						ColorTimeSamples.TimeSamples.Add(TimeCode, Value);
					}
					else if (Type == pxr::SdfValueTypeNames->Float3.GetType())
					{
						FLinearColor Value = USDConvertToLinearColor(VtValue.Get<pxr::GfVec3f>());
						ColorTimeSamples.TimeSamples.Add(TimeCode, Value);
					}
					else if (Type == pxr::SdfValueTypeNames->Float4.GetType())
					{
						FLinearColor Value = USDConvertToLinearColor(VtValue.Get<pxr::GfVec4f>());
						ColorTimeSamples.TimeSamples.Add(TimeCode, Value);
					}
				}
			}

			if (FloatTimeSamples.TimeSamples.Num() > 0)
			{
				ParameterTimeSamples->ScalarTimeSamples.Add(*DisplayName, FloatTimeSamples);
			}
			else if (ColorTimeSamples.TimeSamples.Num() > 0)
			{
				ParameterTimeSamples->ColorTimeSamples.Add(*DisplayName, ColorTimeSamples);
			}
		}
	}
}

void AOmniverseStageActor::UpdateShadeInputs(UMaterialInstanceConstant* InstanceDynamic, const pxr::UsdShadeShader& ShadeShader, const FString& ParentInputName)
{
	std::vector<pxr::UsdShadeInput> Inputs = ShadeShader.GetInputs();
	for (auto Input: Inputs)
	{
		auto ConnectInput = Input;
		FString InputName = ParentInputName + TEXT(".") + Input.GetBaseName().GetText();
		if (Input.HasConnectedSource())
		{
			pxr::UsdShadeConnectableAPI Source;
			pxr::TfToken SourceName;
			pxr::UsdShadeAttributeType SourceType;
			Input.GetConnectedSource(&Source, &SourceName, &SourceType);

			if (SourceType == pxr::UsdShadeAttributeType::Output)
			{
				auto InputShader = pxr::UsdShadeShader(Source);
				if (InputShader)
				{
					UpdateShadeInputs(InstanceDynamic, InputShader, InputName);
					continue;
				}
			}
			else
			{
				ConnectInput = Source.GetInput(SourceName);
			}
		}

		FOmniverseUSDImporterHelper::LoadMdlInput(*InstanceDynamic, ConnectInput, InputName, false,
		[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
		{
			CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
		},
		[&](FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
		{
			LoadOmniTexture(TexturePath, OutTexture, OutOmniTexture);
		},
		[&](UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
		{
			PostLoadOmniTexture(InTextureAsset, InTexture, OverrideSRGB);
		});
	}
}

void AOmniverseStageActor::UpdateShadeInputs(UMaterialInstanceConstant* InstanceDynamic, const pxr::UsdShadeShader& ShadeShader, FNamedParameterTimeSamples* ParameterTimeSamples)
{
	if (!InstanceDynamic->Parent)
	{
		return;
	}

	if (!InstanceDynamic->GetMaterial())
	{
		return;
	}

	UOmniverseMDL* OmniMDL = nullptr;
	auto LocalBaseMDL = UOmniverseMDL::GetLocalBaseMaterial(InstanceDynamic);
	bool bIsLocalCore = (LocalBaseMDL != nullptr);
	if (!bIsLocalCore)
	{
		if (!HasValidImportStage())
		{
			UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(InstanceDynamic->Parent->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
			if (!OmniverseAssetUserData)
			{
				return;
			}
		
			OmniMDL = CastChecked<UOmniverseMDL>(OmniverseAssetUserData->OmniAsset);
			if(!OmniMDL)
			{
				return;
			}
		}
	}

	//TMap<FName, bool> SwitchParameters;
	std::vector<pxr::UsdShadeInput> Inputs = ShadeShader.GetInputs();
	for(auto Input : Inputs)
	{
		FString DisplayName;
		auto ConnectInput = Input;
		if (Input.HasConnectedSource())
		{
			pxr::UsdShadeConnectableAPI Source;
			pxr::TfToken SourceName;
			pxr::UsdShadeAttributeType SourceType;
			Input.GetConnectedSource(&Source, &SourceName, &SourceType);
						
			if (SourceType == pxr::UsdShadeAttributeType::Output)
			{
				auto InputShader = pxr::UsdShadeShader(Source);
				if (InputShader)
				{
					UpdateShadeInputs(InstanceDynamic, InputShader, Input.GetBaseName().GetText());
					continue;
				}
			}
			else
			{
				ConnectInput = Source.GetInput(SourceName);
			}
		}

		if (bIsLocalCore)
		{
			UOmniverseMDL::GetDisplayNameFromLocalBaseMDL(LocalBaseMDL->GetName(), ConnectInput.GetBaseName().GetText(), DisplayName);
		}
		else if (OmniMDL)
		{
			OmniMDL->GetUnrealDisplayName(InstanceDynamic->Parent->GetName(), ConnectInput.GetBaseName().GetText(), DisplayName);
		}
		else if (HasValidImportStage())
		{
			UOmniverseMDL::GetImportDisplayName(InstanceDynamic->Parent->GetName(), ConnectInput.GetBaseName().GetText(), DisplayName);
		}

		if (!DisplayName.IsEmpty())
		{
			LoadInputTimeSamples(ConnectInput, DisplayName, ParameterTimeSamples);
			FOmniverseUSDImporterHelper::LoadMdlInput(*InstanceDynamic, ConnectInput, DisplayName, false,
			[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
			{
				CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
			},
			[&](FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
			{
				LoadOmniTexture(TexturePath, OutTexture, OutOmniTexture);
			},
			[&](UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
			{
				PostLoadOmniTexture(InTextureAsset, InTexture, OverrideSRGB);
			});
		}
	}

	//UpdateStaticParameters(InstanceDynamic, &SwitchParameters);
}

UMaterialInstanceConstant* AOmniverseStageActor::CreateDynamicInstanceFromMdl(UMeshComponent* Component, int32 SlotIndex, const FString& MdlPath,  bool bRelativePath, const FString& InMaterialName, const FString& InstanceName)
{
	UMaterialInstanceConstant* MaterialInst = nullptr;
	UMaterialInterface* Material = nullptr;
	auto BindMDLDelegates = [this](UMeshComponent& Component, UOmniverseMDL& OmniMDL, bool bNewCreated)
	{
		auto& DelegateHandles = MDLDelegateHandles.FindOrAdd(&Component);

		FDelegateHandle DelegateHandle;
		if(DelegateHandles.RemoveAndCopyValue(&OmniMDL, DelegateHandle))
		{
			OmniMDL.OnUpdated.Remove(DelegateHandle);
		}

		DelegateHandle = OmniMDL.OnUpdated.AddUObject(
			this,
			&AOmniverseStageActor::OnMDLUpdated,
			TWeakObjectPtr<USceneComponent>(&Component),
			TWeakObjectPtr<UOmniverseMDL>(&OmniMDL),
			bNewCreated
		);

		DelegateHandles.Add(&OmniMDL, DelegateHandle);
	};

	// NOTE: Material Name could be with parameters
	FString MdlMaterialName = InMaterialName;
	int32 ParamStart = MdlMaterialName.Find(TEXT("("));
	if (ParamStart != INDEX_NONE)
	{
		MdlMaterialName = MdlMaterialName.Left(ParamStart);
	}

	if (!bRelativePath && UOmniverseMDL::IsLocalBaseMDL(MdlPath))
	{
		Material = UOmniverseMDL::LoadLocalBaseMDL(MdlPath, MdlMaterialName);
	}
	else if (!MdlPath.IsEmpty() && FOmniversePathHelper::IsPackagePath(MdlPath))
	{
		auto PackageMDLFile = FOmniversePathHelper::GetPackagedSubPath(MdlPath);
		FString ModuleName = FPaths::GetPath(PackageMDLFile) / FPaths::GetBaseFilename(PackageMDLFile);
		ModuleName.ReplaceInline(TEXT("/"), TEXT("::"));
		if (!ModuleName.StartsWith(TEXT("::")))
		{
			ModuleName = TEXT("::") + ModuleName;
		}

		TSharedPtr<FOmniversePackageReader> PackageReader = MakeShareable(new FOmniversePackageReader());
		PackageReader->SetPackageRoot(FOmniversePathHelper::GetPackageRoot(MdlPath));
		
		FString AssetMaterialName = GetUniqueImportName(MdlPath, MdlMaterialName);

		if (HasValidImportStage())
		{
			auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(MdlPath));
			if (Object && Object->IsValid())
			{
				Material = Cast<UMaterialInterface>(Object->Get());
			}
		}
		
		if (Material == nullptr)
		{
			Material = LoadImportObject<UMaterialInterface>(ImportType::Material, AssetMaterialName);
		}
		if (Material == nullptr)
		{
			Material = UOmniverseMDL::ImportMDL(GetAssetPackage(ImportType::Material, AssetMaterialName), ModuleName, MdlMaterialName, {FOmniversePathHelper::GetPackageRoot(MdlPath)}, PackageReader, GetAssetName(AssetMaterialName), GetAssetFlag(), MdlPath, [&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
			{
				FString TextureSouceFile = FileName;
                if (FOmniversePathHelper::IsPackagePath(MdlPath))
				{
                    auto PackageRoot = FOmniversePathHelper::GetPackageRoot(MdlPath);
                    if (FileName.StartsWith(PackageRoot, ESearchCase::CaseSensitive))
                    {
                        TextureSouceFile.RemoveAt(PackageRoot.Len());
                        TextureSouceFile.InsertAt(PackageRoot.Len(), "[");
                        TextureSouceFile.Append("]");
                    }
				}

				CreateTextureFromBuffer(Content, Size, TextureSouceFile, OutTexture);
			});	
		}
		else
		{
			UOmniverseMDL::ImportMdlParameters(ModuleName, MdlMaterialName, {FOmniversePathHelper::GetPackageRoot(MdlPath)}, PackageReader, AssetMaterialName);
		}

		// only for importing
		if (HasValidImportStage() && Material)
		{
			USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(MdlPath), Material);
		}
	}
	else
	{
		if (HasValidImportStage())
		{
			FString AssetMaterialName = GetUniqueImportName(MdlPath, MdlMaterialName);
			auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(MdlPath));
			if (Object && Object->IsValid())
			{
				Material = Cast<UMaterialInterface>(Object->Get());
			}

			if (Material == nullptr)
			{
				Material = LoadImportObject<UMaterialInterface>(ImportType::Material, AssetMaterialName);
			}

			FString UserName;
			FString Server;
			FString AssetPath;
			FString Branch;
			FString CheckPoint;
			FOmniversePathHelper::SplitUrlPath(MdlPath, UserName, Server, AssetPath, Branch, CheckPoint);
			AssetPath.ReplaceInline(TEXT("\\"), TEXT("/"));
			FString ModuleName = FPaths::GetPath(AssetPath) / FPaths::GetBaseFilename(AssetPath);
			int32 Colon = ModuleName.Find(TEXT(":"));
			if (Colon != INDEX_NONE)
			{
				ModuleName = ModuleName.RightChop(Colon + 1);
			}
			ModuleName.ReplaceInline(TEXT("/"), TEXT("::"));

			TArray<FString> ModulePaths;
			if (!Server.IsEmpty())
			{
				if (MdlPath.StartsWith(TEXT("omniverse://")))
				{
					ModulePaths.Add(TEXT("omniverse://") + Server + TEXT("/"));
				}
				if (MdlPath.StartsWith(TEXT("https://")))
				{
					ModulePaths.Add(TEXT("https://") + Server + TEXT("/"));
				}
				if (MdlPath.StartsWith(TEXT("http://")))
				{
					ModulePaths.Add(TEXT("http://") + Server + TEXT("/"));
				}
			}

			if (Material == nullptr)
			{
				Material = UOmniverseMDL::ImportMDL(GetAssetPackage(ImportType::Material, AssetMaterialName), ModuleName, MdlMaterialName, ModulePaths, nullptr, GetAssetName(AssetMaterialName), GetAssetFlag(), MdlPath, [&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
				{
					CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
				});
			}			
			else
			{
				UOmniverseMDL::ImportMdlParameters(ModuleName, MdlMaterialName, ModulePaths, nullptr, AssetMaterialName);
			}

			// only for importing
			if (Material)
			{
				USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(MdlPath), Material);
			}
		}
		else
		{
			auto OmniMDL = UOmniverseAsset::LoadAsset<UOmniverseMDL>(*MdlPath/*, false*/);
			if(OmniMDL && Component)
			{
				// If Material Name was empty, the first material matching with material class type will be returned.
				Material = OmniMDL->FindMaterial(*MdlMaterialName);
				BindMDLDelegates(*Component, *OmniMDL, !Material);
			}
		}
	}

	if (Material)
	{
		MaterialInst = NewObject<UMaterialInstanceConstant>(GetAssetPackage(ImportType::Material, InstanceName), GetAssetName(InstanceName), GetAssetFlag());
		if (MaterialInst)
		{
			MaterialInst->SetParentEditorOnly(Material);
		}
	}

	return MaterialInst;
}

void AOmniverseStageActor::SetMaterial(UMeshComponent& Component, int32 SlotIndex, UMaterialInterface* Material)
{
	Component.SetMaterial(SlotIndex, Material);

	if (HasValidImportStage() && Material)
	{
		UMaterial* DefaultMaterial = LoadObject<UMaterial>(nullptr, *OmniverseDefaultMaterial);

		if (Component.IsA<UStaticMeshComponent>())
		{
			auto StaticMesh = Cast<UStaticMeshComponent>(&Component)->GetStaticMesh();
			if (StaticMesh)
			{
				if (StaticMesh->GetMaterial(SlotIndex) == nullptr || StaticMesh->GetMaterial(SlotIndex) == DefaultMaterial)
				{
					StaticMesh->SetMaterial(SlotIndex, Material);
				}
			}
		}
		else if (Component.IsA<USkeletalMeshComponent>())
		{
			auto SkeletalMesh = Cast<USkeletalMeshComponent>(&Component)->GetSkeletalMeshAsset();
			if (SkeletalMesh && SlotIndex < SkeletalMesh->GetMaterials().Num())
			{
				if (SkeletalMesh->GetMaterials()[SlotIndex].MaterialInterface == nullptr
				|| SkeletalMesh->GetMaterials()[SlotIndex].MaterialInterface == DefaultMaterial)
				{
					SkeletalMesh->GetMaterials()[SlotIndex].MaterialInterface = Material;
				}
			}
		}
	}
}

pxr::SdfValueTypeName ConvertValueType(EMdlValueType ValueType)
{
	switch(ValueType)
	{
	case EMdlValueType::MDL_BOOL:
		return pxr::SdfValueTypeNames->Bool;
	case EMdlValueType::MDL_INT:
		return pxr::SdfValueTypeNames->Int;	
	case EMdlValueType::MDL_FLOAT:
		return pxr::SdfValueTypeNames->Float;	
	case EMdlValueType::MDL_FLOAT2:
		return pxr::SdfValueTypeNames->Float2;	
	case EMdlValueType::MDL_FLOAT3:
		return pxr::SdfValueTypeNames->Float3;	
	case EMdlValueType::MDL_FLOAT4:
		return pxr::SdfValueTypeNames->Float4;	
	case EMdlValueType::MDL_COLOR:
		return pxr::SdfValueTypeNames->Color3f;	
	case EMdlValueType::MDL_TEXTURE:
		return pxr::SdfValueTypeNames->Asset;
	default:
		return pxr::SdfValueTypeNames->Float;
	}
}

void FUSDExporter::ExportMdlSchemaParameters(const pxr::UsdStageRefPtr& Stage, UMaterialInstance& MaterialInst, pxr::UsdShadeShader& ShadeShader, const FOmniverseExportTextureSettings& TextureSettings, const FString& CustomPath, bool bUniqueName)
{
	UMaterialInterface* ParentMaterial = MaterialInst.Parent;
	if (MaterialInst.GetMaterial() == nullptr || ParentMaterial == nullptr)
	{
		return;
	}
	auto LocalBaseMaterial = UOmniverseMDL::GetLocalBaseMaterial(&MaterialInst);
	bool bLocalBase = (LocalBaseMaterial != nullptr);
	UOmniverseMDL* OmniverseMDL = UOmniverseAsset::GetOmniverseAsset<UOmniverseMDL>(*ParentMaterial);

	TArray<FString> UsedInputNames;
	for (auto ScalarParameter : MaterialInst.ScalarParameterValues)
	{
		EMdlValueType ValueType = EMdlValueType::MDL_UNKNOWN;
		FString MdlParamName;
		if (bLocalBase)
		{
			UOmniverseMDL::GetMdlParameterTypeAndNameFromLocalBaseMDL(LocalBaseMaterial->GetName(), ScalarParameter.ParameterInfo.Name.ToString(), ValueType, MdlParamName);
		}
		else if (OmniverseMDL)
		{
			OmniverseMDL->GetMdlParameterTypeAndName(ParentMaterial->GetName(), ScalarParameter.ParameterInfo.Name.ToString(), ValueType, MdlParamName);
		}
		
		if (ValueType == EMdlValueType::MDL_UNKNOWN)
		{
			continue;
		}
		UsedInputNames.Add(MdlParamName);
		ExportParameter<float>(ConvertValueType(ValueType), MdlParamName, ShadeShader, ScalarParameter.ParameterValue);
	}

	for (auto VectorParameter : MaterialInst.VectorParameterValues)
	{
		EMdlValueType ValueType = EMdlValueType::MDL_UNKNOWN;
		FString MdlParamName;
		if (bLocalBase)
		{
			UOmniverseMDL::GetMdlParameterTypeAndNameFromLocalBaseMDL(LocalBaseMaterial->GetName(), VectorParameter.ParameterInfo.Name.ToString(), ValueType, MdlParamName);
		}
		else if (OmniverseMDL)
		{
			OmniverseMDL->GetMdlParameterTypeAndName(ParentMaterial->GetName(), VectorParameter.ParameterInfo.Name.ToString(), ValueType, MdlParamName);
		}

		if (ValueType == EMdlValueType::MDL_UNKNOWN)
		{
			continue;
		}
		UsedInputNames.Add(MdlParamName);
		ExportParameter<pxr::GfVec4f>(ConvertValueType(ValueType), MdlParamName, ShadeShader, LinearColorToVec(VectorParameter.ParameterValue));
	}

	for (auto TextureParameter : MaterialInst.TextureParameterValues)
	{
		UTexture* Texture = TextureParameter.ParameterValue;
		if (Texture)
		{
			FString TexturePath;
			UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(Texture->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
			if (OmniverseAssetUserData && OmniverseAssetUserData->OmniAsset)
			{
				UOmniverseTexture* OmniverseTexture = CastChecked<UOmniverseTexture>(OmniverseAssetUserData->OmniAsset);
				TexturePath = MakeAssetPathRelative(OmniverseTexture->GetOmniPath(), *Stage).c_str();
			}
			// Do not upload the texture from mdl and omniverse content, they meant empty texture for mdl
			else if ((bUniqueName || IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled()) && Texture->GetOutermost() != GetTransientPackage() && !Texture->GetOutermost()->GetName().StartsWith(TEXT("/MDL/")) && !Texture->GetOutermost()->GetName().StartsWith(TEXT("/Omniverse/")))
			{
				// Need uploading UE4 texture to server
				FString TextureFileName = bUniqueName ? FOmniverseAssetExportHelper::GetUniqueTextureName(Texture, TextureSettings.bDDSExport) : FOmniverseAssetExportHelper::GetTextureFileName(Texture);
				auto LayerPath = (*Stage).GetEditTarget().GetLayer()->GetRealPath().c_str();
				FString OmniPath = FPaths::GetPath(LayerPath) / TextureFileName;
						
				if (CustomPath.IsEmpty())
				{
					TexturePath = TEXT("./") + TextureFileName;
				}
				else
				{
					TexturePath = FOmniversePathHelper::ComputeRelativePath(CustomPath, LayerPath, true) / TextureFileName;
					OmniPath = CustomPath / TextureFileName;
				}
						
				FOmniverseAssetExportHelper::ExportTextureToPath(Texture, OmniPath, TextureSettings);

				if (bUniqueName)
				{
					FOmniverseAssetExportHelper::RegisterExportedTexture(Texture);
				}
			}

			EMdlValueType ValueType = EMdlValueType::MDL_UNKNOWN;
			FString MdlParamName;
			if (bLocalBase)
			{
				UOmniverseMDL::GetMdlParameterTypeAndNameFromLocalBaseMDL(LocalBaseMaterial->GetName(), TextureParameter.ParameterInfo.Name.ToString(), ValueType, MdlParamName);
			}
			else if (OmniverseMDL)
			{
				OmniverseMDL->GetMdlParameterTypeAndName(ParentMaterial->GetName(), TextureParameter.ParameterInfo.Name.ToString(), ValueType, MdlParamName);
			}

			if (ValueType == EMdlValueType::MDL_UNKNOWN)
			{
				continue;
			}

			UsedInputNames.Add(MdlParamName);
			if (!TexturePath.IsEmpty() && Texture->IsCurrentlyVirtualTextured())
			{
				TexturePath = FPaths::GetPath(TexturePath) / FPaths::GetBaseFilename(TexturePath) + TEXT(".<UDIM>.") + FPaths::GetExtension(TexturePath);
			}

			// NOTE: TexturePath could be empty
			ExportParameter<FString>(ConvertValueType(ValueType), MdlParamName, ShadeShader, TexturePath);
			SetColorSpace(MdlParamName, ShadeShader, Texture->SRGB);
		}
	}

	//Remove unused inputs from mdl schema
	std::vector<pxr::UsdShadeInput> Inputs = ShadeShader.GetInputs();
	for(auto Input : Inputs)
	{
		auto ConnectInput = Input;
		if (Input.HasConnectedSource())
		{
			pxr::UsdShadeConnectableAPI Source;
			pxr::TfToken SourceName;
			pxr::UsdShadeAttributeType SourceType;
			Input.GetConnectedSource(&Source, &SourceName, &SourceType);
								    
			ConnectInput = Source.GetInput(SourceName);
		}
		FString MdlInputName = ConnectInput.GetBaseName().GetText();

		bool bRemoveProperty = false;
		if (UsedInputNames.Find(MdlInputName) == INDEX_NONE)
		{
			if (bLocalBase)
			{
				bRemoveProperty = UOmniverseMDL::IsParameterUsedFromLocalBaseMDL(LocalBaseMaterial->GetName(), MdlInputName);
			}
			else if (OmniverseMDL)
			{
				bRemoveProperty = OmniverseMDL->IsParameterUsed(ParentMaterial->GetName(), MdlInputName);
			}
		}

		if (bRemoveProperty)
		{
			FString PropertyName = TEXT("inputs:") + MdlInputName;
			ShadeShader.GetPrim().RemoveProperty(pxr::TfToken(TCHAR_TO_ANSI(*PropertyName)));
		}
	}
}

void FUSDExporter::ExportMdlSchema(const pxr::UsdStageRefPtr& Stage, UMaterialInstance& MaterialInst, pxr::UsdShadeShader& ShadeShader)
{
	if (!ShadeShader)
	{
		return;
	}

	const auto ImplementationSource = ShadeShader.GetImplementationSource();
	if (ImplementationSource == USDTokens.sourceAsset)
	{
		FString MdlPath, MaterialName;
		bool bRelativePath = false;
		if (FOmniverseUSDImporterHelper::GetMdlPathAndName(ShadeShader, MdlPath, MaterialName, bRelativePath))
		{
			UMaterialInterface* ParentMaterial = MaterialInst.Parent;
			check(ParentMaterial);
			auto LocalBaseMdl = UOmniverseMDL::GetLocalBaseMaterial(&MaterialInst);
			bool bLocalBase = (LocalBaseMdl != nullptr);

			UOmniverseMDL* OmniverseMDL = UOmniverseAsset::GetOmniverseAsset<UOmniverseMDL>(*ParentMaterial);
			if (OmniverseMDL)
			{
				FString CurrentMdlPath = OmniverseMDL->GetOmniPath();
				if (CurrentMdlPath != MdlPath)
				{
					if (bRelativePath)
					{
						CurrentMdlPath = MakeAssetPathRelative(CurrentMdlPath, *Stage).c_str();
					}

					// Update sourceAsset
					ShadeShader.SetSourceAsset(pxr::SdfAssetPath(TCHAR_TO_ANSI(*CurrentMdlPath)), USDTokens.mdl);
				}

				if (ParentMaterial->GetName() != MaterialName)
				{
					//The MDL Schema in USD requires the subIdentifier attribute to be the material name
					ShadeShader.SetSourceAssetSubIdentifier(pxr::TfToken(TCHAR_TO_ANSI(*ParentMaterial->GetName())), USDTokens.mdl);
				}
			}
			else if (bLocalBase)
			{
				// Update sourceAsset
				// NOTE: material name might not be the mdl module name
				FString ModuleName;
				if (UOmniverseMDL::GetMDLModuleByMaterialName(LocalBaseMdl->GetName(), ModuleName))
				{
					FString CurrentMdlPath = ModuleName + TEXT(".mdl");
					if (CurrentMdlPath != MdlPath)
					{
						ShadeShader.SetSourceAsset(pxr::SdfAssetPath(TCHAR_TO_ANSI(*CurrentMdlPath)), USDTokens.mdl);
					}
				}

				if (LocalBaseMdl->GetName() != MaterialName)
				{
					ShadeShader.SetSourceAssetSubIdentifier(pxr::TfToken(TCHAR_TO_ANSI(*LocalBaseMdl->GetName())), USDTokens.mdl);
				}
			}
			else
			{
				return;
			}

			ExportMdlSchemaParameters(Stage, MaterialInst, ShadeShader);
		}
	}
}