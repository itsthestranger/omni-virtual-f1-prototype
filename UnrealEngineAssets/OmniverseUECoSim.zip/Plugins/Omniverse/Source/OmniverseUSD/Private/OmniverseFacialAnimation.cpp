// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseFacialAnimation.h"
#include "USDConverter.h"
#include "OmniverseUSDHelper.h"
#include "Animation/Skeleton.h"
#include "Animation/AnimSequence.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Extractors/TimeSamplesData.h"
#include "GenericPlatform/GenericPlatformMisc.h"
#include "Misc/MessageDialog.h"

DECLARE_LOG_CATEGORY_EXTERN(LogOmniverseImporter, Log, All);
#define LOCTEXT_NAMESPACE "OmniverseEditor"

bool FOmniverseFacialAnimation::CreateFacialAnimationSequence(const pxr::UsdSkelAnimation& SkelAnimation, const FString& ParentPath, USkeleton* Skeleton, int32& OverwriteStatus, FName Name)
{
	if (SkelAnimation && Skeleton)
	{
		FString AnimationName = Name.IsNone() ? SkelAnimation.GetPrim().GetName().GetText() : Name.ToString();
		auto Stage = SkelAnimation.GetPrim().GetStage();		
		FString RootLayerFile = Stage->GetRootLayer()->GetIdentifier().c_str();

		TArray<FString> CurveNames;
		if (pxr::UsdAttribute CurveNamesAttr = SkelAnimation.GetPrim().GetAttribute(pxr::TfToken("custom:mh_curveNames")))
		{
			auto USDCurveNames = GetUSDValue<pxr::VtArray<pxr::TfToken>>(CurveNamesAttr);
			CurveNames.Reserve(USDCurveNames.size());
			for (auto CurveName : USDCurveNames)
			{
				CurveNames.Add(CurveName.GetText());
			}
		}

		TMap<double, pxr::VtArray<float>> CurveValuesTimeSamples;
		if (pxr::UsdAttribute CurveValuesAttr = SkelAnimation.GetPrim().GetAttribute(pxr::TfToken("custom:mh_curveValues")))
		{
			std::vector<double> TimeSamples;
			CurveValuesAttr.GetTimeSamples(&TimeSamples);

			for(auto TimeCode : TimeSamples)
			{
				pxr::VtArray<float> CurveValues;
				CurveValuesAttr.Get(&CurveValues, pxr::UsdTimeCode(TimeCode));

				if (CurveValues.size() == CurveNames.Num())
				{
					CurveValuesTimeSamples.Add(TimeCode, CurveValues);
				}
			}
		}

		if (CurveValuesTimeSamples.Num() > 0)
		{
			bool bSuccess = false;
			// Verify Curve Name
			for (int32 CurveIndex = 0; CurveIndex < CurveNames.Num(); ++CurveIndex)
			{
				FSmartName NewName;
				bSuccess |= Skeleton->GetSmartNameByName(USkeleton::AnimCurveMappingName, *CurveNames[CurveIndex], NewName);
			}
			
			if (!bSuccess)
			{
				UE_LOG(LogOmniverseImporter, Error, L"Skeleton %s isn't compatible with %s", *Skeleton->GetName(), *RootLayerFile);
				return bSuccess;
			}

			FString PkgPath = FPaths::Combine(ParentPath, AnimationName);
			auto ParentPackage = CreatePackage(*PkgPath);
			ParentPackage->FullyLoad();

			// Check for an existing object
			UObject* ExistingObject = StaticFindObject(UObject::StaticClass(), ParentPackage, *AnimationName);
			
			if(ExistingObject != nullptr)
			{
				EAppReturnType::Type UserResponse;
				if (OverwriteStatus == 1)
				{
					UserResponse = EAppReturnType::YesAll;
				}
				else if (OverwriteStatus == 2)
				{
					UserResponse = EAppReturnType::NoAll;
				}
				else
				{
					UserResponse = FMessageDialog::Open(
						EAppMsgType::YesNoYesAllNoAll,
						FText::Format(LOCTEXT("ImportAssetAlreadyExists", "Do you want to overwrite the existing asset?\n\nAn asset already exists at the import location: {0}"), FText::FromString(PkgPath)));
				
					OverwriteStatus = UserResponse == EAppReturnType::YesAll ? 1 : (UserResponse == EAppReturnType::NoAll ? 2 : 0);
				}

				if (UserResponse == EAppReturnType::No || UserResponse == EAppReturnType::NoAll)
				{
					return true;
				}
			}

			UAnimSequence* Sequence = NewObject<UAnimSequence>(ParentPackage, *AnimationName, EObjectFlags::RF_Standalone | EObjectFlags::RF_Public);
			check(Sequence);

			double TimeCodesPerSecond = Stage->GetRootLayer()->HasTimeCodesPerSecond() ? Stage->GetRootLayer()->GetTimeCodesPerSecond() : DEFAULT_TIMECODESPERSECOND;
			double StartTimeCode = Stage->GetRootLayer()->HasStartTimeCode() ? Stage->GetRootLayer()->GetStartTimeCode() : DEFAULT_STARTTIMECODE;
			double EndTimeCode = Stage->GetRootLayer()->HasEndTimeCode() ? Stage->GetRootLayer()->GetEndTimeCode() : 0.0;
			
			Sequence->SetSkeleton(Skeleton);
			IAnimationDataController& Controller = Sequence->GetController();
			Controller.OpenBracket(LOCTEXT("ImportAnimation_Bracket", "Importing Animation"));
			Controller.RemoveAllBoneTracks();
			Sequence->ImportFileFramerate = TimeCodesPerSecond;
			Sequence->ImportResampleFramerate = TimeCodesPerSecond;
			double TotalTimeSample = FMath::RoundToDouble(EndTimeCode - StartTimeCode + 0.5);
			Controller.SetPlayLength(TotalTimeSample / TimeCodesPerSecond);
			const float FloatDenominator = 1000.0f;
			const float Numerator = FloatDenominator * TimeCodesPerSecond;
			Controller.SetFrameRate(FFrameRate(Numerator, FloatDenominator));

			for (int32 CurveIndex = 0; CurveIndex < CurveNames.Num(); ++CurveIndex)
			{
				FSmartName NewName;
				Skeleton->AddSmartNameAndModify(USkeleton::AnimCurveMappingName, *CurveNames[CurveIndex], NewName);

				FAnimationCurveIdentifier CurveId(NewName, ERawCurveTrackTypes::RCT_Float);
				Controller.AddCurve(CurveId);
				const FFloatCurve* NewCurve = Sequence->GetDataModel()->FindFloatCurve(CurveId);

				FRichCurve RichCurve;
				for (auto CurveTimeSample : CurveValuesTimeSamples)
				{
					FKeyHandle NewKeyHandle = RichCurve.AddKey(CurveTimeSample.Key / TimeCodesPerSecond, CurveTimeSample.Value[CurveIndex], false);

					ERichCurveInterpMode NewInterpMode = RCIM_Cubic;
					ERichCurveTangentMode NewTangentMode = RCTM_Auto;
					ERichCurveTangentWeightMode NewTangentWeightMode = RCTWM_WeightedNone;

					float LeaveTangent = 0.f;
					float ArriveTangent = 0.f;
					float LeaveTangentWeight = 0.f;
					float ArriveTangentWeight = 0.f;

					RichCurve.SetKeyInterpMode(NewKeyHandle, NewInterpMode);
					RichCurve.SetKeyTangentMode(NewKeyHandle, NewTangentMode);
					RichCurve.SetKeyTangentWeightMode(NewKeyHandle, NewTangentWeightMode);
				}

				Controller.SetCurveKeys(CurveId, RichCurve.GetConstRefOfKeys());
			}

			Controller.UpdateCurveNamesFromSkeleton(Skeleton, ERawCurveTrackTypes::RCT_Float);
			Controller.NotifyPopulated();
			Controller.CloseBracket();

			Sequence->PostEditChange();
			Sequence->MarkPackageDirty();
			FAssetRegistryModule::AssetCreated(Sequence);
			UE_LOG(LogOmniverseImporter, Log, L"Animation Sequence %s is imported.", *Sequence->GetName());
			return bSuccess;
		}
		else
		{
			UE_LOG(LogOmniverseImporter, Error, L"Cannot find curve timesamples in %s", *RootLayerFile);
		}
	}

	return false;
}

void FOmniverseFacialAnimation::FindUsdSkelAnimation(const pxr::UsdPrim& Prim, TArray<pxr::UsdPrim>& AnimationPrims)
{
	if (Prim.IsA<pxr::UsdSkelAnimation>())
	{
		AnimationPrims.Add(Prim); 
	}
	else
	{
		auto ChildPrims = Prim.GetFilteredChildren(pxr::UsdTraverseInstanceProxies());
		for(auto ChildPrim : ChildPrims)
		{
			FindUsdSkelAnimation(ChildPrim, AnimationPrims);
		}
	}
}

bool FOmniverseFacialAnimation::LoadFacialAnimation(const FString& Path, const FString& DestinationPath, USkeleton* Skeleton, FName Name)
{
	pxr::UsdStageRefPtr USDStage = FOmniverseUSDHelper::LoadUSDStageFromPath(Path);
 	if (USDStage)
	{
		auto DefaultPrim = USDStage->GetDefaultPrim();
		if (!DefaultPrim)
		{
			DefaultPrim = USDStage->GetPseudoRoot();
		}

		TArray<pxr::UsdPrim> AnimationPrims;
		FindUsdSkelAnimation(DefaultPrim, AnimationPrims);

		if (AnimationPrims.Num() == 0)
		{
			UE_LOG(LogOmniverseImporter, Error, L"Cannot find skeleton animation in %s", *Path);
			return false;
		}

		bool bSuccess = false;
		int32 OverwriteStatus = 0;
		for (int32 AnimationPrimIndex = 0; AnimationPrimIndex < AnimationPrims.Num(); ++AnimationPrimIndex)
		{
			FName SeqName = Name;
			if (!SeqName.IsNone() && AnimationPrims.Num() > 1)
			{
				SeqName = *(SeqName.ToString() + FString::Printf(TEXT("_%d"), AnimationPrimIndex));
			}
			bSuccess |= CreateFacialAnimationSequence(pxr::UsdSkelAnimation(AnimationPrims[AnimationPrimIndex]), DestinationPath, Skeleton, OverwriteStatus, SeqName);
		}

		return bSuccess;
	}

	return false;
}

#undef LOCTEXT_NAMESPACE