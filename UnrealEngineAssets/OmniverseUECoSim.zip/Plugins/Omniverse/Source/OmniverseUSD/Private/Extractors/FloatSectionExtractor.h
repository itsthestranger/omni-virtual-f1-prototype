// Copyright(c) 2018, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"
#include "SectionExtractor.h"
#include "TimeSamplesData.h"

class FFloatSectionExtractor : public ISectionExtractor
{
public:
	FFloatSectionExtractor(const class UMovieSceneSection*);

public:
	virtual void Extract(const FExtractorInput& Input) override;
	virtual bool GetFloatTimeSamples(FFloatTimeSamples&) override;

private:
	const class UMovieSceneFloatSection* FloatSection;
	FFloatTimeSamples					FloatTimeSamples;
};