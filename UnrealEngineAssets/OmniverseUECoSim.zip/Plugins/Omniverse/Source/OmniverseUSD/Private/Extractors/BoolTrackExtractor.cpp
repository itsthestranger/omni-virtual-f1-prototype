// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "BoolTrackExtractor.h"
#include "Tracks/MovieSceneBoolTrack.h"
#include "TimeSamplesData.h"
#include "SectionExtractor.h"


FBoolTrackExtractor::FBoolTrackExtractor(const UMovieSceneTrack* Track)
	: FTrackExtractor(Track)
{
}

void FBoolTrackExtractor::OnPostExtract(TSharedPtr<ISectionExtractor> SectionExtractor, FTimeSamplesData* TimeSamplesData)
{
	auto BoolTrack = Cast<const UMovieSceneBoolTrack>(Track);

	if (SectionExtractor.IsValid() && TimeSamplesData)
	{
		FBooleanTimeSamples TimeSamples;
		if (SectionExtractor->GetBooleanTimeSamples(TimeSamples))
		{
			TimeSamplesData->ParametersTimeSamples.BooleanTimeSamples.Add(BoolTrack->GetTrackName(), TimeSamples);
		}
	}
}