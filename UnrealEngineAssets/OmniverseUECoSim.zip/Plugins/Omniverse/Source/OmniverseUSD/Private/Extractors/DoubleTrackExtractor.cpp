// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "DoubleTrackExtractor.h"
#include "Tracks/MovieSceneDoubleTrack.h"
#include "TimeSamplesData.h"
#include "SectionExtractor.h"


FDoubleTrackExtractor::FDoubleTrackExtractor(const UMovieSceneTrack* Track)
	: FTrackExtractor(Track)
{
}

void FDoubleTrackExtractor::OnPostExtract(TSharedPtr<ISectionExtractor> SectionExtractor, FTimeSamplesData* TimeSamplesData)
{
	auto DoubleTrack = Cast<const UMovieSceneDoubleTrack>(Track);

	if (SectionExtractor.IsValid() && TimeSamplesData)
	{
		// TODO? Convert to float for now
		FFloatTimeSamples TimeSamples;
		if (SectionExtractor->GetFloatTimeSamples(TimeSamples))
		{
			TimeSamplesData->ParametersTimeSamples.ScalarTimeSamples.Add(DoubleTrack->GetTrackName(), TimeSamples);
		}
	}
}