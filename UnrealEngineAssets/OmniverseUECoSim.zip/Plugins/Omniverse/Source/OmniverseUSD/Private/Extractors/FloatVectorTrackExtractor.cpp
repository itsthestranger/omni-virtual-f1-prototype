// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "FloatVectorTrackExtractor.h"
#include "Tracks/MovieSceneVectorTrack.h"
#include "TimeSamplesData.h"
#include "SectionExtractor.h"


FFloatVectorTrackExtractor::FFloatVectorTrackExtractor(const UMovieSceneTrack* Track)
	: FTrackExtractor(Track)
{
}

void FFloatVectorTrackExtractor::OnPostExtract(TSharedPtr<ISectionExtractor> SectionExtractor, FTimeSamplesData* TimeSamplesData)
{
	auto FloatVectorTrack = Cast<const UMovieSceneFloatVectorTrack>(Track);

	if (SectionExtractor.IsValid() && TimeSamplesData)
	{
		FVectorTimeSamples TimeSamples;
		if (SectionExtractor->GetVectorTimeSamples(TimeSamples))
		{
			TimeSamplesData->ParametersTimeSamples.VectorTimeSamples.Add(FloatVectorTrack->GetTrackName(), TimeSamples);
		}
	}
}