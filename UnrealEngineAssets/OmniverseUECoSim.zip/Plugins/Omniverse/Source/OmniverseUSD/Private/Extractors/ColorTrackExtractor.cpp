// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "ColorTrackExtractor.h"
#include "Tracks/MovieSceneColorTrack.h"
#include "TimeSamplesData.h"
#include "SectionExtractor.h"

FColorTrackExtractor::FColorTrackExtractor(const UMovieSceneTrack* Track)
	: FTrackExtractor(Track)
{
}

void FColorTrackExtractor::OnPostExtract(TSharedPtr<ISectionExtractor> SectionExtractor, FTimeSamplesData* TimeSamplesData)
{
	auto ColorTrack = Cast<const UMovieSceneColorTrack>(Track);

	if (SectionExtractor.IsValid() && TimeSamplesData)
	{
		FColorTimeSamples TimeSamples;
		if (SectionExtractor->GetColorTimeSamples(TimeSamples))
		{
			TimeSamplesData->ParametersTimeSamples.ColorTimeSamples.Add(ColorTrack->GetTrackName(), TimeSamples);
		}
	}
}