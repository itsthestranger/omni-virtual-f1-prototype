// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "FloatTrackExtractor.h"
#include "Tracks/MovieSceneFloatTrack.h"
#include "TimeSamplesData.h"
#include "SectionExtractor.h"


FFloatTrackExtractor::FFloatTrackExtractor(const UMovieSceneTrack* Track)
	: FTrackExtractor(Track)
{
}

void FFloatTrackExtractor::OnPostExtract(TSharedPtr<ISectionExtractor> SectionExtractor, FTimeSamplesData* TimeSamplesData)
{
	auto FloatTrack = Cast<const UMovieSceneFloatTrack>(Track);

	if (SectionExtractor.IsValid() && TimeSamplesData)
	{
		FFloatTimeSamples TimeSamples;
		if (SectionExtractor->GetFloatTimeSamples(TimeSamples))
		{
			TimeSamplesData->ParametersTimeSamples.ScalarTimeSamples.Add(FloatTrack->GetTrackName(), TimeSamples);
		}
	}
}