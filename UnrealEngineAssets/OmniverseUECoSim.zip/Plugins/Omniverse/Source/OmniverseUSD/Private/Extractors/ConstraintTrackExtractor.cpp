// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "ConstraintTrackExtractor.h"
#include "Tracks/MovieScene3DConstraintTrack.h"
#include "TimeSamplesData.h"
#include "SectionExtractor.h"

FConstraintTrackExtractor::FConstraintTrackExtractor(const UMovieSceneTrack* Track)
	: FTrackExtractor(Track)
{
}

void FConstraintTrackExtractor::OnPostExtract(TSharedPtr<ISectionExtractor> SectionExtractor, FTimeSamplesData* TimeSamplesData)
{
	if (SectionExtractor.IsValid() && TimeSamplesData)
	{
		FObjectBindingTimeSamples OutObjectBindingTimeSamples;
		if (SectionExtractor->GetObjectBindingTimeSamples(OutObjectBindingTimeSamples))
		{
			TimeSamplesData->ObjectBindingTimeSamples.Add(OutObjectBindingTimeSamples);
		}
	}
}
