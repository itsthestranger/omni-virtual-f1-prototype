// Copyright(c) 2020, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "SkeletalAnimationSectionExtractor.h"
#include "MovieScene.h"
#include "Sections/MovieSceneSkeletalAnimationSection.h"
#include "SequenceExtractor.h"
#include "Channels/MovieSceneChannelProxy.h"

FSkeletalAnimationSectionExtractor::FSkeletalAnimationSectionExtractor(const UMovieSceneSection* Section)
{
	SkeletalAnimationSection = Cast<const UMovieSceneSkeletalAnimationSection>(Section);
}

void FSkeletalAnimationSectionExtractor::Extract(const FExtractorInput& Input)
{
	UMovieScene* MovieScene = SkeletalAnimationSection->GetTypedOuter<UMovieScene>();
	FFrameRate FrameRate = MovieScene->GetTickResolution();
	double SectionStartTimeCode = Input.InternalStartTimeCode + Input.StartTimeCodeOffset;

	TRange<FFrameNumber> Range = SkeletalAnimationSection->GetTrueRange();
	int32 AnimeTimeCodes = (int)((Range.GetUpperBoundValue().Value - 1 - Range.GetLowerBoundValue().Value) * FrameRate.AsInterval() * Input.TimeCodesPerSecond + 0.5f);	
	FTimeSampleRange AnimationTimeRange;
	AnimationTimeRange.StartTimeCode = (FMath::CeilToDouble(Range.GetLowerBoundValue().Value * (FrameRate.AsInterval() * Input.TimeCodesPerSecond)) - SectionStartTimeCode) / Input.TimeScale + Input.StartTimeCode;
	SkeletalAnimationTimeSamples.Range.StartTimeCode = AnimationTimeRange.StartTimeCode;
	AnimationTimeRange.EndTimeCode = AnimationTimeRange.StartTimeCode + AnimeTimeCodes - 1;
	SkeletalAnimationTimeSamples.Range.EndTimeCode = AnimationTimeRange.EndTimeCode;
	if (!AnimationTimeRange.IsInteractWithRange(FTimeSampleRange(Input.StartTimeCode, Input.EndTimeCode)))
	{
		return;
	}
	AnimationTimeRange.ClampToRange(FTimeSampleRange(Input.StartTimeCode, Input.EndTimeCode));

	SkeletalAnimationTimeSamples.Animation = SkeletalAnimationSection->Params.Animation;
	SkeletalAnimationTimeSamples.FirstLoopStartFrameOffset = FMath::RoundToDouble(SkeletalAnimationSection->Params.FirstLoopStartFrameOffset.Value * FrameRate.AsInterval() * Input.TimeCodesPerSecond);
	SkeletalAnimationTimeSamples.StartFrameOffset = FMath::RoundToDouble(SkeletalAnimationSection->Params.StartFrameOffset.Value * FrameRate.AsInterval() * Input.TimeCodesPerSecond);
	SkeletalAnimationTimeSamples.EndFrameOffset = FMath::RoundToDouble(SkeletalAnimationSection->Params.EndFrameOffset.Value * FrameRate.AsInterval() * Input.TimeCodesPerSecond);
	SkeletalAnimationTimeSamples.PlayRate = SkeletalAnimationSection->Params.PlayRate;
	SkeletalAnimationTimeSamples.bReverse = SkeletalAnimationSection->Params.bReverse;

	double TimeCodeCount = AnimationTimeRange.EndTimeCode - AnimationTimeRange.StartTimeCode;
	for (double TimeCode = 0.0; TimeCode <= TimeCodeCount; TimeCode += 1.0)
	{
		FFrameNumber FrameNumber = FFrameNumber((int32)((TimeCode * Input.TimeScale + SectionStartTimeCode + (AnimationTimeRange.StartTimeCode - Input.StartTimeCode)) / (FrameRate.AsInterval() * Input.TimeCodesPerSecond)));

		float ValueAtTime = 1.0f;
		SkeletalAnimationSection->Params.Weight.Evaluate(FFrameTime(FrameNumber), ValueAtTime);
		ValueAtTime = ValueAtTime * SkeletalAnimationSection->EvaluateEasing(FFrameTime(FrameNumber));
		SkeletalAnimationTimeSamples.Weights.TimeSamples.FindOrAdd(TimeCode + AnimationTimeRange.StartTimeCode, ValueAtTime);
	}
}

bool FSkeletalAnimationSectionExtractor::GetSkeletalAnimationTimeSamples(FSkeletalAnimationTimeSamples& OutSkeletalAnimationTimeSamples)
{
	if (SkeletalAnimationTimeSamples.Animation == nullptr || !SkeletalAnimationTimeSamples.Range.IsValid())
	{
		return false;
	}

	OutSkeletalAnimationTimeSamples = SkeletalAnimationTimeSamples;
	return true;
}

