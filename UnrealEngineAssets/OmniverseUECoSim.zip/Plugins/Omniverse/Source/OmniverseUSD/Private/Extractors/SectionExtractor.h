// Copyright(c) 2018, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"

class ISectionExtractor
{
public:
	virtual ~ISectionExtractor() {}

public:
	virtual void Extract(const struct FExtractorInput& Input) = 0;

	virtual bool GetBooleanTimeSamples(struct FBooleanTimeSamples& BoolTimeSamples) { return false; }
	virtual bool GetFloatTimeSamples(struct FFloatTimeSamples& FloatTimeSamples) { return false; }
	virtual bool GetVectorTimeSamples(struct FVectorTimeSamples& VectorTimeSamples) { return false; }
	virtual bool GetColorTimeSamples(struct FColorTimeSamples& ColorTimeSamples) { return false; }
	virtual bool GetTransformTimeSamples(struct FTranslateRotateScaleTimeSamples& TransformTimeSamples) { return false; }
	virtual bool GetParameterTimeSamples(struct FNamedParameterTimeSamples& ParameterTimeSamples) { return false; }
	virtual bool GetObjectBindingTimeSamples(struct FObjectBindingTimeSamples& ObjectBindingTimeSamples) { return false; }
	virtual bool GetSkeletalAnimationTimeSamples(struct FSkeletalAnimationTimeSamples& OutSkeletalAnimationTimeSamples) { return false; }
};