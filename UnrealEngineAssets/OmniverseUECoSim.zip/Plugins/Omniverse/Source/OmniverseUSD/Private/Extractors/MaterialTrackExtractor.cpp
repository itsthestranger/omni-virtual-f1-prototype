// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "MaterialTrackExtractor.h"
#include "Tracks/MovieSceneMaterialTrack.h"
#include "TimeSamplesData.h"
#include "SectionExtractor.h"


FMaterialTrackExtractor::FMaterialTrackExtractor(const UMovieSceneTrack* Track)
	: FTrackExtractor(Track)
{
}

void FMaterialTrackExtractor::OnPostExtract(TSharedPtr<ISectionExtractor> SectionExtractor, FTimeSamplesData* TimeSamplesData)
{
	auto MaterialTrack = Cast<const UMovieSceneComponentMaterialTrack>(Track);

	if (SectionExtractor.IsValid() && TimeSamplesData)
	{
		FNamedParameterTimeSamples TimeSamples;
		if (SectionExtractor->GetParameterTimeSamples(TimeSamples))
		{
			TimeSamplesData->MaterialsTimeSamples.Add(MaterialTrack ? MaterialTrack->GetMaterialIndex() : 0, TimeSamples);
		}
	}
}