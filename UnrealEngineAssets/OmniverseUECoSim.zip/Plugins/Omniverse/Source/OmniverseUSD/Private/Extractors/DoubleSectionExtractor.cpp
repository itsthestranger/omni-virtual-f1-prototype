// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "DoubleSectionExtractor.h"
#include "MovieScene.h"
#include "Sections/MovieSceneDoubleSection.h"
#include "SequenceExtractor.h"
#include "Channels/MovieSceneChannelProxy.h"

FDoubleSectionExtractor::FDoubleSectionExtractor(const UMovieSceneSection* Section)
{
	DoubleSection = Cast<const UMovieSceneDoubleSection>(Section);
}

void FDoubleSectionExtractor::Extract(const FExtractorInput& Input)
{
	FMovieSceneDoubleChannel* DoubleChannel = DoubleSection->GetChannelProxy().GetChannel<FMovieSceneDoubleChannel>(0);
	FFrameRate FrameRate = DoubleSection->GetTypedOuter<UMovieScene>()->GetTickResolution();

	double TimeCodeCount = Input.EndTimeCode - Input.StartTimeCode;
	double SectionStartTimeCode = Input.InternalStartTimeCode + Input.StartTimeCodeOffset;
	for (double TimeCode = 0.0; TimeCode <= TimeCodeCount; TimeCode += 1.0)
	{
		FFrameNumber FrameNumber = FFrameNumber((int32)((TimeCode * Input.TimeScale + SectionStartTimeCode) / (FrameRate.AsInterval() * Input.TimeCodesPerSecond)));	
		// TODO? Convert to float for now
		float ValueAtTime = 0.0f;
		bool Success = DoubleChannel->Evaluate(FFrameTime(FrameNumber), ValueAtTime);
		if (Success)
		{
			FloatTimeSamples.TimeSamples.FindOrAdd(TimeCode + Input.StartTimeCode, ValueAtTime);
		}
	}
}

// TODO? Convert to float for now
bool FDoubleSectionExtractor::GetFloatTimeSamples(FFloatTimeSamples& OutValue)
{
	OutValue = FloatTimeSamples;
	return true;
}