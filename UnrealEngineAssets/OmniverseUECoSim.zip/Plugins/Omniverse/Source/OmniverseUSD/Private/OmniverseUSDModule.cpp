// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseUSDModule.h"
#include "OmniverseUSDLog.h"
#include "EditorModeRegistry.h"
#include "OmniverseEdMode.h"
#include "OmniverseUSDTranslator.h"
#include "Misc/CoreDelegates.h"
#include "Misc/Paths.h"
#include "Interfaces/IPluginManager.h"

DEFINE_LOG_CATEGORY(LogOmniverseUsd);

class FOmniverseUSDModule : public IOmniverseUSDModule
{
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	virtual void RegisterUSDTranslator(IOmniverseUSDTranslator* UsdTranslator) override;
	virtual bool HasUSDTranslator() override;
	virtual TArray<TSharedPtr<IOmniverseUSDTranslator>> GetUSDTranslators() const override;
	void BumpUSDLog();

private:
	TArray<TSharedPtr<IOmniverseUSDTranslator>>	ExternalUsdTranslators;
};

// Do not replace new and delete. It conflicts with USD.
#undef REPLACEMENT_OPERATOR_NEW_AND_DELETE
#define REPLACEMENT_OPERATOR_NEW_AND_DELETE

IMPLEMENT_MODULE(FOmniverseUSDModule, OmniverseUSD)

void FOmniverseUSDModule::StartupModule()
{
#ifdef _WIN64
#ifdef _DEBUG
	const FString Config = "win64_debug";
#else
	const FString Config = "win64_release";
#endif
#endif
	const FString BaseDir = IPluginManager::Get().FindPlugin("Omniverse")->GetBaseDir() / "ThirdParty";
	// USD plugins need the absolute path
	const FString OmniUsdResolverPluginDir = FPaths::ConvertRelativePathToFull(BaseDir / "omni_usd_resolver" / Config / "release/usd/omniverse/resources/");
	pxr::PlugRegistry::GetInstance().RegisterPlugins(TCHAR_TO_UTF8(*OmniUsdResolverPluginDir));
	std::string PluginName = "OmniUsdResolver";
	if (pxr::TfType::FindByName(PluginName).IsUnknown())
	{
		UE_LOG(LogOmniverseUsd, Error, TEXT("Could not find OmniUsdResolver"));
	}

	FEditorModeRegistry::Get().RegisterMode<FOmniverseEdMode>(FOmniverseEdMode::EdModeID);

	// USD log
	FCoreDelegates::OnBeginFrame.AddLambda(
		[this]()
	{
		BumpUSDLog();
	}
	);
}

void FOmniverseUSDModule::ShutdownModule()
{
	ExternalUsdTranslators.Reset(0);
	FEditorModeRegistry::Get().UnregisterMode(FOmniverseEdMode::EdModeID);
}

void FOmniverseUSDModule::RegisterUSDTranslator(IOmniverseUSDTranslator* UsdTranslator)
{
	ExternalUsdTranslators.Add(MakeShareable<IOmniverseUSDTranslator>(UsdTranslator));
}

bool FOmniverseUSDModule::HasUSDTranslator()
{
	return ExternalUsdTranslators.Num() > 0;
}

TArray<TSharedPtr<IOmniverseUSDTranslator>> FOmniverseUSDModule::GetUSDTranslators() const
{
	return ExternalUsdTranslators;
}

void FOmniverseUSDModule::BumpUSDLog()
{
	static pxr::TfErrorMark ErrorMark;

	for (auto Error : ErrorMark)
	{
		FString SourceFileName = Error.GetSourceFileName().c_str();
		FString SourceFunction = Error.GetSourceFunction().c_str();
		UE_LOG(LogOmniverseUsd, Warning, TEXT("USD Error in %s at line %d in file %s : %s"), *SourceFunction, Error.GetSourceLineNumber(), *SourceFileName, ANSI_TO_TCHAR(Error.GetCommentary().c_str()));
	}

	ErrorMark.Clear();
	ErrorMark.SetMark();
}