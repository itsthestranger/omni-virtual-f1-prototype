// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseUSDExporter.h"
#include "OmniverseUSDLog.h"
#include "OmniverseUSD.h"
#include "HAL/IConsoleManager.h"
#include "OmniverseStageActor.h"

static TAutoConsoleVariable<int32> CVarOmniverseExportLayer(
	TEXT("Omniverse.ExportLayer"),
	0,
	TEXT(""),
	ECVF_Default);

UOmniverseUSDExporter::UOmniverseUSDExporter()
{
	bText = true;
	SupportedClass = UOmniverseUSD::StaticClass();
	FormatExtension.Add(TEXT("usda"));	// Must be lower case. Otherwise Stage_Create() will fail.
	FormatDescription.Add(TEXT("Universe Scene Description File"));
}

bool UOmniverseUSDExporter::ExportText(const class FExportObjectInnerContext* Context, UObject* Object, const TCHAR* Type, FOutputDevice& Ar, FFeedbackContext* Warn, uint32 PortFlags)
{
	auto OmniUSD = CastChecked<UOmniverseUSD>(Object);
	auto USDStage = OmniUSD->GetUSDStage();
	if(!USDStage)
	{
		USDStage = OmniUSD->LoadUSDStage();
		if (!USDStage)
		{
			return false;
		}
	}

	std::string USDStr;
	if(CVarOmniverseExportLayer.GetValueOnGameThread())
	{
		USDStage->GetRootLayer()->ExportToString(&USDStr);
	}
	else
	{
		USDStage->ExportToString(&USDStr);
	}

	// NOTE: UE4 OutputDevice can't handle 2GB file even bForceFileOperations enabled. See FAsyncWriter
	if (USDStr.size() >= INT32_MAX)
	{
		UE_LOG(LogOmniverseUsd, Error, TEXT("Failed to export %s, Can't export data larger than 2GB."), *OmniUSD->GetName());
	}
	else
	{
		Ar.Log(*FString(USDStr.c_str()));
	}

	return true;
}
