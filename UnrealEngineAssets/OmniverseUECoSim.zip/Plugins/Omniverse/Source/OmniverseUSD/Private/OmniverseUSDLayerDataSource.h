// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "OmniverseUSD.h"
#include "omniclient.h"
#include "UObject/StrongObjectPtr.h"


class FOmniverseUSDLayerDataSource : public IOmniverseLayerDataSource
{
public:
	static TSharedPtr<FOmniverseUSDLayerDataSource> Create(pxr::UsdStageRefPtr USDStage);

	void Reset();

	virtual ~FOmniverseUSDLayerDataSource();

	virtual bool SetLayerVisibility(UOmniverseLayer* OmniverseLayer, bool Visible) override;

	virtual bool ToggleLayerVisibility(UOmniverseLayer* OmniverseLayer) override;

	// The first layer is the root layer
	virtual void AddAllLayersTo(TArray<UOmniverseLayer*>& OutLayers) override;

	virtual UOmniverseLayer* GetAuthoringLayer() const override;

	virtual bool ReloadLayer(UOmniverseLayer* OmniverseLayer) override;

	virtual bool SaveLayer(UOmniverseLayer* OmniverseLayer) override;

	virtual bool DeleteLayer(UOmniverseLayer* ParentOmniverseLayer, UOmniverseLayer* OmniverseLayer) override;

	virtual bool AttachLayer(UOmniverseLayer* OmniverseLayer, UOmniverseLayer* TargetLayer) override;

	virtual bool AuthorRootLayer() override;

	virtual bool AuthorLayer(UOmniverseLayer* OmniverseLayer) override;

	virtual void RefreshAuthorLayer() override;

	virtual bool LockLayer(UOmniverseLayer* OmniverseLayer) override;

	virtual bool UnlockLayer(UOmniverseLayer* OmniverseLayer) override;

	virtual void SelectSingleActor(UOmniversePrim* Prim) override;

	virtual void SelectAllActors(const TArray<UOmniversePrim*>& Prims) override;

	virtual bool DeleteSinglePrim(UOmniversePrim* Prim) override;

	virtual void SwitchMutenessScope(bool bGlobal) override;

	virtual bool IsMutenessGlobal() const override;

	virtual size_t NumLayers() const override;

	virtual void NotifyPrimChange(const FString& Prim) override;

	virtual void UpdatePrim(const FString& Layer, const FString& Prim) override;

	virtual void RemovePrim(const FString& Layer, const FString& Prim) override;

	virtual void AddSublayer(const FString& Layer, const FString& Sublayer) override;

	virtual void RemoveSublayer(const FString& Layer, const FString& Sublayer) override;

	virtual void UpdateSublayer(const FString& Layer, const FString& Sublayer) override;

	virtual UOmniverseLayer* FindLayer(const FString& LayerPath) override;

	virtual int32 GetSubLayerPriority(const FString& LayerPath, const FString& SubLayerPath) const override;

	virtual void SetLayerDirty(const FString& LayerPath, bool bDirty) override;

	bool SaveTo(FUSDLayersSerialization& Serialization);

	static pxr::UsdStageRefPtr CreateInMemoryStageFrom(const FUSDLayersSerialization& Serialization);

	pxr::TfWeakPtr<class OmniUsdStageCtrl> StageCtrl;

private:
	FOmniverseUSDLayerDataSource(pxr::UsdStageRefPtr USDStage);

	void Initialize();

	void ResetInternal();

	void ReleaseData(UOmniverseLayer* Layer);
	void ReleaseData(UOmniverseLayer* Layer, UOmniversePrim* Prim);
	bool RefreshUSDLayerState();

	UOmniverseLayer* CreateLayerFrom(const std::string& Identifier, ERootLayerType Type, bool bRoot);

	UOmniversePrim* CreatePrimFrom(const pxr::SdfLayerRefPtr& USDLayerHandle, const pxr::SdfPath& InPrimPath);

	void UpdatePrimFrom(UOmniversePrim* Prim, const pxr::SdfLayerRefPtr& USDLayerHandle, const pxr::SdfPath& InPrimPath);

	void CreateSublayerFrom(UOmniverseLayer* Layer);

	bool SetLayerVisibilityInternal(UOmniverseLayer* OmniverseLayer, bool bVisible);

	bool ToggleLayerVisibilityInternal(UOmniverseLayer* OmniverseLayer);

	bool DeleteLayerInternal(ERootLayerType Type, const FString& ParentFullPath, const FString& FullPath);

	bool AuthorLayerInternal(ERootLayerType Type, const FString& FullPath = TEXT(""));

	bool DeleteSinglePrimInternal(UOmniverseLayer* ChangedLayer, UOmniversePrim* Prim);

	bool RefreshAuthorLayerInternal();

	//void SaveLayerState(const FString& SessionName, ELayersEventType UndoEventType, ELayersEventType RedoEventType,
	//	const OmniLayerState& SavedLayerState, const FOmniverseLayer& AffectedLayer);

	void OnOmniverseMessageReceived(const FString& ChannelId, const struct FOmniverseMessage& OmniverseMessage);

	void NotifyError(const FString& Error);

	void CloseUnderneathOperationNotification();
private:
	struct FOmniverseLayerLockState
	{
		bool bLocked = false;
		FString UserId;
		FString UserName;
	};

	bool bInApplyingLayerState;

	bool bInMemoryStage;

	TStrongObjectPtr<class UOmniverseTransaction> TransactionObject;

	TWeakPtr<class SNotificationItem> UnderneathOperationNotification;

	UOmniverseLayer* AuthoringLayerData = nullptr;

	UOmniverseLayer* RootLayerData = nullptr;

	UOmniverseLayer* SessionLayerData = nullptr;

	bool bGlobalMuteness = false;
};