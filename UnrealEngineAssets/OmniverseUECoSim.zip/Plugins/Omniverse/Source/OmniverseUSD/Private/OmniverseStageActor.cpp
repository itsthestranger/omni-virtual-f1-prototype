// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseStageActor.h"
#include "OmniverseUSDLog.h"
#include "OmniverseUsdLuxLightCompat.h"
#include "Algo/Find.h"
#include "Misc/CoreDelegates.h"
#include "UObject/Package.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#if WITH_EDITOR
#include "MeshDescriptionOperations.h"
#endif
#include "Animation/Skeleton.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Camera/CameraComponent.h"
#include "CinematicCamera/Public/CineCameraActor.h"
#include "CinematicCamera/Public/CineCameraComponent.h"
#include "Particles/ParticleSystemComponent.h"
#include "Components/MeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/RectLightComponent.h"
#include "Components/SpotLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "Components/BillboardComponent.h"
#include "Engine/StaticMeshActor.h"
#include "Animation/SkeletalMeshActor.h"
#include "Animation/AnimSequence.h"
#include "Rendering/SkeletalMeshLODImporterData.h"
#include "MeshDescription.h"
#include "Engine/StaticMesh.h"
#include "PhysicsEngine/BodySetup.h"
#include "Engine/DirectionalLight.h"
#include "Engine/PointLight.h"
#include "Engine/SpotLight.h"
#include "Engine/RectLight.h"
#include "Engine/SkyLight.h"
#include "Engine/BlueprintGeneratedClass.h"
#include "Engine/SimpleConstructionScript.h"
#include "Engine/SCS_Node.h"
#include "ActorFactories/ActorFactoryBasicShape.h"
#include "Camera/CameraActor.h"
#include "EngineUtils.h"
#include "ActorFactories/ActorFactoryBoxVolume.h"
#include "Engine/PostProcessVolume.h"
#include "ActorSequenceComponent.h"
#include "ActorSequence.h"
#if WITH_EDITOR
#include "AssetToolsModule.h"
#include "AssetSelection.h"
#include "Editor/EditorEngine.h"
#include "Editor/TransBuffer.h"
#include "Engine/Selection.h"
#include "ScopedTransaction.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "EditorModeManager.h"
#include "OmniverseEdMode.h"
#include "LevelEditor.h"
#include "EditorFramework/AssetImportData.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
extern UNREALED_API class UEditorEngine* GEditor;
#endif
#include "TimerManager.h"
#include "USDConverter.h"
#include "OmniverseUSD.h"
#include "OmniverseMDL.h"
#include "OmniverseTexture.h"
#include "OmniverseSettings.h"
#include "OmniverseAssetUserData.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseUSDLayerDataSource.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseUSDSequenceImporter.h"
#include "OmniverseAssetImportHelper.h"
#include "OmniverseNotificationHelper.h"
#include "OmniverseUSDTokens.h"

#include "GenericPlatform/GenericPlatformMisc.h"
#include "Misc/MessageDialog.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformFilemanager.h"
#include "OmniverseUSDHelper.h"
#include "Features/IModularFeatures.h"
#include "Logging/LogMacros.h"
#include "USDEditDelegate.h"
#include "Extractors/TimeSamplesData.h"
#include "USDGeometryCache.h"
#include "USDHashGenerator.h"
#include "OmniverseReferenceCollector.h"
#include "OmniverseSlowTask.h"
#include "OmniverseUSDImporterHelper.h"

#include "UsdWrappers/SdfLayer.h"
#include "UsdWrappers/UsdPrim.h"
#include "USDLayerUtils.h"
#include "USDModulesIncludesEnd.h"

#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING
#include <experimental/filesystem>
#undef _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING
#include "USDDerivedDataCache.h"

#define LIGHTMAPS_EXPORT_PRIMVARS 1
#define LIGHTMAPS_EXPORT_SCHEMA 0

#if LIGHTMAPS_EXPORT_PRIMVARS || LIGHTMAPS_EXPORT_SCHEMA
#include "Engine/StaticMesh.h"
#include "Engine/MapBuildDataRegistry.h"
#include "Runtime/Engine/Public/ImageUtils.h"
#include "Runtime/Engine/Public/LightMap.h"
#include "Runtime/Engine/Public/ShadowMap.h"
#include "Runtime/Engine/Classes/Engine/ShadowMapTexture2D.h"
#endif

#if LIGHTMAPS_EXPORT_SCHEMA
#include <LightmapsSchema/lightmap.h>
#include <LightmapsSchema/shadowmap.h>
#endif

#define LOCTEXT_NAMESPACE "OmniverseStageActor"



#if LIGHTMAPS_EXPORT_PRIMVARS || LIGHTMAPS_EXPORT_SCHEMA
static inline FString FixupTextureName(UTexture2D* Texture)
{
	return Texture->GetPathName().Replace(TEXT("."), TEXT("_")).Replace(TEXT(":"), TEXT("_"));
}
#endif

FString AOmniverseStageActor::ExportUSDToString()
{
	FString StageString;
	if(USD && GetUSDStage())
	{
		std::string USDString;
		GetUSDStage()->ExportToString(&USDString);

		StageString = USDString.c_str();
	}

	return MoveTemp(StageString);
}

void AOmniverseStageActor::SetUSD(UOmniverseUSD * InUSD, bool LoadScene)
{
	if (InUSD == USD && USD != nullptr)
	{
		UE_LOG(LogOmniverseUsd, Warning, TEXT("USD is already set as the current USD: %s"), *InUSD->GetName());
		return;
	}

	if(USD)
	{
		IOmniverseLayerDataSource::SetCurrentLayerDataSource(nullptr);
		USD->OnUSDChanged.RemoveAll(this);
		USD->LeaveSession();
		USD->ReleaseStage();
	}

	if (InUSD == nullptr && LoadScene == false)
	{
		USDSequenceImporter->ResetLevelSequence();
	}

	USD = InUSD;

	if (LoadScene)
	{
		if(!USD)
		{
			USD = NewObject<UOmniverseUSD>(this);

			auto Stage = GetUSDStage();
			auto Root = pxr::UsdGeomXform::Define(Stage, pxr::SdfPath("/Stage"));
			pxr::UsdModelAPI(Root).SetKind(pxr::KindTokens->assembly);
			Stage->SetDefaultPrim(Root.GetPrim());
		}

		if (USD && USD->IsStageLoaded())
		{
			USD->ReloadUSDStage();
		}
		LoadUSDScene();
	}
}

void AOmniverseStageActor::GetPrimBoolAttribute(const FString& PrimPath, const FString& AttributeName, bool& OutSuccess, bool& OutValue)
{
	pxr::UsdAttribute Attr;
	Attr = GetUSDStage()->GetPrimAtPath(ToUSDPath(*PrimPath)).GetAttribute(pxr::TfToken(std::string(TCHAR_TO_UTF8(*AttributeName))));
	if (!Attr)
	{
		OutSuccess = false;
		return;
	}
	OutValue = GetUSDValue<bool>(Attr);
	OutSuccess = true;
	return;
}

void AOmniverseStageActor::SetPrimBoolAttribute(const FString& PrimPath, const FString& AttributeName, bool& OutSuccess, bool InValue)
{
	pxr::UsdAttribute Attr;
	Attr = GetUSDStage()->GetPrimAtPath(ToUSDPath(*PrimPath)).GetAttribute(pxr::TfToken(std::string(TCHAR_TO_UTF8(*AttributeName))));
	if (!Attr)
	{
		OutSuccess = false;
		return;
	}
	// Assume that the type is correct
	Attr.Set(InValue);
	OutSuccess = true;
	return;
}

void AOmniverseStageActor::GetPrimFloatAttribute(const FString& PrimPath, const FString& AttributeName, bool& OutSuccess, float& OutValue)
{
	pxr::UsdAttribute Attr;
	Attr = GetUSDStage()->GetPrimAtPath(ToUSDPath(*PrimPath)).GetAttribute(pxr::TfToken(std::string(TCHAR_TO_UTF8(*AttributeName))));
	if (!Attr)
	{
		OutSuccess = false;
		return;
	}
	OutValue = GetUSDValue<float>(Attr);
	OutSuccess = true;
	return;
}

void AOmniverseStageActor::SetPrimFloatAttribute(const FString& PrimPath, const FString& AttributeName, bool& OutSuccess, float InValue)
{
	pxr::UsdAttribute Attr;
	Attr = GetUSDStage()->GetPrimAtPath(ToUSDPath(*PrimPath)).GetAttribute(pxr::TfToken(std::string(TCHAR_TO_UTF8(*AttributeName))));
	if (!Attr)
	{
		OutSuccess = false;
		return;
	}
	// Assume that the type is correct
	Attr.Set(InValue);
	OutSuccess = true;
	return;
}

void AOmniverseStageActor::GetPrimDoubleAttribute(const FString& PrimPath, const FString& AttributeName, bool& OutSuccess, double& OutValue)
{
	pxr::UsdAttribute Attr;
	Attr = GetUSDStage()->GetPrimAtPath(ToUSDPath(*PrimPath)).GetAttribute(pxr::TfToken(std::string(TCHAR_TO_UTF8(*AttributeName))));
	if (!Attr)
	{
		OutSuccess = false;
		return;
	}
	OutValue = GetUSDValue<double>(Attr);
	OutSuccess = true;
	return;
}

void AOmniverseStageActor::SetPrimDoubleAttribute(const FString& PrimPath, const FString& AttributeName, bool& OutSuccess, double InValue)
{
	pxr::UsdAttribute Attr;
	Attr = GetUSDStage()->GetPrimAtPath(ToUSDPath(*PrimPath)).GetAttribute(pxr::TfToken(std::string(TCHAR_TO_UTF8(*AttributeName))));
	if (!Attr)
	{
		OutSuccess = false;
		return;
	}
	// Assume that the type is correct
	Attr.Set(InValue);
	OutSuccess = true;
	return;
}

bool AOmniverseStageActor::HasValidUSD() const
{
	return USD != nullptr;
}

bool AOmniverseStageActor::HasValidImportStage() const
{
	return ImportUSDStage != nullptr;
}

UActorComponent* AOmniverseStageActor::AddUSDReference(UOmniverseUSD* InUSD, const FTransform& Transform)
{
	// Avoid self reference
	if(!InUSD)
	{
		return nullptr;
	}

	if(InUSD == USD)
	{
		UE_LOG(LogOmniverseUsd, Error, TEXT("Can't place USD into itself. %s"), *InUSD->GetName());

		return nullptr;
	}

	// Check if it has a default prim
	auto USDStage = GetUSDStage();
	std::string Filename = TCHAR_TO_UTF8(*FPaths::GetBaseFilename(InUSD->GetOmniPath()));
	auto BasePrimName = pxr::TfMakeValidIdentifier(Filename);
	auto PrimName = BasePrimName;	

	pxr::UsdPrim ParentPrim;
	if(USDStage->GetDefaultPrim() && bAutoAttach)
	{
		ParentPrim = USDStage->GetDefaultPrim();
	}
	else
	{
		ParentPrim = USDStage->GetPseudoRoot();
	}

	pxr::SdfPath PrimPath;
	for(int Postfix = 0;; ++Postfix)
	{
		PrimPath = ParentPrim.GetPath().AppendElementString(PrimName);
		if(!USDStage->GetPrimAtPath(PrimPath))
		{
			break;
		}

		PrimName = BasePrimName + pxr::TfStringify(Postfix);
	}

	// Create a typed or type less prim.
	pxr::UsdPrim Prim = USDStage->DefinePrim(PrimPath);
	if(!Prim)
	{
		return nullptr;
	}

	// Add reference
	auto RefPath = MakeAssetPathRelative(InUSD->GetOmniPath(), *USDStage);
	Prim.GetReferences().AddReference(RefPath);

	if (Prim.GetTypeName().IsEmpty())
	{
		pxr::UsdGeomXform::Define(USDStage, Prim.GetPath());
	}

	// Retreive the created component
	LoadChangedUSDPaths();

	auto Component = FindObjectFromPath<UActorComponent>(PrimPath);

	// Set Transform
	if(auto SceneComp = Cast<USceneComponent>(Component))
	{
		SceneComp->SetWorldTransform(Transform);
	}

#if WITH_EDITOR
	// Avoid unneeded exporting
	if(Component)
	{
		PlacedUSDs.Add(Component);
		TSharedPtr<FDelegateHandle> DelHandle = MakeShared<FDelegateHandle>();
		*DelHandle = FCoreDelegates::OnBeginFrame.AddWeakLambda(this,
			[DelHandle, this]()
			{
				PlacedUSDs.Reset();
				FCoreDelegates::OnBeginFrame.Remove(*DelHandle);
			}
		);
	}
#endif

	// Transaction
	if(USDTransaction.TransactionObj.IsValid() && GEditor->IsTransactionActive())
	{
		auto Transact = [this, USDObjName = InUSD->GetPathName(), PrimPath = Prim.GetPath(), Transform](UOmniverseTransaction::EUndoType UndoType)
		{
			switch(UndoType)
			{
			case UOmniverseTransaction::EUndoType::Undo:
				if(USD)
				{
					GetUSDStage()->RemovePrim(PrimPath);
					LoadChangedUSDPaths();
				}
				break;
			case UOmniverseTransaction::EUndoType::Redo:
				AddUSDReference(FindObject<UOmniverseUSD>(nullptr, *USDObjName), Transform);
				break;
			}
		};

		USDTransaction.TransactionObj->AddTransaction(UOmniverseTransaction::FUndoDelegate::CreateWeakLambda(this, Transact));
	}

	return Component;
}

AOmniverseStageActor::AOmniverseStageActor()
{
	USDSequenceImporter = MakeShareable(new FOmniverseUSDSequenceImporter(this));
	//ReservedUE4ObjectOuter = NewObject<USceneComponent>(this, "ReservedObjectOuter", EObjectFlags::RF_Transient);
	ReservedUE4ObjectOuter = CreateDefaultSubobject<USceneComponent>("ReservedObjectOuter", true);

	// Create default USD
	SetUSD(CreateDefaultSubobject<UOmniverseUSD>(UOmniverseUSD::StaticClass()->GetFName()));

	// Bind delegates
	if(!HasAllFlags(EObjectFlags::RF_ClassDefaultObject))
	{
		// Actor creation and destroy
		GEngine->OnLevelActorDeleted().AddUObject(this, &AOmniverseStageActor::OnActorDestroyed);
		GEngine->OnLevelActorAdded().AddUObject(this, &AOmniverseStageActor::OnActorAdded);
		GEngine->OnLevelActorDetached().AddUObject(this, &AOmniverseStageActor::OnActorDetached);
		GEngine->OnLevelActorAttached().AddUObject(this, &AOmniverseStageActor::OnActorAttached);

		// Actor renaming
		FCoreDelegates::OnActorLabelChanged.AddUObject(this, &AOmniverseStageActor::OnActorLabelChanged);

		// Property change
		FCoreUObjectDelegates::OnObjectPropertyChanged.AddUObject(this, &AOmniverseStageActor::OnObjectPropertyChanged);

		// Render state callback
		UActorComponent::MarkRenderStateDirtyEvent.AddUObject(this, &AOmniverseStageActor::OnComponentMarkRenderStateDirty);

		// Light color and brightness
		ULightComponent::UpdateColorAndBrightnessEvent.AddUObject(this, &AOmniverseStageActor::OnLightUpdateColorAndBrightness);

		// Mesh editor
		GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OnAssetEditorRequestedOpen().AddUObject(this, &AOmniverseStageActor::OnAssetEditorRequestedOpen);

		// Undo.
		if(GEditor)
		{
			USDTransaction.TransactionObj.Reset(NewObject<UOmniverseTransaction>());
		}

		// Duplication
		UNREALED_API class FEditorModeTools& GLevelEditorModeTools();
		GLevelEditorModeTools().ActivateMode(FOmniverseEdMode::EdModeID);
		FOmniverseEdMode::OnProcessCopy.AddUObject(this, &AOmniverseStageActor::OnProcessCopy);
		FOmniverseEdMode::OnProcessPaste.AddUObject(this, &AOmniverseStageActor::OnProcessPaste);
		FOmniverseEdMode::OnProcessCut.AddUObject(this, &AOmniverseStageActor::OnProcessCut);
		FOmniverseEdMode::OnProcessDuplicate.AddUObject(this, &AOmniverseStageActor::OnProcessDuplicate);
		FOmniverseEdMode::OnProcessDelete.AddUObject(this, &AOmniverseStageActor::OnProcessDelete);

		USelection::SelectObjectEvent.AddUObject(this, &AOmniverseStageActor::OnObjectSelected);

		// Garbage collection
		FCoreUObjectDelegates::GetPostGarbageCollect().AddUObject(this, &AOmniverseStageActor::OnPostGarbageCollect);
	}
}

AOmniverseStageActor::~AOmniverseStageActor()
{
	USDSequenceImporter = nullptr;

	if(!HasAllFlags(EObjectFlags::RF_ClassDefaultObject))
	{
		if (GEngine)
		{
			// Actor creation and destroy
			GEngine->OnLevelActorDeleted().RemoveAll(this);
			GEngine->OnLevelActorAdded().RemoveAll(this);
			GEngine->OnLevelActorDetached().RemoveAll(this);
			GEngine->OnLevelActorAttached().RemoveAll(this);
		}

#if WITH_EDITOR
		// Actor selection
		USelection::SelectionChangedEvent.RemoveAll(this);
#endif

		// Actor renaming
		FCoreDelegates::OnActorLabelChanged.RemoveAll(this);

		// Property change
		FCoreUObjectDelegates::OnObjectPropertyChanged.RemoveAll(this);

		// Render state callback
		UActorComponent::MarkRenderStateDirtyEvent.RemoveAll(this);

		// Light color and brightness
		ULightComponent::UpdateColorAndBrightnessEvent.RemoveAll(this);

		// Undo.
		if(GEditor)
		{
			// Mesh editor
			GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OnAssetEditorRequestedOpen().RemoveAll(this);
			USDTransaction.TransactionObj.Reset();
		}

		// Duplication
		if (GLevelEditorModeToolsIsValid() && GLevelEditorModeTools().IsModeActive(FOmniverseEdMode::EdModeID))
		{
			GLevelEditorModeTools().DeactivateMode(FOmniverseEdMode::EdModeID);
		}

		FOmniverseEdMode::OnProcessCopy.RemoveAll(this);
		FOmniverseEdMode::OnProcessPaste.RemoveAll(this);
		FOmniverseEdMode::OnProcessCut.RemoveAll(this);
		FOmniverseEdMode::OnProcessDuplicate.RemoveAll(this);
		FOmniverseEdMode::OnProcessDelete.RemoveAll(this);

		USelection::SelectObjectEvent.RemoveAll(this);

		// Garbage collection
		FCoreUObjectDelegates::GetPostGarbageCollect().RemoveAll(this);
	}
}

void AOmniverseStageActor::BeginDestroy()
{
	Super::BeginDestroy();

#if WITH_EDITOR
	if (!bInPlayingOrNotInEditor && USD)
	{
		USD->LeaveSession();
		USD->ReleaseStage();
		IOmniverseLayerDataSource::CleanupIfEquals(USD->GetLayerDataSource());
	}
#endif
}

void AOmniverseStageActor::Destroyed()
{
	Super::Destroyed();

	SetUSD(nullptr, false);
}

void AOmniverseStageActor::PostRegisterAllComponents()
{
	Super::PostRegisterAllComponents();

	if(!USD || !GetWorld() || GetWorld()->WorldType == EWorldType::Inactive || State != EState::None)	// Right click causes world being loaded. WorldType is Inactive at this time. We should skip it.
	{
		return;
	}

    // USDStage should be loaded if it's a default USD
    if (USD && USD->IsDefaultUSD() && !USD->IsStageLoaded())
    {        
        USD->ReloadUSDStage();
    }

	TArray<FString> ToReloadPrims;
	for (auto Pair : USDPathToObject)
	{
		if (Pair.Value.IsValid())
		{
			// TODO: there're more transient usd assets need to be reloaded after loading.
			if (Pair.Value->IsA<USkeletalMeshComponent>())
			{
				if (Cast<USkeletalMeshComponent>(Pair.Value.Get())->GetSkeletalMeshAsset() == nullptr)
				{
					ToReloadPrims.Add(FOmniversePathHelper::KeyToPrimPath(Pair.Key));
				}
			}
			else if (Pair.Value->IsA<UStaticMeshComponent>())
			{
				if (Cast<UStaticMeshComponent>(Pair.Value.Get())->GetStaticMesh() == nullptr)
				{
					ToReloadPrims.Add(FOmniversePathHelper::KeyToPrimPath(Pair.Key));
				}
			}
		}
	}

	for (auto PrimPath : ToReloadPrims)
	{
		LoadUSD(ToUSDPath(*PrimPath));
	}

	for (auto Iterator = USDPathToObject.CreateConstIterator(); Iterator; ++Iterator)
	{
		USceneComponent* SceneComponent = Cast<USceneComponent>(Iterator.Value());
		if (SceneComponent)
		{
			SceneComponent->TransformUpdated.RemoveAll(this);
			SceneComponent->TransformUpdated.AddUObject(this, &AOmniverseStageActor::OnSceneComponentTransformChanged);
		}
	}

	// Load from Omniverse
	LoadUSDScene();
}

#if WITH_EDITOR
void AOmniverseStageActor::AdoptAllExistingActors()
{
	TSet<UTexture2D*> LightmapTextures;

	TArray<AActor*> Actors;

	// RootComponents to be exported
	for (FActorIterator It(GetWorld()); It; ++It)
	{
		AActor* Actor = *It;

		auto Path = FindPath((UObject*)Actor);
		if (!Path)
		{
			Actors.Push(Actor);
		}

		// TODO: this was dead code - what should happen to it?
		/*#if LIGHTMAPS_EXPORT_PRIMVARS || LIGHTMAPS_EXPORT_SCHEMA
		for (TSet<UTexture2D*>::TConstIterator It(LightmapTextures); It; ++It)
		{
			UTexture2D * Texture = *It;
			const FString DDSFilename = FixupTextureName(Texture) + TEXT(".dds");
			ExportTexture2D(FPaths::GetPath(Path) / DDSFilename, Texture);
		}
		#endif*/
	}

	SaveActors(Actors);
}


void AOmniverseStageActor::SaveActors(TArray<AActor*> Actors)
{
	for (AActor* Actor : Actors)
	{
		const bool bIsRootComp = Actor->GetRootComponent() && !Actor->GetRootComponent()->GetAttachParent();
		if (bIsRootComp)
		{
			OnUE4ObjectChanged(*Actor->GetRootComponent(), TEXT(""));
		}
	}

	SaveChangedUE4Objects();
}

void AOmniverseStageActor::PreEditChange(FProperty* PropertyAboutToChange)
{
	Super::PreEditChange(PropertyAboutToChange);

	if (PropertyAboutToChange && PropertyAboutToChange->GetFName() == GET_MEMBER_NAME_CHECKED(AOmniverseStageActor, USD))
	{
		IOmniverseLayerDataSource::SetCurrentLayerDataSource(nullptr);
		USD->OnUSDChanged.RemoveAll(this);
		USD->LeaveSession();
		USD->ReleaseStage();
	}
}

void AOmniverseStageActor::PostEditChangeProperty(FPropertyChangedEvent & PropertyChangedEvent)
{
	// Stage actor would be duplicated, return to avoid crash.
	if(GetWorld())
	{
		for(FActorIterator It(GetWorld()); It; ++It)
		{
			if(It->IsA<AOmniverseStageActor>() && *It != this)
			{
				USD = nullptr;
				USDPathToObject.Reset();
				GetWorld()->DestroyActor(this, false, false);
				return;
			}
		}
	}

	// Call parent
	auto StatePtr = SetStateScoped(EState::Saving);	// Do not reload scene in PostRegisterAllComponents()
	Super::PostEditChangeProperty(PropertyChangedEvent);
	StatePtr.Reset();

	auto IsPropertyEdited = [&](const FString& PropName)
	{
		if(!PropertyChangedEvent.MemberProperty)
		{
			return true;
		}

		return PropertyChangedEvent.MemberProperty->GetName() == PropName;
	};

	// USD
	if(IsPropertyEdited(GET_MEMBER_NAME_STRING_CHECKED(AOmniverseStageActor, USD)))
	{
		if(USD)
		{
			//NOTE: must use copy here
			TMap<FString, TWeakObjectPtr<UObject>> CopyMap = USDPathToObject;
			USDPathToObject.Reset();
			for (auto Pair : CopyMap)
			{
				USceneComponent* SceneComp = Cast<USceneComponent>(Pair.Value);
				AActor* OwnerActor = SceneComp ? SceneComp->GetOwner() : nullptr;
				if (OwnerActor)
				{
					GetWorld()->EditorDestroyActor(OwnerActor, true);
				}
			}
			LoadUSDScene();
		}
		else
		{
			// This is called from ForceDeleteObjects() when USD is deleted by user in content browser. We can't rebuild scene here, because it triggers garbage collection, which causes crash in ForceDeleteObjects(). So we have to defer it. 
			TSharedRef<FDelegateHandle> DelegateHandle = MakeShared<FDelegateHandle>();
			TWeakObjectPtr<AOmniverseStageActor> StageActor(this);
			*DelegateHandle = FCoreDelegates::OnBeginFrame.AddLambda(
				[DelegateHandle, StageActor]()
				{
					if(StageActor.IsValid())
					{
						StageActor->SetUSD(nullptr);
					}

					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				}
			);
		}
	}

	// DefaultRoot
	if(!USD)
	{
		return;
	}

	do
	{
		if(!IsPropertyEdited(GET_MEMBER_NAME_STRING_CHECKED(AOmniverseStageActor, USDDefaultPrim)))
		{
			break;
		}

		StatePtr = SetStateScoped(EState::Saving);
		if(!StatePtr.IsValid())
		{
			break;
		}

		if(!USDDefaultPrim)
		{
			GetUSDStage()->SetDefaultPrim(pxr::UsdPrim());
			break;
		}

		bool bOK = false;

		TSharedPtr<void> Finish = MakeShareable<void>(nullptr,
			[&](auto)
			{
				if(bOK)
				{
					return;
				}

				LoadDefaultPrim();

				if(PropertyChangedEvent.MemberProperty)
				{
					FMessageDialog::Open(EAppMsgType::Ok, FText::FromString("Only root prim in USD can be set as default prim."));
				}
			}
		);

		auto PathKey = FindPath((UObject*)USDDefaultPrim->GetRootComponent());
		if(!PathKey)
		{
			break;
		}
		auto Path = FOmniversePathHelper::KeyToPrimPath(*PathKey);
		pxr::UsdPrim DefaultPrim = GetUSDStage()->GetPrimAtPath(ToUSDPath(*Path));
		if (!DefaultPrim)
		{
			break;
		}
		
		if(!DefaultPrim.GetPath().IsRootPrimPath())
		{
			break;
		}

		bOK = true;
		GetUSDStage()->SetDefaultPrim(DefaultPrim);
	} while(false);
}
#endif

AOmniverseStageActor& AOmniverseStageActor::Get(UWorld& World)
{
	if(auto StageActor = Find(World))
	{
		return *StageActor;
	}
	else
	{
		return *World.SpawnActor<AOmniverseStageActor>();
	}
}

AOmniverseStageActor * AOmniverseStageActor::Find(UWorld & World)
{
	for(FActorIterator It(&World); It; ++It)
	{
		if(It->IsA<AOmniverseStageActor>())
		{
			auto OmniStageActor = StaticCast<AOmniverseStageActor*>(*It);
			if(!OmniStageActor->HasValidUSD() && !OmniStageActor->HasValidImportStage())
			{
				OmniStageActor->SetUSD(NewObject<UOmniverseUSD>(OmniStageActor));
			}
			return OmniStageActor;
		}
	}

	return nullptr;
}

void AOmniverseStageActor::ReplicateObjectPropertyChange(UObject * Object)
{
	if (!Object)
	{
		return;
	}

	// Handle only cine camera currently
	if (!Object->IsA<UCineCameraComponent>() && !Object->IsA<ACineCameraActor>())
	{
		return;
	}

	UCineCameraComponent* CameraComponent = nullptr;
	if (Object->IsA<UCineCameraComponent>())
	{
		CameraComponent = Cast<UCineCameraComponent>(Object);
	}
	else
	{
		auto CameraActor = Cast<ACineCameraActor>(Object);
		CameraComponent = CameraActor->FindComponentByClass<UCineCameraComponent>();
	}

	if (CameraComponent && CameraComponent->GetWorld())
	{
		auto StageActor = AOmniverseStageActor::Find(*CameraComponent->GetWorld());
		if (StageActor && StageActor->HasValidUSD())
		{
			auto PrimPathKey = StageActor->FindPath((UObject*)CameraComponent);
			if (PrimPathKey)
			{
				auto PrimPath = FOmniversePathHelper::KeyToPrimPath(*PrimPathKey);
				auto StatePtr = StageActor->SetStateScoped(EState::Saving);
				if (!StatePtr.IsValid())
				{
					return;
				}

				auto USDStage = StageActor->GetUSDStage();
				auto CameraPrimPath = pxr::SdfPath(TCHAR_TO_ANSI(*PrimPath));
				auto CameraPrim = USDStage->GetPrimAtPath(CameraPrimPath);
				if(CameraPrim && CameraPrim.IsA<pxr::UsdGeomCamera>())
				{
					FUSDExporter Exporter;
					Exporter.Stage = USDStage;
					Exporter.PathToObject = MoveTemp(StageActor->USDPathToObject);
					Exporter.ExportCameraComponent(*CameraComponent);
					StageActor->USDPathToObject = MoveTemp(Exporter.PathToObject);
				}
			}
		}
	}
}

void AOmniverseStageActor::LoadUSDScene()
{
	ChangedUE4Objects.Objects.Reset();
	ChangedUSDPaths.Paths.Reset();

	// Callback
	if (GetWorld() == nullptr || USD == nullptr)
	{
		return;
	}

	if (!HasAllFlags(EObjectFlags::RF_ClassDefaultObject))
	{
#if WITH_EDITOR
		bInPlayingOrNotInEditor = false;
		UWorld* World = GetWorld();
		// Only stage actor in editor world will be the layer data source
		if (GEditor && World && World == GEditor->GetEditorWorldContext().World() && !World->IsPlayInEditor()
			&& !GEditor->PlayWorld)
		{
			auto DataSource = USD->GetLayerDataSource();
			IOmniverseLayerDataSource::SetCurrentLayerDataSource(DataSource);
		}
		else
		{
			// The stage actor is not in editor or it's running in PIE
			bInPlayingOrNotInEditor = true;
		}

		if (!USD->GetOmniPath().IsEmpty())
		{
			SpawnGlobalPostProcessVolume();
		}
#endif
	}

	USD->OnUSDChanged.RemoveAll(this);
	USD->OnUSDChanged.AddUObject(this, &AOmniverseStageActor::OnUSDStageNotice);

	// Load USD scene
	if (USD->IsStageLoaded())
	{
		if (USDPathToObject.Num() == 0)
		{
			LoadCustomLayerData();
			LoadLayerTimeInfo();
			USDSequenceImporter->CreateLevelSequence(TimeCodeInfo.StartTimeCode, TimeCodeInfo.EndTimeCode, TimeCodeInfo.TimeCodesPerSecond);
			OnUSDStageNotice(pxr::SdfPath("/"), true);
			LoadChangedUSDPaths();
			USDSequenceImporter->RemoveEmptyLevelSequence();
		}
	}
	else
	{
		USD->LoadUSDStage();
	}
}

void AOmniverseStageActor::OnUSDStageNotice(const pxr::SdfPath& Path, bool bResync)
{
	// Set sync flag
	auto StatePtr = SetStateScoped(EState::Loading);
	if(!StatePtr.IsValid())
	{
		return;
	}

	ChangedUSDPaths.Paths.Add(Path);
	ChangedUSDPaths.ResyncFlag.Add(bResync);
	if(!ChangedUSDPaths.DelegateHandle.IsValid())
	{
		ChangedUSDPaths.DelegateHandle = FCoreDelegates::OnBeginFrame.AddUObject(this, &AOmniverseStageActor::LoadChangedUSDPaths);
	}
}

void AOmniverseStageActor::LoadChangedUSDPaths()
{
	// Load each path
	for(int32 Index = 0; Index < ChangedUSDPaths.Paths.Num(); ++Index)
	{
		auto Path = ChangedUSDPaths.Paths[Index];
		auto Resync = ChangedUSDPaths.ResyncFlag[Index];
		if (Resync)
		{
			ResyncUSD(Path);
		}
		LoadUSD(Path, Resync);
	}

	// Clear up
	ChangedUSDPaths.Paths.Reset();
	ChangedUSDPaths.ResyncFlag.Reset();

	FCoreDelegates::OnBeginFrame.Remove(ChangedUSDPaths.DelegateHandle);
	ChangedUSDPaths.DelegateHandle.Reset();

#if WITH_EDITOR
	GEditor->RedrawLevelEditingViewports(false);
#endif
}

void AOmniverseStageActor::ResyncUSD(const pxr::SdfPath& Path)
{
	//Set flag
	auto StatePtr = SetStateScoped(EState::Loading);
	if(!StatePtr.IsValid())
	{
		return;
	}

	auto RemoveComponents = [&](const TArray<FString>& RemovedKeys, bool bSkipCamera)
	{
		// Delete components
		bool bActorDestroyed = false;
		TSet<USceneComponent*> HandledCineCameraComponents;
		for (auto Key : RemovedKeys)
		{
			auto FindObject = USDPathToObject.Find(Key);
			if (FindObject == nullptr)
			{
				continue;
			}

			auto SceneObject = *FindObject;
			// Destroy owner if it's the root component
			if(!SceneObject.IsValid())
			{
				USDPathToObject.Remove(Key);
				continue;
			}

			USceneComponent* SceneComp = Cast<USceneComponent>(SceneObject);
			AActor* OwnerActor = SceneComp ? SceneComp->GetOwner() : nullptr;

			if (bSkipCamera)
			{
				// Skip destroying camera if necessary
				if(OwnerActor && OwnerActor->IsA<ACineCameraActor>())
				{
					// TODO: This is dirty WAR to avoid destroy and recreate cine camera
					// as it's possible to cause lost track of sequencer
					auto CameraRootComponent = OwnerActor->GetRootComponent();
					if(!HandledCineCameraComponents.Contains(CameraRootComponent))
					{
						if(ToggleCineCameraVisibility(CameraRootComponent))
						{
							HandledCineCameraComponents.Add(CameraRootComponent);
							continue;
						}
					}
					else
					{
						continue;
					}
				}
			}

			// Remove from world
			if(OwnerActor && SceneComp && OwnerActor->GetRootComponent() == SceneComp)
			{
				if(!OwnerActor->IsPendingKillPending() && !OwnerActor->HasAllFlags(EObjectFlags::RF_BeingRegenerated))
				{
					ReserveObject(*OwnerActor, FOmniversePathHelper::KeyToPrimPath(Key));

					bActorDestroyed = true;
				}
			}
			else
			{
				ReserveObject(*SceneObject, FOmniversePathHelper::KeyToPrimPath(Key));
			}

			// Remove from path list
			USDPathToObject.Remove(Key);
		}

		// Notify editor
		if(bActorDestroyed)
		{
			GEngine->BroadcastLevelActorListChanged();
		}
	};

	// Remove all the children
	TArray<FString> RemovedKeys;
	auto ResyncPrimPath = Path.GetText();
	for (auto Pair : USDPathToObject)
	{
		auto EntryPath = FOmniversePathHelper::KeyToPrimPath(Pair.Key);
		if(IsSameOrChildPrimPath(ResyncPrimPath, EntryPath))
		{
			RemovedKeys.Add(Pair.Key);
		}
	}

	RemoveComponents(RemovedKeys, false);
}

void AOmniverseStageActor::LoadUSD(const pxr::SdfPath& Path, bool bLoadChildren)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("OmniStageActorLoadUSD"), STAT_OmniStageActorLoadUSD, STATGROUP_Omniverse);

#if UE_BUILD_DEBUG
	const FString PathText = Path.GetText();
#endif

	//Set flag
	auto StatePtr = SetStateScoped(EState::Loading);
	if(!StatePtr.IsValid())
	{
		return;
	}

	// Create parent
	auto Prim = GetUSDStage()->GetPrimAtPath(Path.GetAbsoluteRootOrPrimPath());
	if(!Prim)
	{
		return;
	}

	// Filter the prim which is either a master prim or a descendent of a master prim.
#if PXR_VERSION >= 2011
	if (Prim.IsInPrototype())
#else
	if (Prim.IsInMaster())
#endif //PXR_VERSION >= 2011
	{
		return;
	}

	if (!Prim.IsActive())
	{
		return;
	}

	auto FromSkelRootPrim = IsPrimFromUsdSchema<pxr::UsdSkelRoot>(Prim);
	// Check if skeletal mesh
	if(Prim.IsA<pxr::UsdSkelRoot>())
	{
		LoadSkeletalMeshComponent(Path);

		if (HasValidImportStage())
		{
			if (ImportSettings.bImportUnusedReferences)
			{
				FromSkelRootPrim = Prim;
			}
			else
			{
				return;
			}
		}
		else
		{
			return;
		}
	}
	else if (!HasValidImportStage() && FromSkelRootPrim)
	{
		LoadSkeletalMeshComponent(FromSkelRootPrim.GetPath());
		return;
	}

	if(!FromSkelRootPrim && Prim.IsA<pxr::UsdGeomXformable>())
	{
		TFunction<void(const pxr::UsdPrim&)> CreateParent;
		CreateParent = [&CreateParent, this](const pxr::UsdPrim& Prim)
		{
			if (!Prim)
			{
				return;
			}

			if(Prim.IsPseudoRoot())
			{
				return;
			}
			
			if(auto SceneComp = FindObjectFromPath<USceneComponent>(Prim.GetPath()))
			{
				if (!Prim.GetParent())
				{
					return;
				}

				if (auto ParentComp = FindObjectFromPath<USceneComponent>(Prim.GetParent().GetPath()))
				{
					if (SceneComp->GetAttachParent() == ParentComp)
					{
						return;
					}
				}
				else
				{
					return;
				}
			}

			CreateParent(Prim.GetParent());

			LoadSceneComponent(Prim.GetPath());
		};

		CreateParent(Prim.GetParent());
	}

	if(!FromSkelRootPrim && Prim.IsA<pxr::UsdGeomMesh>())
	{
		if (IsPrimFromUsdSchema<pxr::UsdGeomPointInstancer>(Prim))
		{
			LoadPointInstancerMesh(Path, bLoadChildren);
		}
		else
		{
			LoadStaticMeshComponent<UStaticMeshComponent, AStaticMeshActor>(Path, bLoadChildren);
		}
	}
	else if(!FromSkelRootPrim && Prim.IsA<pxr::UsdGeomSubset>())	// Geometry subset
	{
		auto GeomSubset = pxr::UsdGeomSubset(Prim);
		do
		{
			// Check mesh prim
			auto USDMesh = pxr::UsdGeomMesh(Prim.GetParent());
			if(!USDMesh)
			{
				break;
			}

			// Skip if parent mesh is reloaded
			auto ReloadedParent = Algo::FindByPredicate(ChangedUSDPaths.Paths,
				[&](const pxr::SdfPath& Path)
				{
					return Prim.GetPath().HasPrefix(Path);
				}
			);

			if(ReloadedParent)
			{
				break;
			}

			// Load geometry
			auto MeshComponent = FindObjectFromPath<UStaticMeshComponent>(USDMesh.GetPath());
			if(!MeshComponent)
			{
				break;
			}

			if(ShouldLoadProperty(Path, pxr::UsdGeomSubset::GetSchemaAttributeNames(false)))
			{
				LoadStaticMesh(USDMesh, *MeshComponent);
			}

			// Load material binding
			if(ShouldLoadProperty(Path, {pxr::UsdShadeTokens->materialBinding}))
			{
				LoadMaterial(*MeshComponent, USDMesh, GeomSubset);
			}

			LoadSceneComponent(Path, bLoadChildren);
		} while(false);
	}
	else if (!FromSkelRootPrim && OmniverseUsdLuxLightCompat::PrimIsALight(Prim))	// Lights
	{
		if(LoadLight(Path, bLoadChildren))
		{
			for(auto Actor : PreviewEnvironmentActors)
			{
				if(Actor.IsValid() && Actor->IsA<ADirectionalLight>())
				{
					GetWorld()->DestroyActor(Actor.Get(), false, false);
				}
			}
		}
	}
	else if (Prim.IsA<pxr::UsdShadeMaterial>())
	{
		pxr::UsdShadeConnectableAPI Source;
		pxr::TfToken SourceName;
		pxr::UsdShadeAttributeType SourceType;

		auto USDMaterial = pxr::UsdShadeMaterial(Prim);
		if (USDMaterial)
		{
			bool bImportAll = HasValidImportStage() && ImportSettings.bImportUnusedReferences;

			auto MdlSurfaceOutput = USDMaterial.GetSurfaceOutput(USDTokens.mdl);
			if (MdlSurfaceOutput)
			{
				if (MdlSurfaceOutput.GetConnectedSource(&Source, &SourceName, &SourceType))
				{
					auto MDLShader = pxr::UsdShadeShader(Source);
					if (MDLShader)
					{
						auto MaterialInst = FindObjectFromPath<UMaterialInstanceConstant>(MDLShader.GetPath());

						if (MaterialInst)
						{
							UpdateShadeInputs(MaterialInst, MDLShader);
						}
						else if (bImportAll)
						{
							// Import unused materials
							LoadMaterial(nullptr, 0, pxr::UsdGeomMesh(), pxr::UsdShadeShader(), MDLShader);
						}
					}
				}
			}

			// Check preview surface as well
			if (bImportAll)
			{
				auto SurfaceOutput = USDMaterial.GetSurfaceOutput();

				if (SurfaceOutput)
				{
					if (SurfaceOutput.GetConnectedSource(&Source, &SourceName, &SourceType))
					{
						auto Shader = pxr::UsdShadeShader(Source);	
						if (Shader)
						{
							auto MaterialInst = FindObjectFromPath<UMaterialInstanceConstant>(Shader.GetPath());
							if (MaterialInst == nullptr)
							{
								LoadMaterial(nullptr, 0, pxr::UsdGeomMesh(), Shader, pxr::UsdShadeShader());
							}
						}
					}
				}
			}
		}
	}
	else if (Prim.IsA<pxr::UsdShadeNodeGraph>())
	{
		if (Prim.HasAPI<pxr::UsdUINodeGraphNodeAPI>())
		{
			UpdateGraphNodePrim(Path);
		}
	}
	else if(Prim.IsA<pxr::UsdShadeShader>())	// Material
	{
		if (Prim.HasAPI<pxr::UsdUINodeGraphNodeAPI>())
		{
			UpdateGraphNodePrim(Path);
		}
		else
		{
			auto USDShader = pxr::UsdShadeShader(Prim);
			auto MaterialInst = FindObjectFromPath<UMaterialInstance>(Path.GetPrimPath());
			if (MaterialInst)
			{
				if (MaterialInst->IsA<UMaterialInstanceDynamic>())
				{
					FUSDConversion::SyncMaterialParameters(*MaterialInst, USDShader, FUSDConversion::EDirection::Import);
				}
				else if (MaterialInst->IsA<UMaterialInstanceConstant>())
				{
					auto MaterialInstConst = Cast<UMaterialInstanceConstant>(MaterialInst);
					if (IsPreviewSurface(MaterialInstConst))
					{
						FOmniverseUSDImporterHelper::UpdatePreviewSurfaceInputs(MaterialInstConst, USDShader, nullptr, [&](const FString& PrimName)
						{
							USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(PrimName), MaterialInstConst);
						},
						[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
						{
							CreateTextureFromBuffer(Content, Size, FileName, OutTexture);
						},
						[&](FString& TexturePath, UTexture*& OutTexture, UOmniverseTexture*& OutOmniTexture)
						{
							LoadOmniTexture(TexturePath, OutTexture, OutOmniTexture);
						},
						[&](UOmniverseTexture* InTextureAsset, UTexture* InTexture, bool OverrideSRGB)
						{
							PostLoadOmniTexture(InTextureAsset, InTexture, OverrideSRGB);
						});
					}
					else
					{
						UpdateShadeInputs(MaterialInstConst, USDShader);
					}
				}
			}
		}
	}
	else if(!FromSkelRootPrim && Prim.IsA<pxr::UsdGeomCamera>())	// Camera
	{
		UCameraComponent* Camera = nullptr;
		// Check if there's already an ACameraActor, if not, creating or getting an ACineCameraActor
		auto SceneComponent = FindObjectFromPath<USceneComponent>(Prim.GetPath());
		if (SceneComponent)
		{		
			if(SceneComponent->GetOwner() && SceneComponent->GetOwner()->IsA<ACameraActor>() && SceneComponent->GetOwner()->GetRootComponent() == SceneComponent)
			{
				auto CameraActor = Cast<ACameraActor>(SceneComponent->GetOwner());
				Camera = CameraActor->GetCameraComponent();
			}
		}

		pxr::UsdGeomCamera CameraPrim(Prim);
		auto Projection = GetUSDValue<pxr::TfToken>(CameraPrim.GetProjectionAttr());
		if (Camera == nullptr)
		{
			if (Projection == pxr::UsdGeomTokens->orthographic)
			{
				Camera = CreateActorAndComponent<UCameraComponent, ACameraActor>(Prim, true);
			}
			else
			{
				Camera = CreateActorAndComponent<UCineCameraComponent, ACineCameraActor>(Prim, true);
			}
		}
		else
		{
			// NOTE: Cine camera component can't set ortho camera, have to replace with camera component
			if (Camera->IsA<UCineCameraComponent>() && Projection == pxr::UsdGeomTokens->orthographic
			|| !Camera->IsA<UCineCameraComponent>() && Projection != pxr::UsdGeomTokens->orthographic)
			{
				ResyncUSD(Prim.GetPath());
				LoadUSD(Prim.GetPath(), true);
				return;
			}
		}

		if(Camera && ShouldLoadProperty(Path, pxr::UsdGeomCamera::GetSchemaAttributeNames(false)))
		{
			FNamedParameterTimeSamples NamedParameterTimeSamples;		
			USDImportCamera(CameraPrim, *Camera, NamedParameterTimeSamples);
			USDSequenceImporter->CreateObjectTrack(Camera, NamedParameterTimeSamples);
		}
		LoadSceneComponent(Path, bLoadChildren);
	}
	else if(!FromSkelRootPrim && Prim.IsA<pxr::UsdGeomGprim>())	// Basic shape
	{
		LoadBasicShape(Path, bLoadChildren);
	}
    else if(!FromSkelRootPrim && Prim.IsA<pxr::UsdGeomPointInstancer>())
    {
		LoadPointInstancer(Path, bLoadChildren);
    }
	else if(!FromSkelRootPrim && Prim.IsA<pxr::UsdGeomXformable>())	// Load scene component
	{
		LoadSceneComponent(Path, bLoadChildren);
	}
	else if(Path.IsAbsoluteRootOrPrimPath())
	{
		auto ChildPrims = Prim.GetFilteredChildren(pxr::UsdTraverseInstanceProxies());
		for(auto ChildPrim : ChildPrims)
		{
			LoadUSD(ChildPrim.GetPath(), bLoadChildren);
		}
	}

	// Load default prim
	if(Path == pxr::SdfPath::AbsoluteRootPath())
	{
		LoadDefaultPrim();
	}
}

void AOmniverseStageActor::LoadStaticMeshFromGeomGprim(const pxr::SdfPath& Path, UStaticMeshComponent& MeshComponent, bool bLoadChildren)
{
	pxr::UsdGeomGprim USDGprim = pxr::UsdGeomGprim::Get(GetUSDStage(), Path.GetPrimPath());
	if(!USDGprim)
	{
		return;
	}

	// Load material binding
	if(ShouldLoadProperty(Path, {pxr::UsdShadeTokens->materialBinding}))
	{
		LoadMaterial(MeshComponent, USDGprim);
	}

	// Cast shadow
	// We should also check parent prim if there's no "doNotCastShadows" primvar in current prim
	pxr::SdfPath CurrentPath = Path;
	pxr::UsdGeomXform CurrentPrim = pxr::UsdGeomXform(USDGprim);
	do
	{
		if(ShouldLoadProperty(CurrentPath, { USDTokens.doNotCastShadows }))
		{
			auto CastShadowVar = pxr::UsdGeomPrimvarsAPI(CurrentPrim).GetPrimvar(USDTokens.doNotCastShadows);
			bool bNotCastShadow = false;
			if (CastShadowVar && CastShadowVar.Get<bool>(&bNotCastShadow))
			{
				MeshComponent.CastShadow = !bNotCastShadow;
				MeshComponent.MarkRenderStateDirty();
				break;
			}
		}

		CurrentPath = CurrentPath.GetParentPath();
		CurrentPrim = pxr::UsdGeomXform::Get(GetUSDStage(), CurrentPath.GetPrimPath());
	}
	while(CurrentPrim);

	LoadSceneComponent(Path, bLoadChildren);
}

void AOmniverseStageActor::LoadAnimationSequence(USkeletalMeshComponent* SkeletalMeshComponent, const pxr::UsdSkelRoot& Root, const pxr::UsdSkelSkeletonQuery& USDSkeletonQuery, const pxr::UsdSkelBinding& SkeletonBinding, const FString& SkelMeshHashString)
{
	pxr::UsdSkelAnimQuery AnimQuery = USDSkeletonQuery.GetAnimQuery();
	auto SkeletalMesh = SkeletalMeshComponent->GetSkeletalMeshAsset();
	if (!SkeletalMesh || !AnimQuery.IsValid())
	{
		return;
	}

	std::vector<double> TimeSamples;
	bool bHasJointSamples = AnimQuery.GetJointTransformTimeSamples(&TimeSamples);
	std::vector<double> BlendShapeTimeSamples;
	bool bHasBlendShapeSamples = AnimQuery.GetBlendShapeWeightTimeSamples(&BlendShapeTimeSamples);
	if (!bHasJointSamples && !bHasBlendShapeSamples)
	{
		return;
	}

	double TimeCodesPerSecond = TimeCodeInfo.TimeCodesPerSecond.IsSet() ? TimeCodeInfo.TimeCodesPerSecond.GetValue() : DEFAULT_TIMECODESPERSECOND;
	double StartTimeCode = TimeCodeInfo.StartTimeCode.IsSet() ? TimeCodeInfo.StartTimeCode.GetValue() : DEFAULT_STARTTIMECODE;
	double EndTimeCode = TimeCodeInfo.EndTimeCode.IsSet() ? TimeCodeInfo.EndTimeCode.GetValue() : 0.0;

	FSHAHash Hash = FUSDHashGenerator::ComputeSHAHash(AnimQuery, StartTimeCode, EndTimeCode, TimeCodesPerSecond);
	FString Name = AnimQuery.GetPrim().GetName().GetText();
	if (FOmniverseReferenceCollector::Get().FindDependency(AnimQuery.GetPrim().GetPath().GetText()))
	{
		FString Text = FString::Printf(TEXT("Loading Animation %s..."), *Name);
		FOmniverseSlowTask::Get().UpdateProgress(1.0, FText::FromString(Text));
	}
	FString HashString = Hash.ToString();
	Name = GetUniqueImportName(HashString, Name);
	UE_LOG(LogOmniverseUsd, Log, TEXT("Loading anim sequence [%s]"), *Name);

	float StartOffsetSeconds = 0.0f;
	UAnimSequence* Sequence = Cast<UAnimSequence>(FUSDGeometryCache::Find(HashString));
	if (Sequence == nullptr)
	{
		Sequence = LoadImportObject<UAnimSequence>(ImportType::Animation, Name);
	}
	// NOTE: AnimSequence need to be recreated if skeleton was changed
	if (!Sequence || !Sequence->GetSkeleton()->IsCompatible(SkeletalMesh->GetSkeleton()))
	{
		// Force a new name for incompatible skeleton
		if (HasValidImportStage() && Sequence && !Sequence->GetSkeleton()->IsCompatible(SkeletalMesh->GetSkeleton()))
		{
			Name = Name + TEXT("_") + FString::FromInt(ImportedSuffixIndex++);
		}

		FBoxSphereBounds Result = SkeletalMesh->GetBounds();
		FBox BoundingBox(ForceInit);
			
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26		
		USkeleton* Skeleton = SkeletalMesh->Skeleton;
#else
		USkeleton* Skeleton = SkeletalMesh->GetSkeleton();
#endif

		FSkeletalMeshImportData SkeletalMeshImportData;
		UsdUtils::FBlendShapeMap BlendShapesByPath;
		TSet<FString> UsedMorphTargetNames;
		bool HasBlendShapes = false;
		if (FUSDDerivedDataCache::Load(SkelMeshHashString, SkeletalMeshImportData, HasBlendShapes))
		{
			if (HasBlendShapes)
			{
				// Blendshapes can't be serialized, have to be reloaded
				uint32 NumPointsBeforeThisMesh = 0;
				for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
				{
					pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
					if (SkinningMesh)
					{
						FOmniverseUSDImporterHelper::USDImportBlendShapes(SkinningQuery, NumPointsBeforeThisMesh, BlendShapesByPath, UsedMorphTargetNames);
						auto Points = GetUSDValue<pxr::VtArray<pxr::GfVec3f>>(SkinningMesh.GetPointsAttr());
						NumPointsBeforeThisMesh += Points.size();
					}
				}
			}
		}

		Sequence = FOmniverseUSDImporterHelper::CreateAnimSequence(USDSkeletonQuery, SkeletonBinding, BlendShapesByPath.Num() > 0 ? &BlendShapesByPath : nullptr, GetAssetPackage(ImportType::Animation, Name), GetAssetName(Name), GetAssetFlag(), Skeleton, SkeletalMesh, StartTimeCode, EndTimeCode, StartOffsetSeconds, &BoundingBox);
		if (Sequence)
		{
			if (BoundingBox.IsValid)
			{
				Result = Result + FBoxSphereBounds(BoundingBox);
			}

			SkeletalMesh->SetImportedBounds(Result);

			if (HasValidImportStage())
			{
				FOmniverseAssetImportHelper::UpdateAssetImportData(Sequence, ImportUSDSourceFile, Root.GetPath().GetText(), USDSkeletonQuery.GetPrim().GetPath().GetText());
				FAssetRegistryModule::AssetCreated(Sequence);
			}
		}
	}
	else
	{
		//Update animation start offset for sequencer
		TOptional<double> FirstJointSampleTimeCode;
		TOptional<double> FirstBlendShapeSampleTimeCode;
		
		if (TimeSamples.size() > 0)
		{
			FirstJointSampleTimeCode = TimeSamples[0];
		}

		if (BlendShapeTimeSamples.size() > 0)
		{
			FirstBlendShapeSampleTimeCode = BlendShapeTimeSamples[0];
		}

		if (FirstJointSampleTimeCode.IsSet() || FirstBlendShapeSampleTimeCode.IsSet())
		{
			const double StageStartTimeCode = FMath::Min(FirstJointSampleTimeCode.Get(TNumericLimits<double>::Max()), FirstBlendShapeSampleTimeCode.Get(TNumericLimits<double>::Max()));

			UE::FSdfLayerOffset Offset = UsdUtils::GetPrimToStageOffset(UE::FUsdPrim{ AnimQuery.GetPrim() });

			StartOffsetSeconds = ((StageStartTimeCode - Offset.Offset) / Offset.Scale) / TimeCodesPerSecond;
		}
	}

	if (Sequence)
	{
		FUSDGeometryCache::Add(HashString, Sequence);
	}

	if (Sequence && Sequence->IsValidToPlay())
	{
		// set to sequence to play the animation
		USDSequenceImporter->CreateSkeletalAnimationTrack(SkeletalMeshComponent->GetOwner(), Sequence, StartOffsetSeconds * TimeCodesPerSecond);
		// set to component to initialize the preview skel pose in the level
		SkeletalMeshComponent->AnimationData.AnimToPlay = Sequence;
		// animation sequence from usd plugin might has offset from start, can't be played directly in skeletal mesh component.
		SkeletalMeshComponent->AnimationData.bSavedLooping = false;
		SkeletalMeshComponent->AnimationData.bSavedPlaying = false;
		SkeletalMeshComponent->PlayAnimation(Sequence, false);
		SkeletalMeshComponent->InitAnim(true);
	}
}

bool AOmniverseStageActor::LoadSkeletalMeshComponent(const pxr::SdfPath& Path)
{
	auto USDSkelRoot = pxr::UsdSkelRoot(GetUSDStage()->GetPrimAtPath(Path.GetAbsoluteRootOrPrimPath()));
	if (!USDSkelRoot)
	{
		return false;
	}
	
	pxr::UsdSkelCache USDSkelCache;
	std::vector< pxr::UsdSkelBinding > USDSkeletonBindings;

#if PXR_VERSION >= 2011
	USDSkelCache.Populate(USDSkelRoot, pxr::UsdTraverseInstanceProxies());
	USDSkelCache.ComputeSkelBindings(USDSkelRoot, &USDSkeletonBindings, pxr::UsdTraverseInstanceProxies());
#else
	USDSkelCache.Populate(USDSkelRoot);
	USDSkelCache.ComputeSkelBindings(USDSkelRoot, &USDSkeletonBindings);
#endif //PXR_VERSION >= 2011

	// Skel root could contain mesh without skeleton binding. UE import it as Static mesh
	TArray<pxr::UsdPrim> MeshPrims;
	FindAllPrims<pxr::UsdGeomMesh>(USDSkelRoot.GetPrim(), MeshPrims);

	// Skeletal mesh not support multiple root skeletons, having to separate them into several skeletal meshes.
	for (auto SkeletonBinding : USDSkeletonBindings)
	{
		auto SkeletonMeshPrim = SkeletonBinding.GetSkeleton().GetPrim().GetParent();
		if (!SkeletonMeshPrim)
		{
			continue;
		}

		// Load the parents of skeletal mesh
		if (!SkeletonMeshPrim.IsA<pxr::UsdSkelRoot>())
		{
			auto Prim = SkeletonMeshPrim.GetParent();
			while (Prim && !Prim.IsPseudoRoot())
			{
				LoadSceneComponent(Prim.GetPath(), false);
				if (Prim.IsA<pxr::UsdSkelRoot>())
				{
					break;
				}
				Prim = Prim.GetParent();
			}
		}

		USkeletalMeshComponent* SkeletalMeshComponent = CreateActorAndComponent<USkeletalMeshComponent, ASkeletalMeshActor>(SkeletonMeshPrim);
		if (!SkeletalMeshComponent)
		{
			continue;
		}
		LoadSceneComponent(SkeletonMeshPrim.GetPath(), false);

		bool bPrimvarsAttribute = false;
		if (Path.IsPrimPropertyPath())
		{
			if (Path.GetName().find("primvars:", 0) == 0)
			{
				bPrimvarsAttribute = true;
			}
		}

		// Filter the mesh info for skeletal mesh
		for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
		{
			if (SkinningQuery.GetPrim())
			{
				MeshPrims.Remove(SkinningQuery.GetPrim());
			}
		}

		if (ShouldLoadProperty(Path, pxr::UsdGeomMesh::GetSchemaAttributeNames(), pxr::UsdGeomBoundable::GetSchemaAttributeNames())
			|| ShouldLoadProperty(Path, pxr::UsdSkelSkeleton::GetSchemaAttributeNames(false))
			|| ShouldLoadProperty(Path, pxr::UsdSkelBindingAPI::GetSchemaAttributeNames(false))
			|| bPrimvarsAttribute)
		{
			const pxr::UsdSkelSkeleton& USDSkeleton = SkeletonBinding.GetSkeleton();
			pxr::UsdSkelSkeletonQuery SkelQuery = USDSkelCache.GetSkelQuery(USDSkeleton);
			FSHAHash Hash = FUSDHashGenerator::ComputeSHAHash(USDSkelCache, SkeletonBinding);
			FString HashString = Hash.ToString();
			FString SkelMeshName = USDSkelRoot.GetPrim().GetName().GetText();
			FName Dependency = USDSkelRoot.GetPath().GetText();
			if (USDSkeletonBindings.size() > 1)
			{
				SkelMeshName = SkeletonMeshPrim.GetName().GetText();
				Dependency = SkeletonMeshPrim.GetPath().GetText();
			}

			if (FOmniverseReferenceCollector::Get().FindDependency(Dependency))
			{
				FString Text = FString::Printf(TEXT("Loading Skeletal Mesh %s..."), *SkelMeshName);
				FOmniverseSlowTask::Get().UpdateProgress(1.0, FText::FromString(Text));
			}

			SkelMeshName = GetUniqueImportName(HashString, SkelMeshName);
			UE_LOG(LogOmniverseUsd, Log, TEXT("Loading skeletal mesh [%s]"), *SkelMeshName);
			USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(FUSDGeometryCache::Find(HashString));
			if (SkeletalMesh == nullptr)
			{
				SkeletalMesh = LoadImportObject<USkeletalMesh>(ImportType::Mesh, SkelMeshName);
			}
			if (!SkeletalMesh)
			{
				FSkeletalMeshImportData SkeletalMeshImportData;
				TSet<FString> UsedMorphTargetNames;
				UsdUtils::FBlendShapeMap BlendShapesByPath;
				bool HasBlendShapes = false;
				if (!FUSDDerivedDataCache::Load(HashString, SkeletalMeshImportData, HasBlendShapes))
				{
					if (!FOmniverseUSDImporterHelper::USDImportSkeleton(SkelQuery, SkeletalMeshImportData))
					{
						continue;
					}

					for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
					{
						pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
						if (SkinningMesh)
						{
							uint32 NumPointsBeforeThisMesh = static_cast<uint32>(SkeletalMeshImportData.Points.Num());
							FOmniverseUSDImporterHelper::USDImportSkinning(SkelQuery, SkinningQuery, SkeletalMeshImportData);
							FOmniverseUSDImporterHelper::USDImportBlendShapes(SkinningQuery, NumPointsBeforeThisMesh, BlendShapesByPath, UsedMorphTargetNames);
						}
					}

					HasBlendShapes = BlendShapesByPath.Num() > 0;
					FUSDDerivedDataCache::Save(HashString, SkeletalMeshImportData, HasBlendShapes);
				}

				if (HasBlendShapes && BlendShapesByPath.IsEmpty())
				{
					// Blendshapes can't be serialized, have to be reloaded
					uint32 NumPointsBeforeThisMesh = 0;
					for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
					{
						pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
						if (SkinningMesh)
						{							
							FOmniverseUSDImporterHelper::USDImportBlendShapes(SkinningQuery, NumPointsBeforeThisMesh, BlendShapesByPath, UsedMorphTargetNames);
							auto Points = GetUSDValue<pxr::VtArray<pxr::GfVec3f>>(SkinningMesh.GetPointsAttr());
							NumPointsBeforeThisMesh += Points.size();
						}
					}
				}

				TArray<FSkeletalMeshImportData> LODIndexToSkeletalMeshImportData;
				LODIndexToSkeletalMeshImportData.Add(SkeletalMeshImportData);
				auto TransientSkeletalMesh = UsdToUnreal::GetSkeletalMeshFromImportData(LODIndexToSkeletalMeshImportData, SkeletalMeshImportData.RefBonesBinary, BlendShapesByPath, GetAssetFlag(), GetAssetName(SkelMeshName));

				if (HasValidImportStage())
				{
					if (TransientSkeletalMesh)
				{
						SkeletalMesh = DuplicateObject<USkeletalMesh>(TransientSkeletalMesh, GetAssetPackage(ImportType::Mesh, SkelMeshName), GetAssetName(SkelMeshName));
						SkeletalMesh->MarkPackageDirty();
				}
				}
				else
				{
					SkeletalMesh = TransientSkeletalMesh;
				}

				if (SkeletalMesh)
				{
					SkeletalMesh->GetMaterials().Empty();
					for (int32 MatIndex = 0; MatIndex < SkeletalMeshImportData.Materials.Num(); ++MatIndex)
					{
						const SkeletalMeshImportData::FMaterial& ImportedMaterial = SkeletalMeshImportData.Materials[MatIndex];
						UMaterialInterface* Material = ImportedMaterial.Material.Get() ? ImportedMaterial.Material.Get() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Omniverse/DefaultMaterial"));
						FString MaterialNameNoSkin = ImportedMaterial.MaterialImportName;
						SkeletalMesh->GetMaterials().Add(FSkeletalMaterial(Material, true, false, FName(*ImportedMaterial.MaterialImportName), FName(*ImportedMaterial.MaterialImportName)));
					}
					SkeletalMesh->PostEditChange();
				}

				if (HasValidImportStage())
				{
					FOmniverseAssetImportHelper::UpdateSkeletalMeshAssetImportData(SkeletalMesh, ImportUSDSourceFile, USDSkelRoot.GetPath().GetText(), USDSkeleton.GetPath().GetText());
					FAssetRegistryModule::AssetCreated(SkeletalMesh);
				}
			}

			if (SkeletalMesh)
			{
				FUSDGeometryCache::Add(HashString, SkeletalMesh);
			}

			// Skeleton
			auto SkelHash = FUSDHashGenerator::ComputeSHAHash(USDSkeleton, false);
			HashString = SkelHash.ToString();
			FString SkeletonName = USDSkeleton.GetPrim().GetName().GetText();
			if (FOmniverseReferenceCollector::Get().FindDependency(USDSkeleton.GetPath().GetText()))
			{
				FString Text = FString::Printf(TEXT("Loading Skeleton %s..."), *SkeletonName);
				FOmniverseSlowTask::Get().UpdateProgress(1.0, FText::FromString(Text));
			}
			SkeletonName = GetUniqueImportName(HashString, SkeletonName);
			UE_LOG(LogOmniverseUsd, Log, TEXT("Loading skeleton [%s]"), *SkeletonName);
			USkeleton* Skeleton = Cast<USkeleton>(FUSDGeometryCache::Find(HashString));
			if (Skeleton == nullptr)
			{
				Skeleton = LoadImportObject<USkeleton>(ImportType::Mesh, SkeletonName);
			}
			if (!Skeleton || !Skeleton->IsCompatibleMesh(SkeletalMesh))
			{
				// Force a new name for incompatible mesh
				if (HasValidImportStage() && Skeleton && !Skeleton->IsCompatibleMesh(SkeletalMesh))
				{
					SkeletonName = SkeletonName + TEXT("_") + FString::FromInt(ImportedSuffixIndex++);
				}

				auto TransientSkeleton = SkeletalMesh->GetSkeleton();
				if (HasValidImportStage())
				{
					if (TransientSkeleton)
			{
						Skeleton = DuplicateObject<USkeleton>(TransientSkeleton, GetAssetPackage(ImportType::Mesh, SkeletonName), GetAssetName(SkeletonName));
						Skeleton->MarkPackageDirty();
			SkeletalMesh->SetSkeleton(Skeleton);
				}
					}
				else
					{
					Skeleton = TransientSkeleton;
						}
					
					if (HasValidImportStage())
					{
					FAssetRegistryModule::AssetCreated(Skeleton);
					}
				}

			if (Skeleton)
				{
				FUSDGeometryCache::Add(HashString, Skeleton);
				}

			SkeletalMeshComponent->SetSkeletalMesh(SkeletalMesh);

			LoadAnimationSequence(SkeletalMeshComponent, USDSkelRoot, SkelQuery, SkeletonBinding, Hash.ToString());
			}

		if (ShouldLoadProperty(Path, { pxr::UsdShadeTokens->materialBinding }))
		{
			int32 MaterialIndex = 0;
			for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
			{
				pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
				SkeletalMeshComponent->SetMaterial(MaterialIndex, nullptr);
				auto USDGeomSubsets = pxr::UsdGeomSubset::GetAllGeomSubsets(SkinningMesh);
				if (!USDGeomSubsets.empty())
				{
					for (auto USDGeomSubset : USDGeomSubsets)
					{
						pxr::TfToken FamilyName;
						if (!USDGeomSubset.GetFamilyNameAttr().Get(&FamilyName) || FamilyName != pxr::UsdShadeTokens->materialBind)
						{
							// Add warning instead of not loading material
							UE_LOG(LogOmniverseUsd, Warning, L"%s: Material bindings authored on GeomSubsets are honored by renderers only if their familyName is UsdShadeTokens->materialBind", *FString(USDGeomSubset.GetPath().GetText()));
						}
						auto MaterialBinding = FUSDConversion::ParsePrimMaterial(USDGeomSubset.GetPrim());
						LoadMaterial(SkeletalMeshComponent, MaterialIndex, SkinningMesh, MaterialBinding.Shader, MaterialBinding.MdlSurfaceShader);
						++MaterialIndex;
					}	
				}
				else
				{
					auto MaterialBinding = FUSDConversion::ParsePrimMaterial(SkinningMesh.GetPrim());
					LoadMaterial(SkeletalMeshComponent, MaterialIndex, SkinningMesh, MaterialBinding.Shader, MaterialBinding.MdlSurfaceShader);
					++MaterialIndex;
				}
			}
		}
	}

	for (auto MeshPrim : MeshPrims)
	{
		auto Prim = MeshPrim.GetParent();
		while (Prim && !Prim.IsPseudoRoot())
		{
			LoadSceneComponent(Prim.GetPath(), false);
			if (Prim.IsA<pxr::UsdSkelRoot>())
			{
				break;
			}
			Prim = Prim.GetParent();
		}

		LoadStaticMeshComponent<UStaticMeshComponent, AStaticMeshActor>(MeshPrim.GetPath(), false);
	}

	return true;
}

#if LIGHTMAPS_EXPORT_PRIMVARS
static bool CreateUniformAttribute(pxr::UsdPrim& Prim, const std::string& Name, const int Value, pxr::UsdTimeCode TimeCode)
{
	auto Attribute = Prim.CreateAttribute(pxr::TfToken(Name), pxr::SdfValueTypeNames->Int, pxr::SdfVariabilityUniform);
	return Attribute.Set<int>(Value, TimeCode);
}

static bool CreateUniformAttribute(pxr::UsdPrim& Prim, const std::string& Name, const FVector2D& Value, pxr::UsdTimeCode TimeCode)
{
	auto Attribute = Prim.CreateAttribute(pxr::TfToken(Name), pxr::SdfValueTypeNames->Float2, pxr::SdfVariabilityUniform);
	return Attribute.Set<pxr::GfVec2f>(USDConvert(Value), TimeCode);
}

static bool CreateUniformAttribute(pxr::UsdPrim& Prim, const std::string& Name, const FString& value, pxr::UsdTimeCode TimeCode)
{
	auto Attribute = Prim.CreateAttribute(pxr::TfToken(Name), pxr::SdfValueTypeNames->String);
	return Attribute.Set(std::string(TCHAR_TO_ANSI(*value)), TimeCode);
}
#endif

#if LIGHTMAPS_EXPORT_PRIMVARS || LIGHTMAPS_EXPORT_SCHEMA
static void SaveLightmappingInfo(const pxr::UsdStageRefPtr& Stage, pxr::UsdPrim MeshPrim, const UStaticMeshComponent& Component, pxr::UsdTimeCode StageTimeCode, TSet<UTexture2D*> * Textures = nullptr)
{
	if (!Component.HasLightmapTextureCoordinates())
	{
		// Lightmap local mapping is not available
		return;
	}

	if (!Component.LODData.Num())
	{
		// LOD information is not available
		return;
	}
	const FStaticMeshComponentLODInfo & ComponentLODInfo = Component.LODData[0];
	const FMeshMapBuildData * MeshMapBuildData = Component.GetMeshMapBuildData(ComponentLODInfo);

	if (!MeshMapBuildData)
	{
		// Mesh build data is not available
		return;
	}

	const UStaticMesh* StaticMesh = Component.GetStaticMesh();
	const int32& CoordIndex = StaticMesh->GetLightMapCoordinateIndex();

	// Lightmaps info
	FLightMap * LightMap = MeshMapBuildData->LightMap.GetReference();
	if (LightMap)
	{
		FLightMap2D * LightMap2D = LightMap->GetLightMap2D();
		if (LightMap2D)
		{
			const FVector2D& CoordBias = LightMap2D->GetCoordinateBias();
			const FVector2D& CoordScale = LightMap2D->GetCoordinateScale();
			UTexture2D* LightTextureHQ = LightMap2D->GetTexture(0);
			UTexture2D* LightTextureLQ = LightMap2D->GetTexture(1);

#if LIGHTMAPS_EXPORT_PRIMVARS
			// keep information on uniform primvars
			CreateUniformAttribute(MeshPrim, "LightmapCoordIndex", CoordIndex, StageTimeCode);
			CreateUniformAttribute(MeshPrim, "LightmapCoordBias", CoordBias, StageTimeCode);
			CreateUniformAttribute(MeshPrim, "LightmapCoordScale", CoordScale, StageTimeCode);
			CreateUniformAttribute(MeshPrim, "LightmapTextureHQ", FixupTextureName(LightTextureHQ), StageTimeCode);
			CreateUniformAttribute(MeshPrim, "LightmapTextureLQ", FixupTextureName(LightTextureLQ), StageTimeCode);
#endif

#if LIGHTMAPS_EXPORT_SCHEMA
			// keep information on schema prim
			auto PrimPath = MeshPrim.GetPath().AppendElementString("LightmapInfo");
			pxr::LightmapsSchemaLightmap LightmapPrim(Stage->DefinePrim(PrimPath, pxr::TfToken("Lightmap")));
			LightmapPrim.CreateCoordIndexAttr(pxr::VtValue(static_cast<int>(CoordIndex)));
			LightmapPrim.CreateCoordBiasAttr(pxr::VtValue(static_cast<pxr::GfVec2f>(USDConvert(CoordBias))));
			LightmapPrim.CreateCoordScaleAttr(pxr::VtValue(static_cast<pxr::GfVec2f>(USDConvert(CoordScale))));
			LightmapPrim.CreateTextureHQAttr(pxr::VtValue(static_cast<std::string>(TCHAR_TO_ANSI(*FixupTextureName(LightTextureHQ)))));
			LightmapPrim.CreateTextureLQAttr(pxr::VtValue(static_cast<std::string>(TCHAR_TO_ANSI(*FixupTextureName(LightTextureLQ)))));
#endif

			if (Textures)
			{
				Textures->Add(LightTextureHQ);
				Textures->Add(LightTextureLQ);
			}
		}
	}

	// Shadomap info
	FShadowMap * ShadowMap = MeshMapBuildData->ShadowMap.GetReference();
	if (ShadowMap)
	{
		FShadowMap2D * ShadowMap2D = ShadowMap->GetShadowMap2D();
		if (ShadowMap2D)
		{
			const FVector2D& CoordBias = ShadowMap2D->GetCoordinateBias();
			const FVector2D& CoordScale = ShadowMap2D->GetCoordinateScale();
			UTexture2D* ShadowTexture = ShadowMap2D->GetShadowMap2D()->GetTexture();

#if LIGHTMAPS_EXPORT_PRIMVARS
			// keep information on uniform primvars
			CreateUniformAttribute(MeshPrim, "ShadowmapCoordIndex", CoordIndex, StageTimeCode);
			CreateUniformAttribute(MeshPrim, "ShadowmapCoordBias", CoordBias, StageTimeCode);
			CreateUniformAttribute(MeshPrim, "ShadowmapCoordScale", CoordScale, StageTimeCode);
			CreateUniformAttribute(MeshPrim, "ShadowmapTexture", FixupTextureName(ShadowTexture), StageTimeCode);
#endif

#if LIGHTMAPS_EXPORT_SCHEMA
			// keep information on schema prim
			auto PrimPath = MeshPrim.GetPath().AppendElementString("ShadowmapInfo");
			pxr::LightmapsSchemaShadowmap ShadowmapPrim(Stage->DefinePrim(PrimPath, pxr::TfToken("Shadowmap")));
			ShadowmapPrim.CreateCoordIndexAttr(pxr::VtValue(static_cast<int>(CoordIndex)));
			ShadowmapPrim.CreateCoordBiasAttr(pxr::VtValue(static_cast<pxr::GfVec2f>(USDConvert(CoordBias))));
			ShadowmapPrim.CreateCoordScaleAttr(pxr::VtValue(static_cast<pxr::GfVec2f>(USDConvert(CoordScale))));
			ShadowmapPrim.CreateTextureAttr(pxr::VtValue(static_cast<std::string>(TCHAR_TO_ANSI(*FixupTextureName(ShadowTexture)))));
#endif

			if (Textures)
			{
				Textures->Add(ShadowTexture);
			}
		}
	}
}
#endif

bool AOmniverseStageActor::ToggleCineCameraVisibility(USceneComponent* Component)
{
	if (!Component || !Component->GetOwner())
	{
		return false;
	}

	auto Actor = Component->GetOwner();
	if (!Actor->IsA<ACineCameraActor>())
	{
		return false;
	}

	auto FoundPathKey = FindPath((UObject*)Actor->GetRootComponent());
	if (!FoundPathKey)
	{
		return false;
	}

	auto PrimPath = ToUSDPath(*FOmniversePathHelper::KeyToPrimPath(*FoundPathKey));
	auto Prim = GetUSDStage()->GetPrimAtPath(PrimPath);
	if (!Prim)
	{
		return false;
	}

	pxr::UsdGeomCamera CameraPrim;
	if (Prim.IsA<pxr::UsdGeomCamera>())
	{
		CameraPrim = pxr::UsdGeomCamera(Prim);
	}
	else if(!Prim.GetAllChildren().empty())
	{
		auto ChildPrim = Prim.GetAllChildren().front();
		CameraPrim = pxr::UsdGeomCamera(ChildPrim);
	}

	bool bVisible = false;
	if (CameraPrim)
	{
		bVisible = true;
		auto CineComponent = Cast<UCameraComponent>(Actor->GetComponentByClass(UCameraComponent::StaticClass()));
		if (CineComponent)
		{
			// what's doing here?
			FNamedParameterTimeSamples NamedParameterTimeSamples;
			USDImportCamera(CameraPrim, *CineComponent, NamedParameterTimeSamples);
		}
	}

	TArray<USceneComponent*> Components;
	Actor->GetComponents(Components);
	for (auto ActorComponent : Components)
	{
		Cast<USceneComponent>(ActorComponent)->SetVisibility(bVisible);
	}
		
	return true;
}

void AOmniverseStageActor::OnUE4ObjectChanged(UObject& ChangedObject, const FString& Change)
{
	if(!USD || !GetUSDStage())
	{
		return;
	}

	// We used to skip this if "Transacting" (Undo/Redo), but then Undo/Redo changes weren't being
	// saved to USD, so we're going to go ahead and do it (OM-16706)
	//if(GIsTransacting)
	//{
	//	return;
	//}

	if (!GetWorld())
	{
		return;
	}

	bool bEnablePlayInEditorChanges = GetDefault<UOmniverseSettings>()->bEnablePlayInEditorChanges;
	if (GetWorld()->WorldType != EWorldType::Editor && !bEnablePlayInEditorChanges)
	{
		return;
	}
	
	// Check state
	auto ScopedState = SetStateScoped(EState::Saving);
	if(!ScopedState.IsValid())
	{
		return;
	}

	// VR Editor Mode spawns transient scene actors that we do not want to interact with
	if (ChangedObject.HasAnyFlags(RF_DuplicateTransient))
	{
		return;
	}

	// Skip Blueprints
	if(Cast<UBlueprintGeneratedClass>(ChangedObject.GetClass()))
	{
		return;
	}

	// Skip reserved objects
	if(ChangedObject.GetTypedOuter<AOmniverseStageActor>() == this)
	{
		return;
	}

	// Skip scene objects that are not in the same world
	AActor* ChangedActor = Cast<AActor>(&ChangedObject);
	if(ChangedActor || ChangedObject.IsA<UActorComponent>())
	{
		if(ChangedObject.GetWorld() != GetWorld())
		{
			return;
		}
	}

	if (ChangedObject.IsA<UActorComponent>())
	{
		if (DetachComponentsFromDestroy.Find(Cast<UActorComponent>(&ChangedObject)) != INDEX_NONE)
		{
			return;
		}
	}

	// Can't save usd when sequence is playing
	if (USDSequenceImporter && USDSequenceImporter->IsPlayingSequence())
	{
		return;
	}

#if WITH_EDITOR
	// Skip placed USD
	if(PlacedUSDs.Num())
	{
		auto Component = Cast<UActorComponent>(&ChangedObject);
		if(!Component)
		{
			if(ChangedActor)
			{
				Component = ChangedActor->GetRootComponent();
			}
		}

		if(Component && Change.IsEmpty() && PlacedUSDs.Find(Component) >= 0)
		{
			return;
		}
	}
#endif

	// Skip some cases
	UObject* ConnectedObject = nullptr;
	if(!ChangedActor && !FindPath((UObject*)const_cast<UObject*>(&ChangedObject))
	|| ChangedActor && !FindPath(ChangedActor->GetRootComponent()))
	{
		// Camera component isn't the root component of Camera actor, switch to the root component here
		if (ChangedObject.IsA<UCameraComponent>())
		{
			USceneComponent* ChangedComponent = Cast<USceneComponent>(&ChangedObject);
			if (ChangedComponent->GetOwner() && ChangedComponent->GetOwner()->IsA<ACameraActor>())
			{
				if (FindPath(Cast<UObject>(ChangedComponent->GetAttachParent())))
				{
					ConnectedObject = ChangedComponent->GetAttachParent();
				}
			}
		}

		if(ConnectedObject == nullptr && Change != "")	// For new objects, only full change is accepted
		{
			return;
		}
	}

	// Add to list
	if(!ChangedUE4Objects.DelegateHandle.IsValid())
	{
		ChangedUE4Objects.DelegateHandle = FCoreDelegates::OnBeginFrame.AddUObject(this, &AOmniverseStageActor::SaveChangedUE4Objects);
	}

	auto& Changes = ChangedUE4Objects.Objects.FindOrAdd(ConnectedObject ? ConnectedObject : (ChangedActor ? ChangedActor->GetRootComponent() : &ChangedObject));
	Changes.AddUnique(Change);

	// Transaction
	if(GEditor->IsTransactionActive())
	{
		ScopedState.Reset();

		USDTransaction.TransactionData = MakeShared<FUSDTransactionData>();

		auto Transact = [TransactionData = USDTransaction.TransactionData, this](UOmniverseTransaction::EUndoType UndoType)
		{
			TransactUSD(*TransactionData, UndoType);
		};

		USDTransaction.TransactionObj->AddTransaction(UOmniverseTransaction::FUndoDelegate::CreateWeakLambda(this, Transact));
	}
}

void AOmniverseStageActor::OnPostGarbageCollect()
{
	// Clear up MDL delegates
	TArray<decltype(MDLDelegateHandles)::TIterator> Removed;

	for(auto Iter = MDLDelegateHandles.CreateIterator(); Iter; ++Iter)
	{
		// Component is invalid, unbind delegate and remove
		if(!Iter.Key().IsValid())
		{
			for(auto MDLIter = Iter.Value().CreateIterator(); MDLIter; ++MDLIter)
			{
				if(MDLIter.Key().IsValid())
				{
					MDLIter.Key()->OnUpdated.Remove(MDLIter.Value());
				}
			}

			Removed.Add(Iter);
			continue;
		}

		// MDL is invalid, remove
		TArray<decltype(Iter.Value().CreateIterator())> RemovedMDL;

		for(auto MDLIter = Iter.Value().CreateIterator(); MDLIter; ++MDLIter)
		{
			if(!MDLIter.Key().IsValid())
			{
				RemovedMDL.Add(MDLIter);
			}
		}

		for(auto MDLIter : RemovedMDL)
		{
			MDLIter.RemoveCurrent();
		}
	}

	for(auto Iter : Removed)
	{
		Iter.RemoveCurrent();
	}

	// Clear up USD paths
	TArray<decltype(USDPathToObject)::TIterator> RemovedPaths;
	for(auto Iter = USDPathToObject.CreateIterator(); Iter; ++Iter)
	{
		if(!Iter.Value().IsValid())
		{
			RemovedPaths.Add(Iter);
		}
	}

	for(auto Iter : RemovedPaths)
	{
		Iter.RemoveCurrent();
	}
}

void AOmniverseStageActor::OnComponentMarkRenderStateDirty(UActorComponent& Component)
{
	OnUE4ObjectChanged(Component, TEXT("RenderState"));
}

void AOmniverseStageActor::OnLightUpdateColorAndBrightness(ULightComponent& LightComponent)
{
	OnComponentMarkRenderStateDirty(LightComponent);
}

bool AOmniverseStageActor::IsComponentSupported(USceneComponent& Component)
{
	bool bSupported = false;
	if (Component.IsA<UStaticMeshComponent>() || Component.IsA<UDirectionalLightComponent>() ||
		Component.IsA<UPointLightComponent>() || Component.IsA<URectLightComponent>() ||
		Component.IsA<UCameraComponent>() ||
		Component.IsA<USkeletalMeshComponent>())
	{
		bSupported = true;
	}

	// Actor to Xform
	if (Component.GetClass() == USceneComponent::StaticClass()
	&& Component.GetOwner() && Component.GetOwner()->GetClass() == AActor::StaticClass()
	&& Component.GetOwner()->GetRootComponent() == &Component)
	{
		bSupported = true;
	}

	if (!bSupported)
	{
		auto AttachChildren = Component.GetAttachChildren();
		for (int32 ChildIndex = 0; ChildIndex < AttachChildren.Num(); ChildIndex++)
		{
			bSupported = IsComponentSupported(*AttachChildren[ChildIndex]);
			if (bSupported)
				break;
		}
	}

	return bSupported;
}

void AOmniverseStageActor::OnSceneComponentTransformChanged(USceneComponent* UpdatedComponent, EUpdateTransformFlags UpdateTransformFlags, ETeleportType Teleport)
{
	// if we're animating, process all PropagateFromParent updates to children, in case we are temporarily faking hierachy adjustments. otherwise if we aren't animating,
	// bail out early - this is a perf suck. 
	bool Animating = StageTimeCode != pxr::UsdTimeCode::Default();
	if (Animating == false &&
		UpdateTransformFlags == EUpdateTransformFlags::PropagateFromParent)
	{
		return;
	}


	OnUE4ObjectChanged(*UpdatedComponent, FString(TEXT("Member")) / TEXT("RelativeLocation"));
	OnUE4ObjectChanged(*UpdatedComponent, FString(TEXT("Member")) / TEXT("RelativeRotation"));
	OnUE4ObjectChanged(*UpdatedComponent, FString(TEXT("Member")) / TEXT("RelativeScale3D"));
}

void AOmniverseStageActor::OnMDLUpdated(TWeakObjectPtr<USceneComponent> Component, TWeakObjectPtr<UOmniverseMDL> OmniMDL, bool bNewCreated)
{
	//Set flag
	auto StatePtr = SetStateScoped(EState::Loading);
	if(!StatePtr.IsValid())
	{
		return;
	}

	// Remove if component is not valid
	if(!Component.IsValid() || !OmniMDL.IsValid() || !FindPath(Component.Get()))
	{
		if(auto DelegateHandles = MDLDelegateHandles.Find(Component))
		{
			for(auto Iter = DelegateHandles->CreateIterator(); Iter; ++Iter)
			{
				if(Iter.Key().IsValid())
				{
					Iter.Key()->OnUpdated.Remove(Iter.Value());
				}
			}

			MDLDelegateHandles.Remove(Component);
		}

		return;
	}

	// Remove if MDL is not bound
	do
	{
		if(bNewCreated)
		{
			break;
		}

		auto MeshComponent = Cast<UMeshComponent>(Component);
		if(!MeshComponent)
		{
			break;
		}

		auto DelegateHandles = MDLDelegateHandles.Find(MeshComponent);
		if(!DelegateHandles)
		{
			break;
		}

		auto DelegateHandle = DelegateHandles->Find(&*OmniMDL);
		if(!DelegateHandle)
		{
			break;
		}

		auto Material = MeshComponent->GetMaterials().FindByPredicate(
			[&](auto Material)
			{
				if(!Material)
				{
					return false;
				}

				return UOmniverseAsset::GetOmniverseAsset<UOmniverseMDL>(*Material) == &*OmniMDL;
			}
		);

		if(Material)
		{
			break;
		}

		OmniMDL->OnUpdated.Remove(*DelegateHandle);
		DelegateHandles->Remove(&*OmniMDL);
	} while(false);

	// Update MDL
	if(!bNewCreated)
	{
		Component->RecreateRenderState_Concurrent();
		return;
	}

	// Material is newly loaded, bind it to meshes
	if(Component->IsA<UMeshComponent>())
	{
		auto USDPathKey = FindPath(Component.Get());
		check(USDPathKey);

		auto Path = ToUSDPath(*FOmniversePathHelper::KeyToPrimPath(*USDPathKey));
		Path.AppendProperty(pxr::UsdShadeTokens->materialBinding);

		OnUSDStageNotice(Path, false);
	}
}

static void RemoveActorFromList(TMap<AActor*, const AActor*>& List, AActor* Actor)
{
	List.Remove(Actor);

	// Can't get children by API GetAttachedActors, the children has been detached.
	// Search the list to get the children.
	while(true)
	{
		auto Child = List.FindKey(Actor);
		if (Child == nullptr)
		{
			break;
		}

		RemoveActorFromList(List, *Child);
	};
}

void AOmniverseStageActor::OnActorDestroyed(AActor * Actor)
{
	RemoveActorFromList(DetachActorLists, Actor);

    // Validate
    if(GetWorld() != Actor->GetWorld() || State != EState::None)
    {
        return;
    }

    auto PathKey = FindPath((UObject*)Actor->GetRootComponent());
    if(!PathKey)
    {
        return;
    }

    auto Path = FOmniversePathHelper::KeyToPrimPath(*PathKey);
    auto USDPath = ToUSDPath(*Path);
    auto Prim = GetUSDStage()->GetPrimAtPath(USDPath);
    if (Prim)
	{
        // Remove corresponding USD prim
        OmniUsdStageCtrl::RemovePrim(Prim);
    }
}

void AOmniverseStageActor::OnActorAdded(AActor* Actor)
{
	if(!GetWorld())
	{
		return;
	}
	
	if(GetWorld()->WorldType != EWorldType::Editor)
	{
		return;
	}

	// VR Editor Mode spawns transient scene actors that we do not want to interact with
	if (Actor->HasAnyFlags(RF_DuplicateTransient))
	{
		return;
	}

	OnUE4ObjectChanged(*Actor, TEXT(""));
}

void AOmniverseStageActor::OnActorDetached(AActor* InActor, const AActor* InParent)
{
	if (DetachActorLists.Find(InActor) == nullptr)
	{
		DetachActorLists.Add(InActor, InParent);
	}

	if (InParent->IsActorBeingDestroyed())
	{
		DetachComponentsFromDestroy.Add(InActor->GetRootComponent());

		TSharedPtr<FDelegateHandle> DelHandle = MakeShared<FDelegateHandle>();
		*DelHandle = FCoreDelegates::OnBeginFrame.AddWeakLambda(this,
			[DelHandle, this]()
			{
				DetachComponentsFromDestroy.Reset();
				FCoreDelegates::OnBeginFrame.Remove(*DelHandle);
			}
		);
	}
}

void AOmniverseStageActor::OnActorAttached(AActor* InActor, const AActor* InParent)
{
	auto OldParent = DetachActorLists.Find(InActor);
	if (OldParent && (*OldParent)->IsValidLowLevel() && *OldParent != InParent)
	{
		auto FoundPathKey = FindPath((UObject*)InActor->GetRootComponent());
		if (FoundPathKey)
		{
			FString ActorPath = FOmniversePathHelper::KeyToPrimPath(*FoundPathKey);
			auto ActorUSDPath = ToUSDPath(*ActorPath);
			auto Prim = GetUSDStage()->GetPrimAtPath(ActorUSDPath);
			if (!Prim)
			{
				return;
			}

			// NOTE: Different behavior between UE4 and Create
			// If select both parent and children actors, children won't attach to the new parent, still keep the old hierarchy
			for(FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
			{
				AActor* Actor = static_cast<AActor*>(*It);
				if (*OldParent == Actor || (*OldParent)->IsAttachedTo(Actor))
				{
					InActor->AttachToActor(const_cast<AActor*>(*OldParent), FAttachmentTransformRules::KeepWorldTransform);
					return;
				}
			}

			if (OmniUsdStageCtrl::IsAncestralPrim(Prim))
			{
				FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot move ancestral prim %s"), *ActorPath));
				InActor->AttachToActor(const_cast<AActor*>(*OldParent), FAttachmentTransformRules::KeepWorldTransform);
				return;
			}

			auto ParentPathKey = FindPath((UObject*)InParent->GetRootComponent());
			if (ParentPathKey == nullptr)
			{
				FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot move prim %s out of root prim"), *ActorPath));
				InActor->AttachToActor(const_cast<AActor*>(*OldParent), FAttachmentTransformRules::KeepWorldTransform);
				return;
			}

			auto ParentPath = FOmniversePathHelper::KeyToPrimPath(*ParentPathKey);
			if (Prim.IsA<pxr::UsdGeomGprim>() && OmniUsdStageCtrl::IsAncestorGprim(GetUSDStage(), ToUSDPath(*ParentPath)))
			{
				FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot move prim %s to %s as nested gprims are not supported."), *ActorPath, *ParentPath));
				InActor->AttachToActor(const_cast<AActor*>(*OldParent), FAttachmentTransformRules::KeepWorldTransform);
				return;
			}

			// NOTE: Must explicitly call saving here before duplicating layer spec
			SaveChangedUE4Objects();

			auto DestPath = ToUSDPath(*ParentPath).AppendElementToken(Prim.GetName());
			auto DestPathText = DestPath.GetText();
			// There's no move prim API in USD, need to copy the prim then delete prim
			// Copy might be failed because there's no prim or over. we need flat the layer then copy
			OmniUsdStageCtrl::StitchPrimSpecs(Prim, DestPath);
			OmniUsdStageCtrl::RemovePrim(Prim);

			// Change USD registry
			// Find out all changed hierarchy
			TArray<FString> ChangedKeys;
			for(auto Iter : USDPathToObject)
			{
				if (IsSameOrChildPrimPath(ActorPath, Iter.Key))
				{
					ChangedKeys.Add(Iter.Key);
				}
			}

			// Map object to new prim path
			for( auto Key : ChangedKeys )
			{
				auto Path = FOmniversePathHelper::KeyToPrimPath(Key);
				auto Comp = USDPathToObject.Find(Key);
				FString NewPath = DestPathText + Path.RightChop(ActorPath.Len());
				if (Comp)
				{
					USDPathToObject.Add(FOmniversePathHelper::PrimPathToKey(NewPath), *Comp);
				}

				USDPathToObject.Remove(Key);
			}
		}
	}

	DetachActorLists.Remove(InActor);
}

void AOmniverseStageActor::OnObjectPropertyChanged(UObject* Object, FPropertyChangedEvent& PropChangedEvent)
{
	FString Change;
	if(PropChangedEvent.MemberProperty)
	{
		Change = TEXT("Member") / PropChangedEvent.MemberProperty->GetName();
	}

	OnUE4ObjectChanged(*Object, Change);
}

void AOmniverseStageActor::OnActorLabelChanged(AActor * Actor)
{
	if(Actor->GetWorld() != GetWorld())
	{
		return;
	}

	auto ScopeState = SetStateScoped(EState::Saving);
	if(!ScopeState.IsValid())
	{
		return;
	}

	// Handle renaming
	auto* OldPathKey = FindPath((UObject*)Actor->GetRootComponent());
	if(!OldPathKey)
	{
		return;
	}

	FString OldPathStr = FOmniversePathHelper::KeyToPrimPath(*OldPathKey);
	pxr::SdfPath OldPath(ToUSDPath(*OldPathStr));

	// Same name
	if (OldPath.GetName().compare(TCHAR_TO_ANSI(*Actor->GetActorLabel())) == 0)
	{
		return;
	}

	auto Prim = GetUSDStage()->GetPrimAtPath(OldPath);
	if (!Prim)
	{
		return;
	}

	if (OmniUsdStageCtrl::IsAncestralPrim(Prim))
	{
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot rename ancestral prim %s"), *OldPathStr));
		Actor->SetActorLabel(OldPath.GetName().c_str());
		return;
	}

	std::string NewName = pxr::TfMakeValidIdentifier(TCHAR_TO_ANSI(*Actor->GetActorLabel()));

	auto ChangePrimName = [this](const pxr::SdfPath& OldPath, const pxr::TfToken& NewName)
	{
		// Rename in USD
		if (OmniUsdStageCtrl::RenamePrim(GetUSDStage()->GetPrimAtPath(OldPath), NewName))
		{
			// Rename mapping
			auto OldPathMap = USDPathToObject;

			pxr::SdfPath NewPath = OldPath.GetParentPath().AppendElementString(NewName);

			for(auto Pair : OldPathMap)
			{
				pxr::SdfPath Path(ToUSDPath(*FOmniversePathHelper::KeyToPrimPath(Pair.Key)));
				if(Path.HasPrefix(OldPath))
				{
					USDPathToObject.Remove(Pair.Key);
					USDPathToObject.Add(FOmniversePathHelper::PrimPathToKey(Path.ReplacePrefix(OldPath, NewPath).GetText()), Pair.Value);
				}
			}
		}
	};

	ChangePrimName(OldPath, pxr::TfToken(NewName));

	// Transaction
	ScopeState.Reset();

	if(USDTransaction.TransactionObj && GEditor->IsTransactionActive())
	{
		auto Transact = [this, NewName, OldPath, ChangePrimName](UOmniverseTransaction::EUndoType UndoType)
		{
			auto ScopeState = SetStateScoped(EState::Saving);

			switch(UndoType)
			{
			case UOmniverseTransaction::EUndoType::Undo:
				ChangePrimName(OldPath.GetParentPath().AppendElementString(NewName), OldPath.GetNameToken());
				break;
			case UOmniverseTransaction::EUndoType::Redo:
				ChangePrimName(OldPath, pxr::TfToken(NewName));
				break;
			}
		};

		USDTransaction.TransactionObj->AddTransaction(UOmniverseTransaction::FUndoDelegate::CreateWeakLambda(this, Transact));
	}
}

void AOmniverseStageActor::OnAssetEditorRequestedOpen(UObject* Object)
{
	// Create editor data for mesh
	UStaticMesh* Mesh = Cast<UStaticMesh>(Object);
	if(!Mesh)
	{
		return;
	}
	
	for(auto Iterator = USDPathToObject.CreateConstIterator(); Iterator; ++Iterator)
	{
		UStaticMeshComponent* MeshComponent = Cast<UStaticMeshComponent>(Iterator.Value());
		if(!MeshComponent)
		{
			continue;
		}

		if(MeshComponent->GetStaticMesh() != Mesh)
		{
			continue;
		}

		FOmniverseUSDImporterHelper::BuildSourceModel(Mesh);

		return;
	}
}

AActor* AOmniverseStageActor::DuplicateActor(AActor* Actor)
{
	AActor* NewActor = nullptr;
	auto PathKey = FindPath((UObject*)Actor->GetRootComponent());
	if (PathKey)
	{
		auto Prim = GetUSDStage()->GetPrimAtPath(ToUSDPath(*FOmniversePathHelper::KeyToPrimPath(*PathKey)));
		if (!Prim)
		{
			return NewActor;
		}

		bool bValidDuplicate = false;
		pxr::SdfPath ParentUsdPath;
		auto SceneParent = Actor->GetRootComponent()->GetAttachParent();
		if (SceneParent)
		{
			auto ParentPathKey = FindPath((UObject*)SceneParent);
			if (ParentPathKey)
			{
				ParentUsdPath = ToUSDPath(*FOmniversePathHelper::KeyToPrimPath(*ParentPathKey));
				bValidDuplicate = true;
			}
		}
		// It's a defalt prim duplication
		else if (Prim.GetParent().IsPseudoRoot())
		{		
			bValidDuplicate = true;
			ParentUsdPath = pxr::SdfPath::AbsoluteRootPath();
		}

		if (bValidDuplicate)
		{
			FName ActorUniqueName = *Actor->GetActorLabel();
			ActorUniqueName = MakeUniqueObjectName(GetWorld()->GetCurrentLevel(), Actor->GetClass(), ActorUniqueName);
			FActorSpawnParameters SpawnInfo;
			SpawnInfo.Name = ActorUniqueName;
			SpawnInfo.Template = Actor;
			SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			NewActor = GetWorld()->SpawnActor(Actor->GetClass(), nullptr, nullptr, SpawnInfo);
			NewActor->SetActorLabel(NewActor->GetName(), false);
			NewActor->SetActorRelativeTransform(Actor->GetRootComponent()->GetRelativeTransform());

			auto DestPath = ParentUsdPath.AppendElementString(TCHAR_TO_UTF8(*NewActor->GetName()));
			if (OmniUsdStageCtrl::CopyPrim(Prim, DestPath))
			{
				USDPathToObject.Add(FOmniversePathHelper::PrimPathToKey(DestPath.GetText()), NewActor->GetRootComponent());
			}
		}
	}

	return NewActor;
}

static void GetAllAttachedActors( AActor* Actor, TSet< AActor* >& OutActors )
{
	TArray< AActor* > ChildrenActors;
	Actor->GetAttachedActors( ChildrenActors );
	for ( AActor* ChildActor : ChildrenActors )
	{
		OutActors.Add( ChildActor );

		GetAllAttachedActors( ChildActor, OutActors );
	}
}

bool AOmniverseStageActor::HasMixSelection()
{
	TOptional<bool> bIsUsdPrim;
	for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		AActor* Actor = static_cast<AActor*>(*It);
		auto PathKey = FindPath((UObject*)Actor->GetRootComponent());
		if (PathKey)
		{
			if (!bIsUsdPrim.IsSet())
			{
				bIsUsdPrim = true;
			}
			else
			{
				if (!bIsUsdPrim.GetValue())
				{
					return true;
				}
			}
		}
		else
		{
			if (!bIsUsdPrim.IsSet())
			{
				bIsUsdPrim = false;
			}
			else
			{
				if (bIsUsdPrim.GetValue())
				{
					return true;
				}
			}
		}
	}

	return false;
}

void AOmniverseStageActor::StoreSelection()
{
	PreCopySelectActors.Reset();
	for(FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		AActor* Actor = static_cast<AActor*>(*It);		
		PreCopySelectActors.Add(Actor);
	}
}

void AOmniverseStageActor::OnProcessCopy(bool& bResult)
{	
	if (HasMixSelection())
	{
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot copy the mixing usd prim and unreal actor.")));
		// Stop the process
		bResult = true;
	}
	else
	{
		StoreSelection();
		bResult = false;
	}
}

void AOmniverseStageActor::OnProcessCut(bool& bResult)
{
	if (HasMixSelection())
	{
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot cut the mixing usd prim and unreal actor.")));
		// Stop the process
		bResult = true;
	}
	else
	{
		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			AActor* Actor = static_cast<AActor*>(*It);
			auto PathKey = FindPath((UObject*)Actor->GetRootComponent());
			if (PathKey)
			{
				FOmniverseNotificationHelper::NotifyError(TEXT("Cannot cut usd prim"));
				bResult = true;	
			}
			else
			{
				bResult = false;
			}

			return;
		}
	}
}

void AOmniverseStageActor::OnProcessDuplicate(bool& bResult)
{
	if (HasMixSelection())
	{
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Cannot duplicate the mixing usd prim and unreal actor.")));
		// Stop the process
		bResult = true;
	}
	else
	{
		StoreSelection();
		OnProcessPaste(bResult);
	}
}

void AOmniverseStageActor::OnProcessDelete(bool& bResult)
{
	TArray<AActor*> ToDeleteUnrealActor;
	for(FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		AActor* Actor = static_cast<AActor*>(*It);		

		// Validate
		if(GetWorld() != Actor->GetWorld() || State != EState::None)
		{
			continue;
		}

		auto PathKey = FindPath((UObject*)Actor->GetRootComponent());
		if(!PathKey)
		{
			ToDeleteUnrealActor.Add(Actor);
			continue;
		}

		auto Path = FOmniversePathHelper::KeyToPrimPath(*PathKey);
		auto USDPath = ToUSDPath(*Path);

		auto Prim = GetUSDStage()->GetPrimAtPath(USDPath);
		if (Prim)
		{
			const FScopedTransaction Transaction(L"USD Stage", FText::FromString("Delete prim"), USDTransaction.TransactionObj.Get());

			if(GEditor->IsTransactionActive() && !GIsTransacting)
			{
				// Reserve USD state
				auto Layer = GetUSDStage()->GetEditTarget().GetLayer();
				pxr::SdfLayerRefPtr AnonymousLayer = pxr::SdfLayer::CreateAnonymous();
				std::string LayerIdentifier = Layer->GetIdentifier();

				if(Layer->GetPrimAtPath(USDPath))
				{
					pxr::SdfCopySpec(Layer, USDPath, AnonymousLayer, USDPath);
				}

				auto Transact = [this, AnonymousLayer, LayerIdentifier, USDPath](UOmniverseTransaction::EUndoType UndoType)
				{
					switch(UndoType)
					{
					case UOmniverseTransaction::EUndoType::Undo:
					{
						// Revert USD
						OmniUsdStageCtrl::RestorePrim(AnonymousLayer, LayerIdentifier, USDPath);
						break;
					}
					case UOmniverseTransaction::EUndoType::Redo:
						OmniUsdStageCtrl::RemovePrim(GetUSDStage()->GetPrimAtPath(USDPath));
						break;
					}
				};

				if (OmniUsdStageCtrl::RemovePrim(Prim))
				{
					USDTransaction.TransactionObj->AddTransaction(UOmniverseTransaction::FUndoDelegate::CreateWeakLambda(this, Transact));
				}
			}
			else
			{
				// Remove corresponding USD prim
				OmniUsdStageCtrl::RemovePrim(Prim);
			}
		}
	}

	// There're unreal actors need to be deleted
	if (ToDeleteUnrealActor.Num() > 0)
	{
		GEditor->SelectNone(false, true);
		for (auto SelectActor : ToDeleteUnrealActor)
		{
			GEditor->SelectActor(SelectActor, true, false, true);
		}
		bResult = false;
	}
	else
	{
		bResult = true;
	}
}

void AOmniverseStageActor::OnProcessPaste(bool& bResult)
{
	TArray<AActor*> SelectActors;
	for (auto SelectActor : PreCopySelectActors)
	{	
		auto DuplicatedActor = DuplicateActor(SelectActor);
		if (DuplicatedActor)
		{
			SelectActors.Add(DuplicatedActor);
		}
	}

	if (SelectActors.Num() > 0)
	{
		GEditor->SelectNone(false, true);
		for (auto SelectActor : SelectActors)
		{
			GEditor->SelectActor(SelectActor, true, false, true);
		}
		bResult = true;
	}
	else
	{
		bResult = false;
	}
}

void AOmniverseStageActor::OnObjectSelected(UObject* Object)
{
	if(Object->GetWorld() != GetWorld())
	{
		return;
	}

	if(ChangedUE4Objects.Objects.Find(Object))
	{
		return;
	}

	USceneComponent* SceneComp = nullptr;

	auto Actor = Cast<AActor>(Object);
	if(Actor)
	{
		SceneComp = Actor->GetRootComponent();
	}
	else
	{
		SceneComp = Cast<USceneComponent>(Object);
	}

	if(!SceneComp)
	{
		return;
	}

	if(SceneComp->GetAssetUserData<UOmniverseCopyAssetUserData>())
	{
		SceneComp->RemoveUserDataOfClass(UOmniverseCopyAssetUserData::StaticClass());
		GEngine->DelayGarbageCollection();
	}
}

USceneComponent* AOmniverseStageActor::CreateActorAndComponent(UClass& SceneCompClass, UClass& ActorClass, const pxr::UsdPrim& Prim, bool bForceCreateActor)
{
	// Create actor if no parent or is model
	USceneComponent* ParentComp = FindObjectFromPath<USceneComponent>(Prim.GetPath().GetParentPath());

	auto IsModel = [](pxr::UsdPrim Prim)
	{
		pxr::TfToken Kind;
		pxr::UsdModelAPI(Prim).GetKind(&Kind);

		return pxr::KindRegistry::IsA(Kind, pxr::KindTokens->model);
	};

#if 0
	bool bCreateActor = false;
	if(!ParentComp || IsModel(Prim) || bForceCreateActor)
	{
		bCreateActor = true;
	}
	else
	{
		// Still create actor if all ascenders are not model.
		bool bModelParent = false;
		for(auto ParentPrim = Prim.GetParent(); !ParentPrim.IsPseudoRoot(); ParentPrim = ParentPrim.GetParent())
		{
			if(IsModel(ParentPrim))
			{
				bModelParent = true;
				break;
			}
		}

		if(!bModelParent)
		{
			bCreateActor = true;
		}
	}
#else
	bool bCreateActor = true;
#endif

	// Check whether existing object can be reused
	auto SceneComponent = FindObjectFromPath<USceneComponent>(Prim.GetPath());
	do
	{
		if(!SceneComponent)
		{
			break;
		}

		if(bCreateActor)
		{
			if(SceneComponent->GetOwner()->GetRootComponent() != SceneComponent)
			{
				break;
			}

			if(!SceneComponent->GetOwner()->IsA(&ActorClass))
			{
				break;
			}
		}

		if(SceneComponent->GetClass() != &SceneCompClass)
		{
			if(bCreateActor)
			{
				// check children
				for (auto Child : SceneComponent->GetAttachChildren())
				{
					if (Child->GetClass() == &SceneCompClass)
					{
						return Child;
					}
				}
			}

			break;
		}

		if (ParentComp && SceneComponent->GetAttachParent() != ParentComp)
		{
			SceneComponent->AttachToComponent(ParentComp, FAttachmentTransformRules::KeepRelativeTransform);
		}

		return SceneComponent;
	} while(false);

	// Reserve the object
	if(SceneComponent)
	{
		if(SceneComponent->GetOwner()->GetRootComponent() == SceneComponent)
		{
			ReserveObject(*SceneComponent->GetOwner(), Prim.GetPath().GetText());
		}
		else
		{
			ReserveObject(*SceneComponent, Prim.GetPath().GetText());
		}

		USDPathToObject.Remove(FOmniversePathHelper::PrimPathToKey(Prim.GetPath().GetText()));

		SceneComponent = nullptr;
	}

	// Create new object
	if(bCreateActor)
	{
		// Spawn new actor if it's not reserved
		AActor* Actor = nullptr;

		TObjectPtr<UObject> ReservedObject = nullptr;
		ReservedUE4Objects.RemoveAndCopyValue(Prim.GetPath().GetText(), ReservedObject);
		if(ReservedObject && ReservedObject->GetClass() == &ActorClass)
		{
			Actor = Cast<AActor>(ReservedObject);
			// If root component class is different from the target component class, we still need to create a new actor
			if (Actor->GetRootComponent() && Actor->GetRootComponent()->GetClass() != &SceneCompClass)
			{
				Actor = GetWorld()->SpawnActor<AActor>(&ActorClass);
			}
			else
			{
				ReservedObject->ClearGarbage();
				Actor->Rename(nullptr, GetLevel());
			}
		}
		else
		{
			Actor = GetWorld()->SpawnActor<AActor>(&ActorClass);
		}

		// Setup actor
		StaticCast<AOmniverseStageActor*>(Actor)->bEditable = ActorClass.GetDefaultObject<AActor>()->IsEditable();
		GetWorld()->GetCurrentLevel()->Actors.AddUnique(Actor);	// Rename() would automatically add to level

#if WITH_EDITOR
		Actor->SetActorLabel(Prim.GetName().GetText(), false);
#endif

		Actor->Tags.AddUnique(TEXT("SequencerActor"));	// Hack to show transient actors in world outliner

		auto FoundComponentClass = [](AActor* InActor, UClass& InComponentClass)
		{
			if (InActor->GetRootComponent())
			{
				auto Root = InActor->GetRootComponent();
				if (Root->GetClass() == &InComponentClass)
				{
					return true;
				}
				else
				{
					for( auto Child : Root->GetAttachChildren())
					{
						if (Child->GetClass() == &InComponentClass)
						{
							return true;
						}
					}
				}
			}

			return false;
		};

		// root is the target component
		if(FoundComponentClass(Actor, SceneCompClass))
		{
			SceneComponent = Actor->GetRootComponent();
			SceneComponent->ClearGarbage();
			if(SceneComponent->CreationMethod == EComponentCreationMethod::Instance)
			{
				SceneComponent->Rename(ANSI_TO_TCHAR(Prim.GetName().GetText()));
			}
		}
		else
		{
			// Create component
			SceneComponent = NewObject<USceneComponent>(Actor, &SceneCompClass, Prim.GetName().GetText(), DefaultObjFlag);
			Actor->SetRootComponent(SceneComponent);
			Actor->AddInstanceComponent(SceneComponent);
		}

		GEngine->BroadcastLevelActorAdded(Actor);
	}
	else
	{
		auto ExistingObject = FindObject<UObject>(ParentComp, ANSI_TO_TCHAR(Prim.GetName().GetText()));
		if(ExistingObject)
		{
			if(ExistingObject->GetClass() == &SceneCompClass)
			{
				ExistingObject->ClearGarbage();
				SceneComponent = Cast<USceneComponent>(ExistingObject);
			}
			else
			{
				ExistingObject->MarkAsGarbage();
			}
		}

		if(!SceneComponent)
		{
			TObjectPtr<UObject> ReservedObject = nullptr;
			ReservedUE4Objects.RemoveAndCopyValue(Prim.GetPath().GetText(), ReservedObject);
			if(auto Actor = Cast<AActor>(ReservedObject))
			{
				ReservedObject = Actor->GetRootComponent();
			}

			if(ReservedObject && ReservedObject->GetClass() == &SceneCompClass)
			{
				ReservedObject->ClearGarbage();
				SceneComponent = Cast<USceneComponent>(ReservedObject);
				SceneComponent->Rename(ANSI_TO_TCHAR(Prim.GetName().GetText()), ParentComp);
			}
			else
			{
				SceneComponent = NewObject<USceneComponent>(ParentComp, &SceneCompClass, Prim.GetName().GetText(), DefaultObjFlag);
			}
		}

		SceneComponent->GetOwner()->AddInstanceComponent(SceneComponent);

		// UI is not correct if two components have the same name. So we need to rename it if necessary.
		FName NewName = SceneComponent->GetFName();
		bool bSameNameFound = false;

		for(auto Component : SceneComponent->GetOwner()->GetComponents())
		{
			if(Component != SceneComponent && Component->GetFName() == NewName && Component->GetClass() != SceneComponent->GetClass())
			{
				NewName.SetNumber(NewName.GetNumber() + 1);
				bSameNameFound = true;
				break;
			}
		}

		if(bSameNameFound && NewName.GetNumber())
		{
			SceneComponent->Rename(*(NewName.GetPlainNameString() + "(" + FString::FromInt(NewName.GetNumber()) + ")"));
		}
	}

	SceneComponent->SetMobility(EComponentMobility::Movable);	// Static can't be attached under movable

	if(ParentComp)
	{
		SceneComponent->AttachToComponent(ParentComp, FAttachmentTransformRules::KeepRelativeTransform);
	}

	USDPathToObject.Add(FOmniversePathHelper::PrimPathToKey(Prim.GetPath().GetText()), (UObject*)SceneComponent);

	if (bCreateActor)
	{
		if (SceneComponent->GetClass() != &SceneCompClass)
		{
			for (auto Child : SceneComponent->GetAttachChildren())
			{
				if (Child->GetClass() == &SceneCompClass)
				{
					SceneComponent = Child;
					break;
				}
			}
		}
	}

	return SceneComponent;
}

void AOmniverseStageActor::ReserveObject(UObject& Object, const FString& USDPath)
{
	if(auto Actor = Cast<AActor>(&Object))
	{
		{
			// When this is called during transaction, objects are loaded from transaction buffer, objects would have strange state, which causes assertion failure.
			for(auto Component : Actor->GetComponents())
			{
				if(auto SceneComp = Cast<USceneComponent>(Component))
				{
					if(SceneComp->GetOwner() != Actor)
					{
						SceneComp->Rename(nullptr, SceneComp->GetAttachParent());
					}
				}
			}
		}

		Actor->Rename(nullptr, ReservedUE4ObjectOuter);	// Must rename before unregistoring. Otherwise meshes will be still rendered and left in the scene
		checkSlow(Actor->GetLevel());
		if(Actor->GetLevel())
		{
			GetWorld()->RemoveActor(Actor, false);	// Rename() would add actor to level.
			Actor->UnregisterAllComponents();
			Actor->RegisterAllActorTickFunctions(false, true);
		}

		ReservedUE4Objects.Add(USDPath, Actor);
	}
	else if(auto Component = Cast<UActorComponent>(&Object))
	{
		if(Component->IsRegistered())
		{
			Component->UnregisterComponent();
		}
		Component->GetOwner()->RemoveOwnedComponent(Component);
		Component->RegisterAllComponentTickFunctions(false);
		Component->Rename(nullptr, ReservedUE4ObjectOuter);

		ReservedUE4Objects.Add(USDPath, Component);
	}
	else if (auto Material = Cast<UMaterialInterface>(&Object))
	{
		if (!IsValidPrimPath(ToUSDPath(*USDPath)))
		{
			for (UActorComponent* ActorComponent : TObjectRange<UActorComponent>())
			{
				if (ActorComponent->IsA<UMeshComponent>())
				{
					auto MeshComponent = Cast<UMeshComponent>(ActorComponent);

					for (int32 MaterialIndex = 0; MaterialIndex < MeshComponent->GetNumMaterials(); ++MaterialIndex)
					{
						if (MeshComponent->GetMaterial(MaterialIndex) == Material)
						{
							MeshComponent->SetMaterial(MaterialIndex, nullptr);
						}
					}
				}
			}

			Material->MarkAsGarbage();
		}
	}
}

bool AOmniverseStageActor::ShouldLoadProperty(const pxr::SdfPath& Path, const pxr::TfTokenVector& PropNames, const pxr::TfTokenVector& ExcludedPropNames)
{
	if(!Path.IsPropertyPath())
	{
		return true;
	}

	return std::find(PropNames.begin(), PropNames.end(), Path.GetNameToken()) != PropNames.end() && std::find(ExcludedPropNames.begin(), ExcludedPropNames.end(), Path.GetNameToken()) == ExcludedPropNames.end();
}

void AOmniverseStageActor::LoadMaterial(UMeshComponent* Component, int32 SlotIndex, const pxr::UsdGeomMesh& USDMesh, const pxr::UsdShadeShader& Shader, const pxr::UsdShadeShader& MdlShader)
{
	if (GetDefault<UOmniverseSettings>()->bDisableMaterialLoading)
	{
		return;
	}

	if (Shader || MdlShader)
	{
		auto LoadMaterialByShaderID = [&](const pxr::UsdShadeShader& ShadeShader)
		{
			if (!ShadeShader)
			{
				return false;
			}

			const auto ShaderID = GetUSDValue<pxr::TfToken>(ShadeShader.GetIdAttr());
			if (ShaderID == USDTokens.mdlMaterial && LoadOldMdlSchema(Component, SlotIndex, ShadeShader))	// MDL
			{
				return true;
			}
			else if (ShaderID == USDTokens.previewSurface && LoadPreviewSurface(Component, SlotIndex, USDMesh, ShadeShader))
			{
				return true;
			}

			return false;
		};

		auto USDMaterial = Shader ? FindShadeMaterial(Shader.GetPrim()) : FindShadeMaterial(MdlShader.GetPrim());
		if (USDMaterial && FOmniverseReferenceCollector::Get().FindDependency(USDMaterial.GetPath().GetText()))
		{
			FString Name = USDMaterial.GetPrim().GetName().GetText();
			FString Text = FString::Printf(TEXT("Loading Material %s..."), *Name);
			FOmniverseSlowTask::Get().UpdateProgress(1.0, FText::FromString(Text));
		}

		const bool bRenderMDLPriority = GetDefault<UOmniverseSettings>()->RenderContext == ERenderContext::ERC_MDL;
		if (bRenderMDLPriority)
		{
			// try mdl surface output at first
			if (!LoadMdlSchema(Component, SlotIndex, MdlShader))
			{
				// try surface output with mdl schema
				if (!LoadMdlSchema(Component, SlotIndex, Shader))
				{
					if (!LoadMaterialByShaderID(MdlShader))
					{
						LoadMaterialByShaderID(Shader);
					}
				}
			}
		}
		else
		{
			if (!LoadMaterialByShaderID(Shader))
			{
				if (!LoadMaterialByShaderID(MdlShader))
				{
					if (!LoadMdlSchema(Component, SlotIndex, Shader))
					{
						// try mdl surface output at last
						LoadMdlSchema(Component, SlotIndex, MdlShader);
					}
				}
			}
		}
	}
}

void AOmniverseStageActor::LoadMaterial(UStaticMeshComponent& Component, const pxr::UsdGeomGprim& USDGprim, pxr::UsdGeomSubset InGeomSubset)
{
	// Collect material bindings
	TArray<FUSDConversion::FMaterialBinding> MaterialBindings;

	pxr::UsdGeomMesh USDMesh(USDGprim);

	auto USDGeomSubsets = pxr::UsdGeomSubset::GetAllGeomSubsets(USDMesh);
	if(!USDGeomSubsets.empty())
	{
		for (auto GeomSubset : USDGeomSubsets)
		{
			pxr::TfToken FamilyName;
			if (!GeomSubset.GetFamilyNameAttr().Get(&FamilyName) || FamilyName != pxr::UsdShadeTokens->materialBind)
			{
				// Add warning instead of not loading material
				UE_LOG(LogOmniverseUsd, Warning, L"%s: Material bindings authored on GeomSubsets are honored by renderers only if their familyName is UsdShadeTokens->materialBind", *FString(GeomSubset.GetPath().GetText()));
			}

			MaterialBindings.Add(FUSDConversion::ParsePrimMaterial(GeomSubset.GetPrim()));
		}
	}
	else
	{
		MaterialBindings.Add(FUSDConversion::ParsePrimMaterial(USDMesh.GetPrim()));
	}

	// Add material slots
	if(!Component.GetStaticMesh())
	{
		return;
	}

	if(Component.GetStaticMesh()->GetStaticMaterials().Num() < MaterialBindings.Num())
	{
		Component.GetStaticMesh()->GetStaticMaterials().SetNum(MaterialBindings.Num());
		Component.GetStaticMesh()->UpdateUVChannelData(false);
	}

	// Reset material to default value first, so after layer is muted,
	// The reference material will be calculated again or it's removed.
	if(!InGeomSubset)
	{
		Component.EmptyOverrideMaterials();
	}

	// Load each material binding
	for(auto SlotIndex = 0; SlotIndex < MaterialBindings.Num(); ++SlotIndex)
	{
		// Skip
		if(InGeomSubset && InGeomSubset.GetPrim() != USDGeomSubsets[SlotIndex].GetPrim())
		{
			continue;
		}

		// Clear current material
		Component.SetMaterial(SlotIndex, nullptr);

		//Get shader
		auto& MaterialBinding = MaterialBindings[SlotIndex];
		LoadMaterial(&Component, SlotIndex, USDMesh, MaterialBinding.Shader, MaterialBinding.MdlSurfaceShader);
	}
}

UStaticMeshComponent* AOmniverseStageActor::LoadBasicShape(const pxr::SdfPath& Path, bool bLoadChildren)
{
	pxr::UsdGeomGprim USDGprim = pxr::UsdGeomGprim::Get(GetUSDStage(), Path.GetPrimPath());
	if(!USDGprim)
	{
		return nullptr;
	}

	FString MeshPath;
	TFunction<void(UStaticMeshComponent&)> PostCreateComponent;

	auto ShouldLoadTransform = [&](const pxr::TfTokenVector& PropNames)
	{
		if(!ShouldLoadProperty(Path, PropNames) 
			&& Path.IsPropertyPath() && !pxr::UsdGeomXformOp::IsXformOp(Path.GetNameToken())
			)
		{
			return false;
		}

		LoadSceneComponent(Path.GetPrimPath().AppendProperty(pxr::UsdGeomXformOp::GetOpName(pxr::UsdGeomXformOp::TypeScale)), bLoadChildren);

		return true;
	};

	auto SetRotateAndScaleWithAxis = [USDGprim](const pxr::TfToken& MeshAxis, USceneComponent& SceneComp)
	{
		FVector Scale = SceneComp.GetRelativeScale3D();
		auto UpAxis = pxr::UsdGeomGetStageUpAxis(USDGprim.GetPrim().GetStage());
		if(MeshAxis == pxr::UsdGeomTokens->x)
		{
			SceneComp.SetRelativeRotation(SceneComp.GetRelativeTransform().GetRotation() * FQuat(FVector(0, 1, 0), HALF_PI));
			// swap x and z
			Swap(Scale.X, Scale.Z);
		}
		else if(MeshAxis == pxr::UsdGeomTokens->y && UpAxis == pxr::UsdGeomTokens->z)
		{
			SceneComp.SetRelativeRotation(SceneComp.GetRelativeTransform().GetRotation() * FQuat(FVector(1, 0, 0), HALF_PI));
			// swap y and z
			Swap(Scale.Y, Scale.Z);
		}
		else if (MeshAxis == pxr::UsdGeomTokens->z && UpAxis == pxr::UsdGeomTokens->y)
		{
			SceneComp.SetRelativeRotation(SceneComp.GetRelativeTransform().GetRotation() * FQuat(FVector(1, 0, 0), -HALF_PI));
			// swap y and z
			Swap(Scale.Y, Scale.Z);
		}

		SceneComp.SetRelativeScale3D(Scale);
	};

	float UnitScale = UnitScaleFromUSDToUE(GetUSDStage()) * 0.01f;

	if(auto USDSphere = pxr::UsdGeomSphere(USDGprim))
	{
		MeshPath = UActorFactoryBasicShape::BasicSphere.ToString();

		PostCreateComponent = [=](UStaticMeshComponent& MeshComp)
		{
			if(ShouldLoadTransform({pxr::UsdGeomTokens->radius}))
			{
				float Radius = GetUSDValue<double>(USDSphere.GetRadiusAttr());
				MeshComp.SetRelativeScale3D(MeshComp.GetRelativeScale3D() * FVector(Radius * 2.0f * UnitScale));
			}
		};
	}
	else if(auto USDCube = pxr::UsdGeomCube(USDGprim))
	{
		MeshPath = UActorFactoryBasicShape::BasicCube.ToString();

		PostCreateComponent = [=](UStaticMeshComponent& MeshComp)
		{
			if(ShouldLoadTransform({pxr::UsdGeomTokens->size}))
			{
				float Size = GetUSDValue<double>(USDCube.GetSizeAttr());
				MeshComp.SetRelativeScale3D(MeshComp.GetRelativeScale3D() * FVector(Size * UnitScale));
			}
		};
	}
	else if(auto USDCone = pxr::UsdGeomCone(USDGprim))
	{
		MeshPath = UActorFactoryBasicShape::BasicCone.ToString();

		PostCreateComponent = [=](UStaticMeshComponent& MeshComp)
		{
			if(ShouldLoadTransform({pxr::UsdGeomTokens->radius, pxr::UsdGeomTokens->height, pxr::UsdGeomTokens->axis}))
			{
				float Radius = GetUSDValue<double>(USDCone.GetRadiusAttr());
				float Height = GetUSDValue<double>(USDCone.GetHeightAttr());
				SetRotateAndScaleWithAxis(GetUSDValue<pxr::TfToken>(USDCone.GetAxisAttr()), MeshComp);
				MeshComp.SetRelativeScale3D(MeshComp.GetRelativeScale3D() * FVector(Radius * 2, Radius * 2, Height) * UnitScale);
			}
		};
	}
	else if(auto USDCylinder = pxr::UsdGeomCylinder(USDGprim))
	{
		MeshPath = UActorFactoryBasicShape::BasicCylinder.ToString();

		PostCreateComponent = [=](UStaticMeshComponent& MeshComp)
		{
			if(ShouldLoadTransform({pxr::UsdGeomTokens->radius, pxr::UsdGeomTokens->height, pxr::UsdGeomTokens->axis}))
			{
				float Radius = GetUSDValue<double>(USDCylinder.GetRadiusAttr());
				float Height = GetUSDValue<double>(USDCylinder.GetHeightAttr());
				SetRotateAndScaleWithAxis(GetUSDValue<pxr::TfToken>(USDCylinder.GetAxisAttr()), MeshComp);
				MeshComp.SetRelativeScale3D(MeshComp.GetRelativeScale3D() * FVector(Radius * 2, Radius * 2, Height) * UnitScale);
			}
		};
	}
	else if (auto USDCapsule = pxr::UsdGeomCapsule(USDGprim))
	{
		MeshPath = TEXT("/Omniverse/Capsule.Capsule");

		PostCreateComponent = [=](UStaticMeshComponent& MeshComp)
		{
			if (ShouldLoadTransform({ pxr::UsdGeomTokens->radius, pxr::UsdGeomTokens->height, pxr::UsdGeomTokens->axis }))
			{
				float Radius = GetUSDValue<double>(USDCapsule.GetRadiusAttr());
				float Height = GetUSDValue<double>(USDCapsule.GetHeightAttr());
				SetRotateAndScaleWithAxis(GetUSDValue<pxr::TfToken>(USDCapsule.GetAxisAttr()), MeshComp);
				MeshComp.SetRelativeScale3D(MeshComp.GetRelativeScale3D() * FVector(Radius * 4, Radius * 4, Height * 2) * UnitScale);
			}
		};
	}
	else
	{
		// Not implemented BasicShape
		return nullptr;
	}

	auto MeshComp = CreateActorAndComponent<UStaticMeshComponent, AStaticMeshActor>(USDGprim.GetPrim());
	if(!MeshComp)
	{
		return nullptr;
	}

	if(Path.IsPrimPath())
	{
		if(MeshPath.IsEmpty())
		{
			return nullptr;
		}

		auto StaticMesh = LoadObject<UStaticMesh>(NULL, *MeshPath);
		MeshComp->SetStaticMesh(DuplicateObject<UStaticMesh>(StaticMesh, nullptr));
	}

	LoadStaticMeshFromGeomGprim(Path, *MeshComp, bLoadChildren);

	if(PostCreateComponent)
	{
		PostCreateComponent(*MeshComp);

		// if no usd material was set, setting Omniverse Default material instead of UE4 default material
		if (MeshComp->GetNumOverrideMaterials() == 0 || MeshComp->OverrideMaterials[0] == nullptr)
		{
			if (UMaterial* DefaultMaterial = LoadObject<UMaterial>(nullptr, *OmniverseDefaultMaterial))
			{
				MeshComp->SetMaterial(0, DefaultMaterial);
			}
		}
	}

	return MeshComp;
}

USceneComponent * AOmniverseStageActor::LoadSceneComponent(const pxr::SdfPath& Path, bool bLoadChildren)
{
	bool ShouldLoadChildren = bLoadChildren && Path.IsAbsoluteRootOrPrimPath();
	USceneComponent* SceneComponent = FindObjectFromPath<USceneComponent>(Path.GetPrimPath());
	auto USDPrim = GetUSDStage()->GetPrimAtPath(Path.GetPrimPath());
	if (!USDPrim)
	{
		return nullptr;
	}

	if(!SceneComponent)
	{
		SceneComponent = CreateActorAndComponent<USceneComponent, AActor>(USDPrim);
	}
	else
	{
		USceneComponent* ParentComp = FindObjectFromPath<USceneComponent>(Path.GetPrimPath().GetParentPath());
		if (ParentComp && SceneComponent->GetAttachParent() != ParentComp)
		{
			SceneComponent->AttachToComponent(ParentComp, FAttachmentTransformRules::KeepRelativeTransform);
		}
	}

	if(!SceneComponent)
	{
		return SceneComponent;
	}

	// Lock the actor if it's a descendent of an instance prim or scope
	// NOTE: UE4 has nothing similar to USD Scope, we used a actor which locks location to represent
	if (SceneComponent->GetOwner())
	{
		SceneComponent->GetOwner()->SetLockLocation(USDPrim.IsInstanceProxy() || USDPrim.IsA<pxr::UsdGeomScope>());
	}

	// Setup new create component
	if(Path.IsPrimPath())
	{
		// Monitor transform
		SceneComponent->TransformUpdated.RemoveAll(this);
		SceneComponent->TransformUpdated.AddUObject(this, &AOmniverseStageActor::OnSceneComponentTransformChanged);

		// Set mobility
		SceneComponent->SetMobility(EComponentMobility::Movable);

		// Register component
		if(!SceneComponent->IsRegistered())
		{
			// bEnableTraceCollision was changed from boolean to uint8:1, can't use swap anymore 
			bool bBackupValue = GetWorld()->bEnableTraceCollision;
			GetWorld()->bEnableTraceCollision = false; // Disable PhysX setup to boost mesh importing

			SceneComponent->RegisterComponent();

			GetWorld()->bEnableTraceCollision = bBackupValue;
		}
	}

	// Transform
	auto USDXform = pxr::UsdGeomXformable::Get(GetUSDStage(), Path.GetPrimPath());
	if(USDXform)
	{
		auto FixPrimaryAxis = [](const pxr::UsdPrim& Prim, USceneComponent* Component, FTransform& Transform)
		{
			bool bFixCamera = false;
			// Do not fix the axis on the camera component, it's easy to have the gimbal lock when pilot the camera
			if (Component->GetOwner() && (Component->GetOwner()->IsA<ACineCameraActor>() || Component->GetOwner()->IsA<ACameraActor>()))
			{
				auto RootComponent = Component->GetOwner()->GetRootComponent();
				bFixCamera = RootComponent == Component;
			}

			auto ParentComponent = Component->GetAttachParent();
			if (ParentComponent && ParentComponent->GetOwner() 
				&& (ParentComponent->GetOwner()->IsA<ACineCameraActor>() 
					|| ParentComponent->GetOwner()->IsA<ACameraActor>()
					|| ParentComponent->GetOwner()->IsA<ADirectionalLight>()
					|| ParentComponent->GetOwner()->IsA<ASpotLight>()
					|| ParentComponent->GetOwner()->IsA<APointLight>()
					|| ParentComponent->GetOwner()->IsA<ARectLight>()))
			{
				if (ParentComponent->GetOwner()->GetRootComponent() == ParentComponent)
				{
					// The actors are attached to the camera/light which is transformed from USD to UE camera/light coord system
					// So they should be inversed
					if (GetUSDStageAxis(Prim.GetStage()) == pxr::UsdGeomTokens->z)
					{
						Transform = Transform * FTransform(FQuat(FVector(0, 0, 1), HALF_PI)) * FTransform(FQuat(FVector(0, 1, 0), -HALF_PI));
					}
					else
					{
						Transform = Transform * FTransform(FQuat(FVector(0, 0, 1), HALF_PI));
					}
				}
			}

			if (bFixCamera || Component->IsA<ULightComponent>())
			{
				// convert from usd camera (-z and y-up) to UE4 camera (+x and z-up)
				// convert from usd light (-z) to UE4 light (+x)
				// convert from Width of USD in the local X axis to Width of UE4, in the local Y axis.
				if (GetUSDStageAxis(Prim.GetStage()) == pxr::UsdGeomTokens->z)
				{
					Transform.SetRotation(Transform.GetRotation() * FQuat(FVector(0, 0, 1), -HALF_PI) * FQuat(FVector(0, 1, 0), HALF_PI));
				}
				else
				{
					Transform.SetRotation(Transform.GetRotation() * FQuat(FVector(0, 0, 1), -HALF_PI));
				}
			}
			else if (Component->IsA<UMeshComponent>())
			{
				if (GetUSDStageAxis(Prim.GetStage()) == pxr::UsdGeomTokens->y)
				{
					auto MeshComponent = Cast<UMeshComponent>(Component);
					if (IsSphericalOrCylindricalProjectionUsed(MeshComponent))
					{
						Transform.SetRotation(Transform.GetRotation() * FQuat(FVector(1, 0, 0), -HALF_PI));
					}
				}
			}

			if (Prim.IsA<pxr::UsdLuxDomeLight>())
			{
				// NOTE: location and scale do nothing on Dome light, we should reset them for UE4 sky sphere
				Transform.SetLocation(FVector::ZeroVector);
				Transform.SetScale3D(FVector::OneVector);

				// Rotate for Y-up dome light
				if (GetUSDStageAxis(Prim.GetStage()) == pxr::UsdGeomTokens->y)
				{
					Transform.SetRotation(Transform.GetRotation() * FQuat(FVector(1, 0, 0), -HALF_PI));
				}
			}
		};

		auto GetPrimTransform = [&](USceneComponent* Component, FTransform& Transform, const pxr::UsdTimeCode& TimeCode)
		{
			auto UsdPrim = USDXform.GetPrim();
			Transform = ConvertRelativeTransformFromUSDToUE4(UsdPrim, TimeCode);
			FixPrimaryAxis(UsdPrim, Component, Transform);

			if (!ShouldLoadChildren)
			{
				auto CurrentPrimPath = Path.GetPrimPath();
				for(auto Iter : USDPathToObject)
				{
					auto UsdPrimPath = pxr::SdfPath(TCHAR_TO_ANSI(*FOmniversePathHelper::KeyToPrimPath(Iter.Key)));
					if (UsdPrimPath.GetParentPath() == CurrentPrimPath)
					{
						USceneComponent* ChildComponent = FindObjectFromPath<USceneComponent>(UsdPrimPath);
						if (ChildComponent)
						{
							auto ChildPrim = GetUSDStage()->GetPrimAtPath(UsdPrimPath);
							if (ChildPrim)
							{
								auto ChildTransform = ConvertRelativeTransformFromUSDToUE4(ChildPrim, TimeCode);
								FixPrimaryAxis(ChildPrim, ChildComponent, ChildTransform);
								ChildComponent->SetRelativeTransform(ChildTransform);
							}
						}
					}
				}
			}
		};

		if (!Path.IsPropertyPath() || pxr::UsdGeomXformOp::IsXformOp(Path.GetNameToken()))
		{
			// Set transform
			std::vector<double> TimeSamples;
			USDXform.GetTimeSamples(&TimeSamples);

			if (TimeSamples.size() > 0)
			{
				FTransformTimeSamples TransformSamples;
				TransformSamples.Transform.Reserve(TimeSamples.size());

				for (double TimeCode = TimeSamples.front(); TimeCode <= TimeSamples.back(); TimeCode += 1.0)
				{
					FTransform Transform;
					GetPrimTransform(SceneComponent, Transform, pxr::UsdTimeCode(TimeCode));
					TransformSamples.Transform.Add(TimeCode, Transform);
				}

				SceneComponent->SetRelativeTransform(TransformSamples.Transform[TimeSamples[0]]);
				USDSequenceImporter->CreateTransformTrack(SceneComponent == SceneComponent->GetOwner()->GetRootComponent() ? Cast<UObject>(SceneComponent->GetOwner()) : Cast<UObject>(SceneComponent), TransformSamples);
			}
			else
			{
				FTransform Transform;
				GetPrimTransform(SceneComponent, Transform, StageTimeCode);
				SceneComponent->SetRelativeTransform(Transform);
			}
		}
	}

	// Visibility
	pxr::UsdGeomImageable USDImageable(USDPrim);
	if(USDImageable && ShouldLoadProperty(Path, {pxr::UsdGeomTokens->visibility}))
	{
		auto IsInherited = [](const pxr::UsdPrim& Prim)
		{
			pxr::UsdGeomImageable USDImageable(Prim);
			if (USDImageable)
			{
				if (USDImageable.ComputePurpose() == pxr::UsdGeomTokens->guide)
				{
					return false;
				}

				std::vector<double> TimeSamples;
				USDImageable.GetVisibilityAttr().GetTimeSamples(&TimeSamples);

				if (TimeSamples.size() > 0) // ignore the prim with timesamples
				{
					return false;
				}

				pxr::TfToken VisibilityValue;
				USDImageable.GetVisibilityAttr().Get(&VisibilityValue);

				return VisibilityValue != pxr::UsdGeomTokens->invisible; // ignore the prim which is invisible
			}

			return false;
		};

		TFunction<void(USceneComponent&, const pxr::UsdPrim&, const FBooleanTimeSamples&)> CreateVisibilityTrack;
		CreateVisibilityTrack = [this, &CreateVisibilityTrack, &IsInherited](USceneComponent& Comp, const pxr::UsdPrim& USDPrim, const FBooleanTimeSamples& VisTimeSamples)
		{
			USDSequenceImporter->CreateVisibilityTrack(&Comp == Comp.GetOwner()->GetRootComponent() ? Cast<UObject>(Comp.GetOwner()) : Cast<UObject>(&Comp), VisTimeSamples);

			for (auto ChildPrim : USDPrim.GetChildren())
			{
				if (!IsInherited(ChildPrim))
				{
					continue;
				}

				USceneComponent* ChildComp = FindObjectFromPath<USceneComponent>(ChildPrim.GetPath());
				if (!ChildComp)
				{
					continue;
				}

				CreateVisibilityTrack(*ChildComp, ChildPrim, VisTimeSamples);
			}
		};

		auto GetVisTimeSamples = [](const pxr::UsdGeomImageable& Imageable, FBooleanTimeSamples& VisibilityTimeSamples)
		{
			std::vector<double> TimeSamples;
			Imageable.GetVisibilityAttr().GetTimeSamples(&TimeSamples);
			if (TimeSamples.size() > 0)
			{
				VisibilityTimeSamples.TimeSamples.Reserve(TimeSamples.size());

				for (auto TimeCode : TimeSamples)
				{
					pxr::TfToken Value;
					Imageable.GetVisibilityAttr().Get(&Value, pxr::UsdTimeCode(TimeCode));
					VisibilityTimeSamples.TimeSamples.Add(TimeCode, Value == pxr::TfToken("invisible") ? false : true);
				}

				return true;
			}

			return false;
		};

		FBooleanTimeSamples VisibilityTimeSamples;
		if (GetVisTimeSamples(USDImageable, VisibilityTimeSamples))
		{
			CreateVisibilityTrack(*SceneComponent, USDPrim, VisibilityTimeSamples);
		}
		else
		{
			TFunction<void(USceneComponent&, const pxr::UsdPrim&, const bool bVisible)> SetVisibility;
			SetVisibility = [this, &SetVisibility, &IsInherited](USceneComponent& SceneComp, const pxr::UsdPrim& USDPrim, const bool bVisible)
			{
				if (SceneComp.ShouldRender() != bVisible)
				{
					SceneComp.SetVisibility(bVisible);
					SceneComp.SetHiddenInGame(false);

					if (SceneComp.GetOwner()->GetRootComponent() == &SceneComp)
					{
						SceneComp.GetOwner()->SetActorHiddenInGame(false);
						SceneComp.GetOwner()->SetIsTemporarilyHiddenInEditor(!bVisible);
					}
				}

				for (auto ChildPrim : USDPrim.GetChildren())
				{
					if (!IsInherited(ChildPrim))
					{
						continue;
					}
					
					USceneComponent* ChildComp = FindObjectFromPath<USceneComponent>(ChildPrim.GetPath());
					if (!ChildComp)
					{
						continue;
					}

					SetVisibility(*ChildComp, ChildPrim, bVisible);
				}
			};

			
			if (!IsInherited(USDPrim))
			{
				SetVisibility(*SceneComponent, USDPrim, false);
			}
			else
			{
				if (USDPrim.GetParent())
				{
					// check if parent has sequence
					pxr::UsdPrim PrimWithSamples;
					auto Prim = USDPrim.GetParent();
					while (Prim)
					{
						pxr::UsdGeomImageable Imageable(Prim);
						if (!Imageable)
						{
							break;
						}

						if (Imageable.ComputePurpose() == pxr::UsdGeomTokens->guide)
						{
							break;
						}

						pxr::TfToken Value;
						Imageable.GetVisibilityAttr().Get(&Value);
						if (Value == pxr::UsdGeomTokens->invisible)
						{
							break;
						}

						std::vector<double> TimeSamples;
						Imageable.GetVisibilityAttr().GetTimeSamples(&TimeSamples);
						if (TimeSamples.size() > 0)
						{
							PrimWithSamples = Prim;
							break;
						}
						else
						{
							Prim = Prim.GetParent();
						}
					}

					if (PrimWithSamples) // found the parent with vis time samples
					{
						pxr::UsdGeomImageable Imageable(PrimWithSamples);
						FBooleanTimeSamples VisTimeSamples;
						if (GetVisTimeSamples(Imageable, VisTimeSamples))
						{
							CreateVisibilityTrack(*SceneComponent, USDPrim, VisTimeSamples);
						}
					}
					else
					{
						// inherit from parent
						USceneComponent* Comp = USDPrim.GetParent() ? FindObjectFromPath<USceneComponent>(USDPrim.GetParent().GetPath()) : nullptr;
						SetVisibility(*SceneComponent, USDPrim, Comp ? Comp->ShouldRender() : true /*if no parent, inherit means visible*/);
					}
				}
				else // Root - always visible
				{
					SetVisibility(*SceneComponent, USDPrim, true);
				}
			}
		}
	}

	// Load descendant
	if(ShouldLoadChildren)
	{
		auto ChildPrims = USDPrim.GetFilteredChildren(pxr::UsdTraverseInstanceProxies());
		for(auto ChildPrim : ChildPrims)
		{
			LoadUSD(ChildPrim.GetPath(), bLoadChildren);
		}
	}

	return SceneComponent;
}

void AOmniverseStageActor::LoadDefaultPrim()
{
	auto DefaultPrim = GetUSDStage()->GetDefaultPrim();
	if(!DefaultPrim)
	{
		USDDefaultPrim = nullptr;
		return;
	}

	auto SceneComp = FindObjectFromPath<USceneComponent>(DefaultPrim.GetPath());
	if(!SceneComp)
	{
		return;
	}

	if(SceneComp->GetOwner()->GetRootComponent() != SceneComp)
	{
		return;
	}

	USDDefaultPrim = SceneComp->GetOwner();
}

void AOmniverseStageActor::SaveUSD(UObject& ChangedObject, const TArray<FString>& Changes)
{
	auto StateScoped = SetStateScoped(EState::Saving);
	if(!StateScoped.IsValid())
	{
		return;
	}

	// Deal with actor
	if(auto Actor = Cast<AActor>(&ChangedObject))
	{
		if(Changes.Find("") >= 0 && Actor->GetRootComponent())
		{
			SaveUSD(*Actor->GetRootComponent(), {""});
			return;
		}
	}

	// Export
	FUSDExporter Exporter;
	Exporter.Stage = GetUSDStage();
	Exporter.Changes = Changes;
	Exporter.TimeCode = StageTimeCode;
	Exporter.PathToObject = MoveTemp(USDPathToObject);

	Exporter.CustomExport = [&](USceneComponent& SceneComp, bool& bContinue)
	{
		// Skip some components
		if(SceneComp.bIsEditorOnly || !IsComponentSupported(SceneComp))
		{
			bContinue = false;
			return pxr::UsdGeomXformable();
		}

		// Monitor transform change
		SceneComp.TransformUpdated.RemoveAll(this);
		SceneComp.TransformUpdated.AddUObject(this, &AOmniverseStageActor::OnSceneComponentTransformChanged);

		// Move under default prim
		// NOTE: Don't use USDPathToObject inside CustomExport since it was swapped with Exporter.PathToObject
		if(bAutoAttach && USDDefaultPrim && USDDefaultPrim->GetRootComponent() && !SceneComp.GetAttachParent() && !Exporter.FindPath((UObject*)&SceneComp))
		{
			SceneComp.SetMobility(EComponentMobility::Movable);
			SceneComp.AttachToComponent(USDDefaultPrim->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);

			auto DefaultPrim = GetUSDStage()->GetDefaultPrim();
			if(SceneComp.GetOwner()->GetRootComponent() == &SceneComp && DefaultPrim && !DefaultPrim.IsModel())
			{
				pxr::UsdModelAPI(DefaultPrim).SetKind(pxr::KindTokens->assembly);
			}
		}

		return pxr::UsdGeomXformable();
	};

	if(auto SceneComp = Cast<USceneComponent>(&ChangedObject))
	{
		Exporter.ExportSceneObject(*SceneComp);
	}
	else if(auto MaterialInstance = Cast<UMaterialInstance>(&ChangedObject))
	{
		Exporter.ExportMaterialInstance(*MaterialInstance);
	}

	USDPathToObject = MoveTemp(Exporter.PathToObject);

	// Deal with reload
	if(Exporter.ReloadPaths.Num())
	{
		EState OldState = State;
		State = EState::Loading;

		for(auto& Path : Exporter.ReloadPaths)
		{
			OnUSDStageNotice(ToUSDPath(*Path), false);
		}

		State = OldState;
	}

	// Notify layer editor
	if(auto PathKey = FindPath((UObject*)&ChangedObject))
	{
		USD->GetLayerDataSource()->NotifyPrimChange(FOmniversePathHelper::KeyToPrimPath(*PathKey));
	}
}

void AOmniverseStageActor::SaveChangedUE4Objects()
{
	auto StateScoped = SetStateScoped(EState::Saving);
	if(!StateScoped.IsValid())
	{
		return;
	}

	// To support objects that may need to perpetually schedule an update, clear the current set now and operate on a copy 
	//  for the remainder of the function. 
	ChangedUE4ObjectSet::ObjectMap ChangedUE4ObjectsThisFrame = ChangedUE4Objects.Objects;
	FCoreDelegates::OnBeginFrame.Remove(ChangedUE4Objects.DelegateHandle);
	ChangedUE4Objects.DelegateHandle.Reset();
	ChangedUE4Objects.Objects.Reset();

	if(!USD || !GetUSDStage())
	{
		return;
	}

	// Prepare the object list
	struct FChangedObj
	{
		UObject* Object;
		TArray<FString> Changes;
	};

	TArray<FChangedObj> ChangedObjs;

	auto IsObjFullyRefreshed = [&](UObject* Object)
	{
		auto Changes = ChangedUE4ObjectsThisFrame.Find(Object);
		if(!Changes)
		{
			return false;
		}

		return Changes->Find("") >= 0;
	};

	for(auto ChangedObj : ChangedUE4ObjectsThisFrame)
	{
		if(!ChangedObj.Key.IsValid())
		{
			continue;
		}

		// Do not add component if the actor is fully refreshed
		if(auto Component = Cast<UActorComponent>(ChangedObj.Key))
		{
			if(Component->GetWorld() != GetWorld())
			{
				continue;
			}

			if(IsObjFullyRefreshed(Component->GetOwner()))
			{
				continue;
			}
		}

		// Just add it if it's not a scene node
		USceneComponent* SceneComponent = Cast<USceneComponent>(ChangedObj.Key);
		if(!SceneComponent)
		{
			ChangedObjs.Add({ChangedObj.Key.Get(), ChangedObj.Value});
			continue;
		}

		// For scene node, add it only when its parent are not fully refreshed
		TArray<USceneComponent*> Parents;
		SceneComponent->GetParentComponents(Parents);

		bool bAddedParent = false;
		for(auto* Parent : Parents)
		{
			if(IsObjFullyRefreshed(Parent) || IsObjFullyRefreshed(Parent->GetOwner()))
			{
				bAddedParent = true;
				break;
			}
		}

		if(!bAddedParent)
		{
			ChangedObjs.Add({ChangedObj.Key.Get(), ChangedObj.Value});
		}
	}

	ChangedObjs.Sort(
		[](auto& Left, auto& Right)
		{
			// Other < scene node < actor
			auto GetOrder = [](auto& ChangedObj)
			{
				if(ChangedObj.Object->IsA<AActor>())
				{
					return 2;
				}
				else if(ChangedObj.Object->IsA<USceneComponent>())
				{
					return 1;
				}
				else
				{
					return 0;
				}
			};

			return GetOrder(Left) < GetOrder(Right);
		}
	);

	// Prepare transaction
	struct FTransactionUSDReceiver: public pxr::TfWeakBase
	{
		void HandleNotice(const pxr::SdfNotice::LayersDidChangeSentPerLayer& LayerNotice, const pxr::TfWeakPtr<pxr::SdfLayer>& Sender)
		{
			auto Iter = LayerNotice.find(Sender);
			for(auto& Entry : Iter->second.GetEntryList())
			{
#if UE_BUILD_DEBUG
				const FString PathText = Entry.first.GetText();
#endif

				auto& flags = Entry.second.flags;
				if(flags.didAddInertPrim || flags.didAddNonInertPrim || flags.didAddPropertyWithOnlyRequiredFields || flags.didAddProperty)
				{
					TransactionData->AddedSpecs.AddUnique(Entry.first);
				}
			}
		}

		FUSDTransactionData* TransactionData = nullptr;
	};

	FTransactionUSDReceiver TransactionUSDReceiver;

	if(USDTransaction.TransactionData.IsValid())
	{
		// Reserve UE4 changes
		auto& TransactionData = *USDTransaction.TransactionData;

		for(auto& ChangedObj : ChangedObjs)
		{
			auto& Changes = TransactionData.UE4Changes.FindOrAdd(ChangedObj.Object->GetPathName());

			for(auto& Change : ChangedObj.Changes)
			{
				Changes.Add(Change);
			}
		}

		// Reserve USD changes
		pxr::TfNotice::Register(pxr::TfCreateWeakPtr(&TransactionUSDReceiver), &FTransactionUSDReceiver::HandleNotice, GetUSDStage()->GetEditTarget().GetLayer());
		TransactionUSDReceiver.TransactionData = USDTransaction.TransactionData.Get();
	}

	TSharedPtr<void> ResetUSDTransaction;
	if(!GEditor->IsTransactionActive())
	{
		ResetUSDTransaction = MakeShareable<void>(nullptr,
			[this](auto)
			{
				USDTransaction.TransactionData.Reset();
			}
		);
	}

	// Save each object
	TSharedPtr<FUSDEditDelegate> EditDelegate = MakeShared<FUSDEditDelegate>();
	pxr::TfNotice::Register(pxr::TfCreateWeakPtr(EditDelegate.Get()), &FUSDEditDelegate::HandleNotice, GetUSDStage()->GetEditTarget().GetLayer());

	for(auto& ChangedObj : ChangedObjs)
	{
		bool bPasted = false;

		do
		{
			// Deal with paste
			auto Actor = Cast<AActor>(ChangedObj.Object);
			if(!Actor || !Actor->GetRootComponent())
			{
				break;
			}

			auto UserData = Actor->GetRootComponent()->GetAssetUserData<UOmniverseCopyAssetUserData>();
			if(!UserData)
			{
				break;
			}

			auto SrcPath = ToUSDPath(*UserData->USDPath);
			auto TgtPath = SrcPath.GetParentPath().AppendElementString(TCHAR_TO_ANSI(*Actor->GetActorLabel()));

			auto CopyLayer = pxr::SdfLayer::CreateAnonymous();
			CopyLayer->ImportFromString(TCHAR_TO_ANSI(*UserData->USDCopyContent));

			StateScoped = SetStateScoped(EState::Saving);
			pxr::SdfCopySpec(CopyLayer, SrcPath, GetUSDStage()->GetEditTarget().GetLayer(), TgtPath);

			Actor->GetRootComponent()->RemoveUserDataOfClass(UOmniverseCopyAssetUserData::StaticClass());

			GEngine->DelayGarbageCollection();

			bPasted = true;
		} while(false);

		pxr::TfErrorMark ErrorMark;
		if(bPasted)
		{
			GetUSDStage()->GetEditTarget().GetLayer()->SetPermissionToEdit(false);
		}

		SaveUSD(*ChangedObj.Object, ChangedObj.Changes);

		if(bPasted)
		{
			ErrorMark.Clear();
			GetUSDStage()->GetEditTarget().GetLayer()->SetPermissionToEdit(true);
		}
	}

	// Revert inert edit
	auto RevertedPaths = EditDelegate->RevertInertEdit(*GetUSDStage());
	EditDelegate.Reset();

	StateScoped.Reset();

	for(auto Path : RevertedPaths)
	{
		OnUSDStageNotice(Path, false);
	}
}

void AOmniverseStageActor::TransactUSD(const FUSDTransactionData& TransactionData, UOmniverseTransaction::EUndoType UndoType)
{
	// Save UE4 object changes
	for(auto& Entry : TransactionData.UE4Changes)
	{
		UObject* Object = FindObject<UObject>(nullptr, *Entry.Get<0>());
		if(!Object)
		{
			continue;
		}

		if(!(IsValidChecked(Object) && !Object->IsUnreachable()))
		{
			continue;
		}

		for(auto& Change : Entry.Get<1>())
		{
			OnUE4ObjectChanged(*Object, Change);
		}
	}

	SaveChangedUE4Objects();

	// Revert USD
	if(UndoType == UOmniverseTransaction::EUndoType::Undo && USD)
	{
		auto ScopedState = SetStateScoped(EState::Saving);
		auto Layer = GetUSDStage()->GetEditTarget().GetLayer();
		for(auto& Path : TransactionData.AddedSpecs)
		{
			auto ParentSpec = Layer->GetPrimAtPath(Path.GetParentPath());
			if(!ParentSpec)
			{
				continue;
			}

			if(Path.IsPrimPath())
			{
				if(auto Spec = Layer->GetPrimAtPath(Path))
				{
					ParentSpec->RemoveNameChild(Spec);
				}
			}
			else if(Path.IsPropertyPath())
			{
				if(auto Spec = Layer->GetPropertyAtPath(Path))
				{
					ParentSpec->RemoveProperty(Spec);
				}
			}
		}
	}
}

bool AOmniverseStageActor::IsInPIEOrStandaloneMode()
{
#if WITH_EDITOR
	UWorld* World = GetWorld();
	if (GEditor && World && World == GEditor->GetEditorWorldContext().World() && !World->IsPlayInEditor()
		&& !GEditor->PlayWorld)
	{
		return false;
	}
#endif

	return true;
}
#if WITH_EDITOR
void AOmniverseStageActor::SpawnGlobalPostProcessVolume()
{
	TActorIterator<APostProcessVolume> ActorIter = TActorIterator<APostProcessVolume>(GetWorld());
	if (!ActorIter)
	{
		APostProcessVolume* PostProcessVolume = GetWorld()->SpawnActor<APostProcessVolume>();
		PostProcessVolume->bUnbound = true;
		PostProcessVolume->SetActorScale3D(FVector(0.01f, 0.01f, 0.01f));
	}
}

void AOmniverseStageActor::OnOmniverseMessageReceived(const FString& ChannelId, const FOmniverseMessage& OmniverseMessage)
{
}

TArray<UMeshComponent*> AOmniverseStageActor::FindMeshComponents(const FString& PrimPath)
{
	if (auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(PrimPath)))
	{
		if (!Object->IsValid())
		{
			return {};
		}

		auto SceneComponent = Cast<USceneComponent>(Object->Get());
		if (!SceneComponent)
		{
			return {};
		}


		auto Actor = SceneComponent->GetOwner();
		if (!Actor)
		{
			return {};
		}

		TArray<UMeshComponent*> MeshComponents;
		Actor->GetComponents<UMeshComponent>(MeshComponents, false);

		return MeshComponents;
	}

	return {};
}

TSet<FString> AOmniverseStageActor::GetSelectedPrimPaths()
{
	TSet<FString> FocusedPrims;
	USelection* SelectedActors = GEditor->GetSelectedActors();
	for (FSelectionIterator Iter(*SelectedActors); Iter; ++Iter)
	{
		AActor* Actor = Cast<AActor>(*Iter);
		if (Actor)
		{
			auto PrimPathKey = FindPath((UObject*)Actor->GetRootComponent());
			if (PrimPathKey)
			{
				FocusedPrims.Add(FOmniversePathHelper::KeyToPrimPath(*PrimPathKey));
			}
		}
	}

	return FocusedPrims;
}
#endif

TSharedPtr<void> AOmniverseStageActor::SetStateScoped(EState InState)
{
	if(State != EState::None && State != InState)
	{
		return nullptr;
	}

	auto OldState = State;
	State = InState;

	auto OldUndo = GUndo;
	GUndo = nullptr;	// Not modify level

	return MakeShareable((void*)ULLONG_MAX, [this, OldState, OldUndo](auto)
		{
			State = OldState;
			GUndo = OldUndo;
		}
	);
}

bool AOmniverseStageActor::LoadStaticMesh(const pxr::UsdGeomMesh& USDMesh, UStaticMeshComponent& MeshComponent)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("OmniStageActorLoadStaticMesh"), STAT_OmniStageActorLoadStaticMesh, STATGROUP_Omniverse);

	// Find in Cache
	if(!USDMesh)
	{
		return false;
	}

	if (HasValidImportStage())
	{
		// check if the collision shape is visible
		// the invisible shape won't be imported
		if (USDMesh.ComputePurpose() == pxr::UsdGeomTokens->guide)
		{
			return false;
		}

		pxr::TfToken VisibilityValue;
		USDMesh.GetVisibilityAttr().Get(&VisibilityValue);
		if (VisibilityValue == pxr::UsdGeomTokens->invisible)
		{
			return false;
		}

		// check parent as well
		if (USDMesh.GetPrim().GetParent())
		{
			USceneComponent* Parent = FindObjectFromPath<USceneComponent>(USDMesh.GetPath().GetParentPath());
			if (Parent && (!Parent->IsVisible() || Parent->GetOwner() && Parent->GetOwner()->IsHidden()))
			{
				return false;
			}
		}
	}
	
	FString Name = USDMesh.GetPrim().GetName().GetText();
	if (FOmniverseReferenceCollector::Get().FindDependency(USDMesh.GetPath().GetText()))
	{
		FString Text = FString::Printf(TEXT("Loading Mesh %s..."), *Name);
		FOmniverseSlowTask::Get().UpdateProgress(1.0, FText::FromString(Text));
	}

	FSHAHash Hash = FUSDHashGenerator::ComputeSHAHash(USDMesh);
	if (Name.StartsWith(TEXT("Section"), ESearchCase::CaseSensitive))
	{
		if (USDMesh.GetPrim().GetParent())
		{
			Name = FString(USDMesh.GetPrim().GetParent().GetName().GetText()) + TEXT("_") + Name;
		}
	}
	FString HashString = Hash.ToString();
	Name = GetUniqueImportName(HashString, Name);
	UE_LOG(LogOmniverseUsd, Log, TEXT("Loading static mesh [%s]"), *Name);
	UStaticMesh* StaticMesh = Cast<UStaticMesh>(FUSDGeometryCache::Find(HashString));
	if (StaticMesh == nullptr)
	{
		StaticMesh = LoadImportObject<UStaticMesh>(ImportType::Mesh, Name);
	}
	if(!StaticMesh)
	{	
		// Create static mesh to avoid breaking existing mesh
		StaticMesh = FOmniverseUSDImporterHelper::CreateStaticMesh(USDMesh, GetAssetPackage(ImportType::Mesh, Name), GetAssetName(Name), GetAssetFlag());

		// Construct mesh
		if(!StaticMesh)
		{
			return false;
		}

		// Update Asset import data
		if (HasValidImportStage())
		{
			FOmniverseAssetImportHelper::UpdateAssetImportData(StaticMesh, ImportUSDSourceFile, USDMesh.GetPath().GetText());
		}
	}

	if (StaticMesh)
	{
		FUSDGeometryCache::Add(HashString, StaticMesh);
	}

	MeshComponent.SetStaticMesh(StaticMesh);

	bool bEnableQueryCollision = GetDefault<UOmniverseSettings>()->bEnableQueryCollision;
	MeshComponent.BodyInstance.SetCollisionEnabled(bEnableQueryCollision ? ECollisionEnabled::QueryOnly : ECollisionEnabled::NoCollision);	// Disable collision to boost mesh construction

	return true;
}

void AOmniverseStageActor::LoadDomeLight(const pxr::UsdLuxDomeLight& DomeLight)
{
	// Get the old/new UsdLuxLight schema preference
	bool bPreferNewSchema = GetDefault<UOmniverseSettings>()->bPreferNewUsdLuxLightSchemaOnImport;
	pxr::UsdAttribute LightAttr;

	auto SkySphere = LoadObject<UStaticMesh>(nullptr, TEXT("/Omniverse/Skysphere"));
	auto SkyMaterial = LoadObject<UMaterial>(nullptr, TEXT("/Omniverse/SkyMaterial"));
	if (SkySphere == nullptr || SkyMaterial == nullptr)
	{
		return;
	}

	// Set a skybox
	bool bRecap = false;
	bool bVisibleInPrimaryRay = true;
	auto VisibleInPrimaryRayAttr = DomeLight.GetPrim().GetAttribute(pxr::TfToken("visibleInPrimaryRay"));
	if (VisibleInPrimaryRayAttr)
	{
		bVisibleInPrimaryRay = GetUSDValue<bool>(VisibleInPrimaryRayAttr);
	}
	auto Path = DomeLight.GetPath();
	UStaticMeshComponent* SkyComponent = FindObjectFromPath<UStaticMeshComponent>(Path);
	if (SkyComponent == nullptr)
	{
		SkyComponent = CreateActorAndComponent<UStaticMeshComponent, AStaticMeshActor>(DomeLight.GetPrim());
		bRecap = true;
	}
	SkyComponent->SetStaticMesh(SkySphere);
	SkyComponent->SetCastShadow(false);
	
	FString Name = DomeLight.GetPrim().GetName().GetText();
	Name += TEXT("_SkyMaterialInst");
	Name = GetUniqueImportName(Path.GetText(), Name);
	UMaterialInstanceConstant* SkyMaterialInst = nullptr;//LoadImportObject<UMaterialInstanceConstant>(ImportType::Material, Name);
	if (SkyMaterialInst == nullptr)
	{
		SkyMaterialInst = Cast<UMaterialInstanceConstant>(SkyComponent->GetMaterial(0));

		if (SkyMaterialInst == nullptr)
		{
			SkyMaterialInst = NewObject<UMaterialInstanceConstant>(GetAssetPackage(ImportType::Material, Name), GetAssetName(Name), GetAssetFlag());
			if (SkyMaterialInst == nullptr)
			{
				return;
			}

			SkyMaterialInst->SetParentEditorOnly(SkyMaterial);
		}

		// Set texture/intensity/exposure
		LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetTextureFileAttr(), bPreferNewSchema);
		auto TextureFile = GetUSDValue<pxr::SdfAssetPath>(LightAttr);
		FString OmniPath = TextureFile.GetResolvedPath().c_str();
		auto Texture = GetTexture(OmniPath);
		LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetColorAttr(), bPreferNewSchema);
		FLinearColor Color = USDConvertToLinearColor(GetUSDValue<pxr::GfVec3f>(LightAttr));
		LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetIntensityAttr(), bPreferNewSchema);
		float Intensity = GetUSDValue<float>(LightAttr);
		LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetExposureAttr(), bPreferNewSchema);
		float Exposure = GetUSDValue<float>(LightAttr);
		bool bTextureEnabled = (Texture != nullptr);
		
		// Check exist material
		if (!bRecap)
		{
			float PreTextureEnabled;
			if (SkyMaterialInst->GetScalarParameterValue(TEXT("TextureEnabled"), PreTextureEnabled))
			{
				float FloatTextureEnabled = bTextureEnabled ? 1.0f : 0.0f;
				if (PreTextureEnabled != FloatTextureEnabled)
				{
					bRecap = true;
				}
			}
		}
		if (!bRecap && bTextureEnabled)
		{
			UTexture* PreTexture;
			if (SkyMaterialInst->GetTextureParameterValue(TEXT("Texture"), PreTexture))
			{
				if (PreTexture != Texture)
				{
					bRecap = true;
				}
			}
		}

		if (!bRecap)
		{
			FLinearColor PreColor;
			if (SkyMaterialInst->GetVectorParameterValue(TEXT("Color"), PreColor))
			{
				if (PreColor != Color)
				{
					bRecap = true;
				}
			}
		}

		if (!bRecap)
		{
			float PreIntensity;
			if (SkyMaterialInst->GetScalarParameterValue(TEXT("Intensity"), PreIntensity))
			{
				if (PreIntensity != Intensity)
				{
					bRecap = true;
				}
			}
		}

		if (!bRecap)
		{
			float PreExposure;
			if (SkyMaterialInst->GetScalarParameterValue(TEXT("Exposure"), PreExposure))
			{
				if (PreExposure != Exposure)
				{
					bRecap = true;
				}
			}
		}

		if (bTextureEnabled)
		{
			SkyMaterialInst->SetTextureParameterValueEditorOnly(TEXT("Texture"), Texture);
		}
		SkyMaterialInst->SetScalarParameterValueEditorOnly(TEXT("TextureEnabled"), bTextureEnabled ? 1.0f : 0.0f);
		SkyMaterialInst->SetVectorParameterValueEditorOnly(TEXT("Color"), Color);
		SkyMaterialInst->SetScalarParameterValueEditorOnly(TEXT("Intensity"), Intensity);
		SkyMaterialInst->SetScalarParameterValueEditorOnly(TEXT("Exposure"), Exposure);

		SkyMaterialInst->MarkPackageDirty();
		FAssetRegistryModule::AssetCreated(SkyMaterialInst);
	}
	SkyComponent->SetMaterial(0, SkyMaterialInst);

	FNamedParameterTimeSamples ParameterTimeSamples;
	FColorTimeSamples ColorTimeSamples;

	LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetColorAttr(), bPreferNewSchema);
	if (GetUSDTimeSamples2<pxr::GfVec3f, FVector3f, FColorTimeSamples>(LightAttr, ColorTimeSamples))
	{
		ParameterTimeSamples.ColorTimeSamples.Add(TEXT("Color"), ColorTimeSamples);
	}
	FFloatTimeSamples IntensityTimeSamples;
	LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetIntensityAttr(), bPreferNewSchema);
	if (GetUSDTimeSamples<float, FFloatTimeSamples>(LightAttr, IntensityTimeSamples))
	{
		ParameterTimeSamples.ScalarTimeSamples.Add(TEXT("Intensity"), IntensityTimeSamples);
	}
	FFloatTimeSamples ExposureTimeSamples;
	LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetExposureAttr(), bPreferNewSchema);
	if (GetUSDTimeSamples<float, FFloatTimeSamples>(LightAttr, ExposureTimeSamples))
	{
		ParameterTimeSamples.ScalarTimeSamples.Add(TEXT("Exposure"), ExposureTimeSamples);
	}
	USDSequenceImporter->CreateMaterialTrack(SkyComponent, 0, ParameterTimeSamples);

	const float DomeSkyDistance = 70000.0f;
	for (auto Actor : PreviewEnvironmentActors)
	{
		if (Actor.IsValid())
		{
			if (Actor->IsA<ASkyLight>())
			{
				auto SkyLight = Cast<ASkyLight>(Actor.Get());
				LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(DomeLight.GetPrim(), DomeLight.GetColorAttr(), bPreferNewSchema);
				SkyLight->GetLightComponent()->SetLightColor(USDConvertToLinearColor(GetUSDValue<pxr::GfVec3f>(LightAttr)));
				SkyLight->GetLightComponent()->SkyDistanceThreshold = DomeSkyDistance;
				
				if (bRecap)
				{
					SkyLight->GetLightComponent()->RecaptureSky();
				}
			}
		}
	}	
}

bool AOmniverseStageActor::LoadLight(const pxr::SdfPath& Path, bool bLoadChildren)
{
	pxr::UsdPrim USDLight(GetUSDStage()->GetPrimAtPath(Path.GetPrimPath()));
	if(!USDLight)
	{
		return false;
	}

	// Get the old/new UsdLuxLight schema preference
	bool bPreferNewSchema = GetDefault<UOmniverseSettings>()->bPreferNewUsdLuxLightSchemaOnImport;
	pxr::UsdAttribute LightAttr;

	ULightComponent* LightComponent = nullptr;

	bool bShouldLoadProperty = false;
	if(USDLight.IsA<pxr::UsdLuxDistantLight>())
	{
		// Create directional light component and actor
		LightComponent = CreateActorAndComponent<UDirectionalLightComponent, ADirectionalLight>(USDLight);
		bShouldLoadProperty = ShouldLoadProperty(Path, OmniverseUsdLuxLightCompat::DistantLightGetSchemaAttributeNames());
	}
	else if(USDLight.IsA<pxr::UsdLuxSphereLight>())
	{
		bool bSpotLight = false;
		auto Cone = pxr::UsdLuxShapingAPI(USDLight);
		if(Cone)
		{
			LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(USDLight, Cone.GetShapingConeAngleAttr(), bPreferNewSchema);
			float OuterConeAngle = GetUSDValue<float>(LightAttr);
			if (OuterConeAngle > 0 && OuterConeAngle < 180)
			{
				bSpotLight = true;
			}
		}

		//NOTE: USD sphere light might be imported as Spot or Point light. We should check if there's already one in the stage and remove it.
		auto ExistedLightComponent = FindObjectFromPath<ULightComponent>(Path.GetPrimPath());
		if (ExistedLightComponent)
		{
			if (bSpotLight != ExistedLightComponent->IsA<USpotLightComponent>())
			{
				// remove the existed component
				FString UEPrimPath = Path.GetPrimPath().GetText();
				ReserveObject(*ExistedLightComponent->GetOwner(), UEPrimPath);
				USDPathToObject.Remove(FOmniversePathHelper::PrimPathToKey(UEPrimPath));
				GEngine->BroadcastLevelActorListChanged();
			}
		}

		if (bSpotLight)
		{
			LightComponent = CreateActorAndComponent<USpotLightComponent, ASpotLight>(USDLight);
		}
		else
		{
			LightComponent = CreateActorAndComponent<UPointLightComponent, APointLight>(USDLight);
		}
		bShouldLoadProperty = ShouldLoadProperty(Path, OmniverseUsdLuxLightCompat::SphereLightGetSchemaAttributeNames());
	}
	else if(USDLight.IsA<pxr::UsdLuxRectLight>())
	{
		LightComponent = CreateActorAndComponent<URectLightComponent, ARectLight>(USDLight);
		bShouldLoadProperty = ShouldLoadProperty(Path, OmniverseUsdLuxLightCompat::RectLightGetSchemaAttributeNames());
	}
	else if (USDLight.IsA<pxr::UsdLuxDomeLight>())
	{
		LoadDomeLight(pxr::UsdLuxDomeLight(USDLight));
		LoadSceneComponent(Path, bLoadChildren);
		return true;
	}

	if(!LightComponent)
	{
		UE_LOG(LogOmniverseUsd, Warning, L"Doesn't support this type of light: %s", *FString(USDLight.GetPath().GetText()));
		return false;
	}

	if (!bShouldLoadProperty)
	{
		bShouldLoadProperty = ShouldLoadProperty(
			Path, 
			OmniverseUsdLuxLightCompat::LightGetSchemaAttributeNames()) || ShouldLoadProperty(Path, OmniverseUsdLuxLightCompat::ShapingAPIGetSchemaAttributeNames());
	}

	// Set basic light properties
	if(bShouldLoadProperty)
	{
		FNamedParameterTimeSamples NamedParameterTimeSamples;
		if (USDImportLight(USDLight, *LightComponent, NamedParameterTimeSamples))
		{
			auto Shape = pxr::UsdLuxShapingAPI(USDLight);
			if (Shape)
			{
				// Load IES
				LightAttr = OmniverseUsdLuxLightCompat::GetLightAttr(USDLight, Shape.GetShapingIesFileAttr(), bPreferNewSchema);
				auto LightProfileFile = GetUSDValue<pxr::SdfAssetPath>(LightAttr);
				FString OmniPath = LightProfileFile.GetResolvedPath().c_str();
				auto Texture = GetTexture(OmniPath);
				if (Texture && Texture->IsA<UTextureLightProfile>())
				{
					LightComponent->IESTexture = Cast<UTextureLightProfile>(Texture);
				}
			}
		}

		USDSequenceImporter->CreateObjectTrack(LightComponent, NamedParameterTimeSamples);
		LightComponent->MarkRenderStateDirty();
	}

	LoadSceneComponent(Path, bLoadChildren);

	return true;
}

template <typename UsdType>
void LoadLayerDataSetting(const pxr::VtDictionary& UsdSettings, const std::string SettingName, UsdType& OutValue)
{
	auto SettingEntry = UsdSettings.find(SettingName);
	if (SettingEntry != UsdSettings.end())
	{
		OutValue = pxr::VtValue::Cast<UsdType>(SettingEntry->second).UncheckedGet<UsdType>();
	}
};

FORCEINLINE float EV100ToLuminance(float EV100)
{
	return 1.2 * FMath::Pow(2.0f, EV100);
}

FORCEINLINE float HistogramEVToEV100(float EV)
{
	return FMath::Log2(EV * 0.001f) + 3;
}

void AOmniverseStageActor::LoadCustomLayerData()
{
	if (!GetUSDStage())
	{
		return;
	}

	auto RootLayer = GetUSDStage()->GetRootLayer();
	
	pxr::VtDictionary CustomLayerData;
	const pxr::VtDictionary* CameraSettingsDict = nullptr;
	const pxr::VtDictionary* RenderSettingsDict = nullptr;
	if (RootLayer->HasCustomLayerData())
	{
		CustomLayerData = RootLayer->GetCustomLayerData();
		auto CameraSettingsEntry = CustomLayerData.find(std::string("cameraSettings"));
		if (CameraSettingsEntry != CustomLayerData.end())
		{
			CameraSettingsDict = &(CameraSettingsEntry->second.Get<pxr::VtDictionary>());
		}

		auto RenderSettingsEntry = CustomLayerData.find(std::string("renderSettings"));
		if (RenderSettingsEntry != CustomLayerData.end())
		{
			RenderSettingsDict = &(RenderSettingsEntry->second.Get<pxr::VtDictionary>());
		}
	}

	if (CameraSettingsDict)
	{
		auto CamUsdSettingsEntry = (*CameraSettingsDict).find("Perspective");
		if (CamUsdSettingsEntry != (*CameraSettingsDict).end())
		{
			const auto& CamUsdSettings = CamUsdSettingsEntry->second.Get<pxr::VtDictionary>();
			pxr::GfVec3d Position;
			pxr::GfVec3d Target;
			LoadLayerDataSetting<pxr::GfVec3d>(CamUsdSettings, "position", Position);
			LoadLayerDataSetting<pxr::GfVec3d>(CamUsdSettings, "target", Target);

			auto World = GetWorld();
			if (World)
			{
				FVector CamPosition = USDConvertPosition(GetUSDStage(), USDConvert(Position), true);
				FVector CamTarget = USDConvertPosition(GetUSDStage(), USDConvert(Target), true);
				FRotator CamRotation = (CamTarget- CamPosition).ToOrientationRotator();

				FLevelViewportInfo& ViewportInfo = World->EditorViews[ELevelViewportType::LVT_Perspective];
				ViewportInfo.CamPosition = CamPosition;
				ViewportInfo.CamRotation = CamRotation;

				if (FModuleManager::Get().IsModuleLoaded("LevelEditor"))
				{
					FLevelEditorModule& LevelEditor = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");

					// Notify level editors of the map change
					LevelEditor.BroadcastMapChanged(World, EMapChangeType::LoadMap);
				}
			}
		}
	}

	if (RenderSettingsDict)
	{
		float CameraShutter = 50.0f; // ms in Kit, should convert to s
		float CamerafNumber = 5.0f;
		float CameraFilmIso = 100.0f;
		float TonemapFactor = 1.0f;
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:tonemap:cameraShutter", CameraShutter);
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:tonemap:fNumber", CamerafNumber);
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:tonemap:filmIso", CameraFilmIso);
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:tonemap:cm2Factor", TonemapFactor);

		bool bAutoExposure = false;
		float AdaptSpeed = 3.5f;
		float MinEV = 50.0f;
		float MaxEV = 100000.0f;
		float WhiteScale = 10.0f;
		LoadLayerDataSetting<bool>(*RenderSettingsDict, "rtx:post:histogram:enabled", bAutoExposure);
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:histogram:minEV", MinEV);
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:histogram:maxEV", MaxEV);
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:histogram:tau", AdaptSpeed);
		LoadLayerDataSetting<float>(*RenderSettingsDict, "rtx:post:histogram:whiteScale", WhiteScale);

		auto World = GetWorld();
		if (World)
		{
			TActorIterator<APostProcessVolume> PPVIter = TActorIterator<APostProcessVolume>(World);
			if (PPVIter)
			{
				PPVIter->Settings.bOverride_AutoExposureMethod = true;
				PPVIter->Settings.bOverride_AutoExposureBias = true;
				PPVIter->Settings.AutoExposureMethod = bAutoExposure ? EAutoExposureMethod::AEM_Histogram : EAutoExposureMethod::AEM_Manual;

				if (bAutoExposure)
				{
					PPVIter->Settings.bOverride_AutoExposureSpeedUp = true;
					PPVIter->Settings.bOverride_AutoExposureSpeedDown = true;
					PPVIter->Settings.bOverride_AutoExposureMinBrightness = true;
					PPVIter->Settings.bOverride_AutoExposureMaxBrightness = true;

					PPVIter->Settings.AutoExposureSpeedUp = AdaptSpeed;
					PPVIter->Settings.AutoExposureSpeedDown = AdaptSpeed;

					static const auto VarDefaultAutoExposureExtendDefaultLuminanceRange = IConsoleManager::Get().FindTConsoleVariableDataInt(TEXT("r.DefaultFeature.AutoExposure.ExtendDefaultLuminanceRange"));
					const bool bExtendedLuminanceRange = VarDefaultAutoExposureExtendDefaultLuminanceRange->GetValueOnGameThread() == 1;

					if (bExtendedLuminanceRange)
					{
						PPVIter->Settings.AutoExposureMinBrightness = HistogramEVToEV100(MinEV);
						PPVIter->Settings.AutoExposureMaxBrightness = HistogramEVToEV100(MaxEV);
					}
					else
					{
						PPVIter->Settings.AutoExposureMinBrightness = EV100ToLuminance(HistogramEVToEV100(MinEV));
						PPVIter->Settings.AutoExposureMaxBrightness = EV100ToLuminance(HistogramEVToEV100(MaxEV));
					}

					PPVIter->Settings.AutoExposureBias = FMath::Log2(10.0f / WhiteScale);
				}
				else
				{
					PPVIter->Settings.bOverride_CameraShutterSpeed = true;
					PPVIter->Settings.bOverride_DepthOfFieldFstop = true;
					PPVIter->Settings.bOverride_CameraISO = true;
					
					PPVIter->Settings.CameraShutterSpeed = CameraShutter * 0.001f;
					PPVIter->Settings.DepthOfFieldFstop = CamerafNumber;
					PPVIter->Settings.CameraISO = CameraFilmIso;
					PPVIter->Settings.AutoExposureBias = FMath::Log2(TonemapFactor);
				}
			}
		}
	}
}

void AOmniverseStageActor::LoadLayerTimeInfo()
{
	auto USDStage = GetUSDStage();
	if (!USDStage)
	{
		return;
	}

	pxr::SdfLayerRefPtr RootLayer = USDStage->GetRootLayer();

	if (!TimeCodeInfo.StartTimeCode.IsSet())
	{
		TimeCodeInfo.StartTimeCode = RootLayer->HasStartTimeCode() ? RootLayer->GetStartTimeCode() : TOptional<double>();
	}
	if (!TimeCodeInfo.EndTimeCode.IsSet())
	{
		TimeCodeInfo.EndTimeCode = RootLayer->HasEndTimeCode() ? RootLayer->GetEndTimeCode() : TOptional<double>();
	}
	if (!TimeCodeInfo.TimeCodesPerSecond.IsSet())
	{
		TimeCodeInfo.TimeCodesPerSecond = RootLayer->HasTimeCodesPerSecond() ? RootLayer->GetTimeCodesPerSecond() : (RootLayer->HasFramesPerSecond() ? RootLayer->GetFramesPerSecond() : TOptional<double>());
	}
}

bool AOmniverseStageActor::IsValidPrimPath(const pxr::SdfPath& Path)
{
	if(USD)
	{
		auto Stage = GetUSDStage();
		if(Stage && Stage->GetPrimAtPath(Path))
		{
			return true;
		}
	}

	return false;
}

const pxr::UsdStageRefPtr& AOmniverseStageActor::GetUSDStage()
{
	if (USD)
	{
		return USD->GetUSDStage();
	}

	return ImportUSDStage;
}

void AOmniverseStageActor::SaveStage()
{
	if (USD)
	{
		USD->SaveToOmniverse();
	}
}

FString AOmniverseStageActor::GetUSDPath()
{
	if (USD)
	{
		return USD->GetOmniPath();
	}
	else if (ImportUSDStage)
	{
		return ImportUSDStage->GetRootLayer()->GetIdentifier().c_str();
	}

	return FString();
}

FString AOmniverseStageActor::GetUSDName()
{
	FString Name = FPaths::GetBaseFilename(GetUSDPath());
	if (Name.IsEmpty())
	{
		if (USD)
		{
			Name = USD->GetName();
		}
	}
	else
	{
		FOmniversePathHelper::FixAssetName(Name);
	}
	return Name;
}

EObjectFlags AOmniverseStageActor::GetAssetFlag()
{
	if (HasValidImportStage())
	{
		return EObjectFlags::RF_Standalone | EObjectFlags::RF_Public;
	}
	else
	{
		return EObjectFlags::RF_Transactional | EObjectFlags::RF_Public;
	}
}

UPackage* AOmniverseStageActor::GetAssetPackage(ImportType Type, const FString& AssetName)
{
	if (HasValidImportStage())
	{
		FString SubPath;
		switch(Type)
		{
		case ImportType::Mesh:
			SubPath = TEXT("Meshes");
			break;
		case ImportType::Material:
			SubPath = TEXT("Materials");
			break;
		case ImportType::Texture:
			SubPath = TEXT("Textures");
			break;
		case ImportType::Animation:
			SubPath = TEXT("Animations");
			break;
		}

		FString PkgPath = FPaths::Combine(SavePackagePath, SubPath);
		PkgPath = FPaths::Combine(PkgPath, AssetName);
		auto Package = CreatePackage(*PkgPath);
		Package->FullyLoad();
		return Package;
	}
	else
	{
		return GetTransientPackage();
	}
}

UTexture* AOmniverseStageActor::GetTexture(const FString& OmniPath)
{
	if (HasValidImportStage())
	{
		UTexture* Texture = nullptr;
		auto Object = USDPathToObject.Find(FOmniversePathHelper::PrimPathToKey(OmniPath));
		if (Object && Object->IsValid())
		{
			Texture = Cast<UTexture>(Object->Get());
			if (Texture)
			{
				return Texture;
			}
		}

		FString TextureName = FPaths::GetBaseFilename(OmniPath);
		FOmniversePathHelper::FixAssetName(TextureName);
		TextureName = GetUniqueImportName(OmniPath, TextureName);
		Texture = LoadImportObject<UTexture>(ImportType::Texture, TextureName);
		if (Texture)
		{
			return Texture;
		}

		Texture = UOmniverseTexture::CreateTextureFromFile(OmniPath, GetAssetPackage(ImportType::Texture, TextureName), *TextureName, GetAssetFlag());
		if (Texture)
		{
			USDPathToObject.FindOrAdd(FOmniversePathHelper::PrimPathToKey(OmniPath), Texture);
		}
		
		return Texture;
	}
	else
	{
		return UOmniverseAsset::LoadAsset<UTexture>(OmniPath);
	}
}

FName AOmniverseStageActor::GetAssetName(const FString& Name)
{
	if (HasValidImportStage())
	{
		return *Name;
	}
	else
	{
		return NAME_None;
	}
}

FString AOmniverseStageActor::GetUniqueImportName(const FString& KeyPath, const FString& Name)
{
	if (HasValidImportStage())
	{
		auto ExistName = ImportedNames.Find(KeyPath);
		if (ExistName == nullptr)
		{
			FString UniqueName = Name;
			while(ImportedNames.FindKey(UniqueName))
			{
				UniqueName = UniqueName + TEXT("_") + FString::FromInt(ImportedSuffixIndex++);
			}
			ImportedNames.Add(KeyPath, UniqueName);
			return UniqueName;
		}
		else
		{
			return *ExistName;
		}
	}
	else
	{
		return Name;
	}
}

void AOmniverseStageActor::ImportUSD(const FString& UsdPath, const FString& PackagePath, const FOmniverseImportSettings& InImportSettings)
{
	FUSDGeometryCache::BackupCurrentCache();
	UOmniverseMDL::ResetImportParametersSheet();
	ImportUSDStage = FOmniverseUSDHelper::LoadUSDStageFromPath(UsdPath);
	if (ImportUSDStage)
	{
		ImportOverwriteStatus = 0;
		ImportUSDSourceFile = UsdPath;
		ImportSettings = InImportSettings;
		int32 NumDependencies = FOmniverseReferenceCollector::Get().GetAllDependencies(ImportUSDStage, InImportSettings);
		FString AssetName = FPaths::GetBaseFilename(UsdPath);
		FOmniversePathHelper::FixAssetName(AssetName);
		FOmniverseSlowTask::Get().BeginProgress(NumDependencies, FText::FromString(FString::Printf(TEXT("Importing USD %s..."), *AssetName)), true, false);
		SavePackagePath = PackagePath / AssetName;
		SpawnGlobalPostProcessVolume();
		LoadCustomLayerData();
		LoadLayerTimeInfo();
		if (InImportSettings.bImportAsBlueprint)
		{
			USDSequenceImporter->SetActorSequenceMode();
		}
		else
		{
			USDSequenceImporter->CreateLevelSequence(TimeCodeInfo.StartTimeCode, TimeCodeInfo.EndTimeCode, TimeCodeInfo.TimeCodesPerSecond);
		}
		OnUSDStageNotice(pxr::SdfPath("/"), true);
		LoadChangedUSDPaths();

		UBlueprint* Blueprint = nullptr;
		if (InImportSettings.bImportAsBlueprint)
		{
			TArray<TWeakObjectPtr<UObject>> UsdObjects;
			USDPathToObject.GenerateValueArray(UsdObjects);
			TArray<AActor*> Actors;
			for (auto Obj : UsdObjects)
			{
				if (Obj.IsValid() && Obj.Get()->IsA<USceneComponent>())
				{
					Actors.AddUnique(Cast<USceneComponent>(Obj.Get())->GetOwner());
				}
			}
			FKismetEditorUtilities::FHarvestBlueprintFromActorsParams Params;
			Params.bReplaceActors = true;
			Params.ParentClass = AActor::StaticClass();
			
			FString BlueprintAssetName = AssetName + TEXT("_Blueprint");
			FString BlueprintPath = SavePackagePath / BlueprintAssetName;
			auto BlueprintPackage = CreatePackage(*BlueprintPath);
			if (BlueprintPackage)
			{
				Blueprint = FindObject<UBlueprint>(BlueprintPackage, *BlueprintAssetName);
				if (Blueprint)
				{
					Blueprint->Rename(nullptr, GetTransientPackage(), REN_DoNotDirty | REN_DontCreateRedirectors | REN_NonTransactional);
					Blueprint->MarkAsGarbage();
				}
			}
			Blueprint = FKismetEditorUtilities::HarvestBlueprintFromActors(BlueprintPath, Actors, Params);
			if (Blueprint)
			{
				// Create ActorSequenceComponent to hold usd time-samples
				USCS_Node* NewNode = Blueprint->SimpleConstructionScript->CreateNode(UActorSequenceComponent::StaticClass());
				Blueprint->SimpleConstructionScript->AddNode(NewNode);
				USDSequenceImporter->BuildActorSequence(Blueprint, Actors, TimeCodeInfo.StartTimeCode, TimeCodeInfo.EndTimeCode, TimeCodeInfo.TimeCodesPerSecond);
				// Recompile
				FKismetEditorUtilities::CompileBlueprint(Blueprint);
			}
		}
		else
		{
			USDSequenceImporter->RemoveEmptyLevelSequence();
		}

		FOmniverseSlowTask::Get().EndProgress();
		FOmniverseReferenceCollector::Get().Reset();

		if (InImportSettings.bImportAsBlueprint && Blueprint)
		{
			TArray<UObject*> Objects;
			Objects.Add(Blueprint);
			GEditor->SyncBrowserToObjects( Objects, false );
		}
		else
		{
			TArray<FString> Folders;
			Folders.Add(PackagePath);
			FContentBrowserModule& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
			ContentBrowserModule.Get().SyncBrowserToFolders(Folders);
		}
		ImportUSDStage.Reset();
		ImportUSDStage = nullptr;
	}

	FUSDGeometryCache::RestoreLastBackup();
}

void AOmniverseStageActor::InitializePreviewEnvironment()
{
	UWorld* World = GetWorld();
	if (World)
	{
		// Add Sky Light
		ASkyLight* SkyLight = World->SpawnActor<ASkyLight>();
		SkyLight->GetLightComponent()->bCaptureEmissiveOnly = true;
		// Make the sky light movable
		SkyLight->GetLightComponent()->Mobility = EComponentMobility::Movable;
		SkyLight->SetFolderPath_Recursively("Omniverse/Preview");
		PreviewEnvironmentActors.Add(SkyLight);
		// Add Directional Light
		auto DirectionalLight = World->SpawnActor<ADirectionalLight>();
		DirectionalLight->SetActorRotation(FRotator(-31.341522f, -53.587574f, -51.27301f));
		// Make the directional light movable
		DirectionalLight->GetLightComponent()->Mobility = EComponentMobility::Movable;
		DirectionalLight->SetFolderPath_Recursively("Omniverse/Preview");
		PreviewEnvironmentActors.Add(DirectionalLight);
	}
}

bool AOmniverseStageActor::GetUserResponse(const FString& PkgPath)
{
	EAppReturnType::Type UserResponse;
	if (ImportOverwriteStatus == 1)
	{
		UserResponse = EAppReturnType::YesAll;
	}
	else if (ImportOverwriteStatus == 2)
	{
		UserResponse = EAppReturnType::NoAll;
	}
	else
	{
		UserResponse = FMessageDialog::Open(
			EAppMsgType::YesNoYesAllNoAll,
			FText::Format(LOCTEXT("ImportAssetAlreadyExists", "Do you want to overwrite the existing asset?\n\nAn asset already exists at the import location: {0}"), FText::FromString(PkgPath)));
				
		ImportOverwriteStatus = UserResponse == EAppReturnType::YesAll ? 1 : (UserResponse == EAppReturnType::NoAll ? 2 : 0);
	}

	return (UserResponse == EAppReturnType::No || UserResponse == EAppReturnType::NoAll);
}

const FString* AOmniverseStageActor::FindPath(UObject* Object)
{
	// NOTE: Don't use FindKey because Object is weak ptr, it compares weakptr, not raw ptr itself.
	for (auto& PairIt : USDPathToObject)
	{
		if (PairIt.Value.IsValid() && PairIt.Value.Get() == Object)
		{
			return &PairIt.Key;
		}
	}

	return nullptr;
}
#undef LOCTEXT_NAMESPACE