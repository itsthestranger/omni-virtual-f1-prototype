// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseUSDImporter.h"
#include "USDConverter.h"
#include "OmniverseUSDHelper.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Extractors/TimeSamplesData.h"
#include "GenericPlatform/GenericPlatformMisc.h"
#include "Misc/MessageDialog.h"
#include "Editor.h"
#include "OmniverseStageActor.h"
#include "OmniverseTexture.h"
#include "OmniversePathHelper.h"
#include "OmniverseSettings.h"
#include "UObject/GarbageCollection.h"
#include "Rendering/SkeletalMeshLODImporterData.h"
#include "USDHashGenerator.h"
#include "USDDerivedDataCache.h"
#include "OmniverseAssetImportHelper.h"
#include "OmniverseMDL.h"
#include "OmniverseUSDImporterHelper.h"
#include "OmniverseUSDTokens.h"
#include "OmniversePackageReader.h"
#include "OmniverseUSDLog.h"
#include "ComponentRecreateRenderStateContext.h"
#include "Materials/Material.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstance.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialExpressionTextureObject.h"
#include "Materials/MaterialExpressionTextureObjectParameter.h"
#include "Animation/AnimSequence.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/StaticMesh.h"

DECLARE_LOG_CATEGORY_EXTERN(LogOmniverseImporter, Log, All);
DEFINE_LOG_CATEGORY(LogOmniverseImporter);
#define LOCTEXT_NAMESPACE "OmniverseEditor"

#define ASSET_FLAGS (EObjectFlags::RF_Standalone | EObjectFlags::RF_Public)

bool FOmniverseUSDImporter::LoadUSD(const FString& Path, const FString& DestinationPath, const FOmniverseImportSettings& ImportSettings)
{
	GEditor->CreateNewMapForEditing();

	auto& World = *GEditor->GetEditorWorldContext().World();
	auto& StageActor = AOmniverseStageActor::Get(World);
	StageActor.SetUSD(nullptr, false);
	StageActor.InitializePreviewEnvironment();
	StageActor.ImportUSD(Path, DestinationPath, ImportSettings);
	World.DestroyActor(&StageActor, false, false);
	CollectGarbage( GARBAGE_COLLECTION_KEEPFLAGS );
	return true;
}

template<typename T>
bool GetAssetImportData(UObject* Object, FString& AbsolutePath, FString& PrimPath, FString& SubPrimPath)
{
	if (Object && Object->IsA<T>())
	{
		T* TObject = Cast<T>(Object);
		if (TObject->AssetImportData && TObject->AssetImportData->IsA<UOmniverseAssetImportData>())
		{
			auto OmniAssetImportData = Cast<UOmniverseAssetImportData>(TObject->AssetImportData);
			AbsolutePath = OmniAssetImportData->SourceData.SourceFiles.Num() > 0 ? OmniAssetImportData->SourceData.SourceFiles[0].RelativeFilename : FString();
			if (!FOmniversePathHelper::IsOmniPath(AbsolutePath))
			{
				AbsolutePath = FPaths::ConvertRelativePathToFull(AbsolutePath);
			}
			PrimPath = OmniAssetImportData->PrimPath;
			SubPrimPath = OmniAssetImportData->SubPrimPath;
			return true;
		}
	}
	return false;
}

// Special for Skeletal Mesh, it has warning for using AssetImportData directly
bool GetSkeletalMeshAssetImportData(UObject* Object, FString& AbsolutePath, FString& PrimPath, FString& SubPrimPath)
{
	if (Object && Object->IsA<USkeletalMesh>())
	{
		USkeletalMesh* TObject = Cast<USkeletalMesh>(Object);
		if (TObject->GetAssetImportData() && TObject->GetAssetImportData()->IsA<UOmniverseAssetImportData>())
		{
			auto OmniAssetImportData = Cast<UOmniverseAssetImportData>(TObject->GetAssetImportData());
			AbsolutePath = OmniAssetImportData->SourceData.SourceFiles.Num() > 0 ? OmniAssetImportData->SourceData.SourceFiles[0].RelativeFilename : FString();
			if (!FOmniversePathHelper::IsOmniPath(AbsolutePath))
			{
				AbsolutePath = FPaths::ConvertRelativePathToFull(AbsolutePath);
			}
			PrimPath = OmniAssetImportData->PrimPath;
			SubPrimPath = OmniAssetImportData->SubPrimPath;
			return true;
		}
	}
	return false;
}

void SaveExistingMaterials(UStaticMesh* StaticMesh, TMap<FString, UMaterialInterface*>& ExistingMaterials)
{
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
	for (const FStaticMaterial& StaticMaterial : StaticMesh->StaticMaterials)
#else
	for (const FStaticMaterial& StaticMaterial : StaticMesh->GetStaticMaterials())
#endif
	{
		FString AbsolutePath;
		FString PrimPath;
		FString SubPrimPath;
		if (GetAssetImportData<UMaterialInterface>(StaticMaterial.MaterialInterface, AbsolutePath, PrimPath, SubPrimPath))
		{
			ExistingMaterials.FindOrAdd(PrimPath, StaticMaterial.MaterialInterface);
		}
	}
}

void SaveExistingMaterials(USkeletalMesh* SkeletalMesh, TMap<FString, UMaterialInterface*>& ExistingMaterials)
{
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
	for (const FSkeletalMaterial& SkeletalMaterial : SkeletalMesh->Materials)
#else
	for (const FSkeletalMaterial& SkeletalMaterial : SkeletalMesh->GetMaterials())
#endif
	{
		FString AbsolutePath;
		FString PrimPath;
		FString SubPrimPath;
		if (GetAssetImportData<UMaterialInterface>(SkeletalMaterial.MaterialInterface, AbsolutePath, PrimPath, SubPrimPath))
		{
			ExistingMaterials.FindOrAdd(PrimPath, SkeletalMaterial.MaterialInterface);
		}
	}
}

UMaterialInterface* FOmniverseUSDImporter::ReimportMaterial(const TMap<FString, UMaterialInterface*>& ExistingMaterials, UObject* ParentPackage, const pxr::UsdShadeShader& Shader, const pxr::UsdShadeShader& MdlShader)
{
	auto ReimportShader = [&](const pxr::UsdShadeShader& InShader, bool bPreviewSurfaceEnabled)
	{
		UMaterialInterface* Mat = nullptr;
		TMap<FString, UTexture*> ExistingTextures;
		auto USDMaterial = FindShadeMaterial(InShader.GetPrim());
		FString MaterialPrimName = USDMaterial.GetPrim().GetName().GetText();
		auto MaterialInstPrimName = MaterialPrimName + TEXT("_Instance");
		FString PkgPath = FPaths::Combine(FPaths::GetPath(ParentPackage->GetName()), TEXT("Materials"), MaterialInstPrimName);
		auto Package = CreatePackage(*PkgPath);
		Package->FullyLoad();
		const auto ShaderID = GetUSDValue<pxr::TfToken>(InShader.GetIdAttr());
		if (InShader.GetPrim().HasAPI<pxr::UsdUINodeGraphNodeAPI>())
		{
			Mat = ReimportMaterialGraph(InShader, Package, *MaterialInstPrimName, nullptr, ExistingTextures);
		}
		else if (bPreviewSurfaceEnabled && ShaderID == USDTokens.previewSurface)
		{
			Mat = ReimportPreviewSurface(InShader, Package, *MaterialInstPrimName, ExistingTextures);
		}
		else
		{
			Mat = ReimportMDLSchema(InShader, Package, *MaterialInstPrimName, nullptr, ExistingTextures);
		}

		if (Mat)
		{
			FString RootLayerFile = InShader.GetPrim().GetStage()->GetRootLayer()->GetIdentifier().c_str();
			FOmniverseAssetImportHelper::UpdateAssetImportData(Mat, RootLayerFile, InShader.GetPath().GetText());
			FAssetRegistryModule::AssetCreated(Mat);
		}

		return Mat;
	};

	UMaterialInterface* Mat = nullptr;
	const bool bRenderMDLPriority = GetDefault<UOmniverseSettings>()->RenderContext == ERenderContext::ERC_MDL;
	if (bRenderMDLPriority)
	{
		// Try load mdl at first
		if (MdlShader)
		{
			auto ExistingMaterial = ExistingMaterials.Find(MdlShader.GetPath().GetText());
			if (ExistingMaterial)
			{
				Reimport(*ExistingMaterial);
				Mat = *ExistingMaterial;
			}
			else
			{
				Mat = ReimportShader(MdlShader, false);
			}
		}

		// No mdl is loaded, try preview surface
		if (Mat == nullptr && Shader)
		{
			auto ExistingMaterial = ExistingMaterials.Find(Shader.GetPath().GetText());
			if (ExistingMaterial)
			{
				Reimport(*ExistingMaterial);
				Mat = *ExistingMaterial;
			}
			else
			{
				Mat = ReimportShader(Shader, true);
			}
		}
	}
	else
	{
		// Try preview surface at first
		if (Shader)
		{
			auto ExistingMaterial = ExistingMaterials.Find(Shader.GetPath().GetText());
			if (ExistingMaterial)
			{
				Reimport(*ExistingMaterial);
				Mat = *ExistingMaterial;
			}
			else
			{
				Mat = ReimportShader(Shader, true);
			}
		}

		if (Mat == nullptr && MdlShader)
		{
			auto ExistingMaterial = ExistingMaterials.Find(MdlShader.GetPath().GetText());
			if (ExistingMaterial)
			{
				Reimport(*ExistingMaterial);
				Mat = *ExistingMaterial;
			}
			else
			{
				Mat = ReimportShader(MdlShader, false);
			}
		}
	}

	return Mat;
}

UMaterialInterface* FOmniverseUSDImporter::ReimportMaterial(const TMap<FString, UMaterialInterface*>& ExistingMaterials, UObject* ParentPackage, const pxr::UsdGeomSubset& USDSubset)
{
	pxr::TfToken FamilyName;
	if (!USDSubset.GetFamilyNameAttr().Get(&FamilyName) || FamilyName != pxr::UsdShadeTokens->materialBind)
	{
		// Add warning instead of not loading material
		UE_LOG(LogOmniverseUsd, Warning, L"%s: Material bindings authored on GeomSubsets are honored by renderers only if their familyName is UsdShadeTokens->materialBind", *FString(USDSubset.GetPath().GetText()));
	}

	FUSDConversion::FMaterialBinding MaterialBinding = FUSDConversion::ParsePrimMaterial(USDSubset.GetPrim());
	if (MaterialBinding.Material)
	{
		return ReimportMaterial(ExistingMaterials, ParentPackage, MaterialBinding.Shader, MaterialBinding.MdlSurfaceShader);
	}
	return nullptr;
}

UMaterialInterface* FOmniverseUSDImporter::ReimportMaterial(const TMap<FString, UMaterialInterface*>& ExistingMaterials, UObject* ParentPackage, const pxr::UsdGeomMesh& USDMesh)
{
	FUSDConversion::FMaterialBinding MaterialBinding = FUSDConversion::ParsePrimMaterial(USDMesh.GetPrim());
	if (MaterialBinding.Material)
	{
		return ReimportMaterial(ExistingMaterials, ParentPackage, MaterialBinding.Shader, MaterialBinding.MdlSurfaceShader);
	}

	return nullptr;
}

bool FOmniverseUSDImporter::Reimport(UStaticMesh* StaticMesh, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath)
{
	auto ImportUSDStage = FOmniverseUSDHelper::LoadUSDStageFromPath(AbsolutePath);
	if (ImportUSDStage)
	{
		pxr::UsdGeomMesh Mesh = pxr::UsdGeomMesh(ImportUSDStage->GetPrimAtPath(pxr::SdfPath(TCHAR_TO_UTF8(*PrimPath))));
		if (Mesh)
		{
			TIndirectArray<FComponentReregisterContext> ComponentReregisterContexts;
			for (TObjectIterator<UStaticMeshComponent> It; It; ++It)
			{
				UStaticMeshComponent* Comp = *It;
				if (Comp->GetStaticMesh() == StaticMesh)
				{
					ComponentReregisterContexts.Add(new FComponentReregisterContext(Comp));
				}
			}
			FlushRenderingCommands();
			
			TMap<FString, UMaterialInterface*> ExistingMaterials;
			SaveExistingMaterials(StaticMesh, ExistingMaterials);

			StaticMesh->PreEditChange(NULL);
			auto NewStaticMesh = FOmniverseUSDImporterHelper::CreateStaticMesh(Mesh, StaticMesh->GetOutermost(), StaticMesh->GetFName(), ASSET_FLAGS);				
			if (NewStaticMesh)
			{
				auto Subsets = pxr::UsdGeomSubset::GetAllGeomSubsets(Mesh);
				if (!Subsets.empty())
				{
					for (int32 SubsetIndex = 0; SubsetIndex < Subsets.size(); ++SubsetIndex)
					{
						auto MaterialInterface = ReimportMaterial(ExistingMaterials, StaticMesh->GetOutermost(), Subsets[SubsetIndex]);
						if (MaterialInterface)
						{
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
							StaticMesh->StaticMaterials[SubsetIndex].MaterialInterface = MaterialInterface;
#else
								StaticMesh->GetStaticMaterials()[SubsetIndex].MaterialInterface = MaterialInterface;
#endif
						}
					}
				}
				else
				{
					auto MaterialInterface = ReimportMaterial(ExistingMaterials, StaticMesh->GetOutermost(), Mesh);
					if (MaterialInterface)
					{
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
						StaticMesh->StaticMaterials[0].MaterialInterface = MaterialInterface;
#else
						StaticMesh->GetStaticMaterials()[0].MaterialInterface = MaterialInterface;
#endif
					}
				}

				FOmniverseAssetImportHelper::UpdateAssetImportData(NewStaticMesh, AbsolutePath, PrimPath, SubPrimPath);
				return true;
			}
		}
	}

	return false;
}

bool FOmniverseUSDImporter::Reimport(USkeletalMesh* SkeletalMesh, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath)
{
	auto ImportUSDStage = FOmniverseUSDHelper::LoadUSDStageFromPath(AbsolutePath);
	if (ImportUSDStage)
	{
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
		auto Skeleton = SkeletalMesh->Skeleton;
#else
		auto Skeleton = SkeletalMesh->GetSkeleton();
#endif
		auto USDSkelRoot = pxr::UsdSkelRoot(ImportUSDStage->GetPrimAtPath(pxr::SdfPath(TCHAR_TO_UTF8(*PrimPath))));
		if (!USDSkelRoot)
		{
			return false;
		}
	
		pxr::UsdSkelCache USDSkelCache;
		std::vector< pxr::UsdSkelBinding > USDSkeletonBindings;

#if PXR_VERSION >= 2011
		USDSkelCache.Populate(USDSkelRoot, pxr::UsdTraverseInstanceProxies());
		USDSkelCache.ComputeSkelBindings(USDSkelRoot, &USDSkeletonBindings, pxr::UsdTraverseInstanceProxies());
#else
		USDSkelCache.Populate(USDSkelRoot);
		USDSkelCache.ComputeSkelBindings(USDSkelRoot, &USDSkeletonBindings);
#endif //PXR_VERSION >= 2011

		// Skeletal mesh not support multiple root skeletons, having to separate them into several skeletal meshes.
		for (auto SkeletonBinding : USDSkeletonBindings)
		{
			const pxr::UsdSkelSkeleton& USDSkeleton = SkeletonBinding.GetSkeleton();
			pxr::UsdSkelSkeletonQuery SkelQuery = USDSkelCache.GetSkelQuery(USDSkeleton);

			if (SubPrimPath.Equals(USDSkeleton.GetPath().GetText()))
			{
				FSHAHash NewHash = FUSDHashGenerator::ComputeSHAHash(USDSkelCache, SkeletonBinding);
				FString NewHashString = NewHash.ToString();
				FSkeletalMeshImportData SkeletalMeshImportData;
				UsdUtils::FBlendShapeMap BlendShapesByPath;
				TSet<FString> UsedMorphTargetNames;
				bool HasBlendShapes = false;
				if (!FUSDDerivedDataCache::Load(NewHashString, SkeletalMeshImportData, HasBlendShapes))
				{
					if (!FOmniverseUSDImporterHelper::USDImportSkeleton(SkelQuery, SkeletalMeshImportData))
					{
						continue;
					}

					for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
					{
						pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
						if (SkinningMesh)
						{
							uint32 NumPointsBeforeThisMesh = static_cast<uint32>(SkeletalMeshImportData.Points.Num());
							FOmniverseUSDImporterHelper::USDImportSkinning(SkelQuery, SkinningQuery, SkeletalMeshImportData);
							FOmniverseUSDImporterHelper::USDImportBlendShapes(SkinningQuery, NumPointsBeforeThisMesh, BlendShapesByPath, UsedMorphTargetNames);
						}
					}

					HasBlendShapes = BlendShapesByPath.Num() > 0;
					FUSDDerivedDataCache::Save(NewHashString, SkeletalMeshImportData, HasBlendShapes);
				}

				if (HasBlendShapes && BlendShapesByPath.IsEmpty())
				{
					uint32 NumPointsBeforeThisMesh = 0;
					for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
					{
						pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
						if (SkinningMesh)
						{
							FOmniverseUSDImporterHelper::USDImportBlendShapes(SkinningQuery, NumPointsBeforeThisMesh, BlendShapesByPath, UsedMorphTargetNames);
							auto Points = GetUSDValue<pxr::VtArray<pxr::GfVec3f>>(SkinningMesh.GetPointsAttr());
							NumPointsBeforeThisMesh += Points.size();
						}
					}
				}

				FlushRenderingCommands();
				FScopedSkeletalMeshPostEditChange ScopedPostEditChange(SkeletalMesh);

				TMap<FString, UMaterialInterface*> ExistingMaterials;
				SaveExistingMaterials(SkeletalMesh, ExistingMaterials);

				SkeletalMesh->PreEditChange(nullptr);
				//Reimport must force a new guid
				SkeletalMesh->InvalidateDeriveDataCacheGUID();
					
				int32 PostEditChangeStackCounter = SkeletalMesh->GetPostEditChangeStackCounter();
				FString Name = SkeletalMesh->GetName();
				USkeletalMesh* NewSkeletalMesh = NewObject<USkeletalMesh>(SkeletalMesh->GetOutermost(), SkeletalMesh->GetFName(), ASSET_FLAGS);
				NewSkeletalMesh->SetPostEditChangeStackCounter(PostEditChangeStackCounter);

				FOmniverseAssetImportHelper::LoadSkeletalMeshFromImportData(NewSkeletalMesh, SkeletalMeshImportData, Name);

				if (NewSkeletalMesh)
				{
					int32 MaterialIndex = 0;
					for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
					{
						pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
					
						auto USDSubsets = pxr::UsdGeomSubset::GetAllGeomSubsets(SkinningMesh);
						if (!USDSubsets.empty())
						{
							for (auto USDSubset : USDSubsets)
							{
								auto MaterialInterface = ReimportMaterial(ExistingMaterials, NewSkeletalMesh->GetOutermost(), USDSubset);
								if (MaterialInterface)
								{
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
									NewSkeletalMesh->Materials[MaterialIndex].MaterialInterface = MaterialInterface;
#else
									NewSkeletalMesh->GetMaterials()[MaterialIndex].MaterialInterface = MaterialInterface;
#endif
								}
								++MaterialIndex;
							}	
						}
						else
						{
							auto MaterialInterface = ReimportMaterial(ExistingMaterials, NewSkeletalMesh->GetOutermost(), SkinningMesh);
							if (MaterialInterface)
							{
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
								NewSkeletalMesh->Materials[MaterialIndex].MaterialInterface = MaterialInterface;
#else
								NewSkeletalMesh->GetMaterials()[MaterialIndex].MaterialInterface = MaterialInterface;
#endif
							}
							++MaterialIndex;
						}
					}

					//Skeleton = NewObject<USkeleton>(Skeleton->GetOutermost(), Skeleton->GetFName(), ASSET_FLAGS);
					//Skeleton->SetPreviewMesh(NewSkeletalMesh);
					//Skeleton->MergeAllBonesToBoneTree(NewSkeletalMesh);
							
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
					NewSkeletalMesh->Skeleton = Skeleton;
#else
					NewSkeletalMesh->SetSkeleton(Skeleton);
#endif
					FOmniverseAssetImportHelper::UpdateSkeletalMeshAssetImportData(NewSkeletalMesh, AbsolutePath, PrimPath, SubPrimPath);
					return true;
				}					
			}
		}
	}
	return false;
}

bool FOmniverseUSDImporter::Reimport(UAnimSequence* AnimSequence, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath)
{
	auto ImportUSDStage = FOmniverseUSDHelper::LoadUSDStageFromPath(AbsolutePath);
	if (ImportUSDStage)
	{
		auto USDSkelRoot = pxr::UsdSkelRoot(ImportUSDStage->GetPrimAtPath(pxr::SdfPath(TCHAR_TO_UTF8(*PrimPath))));
		if (!USDSkelRoot)
		{
			return false;
		}
	
		pxr::UsdSkelCache USDSkelCache;
		std::vector< pxr::UsdSkelBinding > USDSkeletonBindings;

#if PXR_VERSION >= 2011
		USDSkelCache.Populate(USDSkelRoot, pxr::UsdTraverseInstanceProxies());
		USDSkelCache.ComputeSkelBindings(USDSkelRoot, &USDSkeletonBindings, pxr::UsdTraverseInstanceProxies());
#else
		USDSkelCache.Populate(USDSkelRoot);
		USDSkelCache.ComputeSkelBindings(USDSkelRoot, &USDSkeletonBindings);
#endif //PXR_VERSION >= 2011

		// Skeletal mesh not support multiple root skeletons, having to separate them into several skeletal meshes.
		for (auto SkeletonBinding : USDSkeletonBindings)
		{
			const pxr::UsdSkelSkeleton& USDSkeleton = SkeletonBinding.GetSkeleton();
			pxr::UsdSkelSkeletonQuery SkelQuery = USDSkelCache.GetSkelQuery(USDSkeleton);

			if (SubPrimPath.Equals(SkelQuery.GetPrim().GetPath().GetText()))
			{
				FlushRenderingCommands();
				pxr::SdfLayerRefPtr RootLayer = ImportUSDStage->GetRootLayer();
				double TimeCodesPerSecond = RootLayer->HasTimeCodesPerSecond() ? RootLayer->GetTimeCodesPerSecond() : (RootLayer->HasFramesPerSecond() ? RootLayer->GetFramesPerSecond() : DEFAULT_TIMECODESPERSECOND);
				double StartTimeCode = RootLayer->HasStartTimeCode() ? RootLayer->GetStartTimeCode() : DEFAULT_STARTTIMECODE;
				double EndTimeCode = RootLayer->HasEndTimeCode() ? RootLayer->GetEndTimeCode() : 0.0;

				auto Skeleton = AnimSequence->GetSkeleton();
				auto PreviewMesh = AnimSequence->GetPreviewMesh();

				// Check if there're blendshapes, only supports reimporting, can't be serialized
				FSkeletalMeshImportData SkeletalMeshImportData;
				UsdUtils::FBlendShapeMap BlendShapesByPath;
				TSet<FString> UsedMorphTargetNames;
				bool HasBlendShapes = false;
				FSHAHash NewHash = FUSDHashGenerator::ComputeSHAHash(USDSkelCache, SkeletonBinding);
				if (FUSDDerivedDataCache::Load(NewHash.ToString(), SkeletalMeshImportData, HasBlendShapes))
				{
					if (HasBlendShapes)
					{
						// Blendshapes can't be serialized, have to be reloaded
						uint32 NumPointsBeforeThisMesh = 0;
						for (const pxr::UsdSkelSkinningQuery& SkinningQuery : SkeletonBinding.GetSkinningTargets())
						{
							pxr::UsdGeomMesh SkinningMesh = pxr::UsdGeomMesh(SkinningQuery.GetPrim());
							if (SkinningMesh)
							{
								FOmniverseUSDImporterHelper::USDImportBlendShapes(SkinningQuery, NumPointsBeforeThisMesh, BlendShapesByPath, UsedMorphTargetNames);
								auto Points = GetUSDValue<pxr::VtArray<pxr::GfVec3f>>(SkinningMesh.GetPointsAttr());
								NumPointsBeforeThisMesh += Points.size();
							}
						}
					}
				}

				float StartOffsetSeconds = 0.0f;
				auto NewSequence = FOmniverseUSDImporterHelper::CreateAnimSequence(SkelQuery, SkeletonBinding, BlendShapesByPath.Num() > 0 ? &BlendShapesByPath : nullptr, AnimSequence->GetOutermost(), AnimSequence->GetFName(), ASSET_FLAGS, Skeleton, PreviewMesh, StartTimeCode, EndTimeCode, StartOffsetSeconds);
				if (NewSequence)
				{
					FOmniverseAssetImportHelper::UpdateAssetImportData(NewSequence, AbsolutePath, PrimPath, SubPrimPath);				
					return true;
				}
			}
		}
	}

	return false;
}

bool FOmniverseUSDImporter::Reimport(UTexture* Texture, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath)
{
	FlushRenderingCommands();
	bool SRGB = Texture->SRGB;
	auto CompressionSettings = Texture->CompressionSettings;
	UTexture* NewTexture = nullptr;
	if (FOmniversePathHelper::IsPackagePath(AbsolutePath))
	{
		pxr::ArResolver& resolver = pxr::ArGetResolver();

#if !defined(AR_VERSION) || AR_VERSION < 2
		auto Asset = resolver.OpenAsset(TCHAR_TO_UTF8(*AbsolutePath));
#else
		auto Asset = resolver.OpenAsset(pxr::ArResolvedPath(TCHAR_TO_UTF8(*AbsolutePath)));
#endif // AR_VERSION < 2
		
		if (Asset && Asset->GetSize() > 0)
		{
			uint8* Buffer = new uint8[Asset->GetSize()];
			Asset->Read(Buffer, Asset->GetSize(), 0);
			NewTexture = UOmniverseTexture::CreateTextureFromBuffer(Buffer, Asset->GetSize(), Texture->GetOutermost(), Texture->GetFName(), ASSET_FLAGS, AbsolutePath);
			delete[] Buffer;
		}
	}
	else
	{
		NewTexture = UOmniverseTexture::CreateTextureFromFile(AbsolutePath, Texture->GetOutermost(), Texture->GetFName(), ASSET_FLAGS);
	}

	if (NewTexture)
	{
		if (NewTexture->SRGB != SRGB || NewTexture->CompressionSettings != CompressionSettings)
		{
			NewTexture->SRGB = SRGB;
			NewTexture->CompressionSettings = CompressionSettings;
			NewTexture->PostEditChange();
		}
	}

	return NewTexture != nullptr;
}

UTexture* FOmniverseUSDImporter::ReimportTexture(const TMap<FString, UTexture*>& ExistingTextures, UObject* ParentPackage, const uint8* Content, uint64 Size, const FString& InTextureSouceFile)
{
	UTexture* OutTexture = nullptr;
	FString TextureSouceFile = InTextureSouceFile;
	if (!FOmniversePathHelper::IsOmniPath(TextureSouceFile))
	{
		TextureSouceFile = FPaths::ConvertRelativePathToFull(TextureSouceFile);
	}

	auto ExistingTexture = ExistingTextures.Find(TextureSouceFile);
	if (ExistingTexture)
	{
		Reimport(*ExistingTexture);
		OutTexture = *ExistingTexture;
	}
	else
	{
		FString TextureFileName = TextureSouceFile;
		if (FOmniversePathHelper::IsPackagePath(TextureSouceFile))
		{
			TextureFileName = FOmniversePathHelper::GetPackagedSubPath(TextureSouceFile);
		}
		FString TextureName = FPaths::GetBaseFilename(TextureFileName);
		FOmniversePathHelper::FixAssetName(TextureName);
	
		FString PkgPath = FPaths::Combine(FPaths::GetPath(ParentPackage->GetName()), TEXT("Textures"), TextureName);
		auto Package = CreatePackage(*PkgPath);
		Package->FullyLoad();
		OutTexture = UOmniverseTexture::CreateTextureFromBuffer(Content, Size, Package, *TextureName, ASSET_FLAGS, TextureSouceFile);
	}

	return OutTexture;
}

UMaterialInterface* FOmniverseUSDImporter::ReimportPreviewSurface(const pxr::UsdShadeShader& ShadeShader, UObject* InOuter, FName Name, const TMap<FString, UTexture*>& ExistingTextures)
{
	auto NewMaterialInstance = NewObject<UMaterialInstanceConstant>(InOuter, Name, ASSET_FLAGS);
	if (NewMaterialInstance)
	{
		// NOTE: Must recreate render state after the instance was reimported.
		FGlobalComponentRecreateRenderStateContext RecreateComponentsRenderState;

		UMaterial* PreviewSurfaceMaterial = LoadObject<UMaterial>(nullptr, TEXT("/Omniverse/PreviewSurfaceMaterial"));
		NewMaterialInstance->SetParentEditorOnly(PreviewSurfaceMaterial);
		FOmniverseUSDImporterHelper::UpdatePreviewSurfaceInputs(NewMaterialInstance, ShadeShader, nullptr, nullptr,
		[&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
		{
			OutTexture = ReimportTexture(ExistingTextures, InOuter, Content, Size, FileName);
		});

		NewMaterialInstance->PostEditChange();
		NewMaterialInstance->MarkPackageDirty();
	}
	return NewMaterialInstance;
}

UMaterialInterface* FOmniverseUSDImporter::ReimportMDLSchema(const pxr::UsdShadeShader& ShadeShader, UObject* InOuter, FName Name, UMaterialInterface* MaterialInterface, const TMap<FString, UTexture*>& ExistingTextures)
{
	UMaterialInstanceConstant* MaterialInstance = Cast<UMaterialInstanceConstant>(MaterialInterface);
	UMaterialInterface* ParentMaterial = nullptr;
	FString MdlPath, MdlName;
	bool bRelativePath = false;
	bool bIsLocalCore = false;
	if (FOmniverseUSDImporterHelper::GetMdlPathAndName(ShadeShader, MdlPath, MdlName, bRelativePath))
	{
		// NOTE: Material Name could be with parameters
		MdlPath.ReplaceInline(TEXT("\\"), TEXT("/"));
		FString MaterialName = MdlName;
		int32 ParamStart = MaterialName.Find(TEXT("("));
		if (ParamStart != INDEX_NONE)
		{
			MaterialName = MaterialName.Left(ParamStart);
		}
		if (UOmniverseMDL::IsLocalBaseMDL(MdlPath))
		{
			ParentMaterial = UOmniverseMDL::LoadLocalBaseMDL(MdlPath, MaterialName);
			bIsLocalCore = true;
		}
		else if (FOmniversePathHelper::IsPackagePath(MdlPath))
		{
			auto PackageMDLFile = FOmniversePathHelper::GetPackagedSubPath(MdlPath);
			FString ModuleName = FPaths::GetPath(PackageMDLFile) / FPaths::GetBaseFilename(PackageMDLFile);
			ModuleName.ReplaceInline(TEXT("/"), TEXT("::"));
			if (!ModuleName.StartsWith(TEXT("::")))
			{
				ModuleName = TEXT("::") + ModuleName;
			}

			FString AbsolutePath;
			FString PrimPath;
			FString SubPrimPath;
			if (MaterialInstance)
			{
				GetAssetImportData<UMaterialInterface>(MaterialInstance->Parent, AbsolutePath, PrimPath, SubPrimPath);
			}
			
			// Compare if needs to reimport
			if (AbsolutePath.Equals(MdlPath) && PrimPath.Equals(ModuleName) && SubPrimPath.Equals(MaterialName))
			{
				Reimport(MaterialInstance->Parent);
				ParentMaterial = MaterialInstance->Parent;
			}
			else
			{
				FString PkgPath = FPaths::Combine(FPaths::GetPath(InOuter->GetName()), MaterialName);
				auto Package = CreatePackage(*PkgPath);
				Package->FullyLoad();
				ParentMaterial = ReimportMDL(Package, *MaterialName, PackageMDLFile, ModuleName, MaterialName, ExistingTextures);
			}
		}
		else
		{
			FString UserName;
			FString Server;
			FString AssetPath;
			FString Branch;
			FString CheckPoint;
			FOmniversePathHelper::SplitUrlPath(MdlPath, UserName, Server, AssetPath, Branch, CheckPoint);
			FString ModuleName = FPaths::GetPath(AssetPath) / FPaths::GetBaseFilename(AssetPath);
			int32 Colon = ModuleName.Find(TEXT(":"));
			if (Colon != INDEX_NONE)
			{
				ModuleName = ModuleName.RightChop(Colon + 1);
			}
			ModuleName.ReplaceInline(TEXT("/"), TEXT("::"));

			FString AbsolutePath;
			FString PrimPath;
			FString SubPrimPath;
			if (MaterialInstance)
			{
				GetAssetImportData<UMaterialInterface>(MaterialInstance->Parent, AbsolutePath, PrimPath, SubPrimPath);
			}

			if (AbsolutePath.Equals(MdlPath) && PrimPath.Equals(ModuleName) && SubPrimPath.Equals(MaterialName))
			{
				Reimport(MaterialInstance->Parent);
				ParentMaterial = MaterialInstance->Parent;
			}
			else
			{
				FString PkgPath = FPaths::Combine(FPaths::GetPath(InOuter->GetName()), MaterialName);
				auto Package = CreatePackage(*PkgPath);
				Package->FullyLoad();

				ParentMaterial = ReimportMDL(Package, *MaterialName, MdlPath, ModuleName, MaterialName, ExistingTextures);
			}
		}
	}

	auto NewMaterialInstance = NewObject<UMaterialInstanceConstant>(InOuter, Name, ASSET_FLAGS);
	if (NewMaterialInstance)
	{
		// NOTE: Must recreate render state after the instance was reimported.
		FGlobalComponentRecreateRenderStateContext RecreateComponentsRenderState;
		NewMaterialInstance->SetParentEditorOnly(ParentMaterial);
		std::vector<pxr::UsdShadeInput> Inputs = ShadeShader.GetInputs();
		for(auto Input : Inputs)
		{
			FString DisplayName;
			auto ConnectInput = Input;
			if (Input.HasConnectedSource())
			{
				pxr::UsdShadeConnectableAPI Source;
				pxr::TfToken SourceName;
				pxr::UsdShadeAttributeType SourceType;
				Input.GetConnectedSource(&Source, &SourceName, &SourceType);
								    
				ConnectInput = Source.GetInput(SourceName);
			}

			if (bIsLocalCore)
			{
				UOmniverseMDL::GetDisplayNameFromLocalBaseMDL(ParentMaterial->GetName(), ConnectInput.GetBaseName().GetText(), DisplayName);
			}
			else
			{
				UOmniverseMDL::GetImportDisplayName(ParentMaterial->GetName(), ConnectInput.GetBaseName().GetText(), DisplayName);
			}

			if (!DisplayName.IsEmpty())
			{
				FOmniverseUSDImporterHelper::LoadMdlInput(*NewMaterialInstance, ConnectInput, DisplayName, false, [&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
				{
					OutTexture = ReimportTexture(ExistingTextures, InOuter, Content, Size, FileName);
				});
			}
		}

		NewMaterialInstance->PostEditChange();
		NewMaterialInstance->MarkPackageDirty();
	}
	return NewMaterialInstance;
}

UMaterialInterface* FOmniverseUSDImporter::ReimportMaterialGraph(const pxr::UsdShadeShader& ShadeShader, UObject* InOuter, FName Name, UMaterialInterface* MaterialInterface, const TMap<FString, UTexture*>& ExistingTextures)
{
	if (Cast<UMaterial>(MaterialInterface))
	{
		auto NewMaterial = NewObject<UMaterial>(InOuter, Name, ASSET_FLAGS);
		if (NewMaterial)
		{
			FOmniverseUSDImporterHelper::LoadMaterialGraph(ShadeShader, NewMaterial);
		}
		return NewMaterial;
	}
	

	// Update Material Graph
	UMaterialInterface* ParentMaterial = nullptr;
	UMaterialInstanceConstant* MaterialInstance = Cast<UMaterialInstanceConstant>(MaterialInterface);
	auto USDMaterial = FindShadeMaterial(ShadeShader.GetPrim());
	if (USDMaterial)
	{
		FString AbsolutePath;
		FString PrimPath;
		FString SubPrimPath;
		if (MaterialInstance)
		{
			GetAssetImportData<UMaterialInterface>(MaterialInstance->Parent, AbsolutePath, PrimPath, SubPrimPath);
		}

		if (PrimPath.Equals(ShadeShader.GetPath().GetText()))
		{
			Reimport(MaterialInstance->Parent);
			ParentMaterial = MaterialInstance->Parent;
		}
		else
		{
			FString MaterialName = USDMaterial.GetPrim().GetName().GetText();

			FString PkgPath = FPaths::Combine(FPaths::GetPath(InOuter->GetName()), MaterialName);
			auto Package = CreatePackage(*PkgPath);
			Package->FullyLoad();

			UMaterial* NewMaterial = NewObject<UMaterial>(Package, *MaterialName, ASSET_FLAGS);
			if (NewMaterial)
			{
				FString RootLayerFile = ShadeShader.GetPrim().GetStage()->GetRootLayer()->GetIdentifier().c_str();
				FOmniverseUSDImporterHelper::LoadMaterialGraph(ShadeShader, NewMaterial);
				FOmniverseAssetImportHelper::UpdateAssetImportData(NewMaterial, RootLayerFile, ShadeShader.GetPath().GetText());
				FAssetRegistryModule::AssetCreated(NewMaterial);
			}
			ParentMaterial = NewMaterial;
		}
	}

	auto NewMaterialInstance = NewObject<UMaterialInstanceConstant>(InOuter, Name, ASSET_FLAGS);
	if (NewMaterialInstance)
	{
		// NOTE: Must recreate render state after the instance was reimported.
		FGlobalComponentRecreateRenderStateContext RecreateComponentsRenderState;

		NewMaterialInstance->SetParentEditorOnly(ParentMaterial);
		FOmniverseUSDImporterHelper::UpdateMaterialGraphInputs(ShadeShader, NewMaterialInstance, [&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
		{
			OutTexture = ReimportTexture(ExistingTextures, InOuter, Content, Size, FileName);
		});

		NewMaterialInstance->PostEditChange();
		NewMaterialInstance->MarkPackageDirty();
	}
	return NewMaterialInstance;
}

UMaterialInterface* FOmniverseUSDImporter::ReimportMDL(UObject* InOuter, FName Name, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath, const TMap<FString, UTexture*>& ExistingTextures)
{
	if (FOmniversePathHelper::IsPackagePath(AbsolutePath))
	{
		TSharedPtr<FOmniversePackageReader> PackageReader = MakeShareable(new FOmniversePackageReader());
		PackageReader->SetPackageRoot(FOmniversePathHelper::GetPackageRoot(AbsolutePath));
		return UOmniverseMDL::ImportMDL(InOuter, PrimPath, SubPrimPath, {FOmniversePathHelper::GetPackageRoot(AbsolutePath)}, PackageReader, Name, ASSET_FLAGS, AbsolutePath, [&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
		{
			FString TextureSouceFile = FileName;
            if (FOmniversePathHelper::IsPackagePath(AbsolutePath))
			{
                auto PackageRoot = FOmniversePathHelper::GetPackageRoot(AbsolutePath);
                if (FileName.StartsWith(PackageRoot, ESearchCase::CaseSensitive))
                {
                    TextureSouceFile.RemoveAt(PackageRoot.Len());
                    TextureSouceFile.InsertAt(PackageRoot.Len(), "[");
                    TextureSouceFile.Append("]");
                }
			}
			OutTexture = ReimportTexture(ExistingTextures, InOuter, Content, Size, TextureSouceFile);
		});
	}
	else
	{
		FString UserName;
		FString Server;
		FString AssetPath;
		FString Branch;
		FString CheckPoint;
		FOmniversePathHelper::SplitUrlPath(AbsolutePath, UserName, Server, AssetPath, Branch, CheckPoint);

		TArray<FString> ModulePaths;
		if (!Server.IsEmpty())
		{
			if (AbsolutePath.StartsWith(TEXT("omniverse://")))
			{
				ModulePaths.Add(TEXT("omniverse://") + Server + TEXT("/"));
			}
			if (AbsolutePath.StartsWith(TEXT("https://")))
			{
				ModulePaths.Add(TEXT("https://") + Server + TEXT("/"));
			}
			if (AbsolutePath.StartsWith(TEXT("http://")))
			{
				ModulePaths.Add(TEXT("http://") + Server + TEXT("/"));
			}
		}
			
		return UOmniverseMDL::ImportMDL(InOuter, PrimPath, SubPrimPath, ModulePaths, nullptr, Name, ASSET_FLAGS, AbsolutePath, [&](const uint8* Content, uint64 Size, const FString& FileName, UTexture*& OutTexture)
		{
			OutTexture = ReimportTexture(ExistingTextures, InOuter, Content, Size, FileName);
		});
	}
}

void SaveExistingTextures(UMaterialInterface* MaterialInterface, TMap<FString, UTexture*>& ExistingTextures)
{
	if (MaterialInterface->IsA<UMaterialInstance>())
	{
		auto MaterialInstance = Cast<UMaterialInstance>(MaterialInterface);
		for (auto TextureParameter : MaterialInstance->TextureParameterValues)
		{
			FString AbsolutePath;
			FString PrimPath;
			FString SubPrimPath;
			if (GetAssetImportData<UTexture>(TextureParameter.ParameterValue, AbsolutePath, PrimPath, SubPrimPath))
			{
				ExistingTextures.FindOrAdd(AbsolutePath, TextureParameter.ParameterValue);
			}
		}
	}
	else if (MaterialInterface->IsA<UMaterial>())
	{
		auto Material = Cast<UMaterial>(MaterialInterface);
		for (auto Expression : Material->GetExpressions())
		{
			if (Expression->IsA<UMaterialExpressionTextureObject>())
			{
				auto TextureExpression = Cast<UMaterialExpressionTextureObject>(Expression);
				FString AbsolutePath;
				FString PrimPath;
				FString SubPrimPath;
				if (GetAssetImportData<UTexture>(TextureExpression->Texture, AbsolutePath, PrimPath, SubPrimPath))
				{
					ExistingTextures.FindOrAdd(AbsolutePath, TextureExpression->Texture);
				}
			}
			else if (Expression->IsA<UMaterialExpressionTextureObjectParameter>())
			{
				auto TextureExpression = Cast<UMaterialExpressionTextureObjectParameter>(Expression);
				FString AbsolutePath;
				FString PrimPath;
				FString SubPrimPath;
				if (GetAssetImportData<UTexture>(TextureExpression->Texture, AbsolutePath, PrimPath, SubPrimPath))
				{
					ExistingTextures.FindOrAdd(AbsolutePath, TextureExpression->Texture);
				}
			}
		}
	}
}

bool FOmniverseUSDImporter::Reimport(UMaterialInterface* MaterialInterface, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath)
{
	FString MdlPath = AbsolutePath;
	if (FOmniversePathHelper::IsPackagePath(AbsolutePath))
	{
		MdlPath = FOmniversePathHelper::GetPackagedSubPath(AbsolutePath);
	}

	TMap<FString, UTexture*> ExistingTextures;
	SaveExistingTextures(MaterialInterface, ExistingTextures);

	FlushRenderingCommands();

	UMaterialInterface* NewMaterial = nullptr;
	if (MdlPath.EndsWith(TEXT(".mdl")))
	{
		NewMaterial = ReimportMDL(MaterialInterface->GetOutermost(), MaterialInterface->GetFName(), AbsolutePath, PrimPath, SubPrimPath, ExistingTextures);
	}
	else
	{
		auto ImportUSDStage = FOmniverseUSDHelper::LoadUSDStageFromPath(AbsolutePath);
		if (ImportUSDStage)
		{
			pxr::UsdShadeShader ShadeShader = pxr::UsdShadeShader(ImportUSDStage->GetPrimAtPath(pxr::SdfPath(TCHAR_TO_UTF8(*PrimPath))));
			if (ShadeShader)
			{
				const auto ShaderID = GetUSDValue<pxr::TfToken>(ShadeShader.GetIdAttr());
				if (ShadeShader.GetPrim().HasAPI<pxr::UsdUINodeGraphNodeAPI>())
				{
					NewMaterial = ReimportMaterialGraph(ShadeShader, MaterialInterface->GetOutermost(), MaterialInterface->GetFName(), MaterialInterface, ExistingTextures);
				}
				else if (ShaderID == USDTokens.previewSurface)
				{
					NewMaterial = ReimportPreviewSurface(ShadeShader, MaterialInterface->GetOutermost(), MaterialInterface->GetFName(), ExistingTextures);
				}
				else
				{
					NewMaterial = ReimportMDLSchema(ShadeShader, MaterialInterface->GetOutermost(), MaterialInterface->GetFName(), MaterialInterface, ExistingTextures);
				}
			}
		}
	}	

	if (NewMaterial)
	{
		FOmniverseAssetImportHelper::UpdateAssetImportData(NewMaterial, AbsolutePath, PrimPath, SubPrimPath);
		return true;
	}

	return false;
}

bool FOmniverseUSDImporter::Reimport(UObject* Object)
{
	if (Object == nullptr)
	{
		return false;
	}

	FString AbsolutePath;
	FString PrimPath;
	FString SubPrimPath;
	if (GetAssetImportData<UStaticMesh>(Object, AbsolutePath, PrimPath, SubPrimPath))
	{
		return Reimport(Cast<UStaticMesh>(Object), AbsolutePath, PrimPath, SubPrimPath);
	}
	else if (GetSkeletalMeshAssetImportData(Object, AbsolutePath, PrimPath, SubPrimPath))
	{
		return Reimport(Cast<USkeletalMesh>(Object), AbsolutePath, PrimPath, SubPrimPath);
	}
	else if (GetAssetImportData<UAnimSequence>(Object, AbsolutePath, PrimPath, SubPrimPath))
	{
		return Reimport(Cast<UAnimSequence>(Object), AbsolutePath, PrimPath, SubPrimPath);
	}
	else if (GetAssetImportData<UMaterialInterface>(Object, AbsolutePath, PrimPath, SubPrimPath))
	{
		return Reimport(Cast<UMaterialInterface>(Object), AbsolutePath, PrimPath, SubPrimPath);
	}
	else if (GetAssetImportData<UTexture>(Object, AbsolutePath, PrimPath, SubPrimPath))
	{
		return Reimport(Cast<UTexture>(Object), AbsolutePath, PrimPath, SubPrimPath);
	}

	return false;
}

#undef LOCTEXT_NAMESPACE