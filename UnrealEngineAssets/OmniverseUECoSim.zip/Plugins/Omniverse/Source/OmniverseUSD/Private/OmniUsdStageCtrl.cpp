// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniUsdStageCtrl.h"
#include "USDCustomLayerData.h"
#include "OmniverseConnectionHelper.h"
#include "OmniversePathHelper.h"
#include "GenericPlatform/GenericPlatformFile.h"
#include "HAL/PlatformFilemanager.h"
#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING
#include <experimental/filesystem>
#undef _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING
namespace fs = std::experimental::filesystem;
#pragma warning(push)
#pragma warning(disable: 4244 4305 4003)
#include <pxr/usd/sdf/attributeSpec.h>
#include <pxr/usd/sdf/copyUtils.h>
#include <pxr/usd/usdGeom/imageable.h>
#pragma warning(pop)

static const pxr::TfToken customLayerData("customLayerData");

OmniUsdStageCtrl::OmniUsdStageCtrl(pxr::UsdStageRefPtr& stage)	
{
	remoteRootLayer = stage->GetRootLayer();
	sessionLayer = stage->GetSessionLayer();
	this->stage = stage;

	if (stageChangeNotice.IsValid())
	{
		pxr::TfNotice::Revoke(stageChangeNotice);
	}

	// Filter stage changes
	stageChangeNotice = pxr::TfNotice::Register(pxr::TfCreateWeakPtr(this), &OmniUsdStageCtrl::OnStageChanged, stage);

	// Init layer muteness map
	layerMutenessMap.empty();
	InitLayerMuteness(remoteRootLayer);
}

OmniUsdStageCtrl::~OmniUsdStageCtrl()
{
	pxr::TfNotice::Revoke(stageChangeNotice);
	remoteRootLayer.Reset();
	sessionLayer.Reset();
	liveLayer.Reset();
	subLayers.Reset();
}

static std::string NormalizePath(const std::string& path)
{
    static auto replaceAll = [](std::string str, const std::string& from, const std::string& to)
    {
        size_t start_pos = 0;
        while ((start_pos = str.find(from, start_pos)) != std::string::npos)
        {
            str.replace(start_pos, from.length(), to);
            start_pos += to.length(); // Handles case where 'to' is a substring of 'from'
        }
        return str;
    };

    std::string finalPath = path;
    // FIXME: Need a better way to normalize path.
    finalPath = replaceAll(finalPath, "%3C", "<");
    finalPath = replaceAll(finalPath, "%3E", ">");
    finalPath = replaceAll(finalPath, "%20", " ");
    finalPath = replaceAll(finalPath, "%5C", "/");
    std::replace(finalPath.begin(), finalPath.end(), '\\', '/');

    return finalPath;
}

static std::string ComputeAbsolutePath(const pxr::SdfLayerRefPtr& rootLayer, const std::string& path)
{
    if (pxr::SdfLayer::IsAnonymousLayerIdentifier(path) || rootLayer->IsAnonymous())
    {
        return path;
    }
    else
    {
        // Compute the path through the resolver
        const std::string& absolutePath = rootLayer->ComputeAbsolutePath(path);
        return NormalizePath(absolutePath);
    }
}

std::vector<std::string> LayerTraverse(const pxr::SdfLayerRefPtr& layer, const std::string& identifier)
{
	std::vector<std::string> layerList;
	layerList.push_back(identifier);

    if (layer)
	{
		for (auto subLayerPath : layer->GetSubLayerPaths())
		{
			auto sublayerIdentifier = layer->ComputeAbsolutePath(subLayerPath);
			auto subLayer = pxr::SdfLayer::FindOrOpen(sublayerIdentifier);
			auto sublayers = LayerTraverse(subLayer, sublayerIdentifier);
			layerList.insert(std::end(layerList), std::begin(sublayers), std::end(sublayers));
		}
	}

	return layerList;
}

void OmniUsdStageCtrl::InitLayerMuteness(const pxr::SdfLayerHandle& layer)
{
	if (layer)
	{
		auto SubLayerPaths = layer->GetSubLayerPaths();
		for (int LayerIndex = 0; LayerIndex < SubLayerPaths.size(); ++LayerIndex)
		{
			// Use global muteness to initialize
			std::string AbsolutePath = layer->ComputeAbsolutePath(SubLayerPaths[LayerIndex]);
			bool bMuteness = !GetSubLayerVisibility(AbsolutePath, true);
			layerMutenessMap[AbsolutePath] = pxr::VtValue(bMuteness);
			if (bMuteness)
			{
				stage->MuteLayer(AbsolutePath);
			}
			auto subLayer = pxr::SdfLayer::FindOrOpen(AbsolutePath);
			if (subLayer)
			{
				subLayers.Add(AbsolutePath.c_str(), subLayer);
				InitLayerMuteness(subLayer);
			}
		}
	}
}

bool OmniUsdStageCtrl::SetSubLayerVisibility(const std::string& identifier, bool visible, bool global)
{
	// Check if it's a valid sub layer path

	// switch the edit target
	if (!visible && stage->GetEditTarget().GetLayer()->GetIdentifier() == identifier)
	{
		stage->SetEditTarget(stage->GetRootLayer());
	}

	if (global)
	{
		FUSDCustomLayerData::SetLayerCustomField(remoteRootLayer, identifier, FUSDCustomLayerData::MutenessCustomKey, !visible);
	}
	else
	{
		layerMutenessMap[identifier] = !visible;
	}

	if(visible)
	{
		stage->UnmuteLayer(identifier);
	}
	else
	{
		stage->MuteLayer(identifier);
	}

	return true;
}

bool OmniUsdStageCtrl::GetSubLayerVisibility(const std::string& identifier, bool global)const
{
	if (global)
	{
		return !FUSDCustomLayerData::GetLayerCustomField(remoteRootLayer, identifier, FUSDCustomLayerData::MutenessCustomKey);
	}
	else
	{
		auto FindIter = layerMutenessMap.find(identifier);
		if (FindIter != layerMutenessMap.end())
		{
			return !FindIter->second.Get<bool>();
		}

		return true;
	}
}

bool  OmniUsdStageCtrl::IsSubLayerLocked(const std::string& identifier)const
{
	return FUSDCustomLayerData::GetLayerCustomField(remoteRootLayer, identifier, FUSDCustomLayerData::LockedCustomKey);
}

bool  OmniUsdStageCtrl::SetSubLayerLocked(const std::string& identifier, bool lock)
{
	// Check if it's a valid sub layer path
	FUSDCustomLayerData::SetLayerCustomField(remoteRootLayer, identifier, FUSDCustomLayerData::LockedCustomKey, lock);

	// switch the edit target
	if (lock && stage->GetEditTarget().GetLayer()->GetIdentifier() == identifier)
	{
		stage->SetEditTarget(stage->GetRootLayer());
	}

	return true;
}

pxr::SdfLayerRefPtr OmniUsdStageCtrl::CreateSubLayer(int index)
{
	return CreateSubLayer(remoteRootLayer, index);
}


pxr::TfToken OmniUsdStageCtrl::GetSubLayerName(const pxr::SdfLayerHandle& rootLayer, int index)
{
	auto subLayerPaths = rootLayer->GetSubLayerPaths();
	if(index < 0 || index >= subLayerPaths.size())
		return pxr::TfToken();

	std::string absolute_path = rootLayer->ComputeAbsolutePath(subLayerPaths[index]);
	std::string identifier = fs::path(absolute_path).filename().string();
	return pxr::TfToken(identifier);
}

void OmniUsdStageCtrl::OnStageChanged(const pxr::UsdNotice::ObjectsChanged& objectsChanged, const pxr::UsdStageWeakPtr& sender)
{
	assert(sender == stage);
	objectsChanged.Send(pxr::TfCreateWeakPtr(this));
}

bool OmniUsdStageCtrl::OpenLiveSession(const std::string& path)
{
	auto LiveStage = pxr::UsdStage::Open(path);
	if (LiveStage)
	{
		liveLayer = LiveStage->GetRootLayer();
		stage->GetSessionLayer()->InsertSubLayerPath(liveLayer->GetIdentifier());
		stage->SetEditTarget(pxr::UsdEditTarget(liveLayer));
		return true;
	}

	return false;
}

void OmniUsdStageCtrl::CloseLiveSession()
{
	stage->SetEditTarget(pxr::UsdEditTarget(stage->GetRootLayer()));
	if (liveLayer)
	{
		int Index = OmniUsdStageCtrl::FindSubLayerIndex(stage->GetSessionLayer(), liveLayer->GetIdentifier());
		if (Index >= 0)
		{
			stage->GetSessionLayer()->RemoveSubLayerPath(Index);
		}
		liveLayer = nullptr;
	}
}

void OmniUsdStageCtrl::MergeLiveSession()
{
	if (liveLayer)
	{
		for (auto rootPrim : liveLayer->GetRootPrims())
		{
			MergePrimSpecInternal(remoteRootLayer, liveLayer, rootPrim->GetPath(), false);
		}

		liveLayer->Clear();
		// ?? bug? have to save live session layer to make clear work
		liveLayer->Save();
	}
}

void OmniUsdStageCtrl::MergeLiveSessionToNewLayer(const std::string& layerIdentifier)
{
	if (liveLayer)
	{
		auto newLayer = pxr::SdfLayer::FindOrOpen(layerIdentifier);
		if (!newLayer)
		{
			newLayer = pxr::SdfLayer::CreateNew(layerIdentifier);
		}
		else
		{
			newLayer->Clear();
		}

		for (auto rootPrim : liveLayer->GetRootPrims())
		{
			MergePrimSpecInternal(newLayer, liveLayer, rootPrim->GetPath(), false);
		}	
		newLayer->Save();

		std::string relativePath = TCHAR_TO_UTF8(*FOmniversePathHelper::ComputeRelativePath(layerIdentifier.c_str(), remoteRootLayer->GetIdentifier().c_str()));
		remoteRootLayer->InsertSubLayerPath(relativePath, 0);
		
		liveLayer->Clear();
		// ?? bug? have to save live session layer to make clear work
		liveLayer->Save();
	}
}

bool OmniUsdStageCtrl::HasAnySpecsInRootLayer()
{
	if (liveLayer)
	{
		bool bHasAnySpecs = false;
		liveLayer->Traverse(pxr::SdfPath::AbsoluteRootPath(), [&](const pxr::SdfPath& InPath)
		{
			if (!bHasAnySpecs && !InPath.IsAbsoluteRootPath())
			{
				auto prim = stage->GetPrimAtPath(InPath);
				if (prim)
				{
					for (auto primSpec : prim.GetPrimStack())
					{
						if (primSpec && primSpec->GetLayer() == remoteRootLayer)
						{
							bHasAnySpecs = true;
							break;
						}
					}
				}
			}
		});

		return bHasAnySpecs;
	}

	return false;
}

bool OmniUsdStageCtrl::UpdateSublayerHandles()
{
	int32 NumLayers = subLayers.Num();
	subLayers.Reset();

	UpdateSublayerHandlesInternal(remoteRootLayer);

	return (NumLayers != subLayers.Num());
}

void OmniUsdStageCtrl::UpdateSublayerHandlesInternal(const pxr::SdfLayerHandle& layer)
{
	if (layer)
	{
		auto SubLayerPaths = layer->GetSubLayerPaths();
		for (int LayerIndex = 0; LayerIndex < SubLayerPaths.size(); ++LayerIndex)
		{
			std::string AbsolutePath = layer->ComputeAbsolutePath(SubLayerPaths[LayerIndex]);
			auto subLayer = pxr::SdfLayer::FindOrOpen(AbsolutePath);
			if (subLayer)
			{
				subLayers.Add(AbsolutePath.c_str(), subLayer);
				UpdateSublayerHandlesInternal(subLayer);
			}
		}
	}
}

int32 OmniUsdStageCtrl::GetSublayerPriority(const FString& layer, const FString& sublayer)
{
	auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*layer));

	if (Layer)
	{
		auto SubLayerPaths = Layer->GetSubLayerPaths();
		for (int LayerIndex = 0; LayerIndex < SubLayerPaths.size(); ++LayerIndex)
		{
			std::string AbsolutePath = Layer->ComputeAbsolutePath(SubLayerPaths[LayerIndex]);
			if (sublayer.Equals(AbsolutePath.c_str()))
			{
				return LayerIndex;
			}
		}
	}

	return INDEX_NONE;
}

TArray<FString> OmniUsdStageCtrl::GetSublayerIdentifiers()
{
	TArray<FString> layerIdentifiers;
	subLayers.GenerateKeyArray(layerIdentifiers);
	return layerIdentifiers;
}

bool OmniUsdStageCtrl::IsEmptyLiveSession()
{
	if (liveLayer)
	{
		return liveLayer->IsEmpty();
	}

	return false;
}


static bool fileExists(const char* fileUrl)
{
	FOmniverseListFileResult FileResult;
	return FOmniverseConnectionHelper::ListFileSync(fileUrl, FileResult);

}



// copyable static methods start here

bool OmniUsdStageCtrl::RemovePrimSpecInEditLayer(const pxr::UsdPrim& prim)
{
	auto layer = prim.GetStage()->GetEditTarget().GetLayer();
	auto primSpec = layer->GetPrimAtPath(prim.GetPath());
	if (primSpec)
	{
		auto parentSpec = primSpec->GetRealNameParent();
		if (parentSpec)
		{
			parentSpec->RemoveNameChild(primSpec);
			return true;
		}
	}
	return false;
}


pxr::SdfLayerHandle OmniUsdStageCtrl::HasOverriddenInStrongerLayer(const pxr::UsdStageRefPtr& Stage, const pxr::SdfPath& PrimPath, bool bOnlyActivePrim)
{
	auto LayerStack = Stage->GetLayerStack();

	for (auto Layer : LayerStack)
	{
		if (Layer == Stage->GetEditTarget().GetLayer())
		{
			break;
		}

		auto PrimSpec = Layer->GetPrimAtPath(PrimPath);

		if (!PrimSpec)
		{
			continue;
		}

		if (!bOnlyActivePrim || PrimSpec->HasActive() && PrimSpec->GetActive())
		{
			return Layer;
		}
	}

	return nullptr;
}

int OmniUsdStageCtrl::FindSubLayerIndex(const pxr::SdfLayerHandle& rootLayer, const std::string& path)
{
	auto paths = rootLayer->GetSubLayerPaths();

	auto identifier = rootLayer->ComputeAbsolutePath(path);

	for (int i = 0; i < paths.size(); ++i)
	{
		if (rootLayer->ComputeAbsolutePath(paths[i]) == identifier)
			return i;
	}

	return -1;
}

bool OmniUsdStageCtrl::SetSubLayerName(const pxr::SdfLayerHandle& rootLayer, int index, const pxr::TfToken& name)
{
	// Remove old name information
	auto subLayerPaths = rootLayer->GetSubLayerPaths();
	if (index < 0 || index >= subLayerPaths.size())
		return false;

	auto nameDict = rootLayer->GetFieldDictValueByKey(pxr::SdfPath::AbsoluteRootPath(), customLayerData, pxr::TfToken("omni_layer:names")).GetWithDefault<pxr::VtDictionary>();

	auto identifier = rootLayer->ComputeAbsolutePath(subLayerPaths[index]);

	for (const auto& entry : nameDict)
	{
		if (rootLayer->ComputeAbsolutePath(entry.first) != identifier)
			continue;

		nameDict.erase(entry.first);
		break;
	}

	// Set new name information
	auto layerFilename = fs::path((std::string)subLayerPaths[index]).filename().string();

	nameDict.SetValueAtPath(layerFilename, pxr::VtValue(name));

	rootLayer->SetFieldDictValueByKey(pxr::SdfPath::AbsoluteRootPath(), customLayerData, pxr::TfToken("omni_layer:names"), pxr::VtValue(nameDict));

	return true;
}

pxr::SdfLayerRefPtr OmniUsdStageCtrl::CreateSubLayer(const pxr::SdfLayerHandle& rootLayer, int index)
{
	// Find position
	auto subLayerPaths = rootLayer->GetSubLayerPaths();
	if (index > subLayerPaths.size() || index < -1)
		return nullptr;

	pxr::SdfLayerRefPtr subLayer;
	std::string subLayerPath;

	if (rootLayer->IsAnonymous())
	{
		// Create anonymouse layer
		subLayer = pxr::SdfLayer::CreateAnonymous();
		subLayerPath = subLayer->GetIdentifier();
	}
	else
	{
		// Compose sub layer path
		auto filename = fs::path(rootLayer->GetIdentifier()).filename().stem().stem().string();
		std::stringstream strStream;
		strStream << subLayerPaths.size() + 1;
		filename += "_" + strStream.str();

		std::srand((unsigned int)std::time(NULL));
		auto randomString = [](int length)
		{
			static const char alphanum[] =
				"0123456789"
				"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
				"abcdefghijklmnopqrstuvwxyz";

			std::string result(length, ' ');
			for (int i = 0; i < length; ++i)
			{
				result[i] = alphanum[rand() % (sizeof(alphanum) - 1)];
			}

			return result;
		};

		for (;;)
		{
			// Random string would be the same if two calls happen at the same time. We need to generate again if it happens.
			auto newFilename = filename + "_" + randomString(6) + ".sublayer.usd";

			auto identify = rootLayer->ComputeAbsolutePath("./" + newFilename);
			auto itr = std::find_if(subLayerPaths.begin(), subLayerPaths.end(),
				[&](const std::string& path)
				{
					return rootLayer->ComputeAbsolutePath(path) == identify;
				}
			);

			if (itr == subLayerPaths.end())
			{
				subLayerPath = "./" + newFilename;
				break;
			}
		}

		// Create sub layer
		auto newPath = rootLayer->ComputeAbsolutePath(subLayerPath);

		subLayer = pxr::SdfLayer::FindOrOpen(newPath);
		if (subLayer)
			subLayer->Clear();
		else
			subLayer = pxr::SdfLayer::CreateNew(newPath);
	}

	// Add sub layer
	subLayerPaths.Insert(index, subLayerPath);

	return subLayer;
}


// the delete will only happen in the current target, and follows:
// 1. If the prim spec is a def, it will remove the prim spec.
// 2. If the prim spec is a over, it will only deactivate this prim.
// 3. If the prim spec is not existed, it will create over prim and deactivate it.
// 4. If there is an overridden in a stronger layer, it will report errors.
bool OmniUsdStageCtrl::RemovePrim(const pxr::UsdPrim& prim)
{
	if (!prim)
	{
		return false;
	}

	pxr::SdfChangeBlock changeBlock;
	auto layer = prim.GetStage()->GetEditTarget().GetLayer();
	auto primPath = prim.GetPath();
	if (CanRemovePrim(prim))
	{
		return RemovePrimSpecInEditLayer(prim);
	}
	else
	{
		if (HasOverriddenInStrongerLayer(prim.GetStage(), primPath, true))
		{
			// TODO: message?
			return false;
		}

		auto primSpec = layer->GetPrimAtPath(prim.GetPath());

		if (primSpec && primSpec->GetSpecifier() == pxr::SdfSpecifier::SdfSpecifierDef)
		{
			// remove define at first
			if (RemovePrimSpecInEditLayer(prim))
			{
				// create empty over
				primSpec = pxr::SdfCreatePrimInLayer(layer, primPath);
			}
			else
			{
				return false;
			}
		}
		else
		{
			if (!primSpec)
			{
				// create empty over if there isn't one
				primSpec = pxr::SdfCreatePrimInLayer(layer, primPath);
			}
		}

		// deactive over
		if (primSpec)
		{
			primSpec->SetActive(false);
			return true;
		}
	}

	return false;
}

bool OmniUsdStageCtrl::RestorePrim(const pxr::SdfLayerRefPtr& AnonymousLayer, const std::string& LayerIdentifier, const pxr::SdfPath& PrimPath)
{
	pxr::SdfChangeBlock ChangeBlock;

	auto Layer = pxr::SdfLayer::FindOrOpen(LayerIdentifier);
	if (!Layer)
	{
		// Layer has been deleted
		return false;
	}

	auto PreviousPrimSpec = AnonymousLayer->GetPrimAtPath(PrimPath);
	auto CurrentPrimSpec = Layer->GetPrimAtPath(PrimPath);

	// there's an over, remove it
	if (!PreviousPrimSpec && CurrentPrimSpec)
	{
		auto parentSpec = CurrentPrimSpec->GetRealNameParent();
		if (parentSpec)
		{
			parentSpec->RemoveNameChild(CurrentPrimSpec);

			return true;
		}
	}
	// def is removed, recover it
	else if (PreviousPrimSpec)
	{
		if (!CurrentPrimSpec)
		{
			pxr::SdfCopySpec(AnonymousLayer, PrimPath, Layer, PrimPath);
		}
		else
		{
			CurrentPrimSpec->SetActive(true);
		}

		return true;
	}

	return false;
}

bool OmniUsdStageCtrl::CopyPrim(const pxr::UsdPrim& prim, pxr::SdfPath dstPath)
{
	auto primPath = prim.GetPath();
	bool bFromReferenceOrPayload = false;
	pxr::SdfLayerHandle introducingLayer;
	pxr::SdfPath introducingPrimPath;
	pxr::SdfPrimSpecHandle primSpecInDefLayer;

	GetIntroducingLayer(prim, introducingLayer, introducingPrimPath);

	for (auto primSpec : prim.GetPrimStack())
	{
		if (primSpec && primSpec->GetSpecifier() == pxr::SdfSpecifier::SdfSpecifierDef)
		{
			if (introducingLayer != primSpec->GetLayer() && introducingPrimPath != primPath)
			{
				bFromReferenceOrPayload = true;
				primSpecInDefLayer = primSpec;
				break;
			}
		}
	}

	pxr::SdfChangeBlock changeBlock;
	std::vector<std::string> LayersHasPrimSpec;
	for (auto oldPrimSpec : prim.GetPrimStack())
	{
		if (!oldPrimSpec)
		{
			continue;
		}
		auto layer = oldPrimSpec->GetLayer();
		auto destLayer = prim.GetStage()->GetEditTarget().GetLayer();
		if (oldPrimSpec->HasReferences() || oldPrimSpec->HasPayloads() || oldPrimSpec->GetSpecifier() == pxr::SdfSpecifier::SdfSpecifierDef)
		{
			pxr::SdfLayerRefPtr srcLayer;
			pxr::SdfPath srcPrimPath;
			if (layer != destLayer)
			{
				auto tempLayer = pxr::SdfLayer::CreateAnonymous();
				pxr::SdfCreatePrimInLayer(tempLayer, primPath);
				pxr::SdfCopySpec(layer, oldPrimSpec->GetPath(), tempLayer, primPath);
				ResolvePaths(layer->GetIdentifier(), tempLayer->GetIdentifier(), false);
				ResolvePaths(destLayer->GetIdentifier(), tempLayer->GetIdentifier(), true, true);

				if (!prim.GetStage()->HasLocalLayer(layer) && bFromReferenceOrPayload)
				{
					auto Prefixes = oldPrimSpec->GetPath().GetPrefixes();
					if (Prefixes.size() > 0)
					{
						ResolvePrimPathReferences(tempLayer, pxr::SdfPath(Prefixes[0]), pxr::SdfPath(introducingPrimPath));
					}
				}

				while (LayersHasPrimSpec.size() > 0)
				{
					auto layerHasPrim = LayersHasPrimSpec[LayersHasPrimSpec.size() - 1];
					if (layerHasPrim != destLayer->GetIdentifier())
					{
						MergePrimSpec(tempLayer->GetIdentifier(), layerHasPrim, primPath.GetString(), false);
					}
					LayersHasPrimSpec.pop_back();
				}

				if (destLayer->GetPrimAtPath(primPath))
				{
					MergePrimSpec(tempLayer->GetIdentifier(), destLayer->GetIdentifier(), primPath.GetString(), false);
				}

				srcLayer = tempLayer;
				srcPrimPath = primPath;
			}
			else
			{
				srcLayer = layer;
				srcPrimPath = oldPrimSpec->GetPath();
			}

			pxr::SdfCreatePrimInLayer(destLayer, dstPath);
			pxr::SdfCopySpec(srcLayer, srcPrimPath, destLayer, dstPath);
			break;
		}
		else
		{
			LayersHasPrimSpec.push_back(layer->GetIdentifier());
		}
	}

	return true;
}

bool OmniUsdStageCtrl::RenamePrim(const pxr::UsdPrim& prim, const pxr::TfToken& newName)
{
	if (!prim)
		return false;

	if (prim.IsPseudoRoot())
		return false;

	if (prim.GetPath().GetName() == newName)
		return false;

	auto dstPath = prim.GetPath().GetParentPath().AppendElementToken(newName);

	if (StitchPrimSpecs(prim, dstPath))
	{
		return RemovePrim(prim);
	}

	return false;
}

bool OmniUsdStageCtrl::IsAncestralPrim(const pxr::UsdPrim& Prim)
{
	if (Prim)
	{
		auto PrimIndex = Prim.GetPrimIndex();
		// walk the nodes, strong-to-weak
		for (auto Node : PrimIndex.GetNodeRange())
		{
			if (Node.IsDueToAncestor())
			{
				return true;
			}
		}
	}

	return false;
}

bool OmniUsdStageCtrl::IsAncestorGprim(const pxr::UsdStageRefPtr& Stage, const pxr::SdfPath& PrimPath)
{
	auto ParentPath = PrimPath;
	while (ParentPath != pxr::SdfPath::AbsoluteRootPath())
	{
		auto Prim = Stage->GetPrimAtPath(ParentPath);
		if (Prim && Prim.IsA<pxr::UsdGeomGprim>())
		{
			return true;
		}
		ParentPath = ParentPath.GetParentPath();
	}

	return false;
}


bool OmniUsdStageCtrl::CanRemovePrim(const pxr::UsdPrim& prim)
{
	if (IsAncestralPrim(prim))
	{
		return false;
	}

	auto editLayer = prim.GetStage()->GetEditTarget().GetLayer();

	bool bHasDelta = false;
	for (auto layer : prim.GetStage()->GetLayerStack())
	{
		auto primSpec = layer->GetPrimAtPath(prim.GetPath());
		if (!primSpec)
		{
			continue;
		}

		if (layer != editLayer && !bHasDelta && !layer->IsAnonymous())
		{
			bHasDelta = true;
		}
	}

	return !bHasDelta;
}

bool OmniUsdStageCtrl::GetIntroducingLayer(const pxr::UsdPrim& prim, pxr::SdfLayerHandle& outLayer, pxr::SdfPath& outPath)
{
	outLayer = nullptr;
	outPath = pxr::SdfPath();
	auto primStack = prim.GetPrimStack();

	for (auto primSpec : primStack)
	{
		if (primSpec && primSpec->GetSpecifier() == pxr::SdfSpecifier::SdfSpecifierDef)
		{
			outLayer = primSpec->GetLayer();
			outPath = primSpec->GetPath();
			break;
		}
	}

	if (outLayer.IsInvalid())
	{
		return false;
	}

	auto query = pxr::UsdPrimCompositionQuery(prim);
	auto filter = pxr::UsdPrimCompositionQuery::Filter();
	filter.arcTypeFilter = pxr::UsdPrimCompositionQuery::ArcTypeFilter::ReferenceOrPayload;
	filter.arcIntroducedFilter = pxr::UsdPrimCompositionQuery::ArcIntroducedFilter::IntroducedInRootLayerStack;
	query.SetFilter(filter);
	auto arcs = query.GetCompositionArcs();
	for (auto arc : arcs)
	{
		auto layer = arc.GetIntroducingLayer();
		// Reference
		if (arc.GetArcType() == pxr::PcpArcTypeReference)
		{
			pxr::SdfReferenceEditorProxy proxy;
			pxr::SdfReference ref;

			if (arc.GetIntroducingListEditor(&proxy, &ref))
			{
				auto assetPath = layer->ComputeAbsolutePath(ref.GetAssetPath());
				if (NormalizePath(outLayer->GetIdentifier()) == NormalizePath(assetPath))
				{
					outLayer = layer;
					outPath = arc.GetIntroducingPrimPath();
					break;
				}
			}
		}
		else if (arc.GetArcType() == pxr::PcpArcTypePayload)
		{
			pxr::SdfPayloadEditorProxy proxy;
			pxr::SdfPayload payload;

			if (arc.GetIntroducingListEditor(&proxy, &payload))
			{
				auto assetPath = layer->ComputeAbsolutePath(payload.GetAssetPath());
				if (NormalizePath(outLayer->GetIdentifier()) == NormalizePath(assetPath))
				{
					outLayer = layer;
					outPath = arc.GetIntroducingPrimPath();
					break;
				}
			}
		}
	}

	return true;
}

void OmniUsdStageCtrl::ResolvePaths(const std::string& srcLayerIdentifier,
	const std::string& targetLayerIdentifier,
	bool storeRelativePath,
	bool relativeToSrcLayer,
	bool copySublayerLayerOffsets)
{
	auto srcLayer = pxr::SdfLayer::Find(srcLayerIdentifier);
	auto dstLayer = pxr::SdfLayer::Find(targetLayerIdentifier);
	if (!srcLayer || !dstLayer)
	{
		return;
	}

	ResolvePathsInternal(srcLayer, dstLayer, storeRelativePath, relativeToSrcLayer, copySublayerLayerOffsets);
}

bool OmniUsdStageCtrl::MergePrimSpec(const std::string& dstLayerIdentifier,
	const std::string& srcLayerIdentifier,
	const std::string& primSpecPath,
	bool isDstStrongerThanSrc,
	const std::string& targetPrimPath)
{
	auto dstLayer = pxr::SdfLayer::Find(dstLayerIdentifier);
	auto srcLayer = pxr::SdfLayer::Find(srcLayerIdentifier);
	if (!dstLayer || !srcLayer)
	{
		return false;
	}

	pxr::SdfPath sdfPrimPath;
	pxr::SdfPath sdfTargetPrimPath;
	if (primSpecPath.empty())
	{
		sdfPrimPath = pxr::SdfPath::EmptyPath();
	}
	else
	{
		sdfPrimPath = pxr::SdfPath(primSpecPath);
	}

	if (targetPrimPath.empty())
	{
		sdfTargetPrimPath = pxr::SdfPath::EmptyPath();
	}
	else
	{
		sdfTargetPrimPath = pxr::SdfPath(targetPrimPath);
	}

	return MergePrimSpecInternal(
		dstLayer, srcLayer, sdfPrimPath, isDstStrongerThanSrc, sdfTargetPrimPath);
}

std::vector<std::string> OmniUsdStageCtrl::GetAllSublayers(const pxr::UsdStageRefPtr& stage, bool includeSessionLayer)
{
	std::vector<std::string> allLayers;

	if (includeSessionLayer)
	{
		allLayers = LayerTraverse(stage->GetSessionLayer(), stage->GetSessionLayer()->GetIdentifier());
	}

	std::vector<std::string> layersInRoot = LayerTraverse(stage->GetRootLayer(), stage->GetRootLayer()->GetIdentifier());
	allLayers.insert(std::end(allLayers), std::begin(layersInRoot), std::end(layersInRoot));

	return allLayers;
}

void OmniUsdStageCtrl::ResolvePrimPathReferences(const pxr::SdfLayerRefPtr& layer, const pxr::SdfPath& oldPath, const pxr::SdfPath& newPath)
{
	static auto updatePrimPathRef = [](const pxr::SdfPrimSpecHandle& primSpec, const pxr::SdfPath& oldPath, const pxr::SdfPath& newPath)
	{
		auto modifyItemEditsCallback = [&oldPath, &newPath](const pxr::SdfPath& path)
		{
			return path.ReplacePrefix(oldPath, newPath);
		};

		auto modifyItemReferencesCallback = [&oldPath, &newPath](const pxr::SdfReference& reference)
		{
			pxr::SdfPath primPath;
			if (reference.GetAssetPath().empty())
			{
				primPath = reference.GetPrimPath().ReplacePrefix(oldPath, newPath);
			}
			else
			{
				primPath = reference.GetPrimPath();
			}

			return pxr::SdfReference(
				reference.GetAssetPath(),
				primPath,
				reference.GetLayerOffset(),
				reference.GetCustomData()
			);
		};

		// Update relationships
		for (const auto& relationship : primSpec->GetRelationships())
		{
			relationship->GetTargetPathList().ModifyItemEdits(modifyItemEditsCallback);
		}

		// Update connections
		for (const auto& attribute : primSpec->GetAttributes())
		{
			attribute->GetConnectionPathList().ModifyItemEdits(modifyItemEditsCallback);
		}

		primSpec->GetReferenceList().ModifyItemEdits(modifyItemReferencesCallback);
	};

	auto onPrimSpecPath = [&layer, &oldPath, &newPath](const pxr::SdfPath& primPath)
	{
		if (primPath.IsPropertyPath() || primPath == pxr::SdfPath::AbsoluteRootPath())
		{
			return;
		}

		auto primSpec = layer->GetPrimAtPath(primPath);
		if (primSpec)
		{
			updatePrimPathRef(primSpec, oldPath, newPath);
		}
	};

	layer->Traverse(pxr::SdfPath::AbsoluteRootPath(), onPrimSpecPath);
}

bool OmniUsdStageCtrl::StitchPrimSpecs(const pxr::UsdPrim& prim, pxr::SdfPath dstPath)
{
	auto primPath = prim.GetPath();
	auto editLayer = prim.GetStage()->GetEditTarget().GetLayer();

	bool bFromReferenceOrPayload = false;
	pxr::SdfLayerHandle introducingLayer;
	pxr::SdfPath introducingPrimPath;
	pxr::SdfPrimSpecHandle primSpecInDefLayer;

	GetIntroducingLayer(prim, introducingLayer, introducingPrimPath);
	for (auto primSpec : prim.GetPrimStack())
	{
		if (primSpec && primSpec->GetSpecifier() == pxr::SdfSpecifier::SdfSpecifierDef)
		{
			if (introducingLayer != primSpec->GetLayer() && introducingPrimPath != primPath)
			{
				bFromReferenceOrPayload = true;
				primSpecInDefLayer = primSpec;
				break;
			}
		}
	}

	auto Sublayers = GetAllSublayers(prim.GetStage(), true);

	pxr::SdfChangeBlock changeBlock;

	auto tempLayer = pxr::SdfLayer::CreateAnonymous();
	pxr::SdfCreatePrimInLayer(tempLayer, primPath);
	for (auto subLayerIdentifier : Sublayers)
	{
		pxr::SdfLayerRefPtr subLayer;
		if (bFromReferenceOrPayload && introducingLayer && introducingLayer->GetIdentifier() == subLayerIdentifier)
		{
			subLayer = pxr::SdfLayer::CreateAnonymous();
			pxr::SdfCreatePrimInLayer(subLayer, primPath);
			pxr::SdfCopySpec(primSpecInDefLayer->GetLayer(), primSpecInDefLayer->GetPath(), subLayer, primPath);
		}
		else
		{
			subLayer = pxr::SdfLayer::FindOrOpen(subLayerIdentifier);
		}

		if (subLayer)
		{
			auto srcPrimSpec = subLayer->GetPrimAtPath(primPath);
			if (srcPrimSpec)
			{
				MergePrimSpec(tempLayer->GetIdentifier(), subLayer->GetIdentifier(), primPath.GetString(), true);
			}
		}
	}

	pxr::SdfCreatePrimInLayer(editLayer, dstPath);
	ResolvePaths(editLayer->GetIdentifier(), tempLayer->GetIdentifier(), true, true);
	pxr::SdfCopySpec(tempLayer, primPath, editLayer, dstPath);

	return true;
}

bool OmniUsdStageCtrl::IsLayerExist(const std::string& layerIdentifier)
{
	auto layer = pxr::SdfLayer::FindOrOpen(layerIdentifier);
	return layer != nullptr;
}

// These utilities were removed from the AR 2.0 API, so provide them here
static bool IsFileRelative(const std::string& path) {
	return path[0] == '.';
}
static bool HasScheme(const std::string& path) {
	auto colon = path.find(':');
	return colon != std::string::npos && colon < path.find('/');
}
static bool IsAbsolute(const std::string& path) {
	return path[0] == '/' || HasScheme(path);
}
static bool IsSearchPath(const std::string& path) {
	return !IsAbsolute(path) && !IsFileRelative(path);
}

void OmniUsdStageCtrl::ResolvePathsInternal(const pxr::SdfLayerRefPtr& srcLayer,
	pxr::SdfLayerRefPtr dstLayer,
	bool storeRelativePath,
	bool relativeToSrcLayer,
	bool copyLayerOffsets)
{
	using PathConvertFn = std::function<std::string(const std::string& path)>;
	PathConvertFn makePathAbsolute = [&srcLayer, &dstLayer](const std::string& path)
	{
		if (path.empty())
		{
			return path;
		}

		std::string externRefPathFull;
		if (!srcLayer->IsAnonymous())
		{
			externRefPathFull = ComputeAbsolutePath(srcLayer, path);
		}
		else
		{
			externRefPathFull = ComputeAbsolutePath(dstLayer, path);
		}

		if (IsSearchPath(path) && !fileExists(externRefPathFull.c_str()))
		{
			return path;
		}

		if (externRefPathFull.empty())
		{
			// If it failed to compute the absolute path, just returning the original one.
			return path;
		}
		else
		{
			return externRefPathFull;
		}
	};

	PathConvertFn makePathRelative = [&srcLayer, &dstLayer, relativeToSrcLayer](const std::string& path)
	{
		if (path.empty())
		{
			return path;
		}

		std::string relativePath = ComputeAbsolutePath(srcLayer, path);
		// FIXME: Resolver will firstly find MDL in the same dir as USD
		// for material reference, then Core Library. Currently, this is
		// used to check the existence of the path and see if it's necessary
		// to resolve path of mdl references.
		if (IsSearchPath(path) && !fileExists(relativePath.c_str()))
		{
			return path;
		}

		if (relativePath.empty() || pxr::SdfLayer::IsAnonymousLayerIdentifier(relativePath))
		{
			return path;
		}
		else
		{
			// Remove old omni: prefix
			if (relativePath.size() >= 5 && relativePath.substr(0, 5) == "omni:")
			{
				relativePath = relativePath.substr(5);
			}
			if (relativeToSrcLayer)
			{
				relativePath = TCHAR_TO_UTF8(*FOmniversePathHelper::ComputeRelativePath(relativePath.c_str(), srcLayer->GetIdentifier().c_str()));
			}
			else
			{
				relativePath = TCHAR_TO_UTF8(*FOmniversePathHelper::ComputeRelativePath(relativePath.c_str(), dstLayer->GetIdentifier().c_str()));
			}
			relativePath = NormalizePath(relativePath);

			// If relative path cannot be computed, it returns absolute path to avoid
			// reference issue. For example, if src and dst are not in the same domain.
			return relativePath;
		}
	};

	// Save offsets and scales.
	const auto& layerOffsets = srcLayer->GetSubLayerOffsets();

	PathConvertFn convertPath = storeRelativePath ? makePathRelative : makePathAbsolute;
	pxr::UsdUtilsModifyAssetPaths(
		dstLayer, [&convertPath](const std::string& assetPath) { return convertPath(assetPath); });

	// Copy sublayer offsets
	if (copyLayerOffsets)
	{
		for (size_t i = 0; i < layerOffsets.size(); i++)
		{
			const auto& layerOffset = layerOffsets[i];
			dstLayer->SetSubLayerOffset(layerOffset, static_cast<int>(i));
		}
	}

	// Resolve paths saved in customdata.
	pxr::VtDictionary valueMap;
	pxr::VtDictionary rootLayerCustomData = dstLayer->GetCustomLayerData();
	const auto& customDataValue = rootLayerCustomData.GetValueAtPath(FUSDCustomLayerData::MutenessCustomKey);
	if (customDataValue && !customDataValue->IsEmpty())
	{
		valueMap = customDataValue->Get<pxr::VtDictionary>();
	}

	pxr::VtDictionary newValueMap;
	for (const auto& valuePair : valueMap)
	{
		const std::string& absolutePath = srcLayer->ComputeAbsolutePath(valuePair.first);
		const std::string& relativePath = convertPath(absolutePath);
		newValueMap[relativePath] = valuePair.second;
	}

	rootLayerCustomData.SetValueAtPath(FUSDCustomLayerData::MutenessCustomKey, pxr::VtValue(newValueMap));
	dstLayer->SetCustomLayerData(rootLayerCustomData);
}

bool OmniUsdStageCtrl::MergePrimSpecInternal(pxr::SdfLayerRefPtr dstLayer,
	const pxr::SdfLayerRefPtr& srcLayer,
	const pxr::SdfPath& primSpecPath,
	bool isDstStrongerThanSrc,
	const pxr::SdfPath& targetPrimPath)
{
	if (dstLayer == srcLayer)
	{
		// If target path is not the same as original path, it means a duplicate.
		if (!targetPrimPath.IsEmpty() && primSpecPath != targetPrimPath)
		{
			pxr::SdfCopySpec(srcLayer, primSpecPath, dstLayer, targetPrimPath);
			return true;
		}

		return false;
	}

	if (!srcLayer->HasSpec(primSpecPath) && !dstLayer->HasSpec(primSpecPath))
	{
		return false;
	}

	auto originalStrongLayer = isDstStrongerThanSrc ? dstLayer : srcLayer;
	auto originalWeakLayer = isDstStrongerThanSrc ? srcLayer : dstLayer;
	auto targetLayer = dstLayer;

	// srcLayer is weak and dst is strong
	auto shouldCopyValueFn = [targetLayer](const pxr::TfToken& field, const pxr::SdfPath& path,
		const pxr::SdfLayerHandle& strongLayer, bool fieldInStrong,
		const pxr::SdfLayerHandle& weakLayer, bool fieldInWeak,
		pxr::VtValue* valueToCopy)
	{
		pxr::UsdUtilsStitchValueStatus status = pxr::UsdUtilsStitchValueStatus::UseDefaultValue;
		bool handleSublayers = false;
		if (field == pxr::SdfFieldKeys->SubLayers)
		{
			handleSublayers = true;
			status = pxr::UsdUtilsStitchValueStatus::UseSuppliedValue;
		}
		else if (fieldInWeak && fieldInStrong && field == pxr::SdfFieldKeys->Specifier)
		{
			const auto& sObj = weakLayer->GetObjectAtPath(path);
			const auto& dObj = strongLayer->GetObjectAtPath(path);
			const auto& sSpec = sObj->GetField(field).Get<pxr::SdfSpecifier>();
			const auto& dSpec = dObj->GetField(field).Get<pxr::SdfSpecifier>();

			// if either is not an over, we want the new specifier to be whatever that is.
			if (sSpec != pxr::SdfSpecifier::SdfSpecifierOver && dSpec != pxr::SdfSpecifier::SdfSpecifierOver)
			{

			}
			if (sSpec != pxr::SdfSpecifier::SdfSpecifierOver)
			{
				*valueToCopy = pxr::VtValue(sSpec);
				status = pxr::UsdUtilsStitchValueStatus::UseSuppliedValue;
			}
			else if (dSpec != pxr::SdfSpecifier::SdfSpecifierOver)
			{
				*valueToCopy = pxr::VtValue(dSpec);
				status = pxr::UsdUtilsStitchValueStatus::UseSuppliedValue;
			}
		}

		if (handleSublayers)
		{
			// Merge sublayers list between src and dst.
			pxr::SdfSubLayerProxy weakSublayerProxy = weakLayer->GetSubLayerPaths();
			pxr::SdfSubLayerProxy strongSublayerProxy = strongLayer->GetSubLayerPaths();
			std::vector<std::string> mergedSublayerList;
			std::unordered_set<std::string> uniqueSublayers;

			for (size_t i = 0; i < strongSublayerProxy.size(); i++)
			{
				std::string sublayer = strongSublayerProxy[i];
				if (uniqueSublayers.find(sublayer) == uniqueSublayers.end())
				{
					mergedSublayerList.push_back(sublayer);
					uniqueSublayers.insert(sublayer);
				}
			}

			for (size_t i = 0; i < weakSublayerProxy.size(); i++)
			{
				std::string sublayer = weakSublayerProxy[i];
				if (uniqueSublayers.find(sublayer) == uniqueSublayers.end())
				{
					mergedSublayerList.push_back(sublayer);
					uniqueSublayers.insert(sublayer);
				}
			}

			*valueToCopy = pxr::VtValue::Take(mergedSublayerList);
		}

		return status;
	};

	if (!srcLayer->HasSpec(primSpecPath))
	{
		return true;
	}

	auto tempStrongLayer = pxr::SdfLayer::CreateAnonymous();
	auto tempWeakLayer = pxr::SdfLayer::CreateAnonymous();
	auto tempPath = primSpecPath.IsAbsoluteRootPath() ? pxr::SdfPath::AbsoluteRootPath() : pxr::SdfPath::AbsoluteRootPath().AppendElementToken(primSpecPath.GetNameToken());
	pxr::SdfCreatePrimInLayer(tempStrongLayer, tempPath);
	pxr::SdfCreatePrimInLayer(tempWeakLayer, tempPath);
	if (originalStrongLayer->GetPrimAtPath(primSpecPath))
	{
		pxr::SdfCopySpec(originalStrongLayer, primSpecPath, tempStrongLayer, tempPath);
		ResolvePathsInternal(originalStrongLayer, tempStrongLayer, false);
	}
	if (originalWeakLayer->GetPrimAtPath(primSpecPath))
	{
		pxr::SdfCopySpec(originalWeakLayer, primSpecPath, tempWeakLayer, tempPath);
		ResolvePathsInternal(originalWeakLayer, tempWeakLayer, false);
	}
	pxr::UsdUtilsStitchLayers(tempStrongLayer, tempWeakLayer, shouldCopyValueFn);
	ResolvePathsInternal(targetLayer, tempStrongLayer, true, true);

	pxr::SdfCreatePrimInLayer(targetLayer, primSpecPath);
	pxr::SdfPath newPrimPath;
	if (targetPrimPath != pxr::SdfPath::EmptyPath())
	{
		newPrimPath = targetPrimPath;
	}
	else
	{
		newPrimPath = primSpecPath;
	}
	pxr::SdfCopySpec(tempStrongLayer, tempPath, targetLayer, newPrimPath);

	return true;
}

void OmniUsdStageCtrl::ReloadAllRelatedLayers(const pxr::SdfLayerRefPtr& Layer)
{
	if (Layer)
	{
		Layer->Reload();

		for (auto subLayerPath : Layer->GetSubLayerPaths())
		{
			auto sublayerIdentifier = Layer->ComputeAbsolutePath(subLayerPath);
			auto subLayer = pxr::SdfLayer::FindOrOpen(sublayerIdentifier);
			ReloadAllRelatedLayers(subLayer);
		}
	}
}

void OmniUsdStageCtrl::DebugLayerToFile(const pxr::SdfLayerHandle& Layer, const FString& FileName)
{
	std::string Export;
	Layer->ExportToString(&Export);
	IFileHandle* pFile = FPlatformFileManager::Get().GetPlatformFile().OpenWrite(*FileName);
	pFile->Write((const uint8*)Export.c_str(), Export.size());
	delete pFile;
}

