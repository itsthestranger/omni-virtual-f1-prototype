// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseUSDBlueprintLibrary.h"
#include "OmniverseFacialAnimation.h"
#include "OmniverseUSDImporter.h"

bool UOmniverseUSDBlueprintLibrary::LoadFacialAnimation(const FString& Path, const FString& Dest, class USkeleton* Skeleton, FName Name)
{
	return FOmniverseFacialAnimation::LoadFacialAnimation(Path, Dest, Skeleton, Name);
}

bool UOmniverseUSDBlueprintLibrary::LoadUSD(const FString& Path, const FString& Dest, const FOmniverseImportSettings& ImportSettings)
{
	return FOmniverseUSDImporter::LoadUSD(Path, Dest, ImportSettings);
}

bool UOmniverseUSDBlueprintLibrary::Reimport(class UObject* Object)
{
	return FOmniverseUSDImporter::Reimport(Object);
}
