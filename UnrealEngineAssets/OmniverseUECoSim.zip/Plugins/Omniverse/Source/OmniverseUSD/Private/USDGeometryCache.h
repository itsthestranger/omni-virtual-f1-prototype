// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "UObject/StrongObjectPtr.h"

// Mesh cache to boost mesh importing
class FUSDGeometryCache
{
public:
	static class UObject* Find(const FString& Hash);
	static void Add(const FString& Hash, UObject* Object);
	static void BackupCurrentCache();
	static void RestoreLastBackup();

protected:
	static TMap<FString, TStrongObjectPtr<class UObject>> CachedAssets;
	static TMap<FString, TStrongObjectPtr<class UObject>> BackupCache;
};