// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.
#pragma once

#include "EdMode.h"
#include "OmniversePxr.h"

class FOmniverseEdMode:
	public FEdMode
{
public:
	virtual bool IsCompatibleWith(FEditorModeID OtherModeID) const override { return true; }
	virtual bool ProcessEditCopy()override;
	virtual bool ProcessEditPaste()override;
	virtual bool ProcessEditCut()override;
	virtual bool ProcessEditDuplicate()override;
	virtual bool ProcessEditDelete()override;

	pxr::SdfLayerRefPtr CopiedUSDContent;

	static const FName EdModeID;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnProcessCopy, bool&);
	static FOnProcessCopy OnProcessCopy;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnProcessPaste, bool&);
	static FOnProcessPaste OnProcessPaste;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnProcessCut, bool&);
	static FOnProcessCut OnProcessCut;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnProcessDuplicate, bool&);
	static FOnProcessDuplicate OnProcessDuplicate;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnProcessDelete, bool&);
	static FOnProcessDelete OnProcessDelete;
};

