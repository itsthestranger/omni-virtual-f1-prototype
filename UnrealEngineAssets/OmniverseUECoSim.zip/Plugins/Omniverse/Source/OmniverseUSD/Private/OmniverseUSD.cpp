// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseUSD.h"
#include "Algo/NoneOf.h"
#include "UObject/UObjectIterator.h"
#include "UObject/ObjectSaveContext.h"
#include "Misc/Paths.h"
#include "Async/Async.h"

#if WITH_EDITOR
#include "Editor.h"
#include "Misc/MessageDialog.h"
#include "Widgets/Notifications/SNotificationList.h"
#endif
#include "Misc/CoreDelegates.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseSettings.h"
#include "OmniverseUSDLayerDataSource.h"
#include "OmniverseNotificationHelper.h"
#include "USDConverter.h"
#include "USDCustomLayerData.h"
#include "IOmniverseCollaboration.h"
#include "IOmniverseSessionConfig.h"

UOmniverseUSD::UOmniverseUSD()
{
	// By default, USDLayerDataSource is empty
	USDLayerDataSource = FOmniverseUSDLayerDataSource::Create(nullptr);

	SessionListDelegate.BindUObject(this, &UOmniverseUSD::SessionListCallback);
	SessionSubscribeDelegate.BindUObject(this, &UOmniverseUSD::SessionSubscribeCallback);
	SessionRootSubscribeDelegate.BindUObject(this, &UOmniverseUSD::SessionRootSubscribeCallback);
	UsdFolderSubscribeDelegate.BindUObject(this, &UOmniverseUSD::UsdFolderSubscribeCallback);
}

UOmniverseUSD::~UOmniverseUSD()
{
	RevokeAllNoticekeys();
	if (USDLayerDataSource.IsValid())
	{
		USDLayerDataSource->OnPreLayersChanged().RemoveAll(this);
		USDLayerDataSource->OnLayersChanged().RemoveAll(this);
		USDLayerDataSource->OnPostLayersChanged().RemoveAll(this);
	}

	ReleaseStage();

	USDLayerDataSource = nullptr;

	SessionListDelegate.Unbind();
	SessionSubscribeDelegate.Unbind();
	SessionRootSubscribeDelegate.Unbind();
	UsdFolderSubscribeDelegate.Unbind();
}

void UOmniverseUSD::ReleaseStage()
{
	StopSublayersSubscribe();
	CloseFetchNotification();

	RevokeAllNoticekeys();
	USDNoticeListener.Reset();

	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->StageCtrl = nullptr;
	USDLayerStateDataSource->Reset();

#define SAFE_RELEASE_PTR(p) if (p) { p.Reset(); p = nullptr; }
	SAFE_RELEASE_PTR(USDStage);
	SAFE_RELEASE_PTR(StageCtrl);
#undef SAFE_RELEASE_PTR

	StopSubscribe();
	StopLiveSessionWatch();
	StopLiveRootWatch();
	StopUsdFolderWatch();
}

void UOmniverseUSD::ReloadUSDStage()
{
	ReleaseStage();

	pxr::UsdStageRefPtr NewUSDStage = nullptr;
	if(!OmniPath.IsEmpty())
	{
		std::string USDPath = TCHAR_TO_UTF8(*OmniPath);
		NewUSDStage = pxr::UsdStage::Open(USDPath);
	}

	if(!NewUSDStage)
	{
		NewUSDStage = LoadDefaultUSDStage();
	}

	SetUSDStage(NewUSDStage);

	if (!bIsMount && bIsWritable && !IsLiveLayer())
	{
		StartSubscribe();
		StartLiveSessionWatch();
	}
}

const pxr::UsdStageRefPtr& UOmniverseUSD::LoadUSDStage()
{
	if (!USDStage)
	{
		ReloadUSDStage();
	}

	return USDStage;
}

bool UOmniverseUSD::IsStageLoaded()
{
	if (USDStage)
	{
		return true;
	}
	else
	{
		return false;
	}
}

const pxr::UsdStageRefPtr& UOmniverseUSD::GetUSDStage()
{
	LoadUSDStage();

	return USDStage;
}

const TSharedRef<IOmniverseLayerDataSource> UOmniverseUSD::GetLayerDataSource() const
{
	return USDLayerDataSource.ToSharedRef();
}

void UOmniverseUSD::SetUSDStage(pxr::UsdStageRefPtr InUSDStage)
{
	if (USDStage == InUSDStage)
		return;

	USDStage = InUSDStage;
	if (!USDStage)
	{
		USDStage = LoadDefaultUSDStage();
	}
	else if (!USDStage->GetRootLayer()->IsAnonymous()) // Load from omnipath for next start if it's not in-memory stage
	{
		FString RootLayerPath = USDStage->GetRootLayer()->GetIdentifier().c_str();
		if (OmniPath != RootLayerPath)
		{
			OmniPath = RootLayerPath;
		}
	}

	StageCtrl = pxr::TfCreateRefPtr(new OmniUsdStageCtrl(USDStage));

	USDNoticeListener.Reset(new FUSDNoticeListener(*this));
	StageNoticeKey = pxr::TfNotice::Register(pxr::TfCreateWeakPtr(USDNoticeListener.Get()), &FUSDNoticeListener::Handle, StageCtrl);

	USDLayerNoticeListener.Reset(new FUSDLayerNoticeListener(*this));
	LayerSaveNoticeKey = pxr::TfNotice::Register(pxr::TfCreateWeakPtr(USDLayerNoticeListener.Get()), &FUSDLayerNoticeListener::HandleGlobalLayerSave);
	LayerChangeNoticeKey = pxr::TfNotice::Register(pxr::TfCreateWeakPtr(USDLayerNoticeListener.Get()), &FUSDLayerNoticeListener::HandleLayerChange);

	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->StageCtrl = StageCtrl;
	USDLayerStateDataSource->Reset();
	OnUSDChanged.Broadcast(pxr::SdfPath("/"), true);

	StartSublayersSubscribe();
}

TArray<FString> UOmniverseUSD::GetFileTypes()const
{
	return { "usd", "usda", "usdc", "usdz", "live" };
}

void UOmniverseUSD::SaveInMemoryUSD()
{
	FCoreDelegates::OnBeginFrame.Remove(DelegateSaveLocalLayers);
	DelegateSaveLocalLayers.Reset();

	// Not in Omniverse. Save stage content as string.
	if (GetOmniPath().IsEmpty())
	{
		FOmniverseUSDLayerDataSource* USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
		USDLayerStateDataSource->SaveTo(USDLayersSerialization);
	}
}

void UOmniverseUSD::RemovePrimDataSource(const FString& LayerIdentifier, const FString& PrimPath)
{
	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->RemovePrim(LayerIdentifier, PrimPath);
}

void UOmniverseUSD::UpdatePrimDataSource(const FString& LayerIdentifier, const FString& PrimPath)
{
	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->UpdatePrim(LayerIdentifier, PrimPath);
}

void UOmniverseUSD::AddSublayerDataSource(const FString& LayerIdentifier, const FString& SublayerPath)
{
	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->AddSublayer(LayerIdentifier, SublayerPath);

	auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*LayerIdentifier));
	if (Layer && !Layer->IsAnonymous())
	{
		FString AbsolutePath = Layer->ComputeAbsolutePath(TCHAR_TO_UTF8(*SublayerPath)).c_str();
		// Ignore live layer
		if (FPaths::GetExtension(AbsolutePath).Equals(TEXT("live"), ESearchCase::IgnoreCase))
		{
			return;
		}

		auto SubLayer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*AbsolutePath));
		if (SubLayer && !SubLayer->IsAnonymous())
		{
			UOmniverseUSD* OmniUSD = UOmniverseAsset::LoadAsset<UOmniverseUSD>(AbsolutePath);
			if (OmniUSD)
			{
				OmniUSD->StartLayerSubscribe();
				SublayerUSDMap.FindOrAdd(AbsolutePath, OmniUSD);
			}
		}
	}
}

void UOmniverseUSD::RemoveSublayerDataSource(const FString& LayerIdentifier, const FString& SublayerPath)
{
	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->RemoveSublayer(LayerIdentifier, SublayerPath);

	auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*LayerIdentifier));
	if (Layer && !Layer->IsAnonymous())
	{
		FString AbsolutePath = Layer->ComputeAbsolutePath(TCHAR_TO_UTF8(*SublayerPath)).c_str();
		if (SublayerUSDMap.Find(AbsolutePath))
		{
			UOmniverseUSD* OmniUSD = UOmniverseAsset::LoadAsset<UOmniverseUSD>(AbsolutePath);
			if (OmniUSD)
			{
				OmniUSD->StopLayerSubscribe();
				SublayerUSDMap.Remove(AbsolutePath);
			}
		}
	}
}

void UOmniverseUSD::UpdateSublayerDataSource(const FString& LayerIdentifier, const FString& SublayerPath)
{
	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->UpdateSublayer(LayerIdentifier, SublayerPath);
}

void UOmniverseUSD::RevokeAllNoticekeys()
{
	pxr::TfNotice::Revoke(StageNoticeKey);
	pxr::TfNotice::Revoke(LayerSaveNoticeKey);
	pxr::TfNotice::Revoke(LayerChangeNoticeKey);
	for (auto NoticeKey : SublayerNoticeKey)
	{
		pxr::TfNotice::Revoke(NoticeKey.Value);
	}
}

pxr::UsdStageRefPtr UOmniverseUSD::LoadDefaultUSDStage()
{
	return FOmniverseUSDLayerDataSource::CreateInMemoryStageFrom(USDLayersSerialization);
}

void UOmniverseUSD::HandleUSDNotice(const pxr::UsdNotice::ObjectsChanged & ObjectsChanged, const pxr::UsdStageWeakPtr & Sender)
{
	// During asset reloading, we reload the root layer. And it triggers notice. Old version asset object broadcasts this notice to AOmniverseStageActor. And it rebuilds scene objects. And it causes assertion failure in garbage collection function. So we need to skip it for old version asset object.
	checkSlow(USDStage == Sender);
	if (HasAllFlags(RF_NewerVersionExists))
	{
		return;
	}

	auto ResyncedPaths = ObjectsChanged.GetResyncedPaths();
	bool RootPrimRefreshed = ResyncedPaths.find(pxr::SdfPath::AbsoluteRootPath()) != ResyncedPaths.end();
	if (RootPrimRefreshed)
	{
		UpdateSublayerHandles();

		TMap<FString, UOmniverseUSD*> CurrentSublayers = SublayerUSDMap;
		FString RootLayerIdentifier = StageCtrl->GetRemoteRootLayer()->GetIdentifier().c_str();
		auto SubLayerPaths = StageCtrl->GetRemoteRootLayer()->GetSubLayerPaths();
		for (int LayerIndex = 0; LayerIndex < SubLayerPaths.size(); ++LayerIndex)
		{
			std::string SubLayerPath = SubLayerPaths[LayerIndex];
			FString AbsolutePath = StageCtrl->GetRemoteRootLayer()->ComputeAbsolutePath(SubLayerPath).c_str();
			if (CurrentSublayers.Find(AbsolutePath))
			{
				CurrentSublayers.Remove(AbsolutePath);
			}
			else
			{
				AddSublayerDataSource(RootLayerIdentifier, SubLayerPath.c_str());
			}
		}

		for (auto Pair : CurrentSublayers)
		{
			RemoveSublayerDataSource(RootLayerIdentifier, Pair.Key);
		}
	}

	// Broadcast change
	for(auto&& Path : ObjectsChanged.GetResyncedPaths())
	{
		if (Path.IsAbsoluteRootOrPrimPath())
		{
			OnUSDChanged.Broadcast(Path, true);
		}
		else
		{
			OnUSDChanged.Broadcast(Path, false);
		}
	}
	for(auto&& Path : ObjectsChanged.GetChangedInfoOnlyPaths())
	{
		OnUSDChanged.Broadcast(Path, false);
	}

	// Mark dirty for local USD
	if(GetOmniPath().IsEmpty())
	{
		MarkPackageDirty();
	}

	// Save work if it's in-memory stage
	if (!DelegateSaveLocalLayers.IsValid())
	{
		DelegateSaveLocalLayers = FCoreDelegates::OnBeginFrame.AddUObject(this, &UOmniverseUSD::SaveInMemoryUSD);
	}
}

void UOmniverseUSD::CreateUnrealAsset()
{
	SetFlags(EObjectFlags::RF_Public | EObjectFlags::RF_Transactional | EObjectFlags::RF_Standalone);
}

bool UOmniverseUSD::IsAsset() const
{
	return UObject::IsAsset();
}

bool UOmniverseUSD::IsDefaultUSD()
{
	return GetOmniPath().IsEmpty();
}

void UOmniverseUSD::StartLiveSessionWatch()
{
	if (OmniPath.StartsWith(TEXT("omniverse:")))
	{
		FOmniverseListFileResult Result;
		if (SessionListSubscribeTask == nullptr)
		{
			LiveSessionList.Reset();			
			if (FOmniverseConnectionHelper::ListFileSync(FOmniversePathHelper::GetLiveFolderPath(OmniPath), Result))
			{
				SessionListSubscribeTask = FOmniverseConnectionHelper::ListFolderSubscribe(FOmniversePathHelper::GetLiveFolderPath(OmniPath), SessionListDelegate, SessionSubscribeDelegate);
			}
		}

		if (SessionRootListSubscribeTask == nullptr && FOmniverseConnectionHelper::ListFileSync(FOmniversePathHelper::GetLiveRootPath(OmniPath), Result))
		{
			SessionRootListSubscribeTask = FOmniverseConnectionHelper::ListFolderSubscribe(FOmniversePathHelper::GetLiveRootPath(OmniPath), SessionRootListDelegate, SessionRootSubscribeDelegate);
		}

		if (UsdFolderListSubscribeTask == nullptr && FOmniverseConnectionHelper::ListFileSync(FPaths::GetPath(OmniPath), Result))
		{
			UsdFolderListSubscribeTask = FOmniverseConnectionHelper::ListFolderSubscribe(FPaths::GetPath(OmniPath), UsdFolderListDelegate, UsdFolderSubscribeDelegate);
		}
	}
}

void UOmniverseUSD::StopLiveSessionWatch()
{
	if (SessionListSubscribeTask)
	{
		SessionListSubscribeTask->Stop();
		SessionListSubscribeTask = nullptr;
	}
}

void UOmniverseUSD::StopLiveRootWatch()
{
	if (SessionRootListSubscribeTask)
	{
		SessionRootListSubscribeTask->Stop();
		SessionRootListSubscribeTask = nullptr;
	}
}

void UOmniverseUSD::StopUsdFolderWatch()
{
	if (UsdFolderListSubscribeTask)
	{
		UsdFolderListSubscribeTask->Stop();
		UsdFolderListSubscribeTask = nullptr;
	}
}

void UOmniverseUSD::Load()
{
	if (bInPostLoad)
	{
		return;
	}

	LoadUSDStage();
}

void UOmniverseUSD::PostLoad()
{
	bInPostLoad = true;

	Super::PostLoad();

	bInPostLoad = false;
}

void UOmniverseUSD::PreSave(const ITargetPlatform * TargetPlatform)
{
	PRAGMA_DISABLE_DEPRECATION_WARNINGS;
	Super::PreSave(TargetPlatform);
	PRAGMA_ENABLE_DEPRECATION_WARNINGS;
}

void UOmniverseUSD::PreSave(FObjectPreSaveContext ObjectSaveContext)
{
	Super::PreSave(ObjectSaveContext);
	SaveInMemoryUSD();
}

void UOmniverseUSD::FUSDNoticeListener::Handle(const pxr::UsdNotice::ObjectsChanged& ObjectsChanged, const pxr::TfWeakPtr<OmniUsdStageCtrl>& Sender)
{
	checkSlow(&*USDAsset.StageCtrl == &*Sender);
 	USDAsset.HandleUSDNotice(ObjectsChanged, USDAsset.USDStage);
}


void UOmniverseUSD::FUSDLayerNoticeListener::HandleGlobalLayerSave(const pxr::SdfNotice::LayerDidSaveLayerToFile& n)
{
	USDAsset.UpdatehVersion();
}

void UOmniverseUSD::FUSDLayerNoticeListener::HandleLayerChange(const pxr::SdfNotice::LayersDidChange& LayerNotice)
{
	for (auto Iter = LayerNotice.begin(); Iter != LayerNotice.end(); ++Iter)
	{
		auto LayerHandle = Iter->first;
		if (!USDAsset.USDStage || !USDAsset.USDStage->HasLocalLayer(LayerHandle))
		{
			continue;
		}

		FString LayerIdentifier = Iter->first->GetIdentifier().c_str();
		USDAsset.MarkLayerDirty(LayerIdentifier);
		for (auto& ChangeEntry : Iter->second.GetEntryList())
		{
			if (ChangeEntry.first.IsPrimPath())
			{
				FString PrimPath = ChangeEntry.first.GetText();
				if (ChangeEntry.second.flags.didRemoveInertPrim || ChangeEntry.second.flags.didRemoveNonInertPrim)
				{
					USDAsset.RemovePrimDataSource(LayerIdentifier, PrimPath);
				}
				else
				{
					USDAsset.UpdatePrimDataSource(LayerIdentifier, PrimPath);
				}
			}

			bool SubLayerChanged = ChangeEntry.second.subLayerChanges.size() > 0;
			if (SubLayerChanged)
			{
				if (!Iter->first->IsAnonymous())
				{
					USDAsset.UpdateSublayerHandles();
				}
				for (auto SubLayerChange : ChangeEntry.second.subLayerChanges)
				{
					if (SubLayerChange.second == pxr::SdfChangeList::SubLayerChangeType::SubLayerAdded)
					{
						USDAsset.AddSublayerDataSource(LayerIdentifier, SubLayerChange.first.c_str());
					}
					else if (SubLayerChange.second == pxr::SdfChangeList::SubLayerChangeType::SubLayerRemoved)
					{
						USDAsset.RemoveSublayerDataSource(LayerIdentifier, SubLayerChange.first.c_str());
					}
					else if (SubLayerChange.second == pxr::SdfChangeList::SubLayerChangeType::SubLayerOffset)
					{
						USDAsset.UpdateSublayerDataSource(LayerIdentifier, SubLayerChange.first.c_str());
					}
				}
			}
		}
	}
}

void UOmniverseUSD::SaveToOmniverse()
{
	if (!IsLiveLayer() && !bIsMount && bIsWritable && !OmniPath.IsEmpty())
	{
		auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*OmniPath));
		if (Layer)
		{
			Layer->Save();
			auto CurrentDataSource = IOmniverseLayerDataSource::GetCurrentLayerDataSource();
			if (CurrentDataSource)
			{
				CurrentDataSource->SetLayerDirty(OmniPath, false);
			}
		}
	}

#if WITH_EDITOR
	if (!bIsWritable || bIsMount)
	{
		// Output a dialog that this location isn't writable
		FText Title = FText::FromString("ERROR: Output file is read only");
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString("File is read only: " + OmniPath), &Title);
	}
#endif
}

bool UOmniverseUSD::UpdateSublayerHandles()
{
	if (StageCtrl)
	{
		return StageCtrl->UpdateSublayerHandles();
	}

	return false;
}

void UOmniverseUSD::SessionListCallback(const FOmniverseListFolderResult& ListResult)
{
	if (ListResult.Status != eOmniClientResult_Ok && ListResult.Status != eOmniClientResult_OkLatest)
	{
		StopLiveSessionWatch();
		return;
	}

	for (auto Item : ListResult.ListItems)
	{
		LiveSessionList.Add(*FPaths::GetBaseFilename(Item.Path));
	}
}
	
void UOmniverseUSD::SessionSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult)
{
	if (SubscribeResult.Status != eOmniClientResult_Ok && SubscribeResult.Status != eOmniClientResult_OkLatest)
	{
		StopLiveSessionWatch();
		return;
	}

	switch(SubscribeResult.ListEvent)
	{
		case OmniClientListEvent::eOmniClientListEvent_Created:
		{
			FName Session = *FPaths::GetBaseFilename(SubscribeResult.ListItem.Path);
			OnLiveSessionAdded.Broadcast(Session);
			LiveSessionList.Add(Session);
			break;
		}
		case OmniClientListEvent::eOmniClientListEvent_Deleted:
		{
			FName Session = *FPaths::GetBaseFilename(SubscribeResult.ListItem.Path);
			OnLiveSessionRemoved.Broadcast(Session);
			LiveSessionList.Remove(Session);
			break;
		}
	}
}

void UOmniverseUSD::UsdFolderSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult)
{
	if (SubscribeResult.Status != eOmniClientResult_Ok && SubscribeResult.Status != eOmniClientResult_OkLatest)
	{
		StopUsdFolderWatch();
		return;
	}

	if (SubscribeResult.ListEvent == OmniClientListEvent::eOmniClientListEvent_Created)
	{
		if (SubscribeResult.ListItem.Path.Equals(FOmniversePathHelper::GetLiveRootPath(OmniPath)))
		{
			StartLiveSessionWatch();
		}
	}
	else if (SubscribeResult.ListEvent == OmniClientListEvent::eOmniClientListEvent_Deleted)
	{
		if (SubscribeResult.ListItem.Path.Equals(FOmniversePathHelper::GetLiveRootPath(OmniPath)))
		{
			StopLiveRootWatch();
		}
	}
}

void UOmniverseUSD::SessionRootSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult)
{
	if (SubscribeResult.Status != eOmniClientResult_Ok && SubscribeResult.Status != eOmniClientResult_OkLatest)
	{
		StopLiveRootWatch();
		return;
	}

	if (SubscribeResult.ListEvent == OmniClientListEvent::eOmniClientListEvent_Created)
	{
		if (SubscribeResult.ListItem.Path.Equals(FOmniversePathHelper::GetLiveFolderPath(OmniPath)))
		{
			StartLiveSessionWatch();
		}
	}
	else if (SubscribeResult.ListEvent == OmniClientListEvent::eOmniClientListEvent_Deleted)
	{
		if (SubscribeResult.ListItem.Path.Equals(FOmniversePathHelper::GetLiveFolderPath(OmniPath)))
		{
			StopLiveSessionWatch();
		}
	}
}

const TArray<FName>& UOmniverseUSD::GetLiveSessionList() const
{
	return LiveSessionList;
}

const FName UOmniverseUSD::GetSessionName() const
{
	return CurrentLiveSession.IsSet() ? CurrentLiveSession.GetValue() : NAME_None;
}

UOmniverseUSD::ESessionResult UOmniverseUSD::JoinSession(const FString& SessionName, FOmniversePreSessionStarted PreSessionStarted)
{
	if (IsLiveLayer())
	{
		return ESessionResult::Error_NonLivable;
	}

	if (StageCtrl)
	{
		TMap<IOmniverseSessionConfig::Key, FString> ConfigMap;
		if (!IOmniverseSessionConfig::Get()->LoadSessionConfig(FOmniversePathHelper::GetLiveSessionConfigPath(OmniPath, SessionName), ConfigMap))
		{
			return ESessionResult::Error_InvalidToml;
		}
		
		if (auto Version = ConfigMap.Find(IOmniverseSessionConfig::Key::Version))
		{
			int32 ConfigMajorVersion = 0;
			int32 ConfigMinorVersion = 0;
			FOmniversePathHelper::ParseVersion(*Version, ConfigMajorVersion, ConfigMinorVersion);

			if (IOmniverseSessionConfig::Get()->IsCompatible(ConfigMajorVersion, ConfigMinorVersion))
			{
				IsLiveSessionOwner = false;
				if (auto UserName = ConfigMap.Find(IOmniverseSessionConfig::Key::UserName))
				{
					CurrentLiveSessionOwner = FName(*UserName);
					const auto& WatchServerList = IOmniverseRuntimeModule::Get().GetWatchList();
					for (auto WatchServer : WatchServerList)
					{
						if (GetAssetServer().Equals(WatchServer.Address))
						{
							if (WatchServer.UserName.Equals(*UserName))
							{
								IsLiveSessionOwner = true;
							}
							break;
						}
					}
				}

				CurrentLiveSession = *SessionName;
				if (!StageCtrl->OpenLiveSession(TCHAR_TO_UTF8(*FOmniversePathHelper::GetLiveSessionLayerPath(OmniPath, SessionName))))
				{
					return ESessionResult::Error_LayerOpen;
				}

				if (PreSessionStarted)
				{
					PreSessionStarted();
				}
				IOmniverseCollaboration::Get()->Subscribe(FOmniversePathHelper::GetLiveSessionChannelPath(OmniPath, SessionName));
				IOmniverseCollaboration::Get()->SendMessage(EOmniverseMessageType::UserJoin);
				USDLayerDataSource->RefreshAuthorLayer();
				IOmniverseRuntimeModule::Get().EnableLiveUpdate(true);

				return ESessionResult::OK;
			}
			else
			{
				FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Failed to join the session as the version (%d.%d) is not compatible."), ConfigMajorVersion, ConfigMinorVersion));
				return ESessionResult::Error_InvalidTomlVersion;
			}
		}
		else
		{
			FOmniverseNotificationHelper::NotifyError(TEXT("Failed to join the session as no version is found."));
			return ESessionResult::Error_TomlVersionNotFound;
		}
	}

	return ESessionResult::Error_InvalidStage;
}

UOmniverseUSD::ESessionResult UOmniverseUSD::CreateSession(const FString& SessionName, FOmniversePreSessionStarted PreLiveEnabled)
{
	if (IsLiveLayer())
	{
		return ESessionResult::Error_NonLivable;
	}

	if (StageCtrl)
	{
		FOmniverseListFileResult Result;
		if (FOmniverseConnectionHelper::ListFileSync(FOmniversePathHelper::GetLiveSessionPath(OmniPath, SessionName), Result))
		{
			return ESessionResult::Error_ExistSession;
		}

		TMap<IOmniverseSessionConfig::Key, FString> ConfigMap;

		const auto& WatchServerList = IOmniverseRuntimeModule::Get().GetWatchList();
		for (auto WatchServer : WatchServerList)
		{
			if (GetAssetServer().Equals(WatchServer.Address))
			{
				ConfigMap.Add(IOmniverseSessionConfig::Key::UserName, WatchServer.UserName);
				break;
			}
		}
		
        ConfigMap.Add(IOmniverseSessionConfig::Key::StageUrl, OmniPath);
        ConfigMap.Add(IOmniverseSessionConfig::Key::Mode, "default");

		if (IOmniverseSessionConfig::Get()->CreateSessionConfig(FOmniversePathHelper::GetLiveSessionConfigPath(OmniPath, SessionName), ConfigMap))
		{
			auto Stage = pxr::UsdStage::CreateNew(TCHAR_TO_UTF8(*FOmniversePathHelper::GetLiveSessionLayerPath(OmniPath, SessionName)));
			if (!Stage)
			{
				return ESessionResult::Error_LayerCreate;
			}
			
			return JoinSession(SessionName, PreLiveEnabled);
		}
		else
		{
			return ESessionResult::Error_WriteToml;
		}
	}

	return ESessionResult::Error_InvalidStage;
}

bool UOmniverseUSD::IsSessionOwner() const
{
	return IsLiveSessionOwner.IsSet() ? IsLiveSessionOwner.GetValue() : false;
}

bool UOmniverseUSD::IsEmptySession() const
{
	return StageCtrl ? StageCtrl->IsEmptyLiveSession() : false;
}

const FName UOmniverseUSD::GetSessionOwner() const
{
	return CurrentLiveSessionOwner.IsSet() ? CurrentLiveSessionOwner.GetValue() : NAME_None;
}

void UOmniverseUSD::StartMergeSession()
{
	IOmniverseCollaboration::Get()->SendMessage(EOmniverseMessageType::MergeStarted);
}

bool UOmniverseUSD::CanEndToNewLayer()
{
	return StageCtrl ? !StageCtrl->HasAnySpecsInRootLayer() : false;
}

void UOmniverseUSD::EndAndMergeSession(const FString& LayerFile)
{
	FOmniverseConnectionHelper::LiveUpdate();

	if (StageCtrl)
	{
		// Create checkpoints to live layer and root layer
		FOmniverseConnectionHelper::CreateCheckpointSync(FOmniversePathHelper::GetLiveSessionLayerPath(OmniPath, CurrentLiveSession.GetValue().ToString()));
		FOmniverseConnectionHelper::CreateCheckpointSync(OmniPath);

		if (LayerFile.IsEmpty())
		{
			StageCtrl->MergeLiveSession();
		}
		else
		{
			StageCtrl->MergeLiveSessionToNewLayer(TCHAR_TO_UTF8(*LayerFile));
		}

		// change checkpoint message
		FOmniverseConnectionHelper::SetCheckpointToResolver(FString::Printf(TEXT("Merge changes from live %s: %s"), *CurrentLiveSession.GetValue().ToString(), *IOmniverseRuntimeModule::Get().GetCheckpointComment()));
		StageCtrl->GetRemoteRootLayer()->Save();
		FOmniverseConnectionHelper::SetCheckpointToResolver(FString());

		IOmniverseCollaboration::Get()->SendMessage(EOmniverseMessageType::MergeFinished);

		LeaveSession();
	}
}

void UOmniverseUSD::LeaveSession()
{
	if (StageCtrl)
	{
		CurrentLiveSessionOwner.Reset();
		IsLiveSessionOwner.Reset();
		CurrentLiveSession.Reset();
		StageCtrl->CloseLiveSession();
		IOmniverseCollaboration::Get()->SendMessage(EOmniverseMessageType::UserLeft);
		IOmniverseCollaboration::Get()->Unsubscribe();
		USDLayerDataSource->RefreshAuthorLayer();
		IOmniverseRuntimeModule::Get().EnableLiveUpdate(false);
	}
}

void UOmniverseUSD::OmniListCallback(const FOmniverseListFileResult& ListResult)
{
	if (ListResult.Status != eOmniClientResult_Ok && ListResult.Status != eOmniClientResult_OkLatest)
	{
		HandleError(ListResult.Status);
		StopSubscribe();
		return;
	}
}

void UOmniverseUSD::UpdatehVersion()
{
	if (!IsDefaultUSD())
	{
		FOmniverseListFileResult Result;
		if (FOmniverseConnectionHelper::ListFileSync(OmniPath, Result))
		{
			OmniReceivedLatestVersion = Result.ListItem.Version;
		}
	}
}

void UOmniverseUSD::CloseFetchNotification()
{
	if (FetchNotification.IsValid())
	{
		FetchNotification.Pin()->SetCompletionState(SNotificationItem::CS_None);
		FetchNotification.Pin()->ExpireAndFadeout();
		FetchNotification.Reset();
	}
}

void UOmniverseUSD::OmniSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult)
{
	if (SubscribeResult.Status != eOmniClientResult_Ok && SubscribeResult.Status != eOmniClientResult_OkLatest)
	{
		HandleError(SubscribeResult.Status);
		StopSubscribe();
		return;
	}

	if (OmniReceivedLatestVersion.IsEmpty() || OmniReceivedLatestVersion != SubscribeResult.ListItem.Version)
	{
		OmniReceivedLatestVersion = SubscribeResult.ListItem.Version;

		if (!FetchNotification.IsValid())
		{
			FString Message = FString::Printf(TEXT("%s %s been changed, please fetch changes."), StageCtrl ? TEXT("Base USD files") : *FPaths::GetCleanFilename(OmniPath), StageCtrl ? TEXT("have") : TEXT("has"));
			FetchNotification = FOmniverseNotificationHelper::NotifySelection(Message,
				TEXT("Fetch"), TEXT("Fetch"), FSimpleDelegate::CreateLambda([&]()
				{
					// NOTE: There's known issue about sublayer, watch OM-65678 how it goes
					auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*OmniPath));
					if (Layer)
					{
						Layer->Reload();
						auto CurrentDataSource = IOmniverseLayerDataSource::GetCurrentLayerDataSource();
						if (CurrentDataSource)
						{
							CurrentDataSource->SetLayerDirty(OmniPath, false);
						}
					}
					CloseFetchNotification();
				}),
				TEXT("Cancel"), TEXT("Cancel"), FSimpleDelegate::CreateLambda([&]()
				{
					CloseFetchNotification();
				}));
		}	
	}
}

void UOmniverseUSD::StartSublayersSubscribe()
{
	auto Layer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*OmniPath));
	if (Layer && !Layer->IsAnonymous())
	{
		auto SublayerPaths = Layer->GetSubLayerPaths();
		for (auto SublayerPath : SublayerPaths)
		{
			FString AbsolutePath = Layer->ComputeAbsolutePath(SublayerPath).c_str();
			// Ignore live layer
			if (FPaths::GetExtension(AbsolutePath).Equals(TEXT("live"), ESearchCase::IgnoreCase))
			{
				continue;
			}
			auto SubLayer = pxr::SdfLayer::FindOrOpen(TCHAR_TO_UTF8(*AbsolutePath));
			if (SubLayer && !SubLayer->IsAnonymous())
			{
				UOmniverseUSD* OmniUSD = UOmniverseAsset::LoadAsset<UOmniverseUSD>(AbsolutePath);
				if (OmniUSD)
				{
					OmniUSD->StartLayerSubscribe();
					SublayerUSDMap.FindOrAdd(AbsolutePath, OmniUSD);
				}
			}
		}
	}
}

void UOmniverseUSD::StopSublayersSubscribe()
{
	for (auto SublayerPair : SublayerUSDMap)
	{	
		if (SublayerPair.Value)
		{
			SublayerPair.Value->StopLayerSubscribe();
		}
	}
	SublayerUSDMap.Reset();
}

void UOmniverseUSD::StartLayerSubscribe()
{
	if (!USDLayerNoticeListener.IsValid())
	{
		USDLayerNoticeListener.Reset(new FUSDLayerNoticeListener(*this));
		LayerSaveNoticeKey = pxr::TfNotice::Register(pxr::TfCreateWeakPtr(USDLayerNoticeListener.Get()), &FUSDLayerNoticeListener::HandleGlobalLayerSave);
	}

	StartSubscribe();
	StartSublayersSubscribe();
}

void UOmniverseUSD::StopLayerSubscribe()
{
	pxr::TfNotice::Revoke(LayerSaveNoticeKey);
	USDLayerNoticeListener.Reset();

	StopSublayersSubscribe();
	StopSubscribe();
}

void UOmniverseUSD::MarkLayerDirty(const FString& LayerIdentifier)
{
	auto USDLayerStateDataSource = static_cast<FOmniverseUSDLayerDataSource*>(USDLayerDataSource.Get());
	USDLayerStateDataSource->SetLayerDirty(LayerIdentifier, true);
}

bool UOmniverseUSD::IsLiveLayer()
{
	return FPaths::GetExtension(OmniPath).Equals(TEXT("live"), ESearchCase::IgnoreCase);
}
