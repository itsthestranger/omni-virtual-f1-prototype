// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "ActorFactoryUSD.h"
#include "USDConverter.h"
#include "OmniverseStageActor.h"
#include "OmniverseUSD.h"

#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING
#include <experimental/filesystem>
#undef _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING

UActorFactoryUSD::UActorFactoryUSD(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	DisplayName = FText::FromString("USD");
	NewActorClass = AActor::StaticClass();
	bUseSurfaceOrientation = true;
}

bool UActorFactoryUSD::CanCreateActorFrom(const FAssetData& AssetData, FText& OutErrorMsg)
{
	if(!AssetData.IsValid() || !AssetData.GetClass()->IsChildOf(UOmniverseUSD::StaticClass()))
	{
		return false;
	}

	return true;
}

void UActorFactoryUSD::PostSpawnActor(UObject* Asset, AActor* NewActor)
{
	Super::PostSpawnActor(Asset, NewActor);
}

UObject* UActorFactoryUSD::GetAssetFromActorInstance(AActor* Instance)
{
	return nullptr;
}

void UActorFactoryUSD::PostCreateBlueprint(UObject* Asset, AActor* CDO)
{
}

FQuat UActorFactoryUSD::AlignObjectToSurfaceNormal(const FVector& InSurfaceNormal, const FQuat& ActorRotation) const
{
	// Meshes align the Z (up) axis with the surface normal
	return FindActorAlignmentRotation(ActorRotation, FVector(0.f, 0.f, 1.f), InSurfaceNormal);
}

AActor* UActorFactoryUSD::SpawnActor(UObject* InAsset, ULevel* InLevel, const FTransform& InTransform, const FActorSpawnParameters& InSpawnParams)
{
	auto USD = Cast<UOmniverseUSD>(InAsset);
	if(!USD)
	{
		return nullptr;
	}

	auto& StageActor = AOmniverseStageActor::Get(*InLevel->GetWorld());
	UActorComponent* Component = StageActor.AddUSDReference(USD, InTransform);
	if(!Component)
	{
		return nullptr;
	}

	return Component->GetOwner();
}
