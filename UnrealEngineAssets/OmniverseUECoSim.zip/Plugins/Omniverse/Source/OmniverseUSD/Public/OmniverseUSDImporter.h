// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "OmniversePxr.h"
#include "CoreMinimal.h"
#include "Logging/LogMacros.h"
#include "OmniverseImportSettings.h"

class OMNIVERSEUSD_API FOmniverseUSDImporter
{
public:
	static bool LoadUSD(const FString& Path, const FString& Dest, const FOmniverseImportSettings& ImportSettings = FOmniverseImportSettings());
	static bool Reimport(class UObject* Object);

private:
	static bool Reimport(class UStaticMesh* StaticMesh, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath);
	static bool Reimport(class USkeletalMesh* SkeletalMesh, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath);
	static bool Reimport(class UAnimSequence* AnimSequence, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath);
	static bool Reimport(class UTexture* Texture, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath);
	static bool Reimport(class UMaterialInterface* MaterialInterface, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath);

	static class UMaterialInterface* ReimportMDL(class UObject* InOuter, FName Name, const FString& AbsolutePath, const FString& PrimPath, const FString& SubPrimPath, const TMap<FString, UTexture*>& ExistingTextures);
	static class UMaterialInterface* ReimportMaterialGraph(const pxr::UsdShadeShader& ShadeShader, class UObject* InOuter, FName Name, class UMaterialInterface* MaterialInterface, const TMap<FString, UTexture*>& ExistingTextures);
	static class UMaterialInterface* ReimportPreviewSurface(const pxr::UsdShadeShader& ShadeShader, class UObject* InOuter, FName Name, const TMap<FString, UTexture*>& ExistingTextures);
	static class UMaterialInterface* ReimportMDLSchema(const pxr::UsdShadeShader& ShadeShader, class UObject* InOuter, FName Name, class UMaterialInterface* MaterialInterface, const TMap<FString, UTexture*>& ExistingTextures);
	static class UTexture* ReimportTexture(const TMap<FString, UTexture*>& ExistingTextures, class UObject* InOuter, const uint8* Content, uint64 Size, const FString& TextureSouceFile);
	static class UMaterialInterface* ReimportMaterial(const TMap<FString, UMaterialInterface*>& ExistingMaterials, class UObject* ParentPackage, const pxr::UsdGeomSubset& USDSubset);
	static class UMaterialInterface* ReimportMaterial(const TMap<FString, UMaterialInterface*>& ExistingMaterials, class UObject* ParentPackage, const pxr::UsdGeomMesh& USDMesh);
	static class UMaterialInterface* ReimportMaterial(const TMap<FString, UMaterialInterface*>& ExistingMaterials, class UObject* ParentPackage, const pxr::UsdShadeShader& Shader, const pxr::UsdShadeShader& MdlShader);
};