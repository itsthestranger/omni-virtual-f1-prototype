// Copyright(c) 2020, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "OmniverseExportSettings.h"
#include "OmniverseImportSettings.h"
#include "OmniversePxr.h"

class OMNIVERSEUSD_API FOmniverseReferenceCollector
{
public:
	FOmniverseReferenceCollector();

	virtual ~FOmniverseReferenceCollector();

	int32 GetAllDependencies(const TArray<class AActor*>& Actors, const FOmniverseExportSettings& ExportSettings);

	int32 GetAllDependencies(const pxr::UsdStageRefPtr& USDStage, const FOmniverseImportSettings& ImportSettings);

	bool FindDependency(const FName& PackageName);

	void Reset();

	static FOmniverseReferenceCollector& Get();

private:

	void GetDependenciesInternal(const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& Path, bool bFromSkelRoot);
	void GetDependenciesInternal(const class USceneComponent& Component);
	void GetTextureDependencies(const FName& PackageName, const FString& Root);

	// all the dependencies for current package
	TSet<FName> LoadedDependencies;
	// the dependencies which are needed by omniverse
	TSet<FName> SupportedDependencies;

	bool CurrentMaterialSkipped;
	bool CurrentTextureSkipped;
	bool CurrentDecalSkipped;
	bool CurrentUnusedSkipped;
};