// Copyright(c) 2019, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"
#include "OmniversePxr.h"

class OMNIVERSEUSD_API OmniUsdStageCtrl: public pxr::TfWeakBase, public pxr::TfRefBase
{
public:
	explicit  OmniUsdStageCtrl(pxr::UsdStageRefPtr& stage);
	 ~OmniUsdStageCtrl();

	pxr::UsdStageWeakPtr  GetStage()const { return stage; }
	pxr::SdfLayerRefPtr  GetRemoteRootLayer()const { return remoteRootLayer; }
	pxr::SdfLayerRefPtr  GetSessionLayer()const { return sessionLayer; }
	pxr::SdfLayerRefPtr  GetLiveLayer()const { return liveLayer; }

	void InitLayerMuteness(const pxr::SdfLayerHandle& layer);
	bool  GetSubLayerVisibility(const std::string& identifier, bool global)const;
	bool  SetSubLayerVisibility(const std::string& identifier, bool visible, bool global);
	bool  IsSubLayerLocked(const std::string& identifier)const;
	bool  SetSubLayerLocked(const std::string& identifier, bool lock);
	pxr::SdfLayerRefPtr  CreateSubLayer(int index);
	bool  OpenLiveSession(const std::string& path);
	void  CloseLiveSession();
	bool  IsEmptyLiveSession();
	void  MergeLiveSession();
	void  MergeLiveSessionToNewLayer(const std::string& layerIdentifier);
	bool  UpdateSublayerHandles();
	bool  HasAnySpecsInRootLayer();
	int32 GetSublayerPriority(const FString& layer, const FString& sublayer);
	TArray<FString> GetSublayerIdentifiers();

	static bool RemovePrimSpecInEditLayer(const pxr::UsdPrim& prim);
	static pxr::SdfLayerHandle  HasOverriddenInStrongerLayer(const pxr::UsdStageRefPtr& Stage, const pxr::SdfPath& PrimPath, bool bOnlyActivePrim = false);
	static int  FindSubLayerIndex(const pxr::SdfLayerHandle& rootLayer, const std::string& path);
	static pxr::TfToken  GetSubLayerName(const pxr::SdfLayerHandle& rootLayer, int index);
	static bool  SetSubLayerName(const pxr::SdfLayerHandle& rootLayer, int index, const pxr::TfToken& name);
	static pxr::SdfLayerRefPtr  CreateSubLayer(const pxr::SdfLayerHandle& rootLayer, int index);
	static bool  RemovePrim(const pxr::UsdPrim& prim);
	static bool  RestorePrim(const pxr::SdfLayerRefPtr& AnonymousLayer, const std::string& LayerIdentifier, const pxr::SdfPath& PrimPath);
	static bool  CopyPrim(const pxr::UsdPrim& prim, pxr::SdfPath dstPath = pxr::SdfPath());
	static bool  RenamePrim(const pxr::UsdPrim& prim, const pxr::TfToken& newName);
	static bool IsAncestralPrim(const pxr::UsdPrim& Prim);
	static bool IsAncestorGprim(const pxr::UsdStageRefPtr& Stage, const pxr::SdfPath& PrimPath);
	static bool CanRemovePrim(const pxr::UsdPrim& prim);
	static bool GetIntroducingLayer(const pxr::UsdPrim& prim, pxr::SdfLayerHandle& outLayer, pxr::SdfPath& outPath);
	static void ResolvePaths(const std::string& srcLayerIdentifier, const std::string& targetLayerIdentifier, bool storeRelativePath, bool relativeToSrcLayer = false, bool copySublayerLayerOffsets = false);
	static bool MergePrimSpec(const std::string& dstLayerIdentifier, const std::string& srcLayerIdentifier, const std::string& primSpecPath, bool isDstStrongerThanSrc, const std::string& targetPrimPath = "");
	static std::vector<std::string> GetAllSublayers(const pxr::UsdStageRefPtr& stage, bool includeSessionLayer);
	static void ResolvePrimPathReferences(const pxr::SdfLayerRefPtr& layer, const pxr::SdfPath& oldPath, const pxr::SdfPath& newPath);
	static bool StitchPrimSpecs(const pxr::UsdPrim& prim, pxr::SdfPath dstPath);
	static bool IsLayerExist(const std::string& layerIdentifier);
	static void ResolvePathsInternal(const pxr::SdfLayerRefPtr& srcLayer, pxr::SdfLayerRefPtr dstLayer, bool storeRelativePath, bool relativeToSrcLayer = false, bool copyLayerOffsets = false);
	static bool MergePrimSpecInternal(pxr::SdfLayerRefPtr dstLayer, const pxr::SdfLayerRefPtr& srcLayer, const pxr::SdfPath& primSpecPath, bool isDstStrongerThanSrc, const pxr::SdfPath& targetPrimPath = pxr::SdfPath::EmptyPath());
	static void ReloadAllRelatedLayers(const pxr::SdfLayerRefPtr& Layer);

	static void DebugLayerToFile(const pxr::SdfLayerHandle& Layer, const FString& FileName);

protected:

	void OnStageChanged(const pxr::UsdNotice::ObjectsChanged& objectsChanged, const pxr::UsdStageWeakPtr& sender);
	void UpdateSublayerHandlesInternal(const pxr::SdfLayerHandle& layer);

	pxr::UsdStageWeakPtr stage;
	pxr::SdfLayerRefPtr remoteRootLayer;
	pxr::SdfLayerRefPtr sessionLayer;
	pxr::SdfLayerRefPtr liveLayer;
	pxr::TfNotice::Key stageChangeNotice;
	pxr::VtDictionary layerMutenessMap;
	TMap<FString, pxr::SdfLayerRefPtr> subLayers;
};
