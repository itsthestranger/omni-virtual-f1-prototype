// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "OmniverseImportSettings.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "OmniverseUSDBlueprintLibrary.generated.h"

UCLASS()
class OMNIVERSEUSD_API UOmniverseUSDBlueprintLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/** Import usd facial animation to the animation sequence. Support both Nucleus and local usd. */
	UFUNCTION(BlueprintCallable, Category="Omniverse USD Import")
	static bool LoadFacialAnimation(const FString& Path, const FString& Dest, class USkeleton* Skeleton, FName Name = NAME_None);

	/** Import usd to the unreal assets. Support both Nucleus and local usd. */
	UFUNCTION(BlueprintCallable, Category="Omniverse USD Import")
	static bool LoadUSD(const FString& Path, const FString& Dest, const FOmniverseImportSettings& ImportSettings);
	
	/** Reimport the unreal asset from source file. */
	UFUNCTION(BlueprintCallable, Category="Omniverse USD Import")
	static bool Reimport(class UObject* Object);
};