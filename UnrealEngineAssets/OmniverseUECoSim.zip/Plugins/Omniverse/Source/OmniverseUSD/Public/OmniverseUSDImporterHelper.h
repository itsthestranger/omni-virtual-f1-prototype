// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "OmniversePxr.h"
#include "OmniverseTexture.h"
#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Engine/Texture.h"
#include "USDSkeletalDataConversion.h"
#include "USDModulesIncludesEnd.h"

class OMNIVERSEUSD_API FOmniverseUSDImporterHelper
{
public:
	//Import
	static bool USDImportMesh(const pxr::UsdGeomMesh& USDMesh, class UStaticMesh& Mesh);

	static bool USDImportSkeleton(const pxr::UsdSkelSkeletonQuery& USDSkeletonQuery, class FSkeletalMeshImportData& SkeletalMeshImportData);
	static bool USDImportSkinning(const pxr::UsdSkelSkeletonQuery& USDSkeletonQuery, const pxr::UsdSkelSkinningQuery& USDSkinningQuery, class FSkeletalMeshImportData& SkeletalMeshImportData);
	static bool USDImportBlendShapes(const pxr::UsdSkelSkinningQuery& USDSkinningQuery, const uint32 NumPointsBeforeThisMesh, UsdUtils::FBlendShapeMap& BlendShapesByPath, TSet<FString>& InOutUsedMorphTargetNames);

	static void BuildSourceModel(class UStaticMesh* Mesh);
	static class UStaticMesh* CreateStaticMesh(const pxr::UsdGeomMesh& USDMesh, class UObject* Parent, FName Name, EObjectFlags Flags);
	static class UAnimSequence* CreateAnimSequence(const pxr::UsdSkelSkeletonQuery& USDSkeletonQuery, const pxr::UsdSkelBinding& Binding, const UsdUtils::FBlendShapeMap* InBlendShapes, class UObject* Parent, FName Name, EObjectFlags Flags, class USkeleton* Skeleton, class USkeletalMesh* PreviewMesh, double StartTimeCode, double EndTimeCode, float& StartOffsetSeconds, FBox* BoundingBox = nullptr);

	static bool GetMdlPathAndName(pxr::UsdShadeShader ShadeShader, FString& MdlPath, FString& MaterialName, bool& bRelativePath);
	static bool LoadMaterialGraph(const pxr::UsdShadeShader& ShadeShader, class UMaterial* Material);
	
	static void UpdatePreviewSurfaceInputs(class UMaterialInstanceConstant* MaterialInst, const pxr::UsdShadeShader& ShadeShader, const TMap<FString, int32>* UVSets, TFunction<void(const FString&)> Callback = nullptr, TFunction<void(const uint8*, uint64, const FString&, UTexture*&)> CreateCallback = nullptr, TFunction<void(FString&, UTexture*&, UOmniverseTexture*&)> LoadCallback = nullptr, TFunction<void(UOmniverseTexture*, UTexture*, bool)> OverrideSRGBCallback = nullptr);
	static bool UpdateMaterialGraphInputs(const pxr::UsdShadeShader& ShadeShader, class UMaterialInstanceConstant* Instance, TFunction<void(const uint8*, uint64, const FString&, UTexture*&)> CreateCallback = nullptr, TFunction<void(FString&, UTexture*&, UOmniverseTexture*&)> LoadCallback = nullptr, TFunction<void(UOmniverseTexture*, UTexture*, bool)> OverrideSRGBCallback = nullptr);
	static bool LoadMdlInput(class UMaterialInstanceConstant& InstanceConstant, const pxr::UsdShadeInput& Input, const FString& DisplayName, bool bCheckParameter = false, TFunction<void(const uint8*, uint64, const FString&, UTexture*&)> CreateCallback = nullptr, TFunction<void(FString&, UTexture*&, UOmniverseTexture*&)> LoadCallback = nullptr, TFunction<void(UOmniverseTexture*, UTexture*, bool)> OverrideSRGBCallback = nullptr);

private:
	static void LinkNodeGraphShader(const pxr::UsdShadeShader& ShadeShader, FString& InstanceName);
	static void LinkNodeGraphShader(const pxr::UsdShadeNodeGraph& NodeGraph, const pxr::TfToken& SourceName, const FString& InputName, const FString& InstanceName);
	static bool USDImportMesh(const pxr::UsdGeomMesh& USDMesh, struct FStaticMeshLODResources& MeshRes);
	static bool USDImportMesh(const pxr::UsdGeomMesh& USDMesh, const FTransform& GeomTransform, TArray<struct FStaticMeshBuildVertex>& Vertices, TArray<FVector>& Points, TArray<uint32>& Indices, TArray<uint32>& FacePosInIndices, TArray<uint32>& FacePosInVertices, int32& TriangleCount, int32& UVCount);
	static void UpdateNodeGraphInput(class UMaterialInstanceConstant* Instance, const pxr::UsdShadeShader& ShadeShader, const FString& ParentInputName, TFunction<void(const uint8*, uint64, const FString&, UTexture*&)> CreateCallback, TFunction<void(FString&, UTexture*&, UOmniverseTexture*&)> LoadCallback, TFunction<void(UOmniverseTexture*, UTexture*, bool)> OverrideSRGBCallback);
	static void UpdateNodeGraphInput(class UMaterialInstanceConstant* Instance, const pxr::UsdShadeNodeGraph& NodeGraph, const pxr::TfToken& SourceName, const FString& ParentInputName, TFunction<void(const uint8*, uint64, const FString&, UTexture*&)> CreateCallback, TFunction<void(FString&, UTexture*&, UOmniverseTexture*&)> LoadCallback, TFunction<void(UOmniverseTexture*, UTexture*, bool)> OverrideSRGBCallback);
	static bool LoadTextureByShadeInput(const pxr::UsdShadeInput& FileInput, const pxr::UsdShadeInput& SourceColorSpace, class UMaterialInstanceConstant& MaterialInstance, class UMaterialEditorInstanceConstant* EditorInst, const FString& PropertyName, bool bSetDefaultColorSpace, bool bDefaultSRGB, TFunction<void(const uint8*, uint64, const FString&, UTexture*&)> CreateCallback, TFunction<void(FString&, UTexture*&, UOmniverseTexture*&)> LoadCallback, TFunction<void(UOmniverseTexture*, UTexture*, bool)> OverrideSRGBCallback);
};