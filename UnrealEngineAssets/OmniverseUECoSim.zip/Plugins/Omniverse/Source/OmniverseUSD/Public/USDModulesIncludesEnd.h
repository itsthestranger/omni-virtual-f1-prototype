// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.



// NOTE: USDIncludesStart.h enabled _DEBUG for Boost, but never disabled it in USDIncludesEnd.h
// We must include this file to disable _DEBUG after inluding headers from Epic usd plugin
// Or there's be a compilation error conflicting with PhysX3 PxPreprocessor.h
// #error:  Exactly one of NDEBUG and _DEBUG needs to be defined!

#if PLATFORM_WINDOWS && UE_BUILD_DEBUG
	#ifdef _DEBUG
		#undef _DEBUG
	#endif
#endif
