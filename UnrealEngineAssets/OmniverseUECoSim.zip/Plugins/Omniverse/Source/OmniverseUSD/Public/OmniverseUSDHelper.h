// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "OmniversePxr.h"
#include "MeshDescription.h"
#include "OmniverseExportSettings.h"
#include "SceneTypes.h"
#include "LevelSequenceActor.h"

class UMaterialInterface;

class OMNIVERSEUSD_API FOmniverseUSDHelper
{
public:
	static bool ExportObjectAsUSDToPath(class UObject* Object, const FString& ExportPath, const FString& ExportMDLBasePath, const FOmniverseExportSettings& ExportSettings);

	static bool ExportUWorldAsUSDToPath(class UWorld* World, const FString& ExportWorldStagePath, const FOmniverseExportSettings& ExportSettings);

	static bool ExportActorsAsUSDToPath(const TArray<class AActor*>& Actors, const FString& ExportUSDPath, const FOmniverseExportSettings& ExportSettings);

	static void SetTransfromForXForm(pxr::UsdGeomXformable& XForm, const pxr::GfMatrix4d& Transform);

	static void GetActorsToExportFromWorld(class UWorld* World, bool bSelectedOnly, const FOmniverseExportSettings& ExportSettings, TArray<AActor*>& ActorToExport, TArray<class ALevelSequenceActor*>& LevelSequenceActors);

	// Clear existing or create a new one, if bWithBackgroundLayer is true
	// it will create a stage with a default active background layer
	static pxr::UsdStageRefPtr CreateUSDStageFromPath(const FString& Path, bool bKeepExistingStage, bool bZUpAxis);

	static pxr::UsdStageRefPtr LoadUSDStageFromPath(const FString& Path);

	static pxr::SdfPath InitDefaultPrim(const pxr::UsdStageRefPtr& USDStage, const pxr::TfToken& PrimKind = pxr::KindTokens->assembly);

private:
	static pxr::UsdShadeMaterial BindMaterial(const pxr::UsdStageRefPtr& USDStage, const pxr::UsdPrim& Prim, const pxr::SdfPath& ScopePrimPath, const FString& MaterialName);
	static void CreateMDLSchema(const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& MaterialPrimPath, bool MdlSchema, const FString& MaterialName, const FString& MaterialRelativePath);
	static void CreatePSSchema(const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& MaterialPrimPath, const FString& MaterialName, const TMap<EMaterialProperty, FString>& PropertyTextures, const TMap<EMaterialProperty, struct FLinearColor>& PropertyConstants);
	static pxr::UsdStageRefPtr CreateUsdMaterialStage(const FString& MaterialUsdPath, const FOmniverseExportSettings& ExportSettings);
	static pxr::UsdShadeMaterial DefineUsdMaterial(const pxr::UsdStageRefPtr& USDStage, const FString& MaterialName);
	static void BindMaterialOverrides(const pxr::UsdStageRefPtr& USDStage, const pxr::UsdPrim& Prim, const class UMaterialInterface* MaterialInt, const FString& MDLRelativePath, const TMap<FString, FString>& ExportedMDLs, const FOmniverseExportSettings& ExportSettings);

	static pxr::UsdGeomXformable ExportStaticMeshToUSD(class UStaticMesh* StaticMesh, class UStaticMeshComponent* StaticMeshComponent, const pxr::UsdStageRefPtr& USDStage,
		const pxr::SdfPath& ExportPrimPath, const FString& ExportMDLBaseAbsolutePath, const FString& ExportMDLBaseRelativePath,
		bool bOverrideMaterial, const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs);

	static bool ExportStaticMeshAsUSDToPathInternal(class UStaticMesh* StaticMesh, class UStaticMeshComponent* StaticMeshComponent, const FString& OmniMeshPath,
		const FString& ExportMDLBaseAbsolutePath, bool bOverrideMaterial, const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs);

	static bool ExportOverrideMeshAsUSDToPath(UStaticMeshComponent* StaticMeshComponent, const FString& USDAbsolutePath, const FString& MeshUSDRelativePathToRoot, const FString& MeshUSDPath, int32 LODToExport, const FString& MDLAbsoluteBasePath, const FString& MDLRelativeBasePathToRoot, const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs);

	static bool ExportComponentToUSD(class USceneComponent* SceneComp, const pxr::UsdStageRefPtr& USDStage, const pxr::UsdStageRefPtr& MaterialOversStage, const pxr::SdfPath& RootPath, const FOmniverseExportSettings& ExportSettings,
		TMap<FString, FString>& ExportedMeshUSD, TMap<FString, FString>& ExportedMDLs, TMap<FString, FString>& ExportedAnimeUSD);

	static pxr::UsdGeomXformable ExportLandscapeToUSD(class ALandscapeProxy* LandscapeProxy, const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& ExportPrimPath,
			const FString& ExportMDLBaseAbsolutePath, const FString& ExportMDLBaseRelativePath,
			const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs, TMap<FString, FString>& ExportedMeshUSD,
			bool bStandaloneUSD = false, const FString& ExportMeshPath = TEXT(""));

	template<typename InstancedComponent>

	static pxr::UsdGeomPointInstancer ExportInstancedMeshesToPointInstancer(const TArray<TObjectPtr<InstancedComponent>>& InstancedStaticMeshComponents, 
																			const pxr::UsdStageRefPtr& USDStage, 
																			const pxr::SdfPath& ExportPrimPath, 
																			const FOmniverseExportSettings& ExportSettings, 
																			TMap<FString, FString>& ExportedMDLs,
																			TMap<FString, FString>& ExportedMeshUSD,
																			bool bStandaloneUSD = false, 
																			bool bRenderData = false, 
																			const FString& ExportMeshPath = TEXT(""));

	static pxr::UsdGeomXformable ExportConvertedMeshToUSD(class USceneComponent* SceneComponent, const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& ExportPrimPath,
		const FString& ExportMDLBaseAbsolutePath, const FString& ExportMDLBaseRelativePath,
		const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs,
		bool bStandaloneUSD = false, const FString& ExportMeshPath = TEXT(""));

	static pxr::UsdSkelRoot ExportSkeletalMeshToUSD(class USkeletalMesh* SkeletalMesh, class USkeletalMeshComponent* SkeletalMeshComponent,
		const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& ExportPrimPath, const FString& ExportMDLBaseAbsolutePath, const FString& ExportMDLBaseRelativePath,
		bool bOverrideMaterial, const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs);

	static bool ExportSkeletalMeshAsUSDToPathInternal(class USkeletalMesh* SkeletalMesh, class USkeletalMeshComponent* SkeletalMeshComponent, const FString& OmniMeshPath,
		const FString& ExportMDLBaseAbsolutePath, bool bOverrideMaterial, const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs);

	static pxr::UsdGeomXformable ExportBrushToUSD(class UBrushComponent* BrushComponent, const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& ExportPrimPath,
		const FString& ExportMDLBaseAbsolutePath, const FString& ExportMDLBaseRelativePath,
		const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMDLs, bool bStandaloneUSD = false, const FString& ExportMeshPath = TEXT(""));

	static bool ExportAnimationAssetAsUSDToPathInternal(class UAnimationAsset * AnimationAsset, class USkeletalMeshComponent* SkeletalMeshComponent, const FString & ExportAnimePath, const FOmniverseExportSettings& ExportSettings);

	static bool ExportAnimationTimeSamplesAsUSDToPathInternal(const TArray<struct FSkeletalAnimationTimeSamples>* AnimationTimeSamples, const double StartTimeCode, const double EndTimeCode, const double TimeCodesPerSecond, class USkeletalMeshComponent* SkeletalMeshComponent, const FString & ExportAnimePath, const FOmniverseExportSettings& ExportSettings);

	static bool ExportObjectAsUSDToPathInternal(class UObject* Object, const FString & ExportPath, const FOmniverseExportSettings& ExportSettings);

	static bool ExportBlueprintAsUSDToPathInternal(class UBlueprint* Blueprint, const FString& ExportPath, const FOmniverseExportSettings& ExportSettings);

	typedef TFunction<void(const pxr::UsdStageRefPtr& Stage, const pxr::SdfPath& PrimPath, const struct FOmniverseExportMaterialResult&, FString&)> FExportMaterialPreCallback;
	typedef TFunction<void(const pxr::UsdStageRefPtr& Stage, const pxr::SdfPath& PrimPath, const FString&, const struct FOmniverseExportMaterialResult&, const FString&)> FExportMaterialPostCallback;

	static void ExportAndBindMaterial(const pxr::UsdStageRefPtr& USDStage, class UMaterialInterface* MaterialInterface, const struct FNamedParameterTimeSamples* ParameterTimeSamples, const pxr::UsdPrim& Prim, const FOmniverseExportSettings& ExportSettings, const FString& MDLAbsolutePath, const FString& MDLRelativePath, TMap<FString, FString>& ExportedMDLs, const FString& CustomMaterialName = TEXT(""), const FString& CustomUsdMaterialName = TEXT(""), FExportMaterialPreCallback InPreCallback = nullptr, FExportMaterialPostCallback InPostCallback = nullptr);

	static bool TryExportAndBindMaterialWithAOMask(class UStaticMeshComponent* StaticMeshComponent, const struct FNamedParameterTimeSamples* ParameterTimeSamples, int32 LODToExport, const pxr::UsdStageRefPtr& USDStage, class UMaterialInterface* MaterialInt, const pxr::UsdPrim& Prim,
		const FOmniverseExportSettings& ExportSettings, const FString& MDLBaseAbsolutePath, const FString& MDLBaseRelativePath, TMap<FString, FString>& ExportedMDLs);

	static void BakePreviewSurface(UMaterialInterface* MaterialInterface, const FString& MaterialName, const FString& AbsolutePath, const FString& RelativePath, const TMap<EMaterialProperty, struct FLinearColor>& ConstantProperties, TMap<EMaterialProperty, FString>& OutTextureProperties);

	static void ExportModelToUSD(class UModel* Model, const pxr::UsdStageRefPtr& USDStage, const pxr::UsdStageRefPtr& MaterialOversStage, const FOmniverseExportSettings& ExportSettings, TMap<FString, FString>& ExportedMeshUSD, TMap<FString, FString>& ExportedMDLs);
	
	static void ExportInstanceParametersToMDLSchema(const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& MaterialPrimPath, const FString& MaterialName, class UMaterialInstance* InstanceDynamic, const struct FOmniverseExportMaterialResult& MaterialResult, const FString& MDLAbsolutePath, bool bMaterialNameAsTextureFolder, const FOmniverseExportTextureSettings& TextureSettings);

	static void ExportParameterTimeSamplesToMDLSchema(const pxr::UsdStageRefPtr& USDStage, const pxr::SdfPath& MaterialPrimPath, const FString& MaterialName, UMaterialInterface* Material, const struct FNamedParameterTimeSamples& ParameterTimeSamples, const FOmniverseExportMaterialResult& MaterialResult, const FString& MDLAbsolutePath, bool bMaterialNameAsTextureFolder, const FOmniverseExportTextureSettings& TextureSettings);

	static bool IsActorSupported(const AActor* Actor, const FOmniverseExportSettings& ExportSettings);

	static int32 SuffixIndex;

	friend class UOmniverseCommandlet;
};