// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"
#include "OmniversePxr.h"

class OMNIVERSEUSD_API IOmniverseUSDTranslator
{
public:
	virtual ~IOmniverseUSDTranslator()
	{
	}

	virtual bool IsActorSupported(const class AActor* Actor) = 0;

	virtual bool IsComponentSupported(const class USceneComponent* Component) = 0;

	virtual bool IsObjectSupported(const class UObject* Object) = 0;

	virtual void GetExportNameAndFullName(const class USceneComponent* Component, FString& Name, FString& FullName) = 0;

	virtual pxr::UsdGeomXformable TranslateObjectToUSD(class UObject* Object, pxr::UsdStageRefPtr USDStage, const pxr::SdfPath& PrimPath) = 0;

	virtual pxr::UsdGeomXformable TranslateComponentToUSD(class USceneComponent* Component, pxr::UsdStageRefPtr USDStage, const pxr::SdfPath& PrimPath) = 0;

};

