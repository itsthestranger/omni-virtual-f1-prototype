// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "OmniversePxr.h"
#include "OmniverseAsset.h"
#include "OmniUsdStageCtrl.h"
#include "OmniverseLayerDataSource.h"
#include "OmniverseConnectionHelper.h"

#include "OmniverseUSD.generated.h"

USTRUCT()
struct FUSDLayerDescription
{
	GENERATED_BODY()

	UPROPERTY()
	FString LayerName;

	UPROPERTY()
	FString LayerContent;

	UPROPERTY()
	bool	bMuted = false;
};

USTRUCT()
struct FUSDLayersSerialization
{
	GENERATED_BODY()

	UPROPERTY()
	FString RootLayerContent;

	// All sublayers will be serialized.
	// Sublayers will be ordered from bottom to topmost
	UPROPERTY()
	TArray<FUSDLayerDescription> USDSublayers;
};

UCLASS()
class OMNIVERSEUSD_API UOmniverseUSD : public UOmniverseAsset
{
	GENERATED_BODY()
public:
	enum class ESessionResult
	{
		OK = 0,
		Error_ExistSession,
		Error_WriteToml,
		Error_NonLivable,
		Error_LayerCreate,
		Error_InvalidStage,
		Error_InvalidToml,
		Error_TomlVersionNotFound,
		Error_InvalidTomlVersion,
		Error_LayerOpen,
	};
public:
	typedef TFunction<void()> FOmniversePreSessionStarted;

	DECLARE_MULTICAST_DELEGATE_TwoParams(FOnUSDChanged, const pxr::SdfPath&, bool);
	FOnUSDChanged OnUSDChanged;

	UOmniverseUSD();
	~UOmniverseUSD();

	virtual bool IsAsset() const override;
	virtual void Load()override;
	virtual void PostLoad()override;
	PRAGMA_DISABLE_DEPRECATION_WARNINGS // Suppress compiler warning on override of deprecated function
	UE_DEPRECATED(5.0, "Use version that takes FObjectPreSaveContext instead.")
	virtual void PreSave(const class ITargetPlatform* TargetPlatform)override;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	virtual void PreSave(class FObjectPreSaveContext ObjectSaveContext) override;
	virtual void SaveToOmniverse() override;

	const pxr::UsdStageRefPtr& LoadUSDStage();
	void ReloadUSDStage();
	bool IsStageLoaded();
	bool IsDefaultUSD();
	const pxr::UsdStageRefPtr& GetUSDStage();
	const TSharedRef<IOmniverseLayerDataSource> GetLayerDataSource() const;

	void SetUSDStage(pxr::UsdStageRefPtr USDStage);
	const TArray<FName>& GetLiveSessionList() const;

	ESessionResult JoinSession(const FString& SessionName, FOmniversePreSessionStarted PreSessionStarted = nullptr);
	ESessionResult CreateSession(const FString& SessionName, FOmniversePreSessionStarted PreSessionStarted = nullptr);
	void LeaveSession();
	void StartMergeSession();
	void EndAndMergeSession(const FString& LayerFile = TEXT(""));
	bool IsEmptySession() const;
	const FName GetSessionName() const;
	bool IsSessionOwner() const;
	const FName GetSessionOwner() const;
	void UpdatehVersion();
	void ReleaseStage();
	bool CanEndToNewLayer();
	void StartSublayersSubscribe();
	void StopSublayersSubscribe();
	void StartLayerSubscribe();
	void StopLayerSubscribe();
	void MarkLayerDirty(const FString& LayerIdentifier);
	bool IsLiveLayer();

	virtual void OmniListCallback(const FOmniverseListFileResult& ListResult) override;
	virtual void OmniSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult) override;

	pxr::TfRefPtr<OmniUsdStageCtrl> StageCtrl;
	
	DECLARE_EVENT_OneParam( UOmniverseUSD, FOnSessionAdded, const FName& );
	FOnSessionAdded OnLiveSessionAdded;

	DECLARE_EVENT_OneParam( UOmniverseUSD, FOnSessionRemoved, const FName& );
	FOnSessionRemoved OnLiveSessionRemoved;

protected:
	struct FUSDNoticeListener: public pxr::TfWeakBase
	{
		FUSDNoticeListener(UOmniverseUSD& USDAsset):USDAsset(USDAsset) {}
		void Handle(const class pxr::UsdNotice::ObjectsChanged& ObjectsChanged, const pxr::TfWeakPtr<OmniUsdStageCtrl>& Sender);

		UOmniverseUSD& USDAsset;
	};

	struct FUSDLayerNoticeListener : public pxr::TfWeakBase
	{
		FUSDLayerNoticeListener(UOmniverseUSD& USDAsset) :USDAsset(USDAsset) {}
		void HandleGlobalLayerSave(const pxr::SdfNotice::LayerDidSaveLayerToFile &n);
		void HandleLayerChange(const class pxr::SdfNotice::LayersDidChange& LayerNotice);
		UOmniverseUSD& USDAsset;
	};

	virtual TArray<FString> GetFileTypes()const override;
	virtual void CreateUnrealAsset() override;

	void SaveInMemoryUSD();
	void HandleUSDNotice(const pxr::UsdNotice::ObjectsChanged& ObjectsChanged, const pxr::UsdStageWeakPtr& Sender);
	void RemovePrimDataSource(const FString& Layer, const FString& Prim);
	void UpdatePrimDataSource(const FString& Layer, const FString& Prim);
	void AddSublayerDataSource(const FString& Layer, const FString& Sublayer);
	void RemoveSublayerDataSource(const FString& Layer, const FString& Sublayer);
	void UpdateSublayerDataSource(const FString& Layer, const FString& Sublayer);
	void RevokeAllNoticekeys();

	void SessionListCallback(const FOmniverseListFolderResult& ListResult);
	void SessionSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult);
	void SessionRootSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult);
	void UsdFolderSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult);
	void StartLiveSessionWatch();
	void StopLiveSessionWatch();
	void StopLiveRootWatch();
	void StopUsdFolderWatch();
	void CloseFetchNotification();
	bool UpdateSublayerHandles();

	// Load USD Stage from serialization or create empty in-memory stage
	pxr::UsdStageRefPtr LoadDefaultUSDStage();

	// After saving UE4 level, this will
	// save all sublayers information
	UPROPERTY()
	FUSDLayersSerialization USDLayersSerialization;

	FOmniverseListFolderCallback SessionListDelegate;
	FOmniverseSubscribeCallback SessionSubscribeDelegate;

	FOmniverseListFolderCallback SessionRootListDelegate;
	FOmniverseSubscribeCallback SessionRootSubscribeDelegate;

	FOmniverseListFolderCallback UsdFolderListDelegate;
	FOmniverseSubscribeCallback UsdFolderSubscribeDelegate;

	bool bInPostLoad = false;
	FString ReloadLayerIdentifier;
	pxr::UsdStageRefPtr USDStage;
	TSharedPtr<IOmniverseLayerDataSource> USDLayerDataSource;
	TUniquePtr<FUSDNoticeListener> USDNoticeListener;
	TUniquePtr<FUSDLayerNoticeListener> USDLayerNoticeListener;
	FDelegateHandle DelegateSaveLocalLayers;
	pxr::TfNotice::Key StageNoticeKey;
	pxr::TfNotice::Key LayerSaveNoticeKey;
	pxr::TfNotice::Key LayerChangeNoticeKey;
	TMap<FString, pxr::TfNotice::Key> SublayerNoticeKey;
	// for watch usd folder
	TSharedOmniverseAyncTask UsdFolderListSubscribeTask;
	// for watch .live
	TSharedOmniverseAyncTask SessionRootListSubscribeTask;
	// for watch .live/session.live
	TSharedOmniverseAyncTask SessionListSubscribeTask;
	TArray<FName> LiveSessionList;
	TOptional<FName> CurrentLiveSession;
	TOptional<FName> CurrentLiveSessionOwner;
	TOptional<bool> IsLiveSessionOwner;
	TWeakPtr<class SNotificationItem> FetchNotification;
	TMap<FString, UOmniverseUSD*> SublayerUSDMap;
};

ENUM_CLASS_FLAGS(UOmniverseUSD::ESessionResult);
