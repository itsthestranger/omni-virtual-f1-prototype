// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include <OmniClient.h>

struct FOmniverseContent
{
public:
	FOmniverseContent(OmniClientContent& InContent)
	{
		Content = omniClientMoveContent(InContent);
	}

	~FOmniverseContent()
	{
		omniClientFreeContent(Content);
	}

	uint8_t* GetData() const
	{
		return (uint8_t*)Content.buffer;
	}

	uint64_t Size() const
	{
		return Content.size;
	}

private:
	OmniClientContent Content;
};
typedef TSharedPtr<FOmniverseContent> TSharedOmniContentPtr;
typedef TSharedRef<FOmniverseContent> TSharedOmniContentRef;

struct FOmniverseListItem
{
	FOmniverseListItem()
		: Path("")
		, Access(0)
		, Flags(0)
		, Size(0)
		, Version("")
		, Hash("")
	{}

	bool operator==(const FOmniverseListItem& Rhs)
	{
		return	Path == Rhs.Path &&
				Access == Rhs.Access && 
				Flags == Rhs.Flags &&
				Size == Rhs.Size &&
				Version == Rhs.Version &&
				Hash == Rhs.Hash;
	}

	// The path for this item relative to the url provided to "List"
	FString Path;
	// YOUR access level OmniClientAccessFlags
	uint32_t Access;
	// Some combination of OmniClientItemFlags
	uint64_t Flags;
	// For files, the size in bytes
	uint64_t Size;
	// Provider-specific version
	// May not be an always incrementing number (could be a hash, for example)
	// Not all URL providers support this, so it may be empty
	FString Version;
	// Provider specific file hash
    // Not all providers support this, so it may be null
	FString Hash;
};

struct FOmniverseListFileResult
{
	FOmniverseListFileResult()
		: Status(eOmniClientResult_Error)
	{}

	OmniClientResult Status;

	FOmniverseListItem ListItem;
};

struct FOmniverseListFolderResult
{
	OmniClientResult Status;
	TArray<FOmniverseListItem> ListItems;
};

struct FOmniverseSubscribeResult
{
	OmniClientResult Status;
	OmniClientListEvent ListEvent;
	FOmniverseListItem ListItem;
};

struct FOmniverseListCheckpointResult
{
	OmniClientResult Status;
	TArray<FOmniverseListItem> ListItems;
};

struct FOmniverseReadResult
{
	OmniClientResult Status;
	TSharedOmniContentPtr Content;
	FString Version;
};

struct FOmniverseJoinChannelResult
{
	OmniClientResult Status;
	OmniClientChannelEvent EventType;
	FString From;
	TSharedOmniContentPtr Content;
};

struct FOmniverseGetServerInfoResult
{
	OmniClientResult Status;
	FString UserName;
	FString AuthToken;
};

class IOmniverseAsyncTask
{
public:
	IOmniverseAsyncTask(OmniClientRequestId Id) : RequestId(Id) {}
	virtual ~IOmniverseAsyncTask() {}

	OmniClientRequestId GetId() const { return RequestId; }

	virtual void Stop() = 0;

protected:
	OmniClientRequestId RequestId;
};
typedef TSharedPtr<IOmniverseAsyncTask> TSharedOmniverseAyncTask;

DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseSendMessageCallback, OmniClientResult);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseDeleteCallback, OmniClientResult);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseListFileCallback, const FOmniverseListFileResult&);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseListFolderCallback, const FOmniverseListFolderResult&);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseSubscribeCallback, const FOmniverseSubscribeResult&);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseListCheckpointCallback, const FOmniverseListCheckpointResult&);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseReadCallback, const FOmniverseReadResult&);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseConnectionStatusCallback, OmniClientConnectionStatus);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseJoinChannelCallback, const FOmniverseJoinChannelResult&);
DECLARE_DELEGATE_RetVal_OneParam(void, FOmniverseGetServerInfoCallback, const FOmniverseGetServerInfoResult&);

class OMNIVERSERUNTIME_API FOmniverseConnectionHelper
{
public:
	static void Init();

	static void Shutdown();

	static bool IsConnected();

	static void Wait(OmniClientRequestId RequestId);

	static void LiveUpdate();

	static bool DeleteSync(const FString& Path);

	static bool CreateFolderSync(const FString& Path);

	static bool WriteFileSync(const FString& Path, const TArrayView<const uint8>& Content);
	
	static bool WriteFileSync(const FString& Path, void* Content, uint64 Size);
	
	static bool WriteFileSync(const FString& Path, const TArray64<uint8>& Content);

	static bool ListFileSync(const FString& Path, FOmniverseListFileResult& FileResult);
	
	static bool ListFolderSync(const FString& Path, TArray<FOmniverseListItem>& ListingResult);

	static bool CopySync(const FString & FromPath, const FString & ToPath);

	static bool ReadSync(const FString& Path, TSharedOmniContentPtr& ContentPtr);

	static void CreateCheckpointSync(const FString& Path);

	static FString GetFileHash(void* Content, uint64 Size);

	// Asynchronous version API
	static TSharedOmniverseAyncTask DeleteAsync(const FString& Path, const FOmniverseDeleteCallback& OnDeleteCallback);

	static TSharedOmniverseAyncTask ListFolderAsync(const FString& Path, const FOmniverseListFolderCallback& OnListCallback);
	
	static TSharedOmniverseAyncTask ListFileSubscribe(const FString& Path, const FOmniverseListFileCallback& OnListCallback,
		const FOmniverseSubscribeCallback& OnSubscribeCallback);

	static TSharedOmniverseAyncTask ListFolderSubscribe(const FString& Path, const FOmniverseListFolderCallback& OnListCallback,
		const FOmniverseSubscribeCallback& OnSubscribeCallback);

	static TSharedOmniverseAyncTask ListCheckpointsAsync(const FString& Path, const FOmniverseListCheckpointCallback& OnListCallback);

	static TSharedOmniverseAyncTask ReadAsync(const FString& Path, const FOmniverseReadCallback& OnReadCallback);
	
	static TSharedOmniverseAyncTask JoinChannel(const FString& Path, const FOmniverseJoinChannelCallback& OnJoinChannelCallback);

	static TSharedOmniverseAyncTask SendMessageToChannel(OmniClientRequestId JoinRequestId, OmniClientContent* Content, const FOmniverseSendMessageCallback& OnSendMessageCallback);

	static TSharedOmniverseAyncTask GetServerInfo(const FString& ServerUrl, const FOmniverseGetServerInfoCallback& OnGetServerInfoCallback);

	static void SetCheckpointToResolver(const FString& Message);
};