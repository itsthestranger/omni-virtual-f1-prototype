// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"
#include "OmniverseAssetImportData.h"
#include "Engine/SkeletalMesh.h"

DECLARE_LOG_CATEGORY_EXTERN(LogOmniverseAssetImport, Log, All);

class OMNIVERSERUNTIME_API FOmniverseAssetImportHelper
{
public:
	template<typename T>
	static void UpdateAssetImportData(T* Asset, const FString& SourceFile, const FString& PrimPath, const FString& SubPrimPath = FString())
	{
		// Update AssetImportData
		if (Asset->AssetImportData == nullptr || !Asset->AssetImportData->IsA<UOmniverseAssetImportData>())
		{
			auto OmniAssetImportData = NewObject<UOmniverseAssetImportData>(Asset, TEXT("OmniverseAssetImportData"));
			OmniAssetImportData->PrimPath = PrimPath;
			OmniAssetImportData->SubPrimPath = SubPrimPath;
			Asset->AssetImportData = OmniAssetImportData;
		}
			
		Asset->AssetImportData->Update(SourceFile);
		int32 SourceFileSize = Asset->AssetImportData->SourceData.SourceFiles.Num();
		for (int32 Index = 0; Index < SourceFileSize; ++Index)
		{
			Asset->AssetImportData->SourceData.SourceFiles[Index].Timestamp = FDateTime::Now();
		}
	}

	// Special for Skeletal Mesh, it has warning for using AssetImportData directly
	static void UpdateSkeletalMeshAssetImportData(USkeletalMesh* Asset, const FString& SourceFile, const FString& PrimPath, const FString& SubPrimPath)
	{
		// Update AssetImportData
		if (Asset->GetAssetImportData() == nullptr || !Asset->GetAssetImportData()->IsA<UOmniverseAssetImportData>())
		{
			auto OmniAssetImportData = NewObject<UOmniverseAssetImportData>(Asset, TEXT("OmniverseAssetImportData"));
			OmniAssetImportData->PrimPath = PrimPath;
			OmniAssetImportData->SubPrimPath = SubPrimPath;
			Asset->SetAssetImportData(OmniAssetImportData);
		}
			
		Asset->GetAssetImportData()->Update(SourceFile);
		int32 SourceFileSize = Asset->GetAssetImportData()->SourceData.SourceFiles.Num();
		for (int32 Index = 0; Index < SourceFileSize; ++Index)
		{
			Asset->GetAssetImportData()->SourceData.SourceFiles[Index].Timestamp = FDateTime::Now();
		}
	}

	static class USkeletalMesh* CreateSkeletalMeshFromImportData(class UPackage* Package, FName Name, enum EObjectFlags Flag, class FSkeletalMeshImportData& SkelMeshImportData, const FString& SkelMeshName);
	static bool LoadSkeletalMeshFromImportData(class USkeletalMesh* SkeletalMesh, class FSkeletalMeshImportData& SkelMeshImportData, const FString& SkelMeshName);
	static void InitStaticMeshRenderData(class UStaticMesh& StaticMesh);
};