// Copyright(c) 2020, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "OmniverseAsset.h"
#if WITH_EDITOR
#include "Engine/Texture.h"
#include "MDLParameter.h"
#include "MDLDependencies.h"
#endif
#include "OmniverseMDL.generated.h"

UCLASS(meta = (OmniListingNeedsLoading))
class OMNIVERSERUNTIME_API UOmniverseMDL: public UOmniverseAsset
{
	GENERATED_BODY()

public:
	UOmniverseMDL();

	UFUNCTION(BlueprintCallable, Category = MDL)
	class UMaterialInterface* FindMaterial(FName Name);

	bool ExportPreset(class UMaterialInstanceConstant* InMaterialInstance, const FString& ExportName, bool bOmniUpload, FString& OutMDL);
	bool LoadModule();
	void UnloadModule();

	bool GetUnrealDisplayName(const FString& MaterialName, const FString& ParameterName, FString& DisplayName);
	bool GetMdlParameterTypeAndName(const FString& MaterialName, const FString& DisplayName, EMdlValueType& ValueType, FString& ParameterName);
	bool IsParameterUsed(const FString& InMaterialName, const FString& InParameterName);

	static bool IsLocalBaseMDL(const FString& Path);
	static UMaterialInterface* GetLocalBaseMaterial(class UMaterialInterface* MaterialInterface);
	static UMaterialInterface* FindLocalBaseMDL(const FString& FileName, const FString& MaterialName);
	static UMaterialInterface* LoadLocalBaseMDL(const FString& FileName, const FString& MaterialName);
	static bool GetMDLModuleByMaterialName(const FString& InMaterialName, FString& ModuleName);
	static bool GetMDLModuleByMaterial(const class UMaterialInterface* MaterialInterface, FString& ModuleName);
	static bool GetDisplayNameFromLocalBaseMDL(const FString& MaterialName, const FString& ParameterName, FString& DisplayName);
	static bool GetMdlParameterTypeAndNameFromLocalBaseMDL(const FString& InMaterialName, const FString& InDisplayName, EMdlValueType& ValueType, FString& ParameterName);
	static void LoadMaterialGraphDefinitions();
	static void UnloadMaterialGraphDefinitions();
	static bool CreateMdlInstance(const FString& ModuleName, const FString& FunctionName, const FString& InstanceName);
	static bool SetCall(const FString& InstanceTarget, const FString& ParameterName, const FString& InstanceCall);
	static bool DistillMaterialInstance(class UMaterial* Material, const FString& MaterialInstanceName, bool bUseDisplayName);
	static class UMaterialInterface* ImportMDL(class UObject* InPackage, const FString& InModuleName, const FString& InMaterialName, 
		const TArray<FString>& ModulePaths, TSharedPtr<class IMDLExternalReader> ExternalReader, 
		FName Name, EObjectFlags Flags, const FString& SourceFile, TFunction<void(const uint8*, uint64, const FString&, class UTexture*&)> Callback = nullptr);
	static void ResetImportParametersSheet();
	static bool GetImportDisplayName(const FString& InMaterialName, const FString& InParameterName, FString& DisplayName);
	static void ImportMdlParameters(const FString& InModuleName, const FString& InMaterialName, const TArray<FString>& ModulePaths, 
	TSharedPtr<IMDLExternalReader> ExternalReader, const FString& InMaterialAssetName);
	static bool IsParameterUsedFromLocalBaseMDL(const FString& MaterialName, const FString& ParameterName);
	static int32 SceneDataStringToEnum(const FString& SceneData);

protected:
	virtual TArray<FString> GetFileTypes()const override;
	virtual void OnRead(const TSharedOmniContentPtr& Content)override;
	virtual void CreateUnrealAsset() override;
	virtual void PostSave() override;
	virtual bool IsAsset() const override;

#if WITH_EDITOR
	void OnMDLCreated();
	void OnTextureUpdated(TWeakObjectPtr<class UMaterial> InMaterial, class UTexture* InTexture, float Gamma, TextureCompressionSettings Compression);
#endif

	template<typename T>
	T* FindMaterial(FName Name);

	bool IsMDLLibrary(const FString& Header);

private:

#if WITH_EDITOR
	UOmniverseMDL* LoadMDLDependency(const FString& InMDLFile, bool bCreateIfNotFound = true);
	//void InitStaticParameters(class UMaterialInstanceConstant* MaterialInstance);
	//bool UpdateStaticParameters(class UMaterialInstanceConstant* MaterialInstance);
	void PrepareModuleName();
	void LoadMDL();
	void OverrideTextureSRGB(TWeakObjectPtr<class UMaterialInstanceConstant> MaterialInstancePtr, FString ParamName, bool SRGB);
	void CorrectTextureSampler(TWeakObjectPtr<class UMaterialInstanceConstant> MaterialInstancePtr, FString ParamName);
	void ReplaceNormalTextureLookup(const TConstArrayView<TObjectPtr<class UMaterialExpression>>& Expressions, class UMaterialExpression* TextureMaterialExpression);

	//TMap<FName, bool> StaticParameters;
#endif

	FString ModuleName;
	
	UPROPERTY()
	bool	bIsAsset = false;

	UPROPERTY()
	TMap<FString, struct FMDLParametersList> ParametersSheet;

	TSharedPtr<class FOmniverseMDLReader>	MDLReader;

	static TMap<FString, struct FMDLParametersList> ImportedParametersSheet;
};