// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "OmniverseLayerDataSource.generated.h"

#define INVALID_LAYER 0x7FFFFFFF

UENUM()
enum class ERootLayerType : uint8
{
	Root,
	Session,
};

UCLASS()
class OMNIVERSERUNTIME_API UOmniversePrim : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	FString Name;

	UPROPERTY()
	FString FullPath;

	UPROPERTY()
	FString LayerFullPath;

	UPROPERTY()
	FString TypeName;

	UPROPERTY()
	bool bIsReference = false;

	UPROPERTY()
	bool bIsPayload = false;

	UPROPERTY()
	bool bOver = true;

	UPROPERTY(transient)
	TMap<FString, TObjectPtr<UOmniversePrim>> Children;
};

UCLASS()
class OMNIVERSERUNTIME_API UOmniverseLayer : public UObject
{
	GENERATED_BODY()

public:
	bool IsValid() const
	{
		return !FullPath.IsEmpty();
	}

	friend bool operator==(const UOmniverseLayer& Lhs, const UOmniverseLayer& Rhs)
	{
		return Lhs.FullPath == Rhs.FullPath;
	}

	friend bool operator!=(const UOmniverseLayer& Lhs, const UOmniverseLayer& Rhs)
	{
		return Lhs.FullPath != Rhs.FullPath;
	}

	UOmniverseLayer* FindSubLayer(const FString& LayerPath)
	{
		auto FoundLayer = SubLayers.Find(LayerPath);
		if (FoundLayer)
		{
			return *FoundLayer;
		}
		else
		{
			for (auto SubLayer : SubLayers)
			{
				auto FoundSubLayer = SubLayer.Value->FindSubLayer(LayerPath);
				if (FoundSubLayer)
				{
					return FoundSubLayer;
				}
			}
		}

		return nullptr;
	}

	UPROPERTY()
	FName Name;

	UPROPERTY()
	FString FullPath;

	/* 0 root, 1 session*/
	UPROPERTY()
	ERootLayerType RootLayerType = ERootLayerType::Root;

	// Local mute
	UPROPERTY()
	bool bMuted = false;

	UPROPERTY()
	bool bGlobalMuted = false;

	UPROPERTY()
	bool bLocked = false;

	UPROPERTY()
	bool bAuthor = false;

	/* If root layer or root session layer. */
	UPROPERTY()
	bool bRootLayer = false;

	UPROPERTY()
	bool bDirty = false;
	
	UPROPERTY(transient)
	TMap<FString, TObjectPtr<UOmniversePrim>> RootPrims;

	UPROPERTY(transient)
	TMap<FString, TObjectPtr<UOmniverseLayer>> SubLayers;
	
	UPROPERTY(transient)
	TMap<FString, TObjectPtr<UOmniversePrim>> SubPrims;
};

enum class ELayersEventType : int32
{
	// Layer info change
	LayerChanged,

	// Prim info change
	PrimChanged,

	// Refresh all layers
	Reset,

	None
};

class OMNIVERSERUNTIME_API IOmniverseLayerDataSource : public TSharedFromThis<IOmniverseLayerDataSource>
{
public:
	virtual ~IOmniverseLayerDataSource() {}

	/** Broadcasts before any possible change to layers */
	DECLARE_EVENT_OneParam(IOmniverseLayerDataSource, FOnPreLayersChanged, ELayersEventType);
	FOnPreLayersChanged& OnPreLayersChanged()
	{
		return PreLayersChanged;
	};

	/** Broadcasts after any possible change to layers */
	DECLARE_EVENT_OneParam(IOmniverseLayerDataSource, FOnPostLayersChanged, ELayersEventType);
	FOnPostLayersChanged& OnPostLayersChanged()
	{
		return PostLayersChanged;
	};

	/** Broadcasts whenever one or more Layers are modified*/
	DECLARE_EVENT_ThreeParams(IOmniverseLayerDataSource, FOnLayersChanged, ELayersEventType, UOmniverseLayer*, UOmniversePrim*);
	FOnLayersChanged& OnLayersChanged()
	{
		return LayersChanged;
	};

	virtual bool SetLayerVisibility(UOmniverseLayer* OmniverseLayer, bool Visible) = 0;

	virtual bool ToggleLayerVisibility(UOmniverseLayer* OmniverseLayer) = 0;

	virtual void AddAllLayersTo(TArray<UOmniverseLayer*>& OutLayers) = 0;

	virtual UOmniverseLayer* GetAuthoringLayer() const = 0;

	virtual bool DeleteLayer(UOmniverseLayer* ParentOmniverseLayer, UOmniverseLayer* OmniverseLayer) = 0;

	virtual bool AttachLayer(UOmniverseLayer* OmniverseLayer, UOmniverseLayer* TargetLayer) = 0;

	virtual bool AuthorRootLayer() = 0;

	virtual bool ReloadLayer(UOmniverseLayer* OmniverseLayer) = 0;

	virtual bool SaveLayer(UOmniverseLayer* OmniverseLayer) = 0;

	// Select OmniverseLayer as working layer. If it's null, no layer will be selected
	virtual bool AuthorLayer(UOmniverseLayer* OmniverseLayer) = 0;

	virtual void RefreshAuthorLayer() = 0;

	virtual bool LockLayer(UOmniverseLayer* OmniverseLayer) = 0;

	virtual bool UnlockLayer(UOmniverseLayer* OmniverseLayer) = 0;

	virtual void SelectSingleActor(UOmniversePrim* Prim) = 0;

	virtual void SelectAllActors(const TArray<UOmniversePrim*>& Prims) = 0;

	virtual bool DeleteSinglePrim(UOmniversePrim* Prim) = 0;

	virtual void SwitchMutenessScope(bool bGlobal) = 0;

	virtual bool IsMutenessGlobal() const = 0;

	virtual void UpdatePrim(const FString& Layer, const FString& Prim) = 0;

	virtual void RemovePrim(const FString& Layer, const FString& Prim) = 0;

	virtual void AddSublayer(const FString& Layer, const FString& Sublayer) = 0;

	virtual void RemoveSublayer(const FString& Layer, const FString& Sublayer) = 0;

	virtual void UpdateSublayer(const FString& Layer, const FString& Sublayer) = 0;

	virtual size_t NumLayers() const = 0;

	virtual void NotifyPrimChange(const FString& Prim) = 0;

	virtual UOmniverseLayer* FindLayer(const FString& LayerPath) = 0;

	virtual int32 GetSubLayerPriority(const FString& LayerPath, const FString& SubLayerPath) const = 0;

	virtual void SetLayerDirty(const FString& LayerPath, bool bDirty) = 0;

	static void Init();

	static void Shutdown();

	static void CleanupIfEquals(const TSharedPtr<IOmniverseLayerDataSource>& DataSource);

	static void SetCurrentLayerDataSource(const TSharedPtr<IOmniverseLayerDataSource>& DataSource);

	static TSharedPtr<IOmniverseLayerDataSource> GetCurrentLayerDataSource();

	DECLARE_EVENT_OneParam(IOmniverseLayerDataSource, FOnLayerDataSourceChanged, const TSharedPtr<IOmniverseLayerDataSource>&);
	static FOnLayerDataSourceChanged& OnLayerDataSourceChanged();

#if WITH_EDITOR
protected:
	static TMap<FString, FString> ActorNameLabelMap;
#endif

private:
	FOnLayersChanged LayersChanged;

	FOnPreLayersChanged PreLayersChanged;

	FOnPostLayersChanged PostLayersChanged;
};
