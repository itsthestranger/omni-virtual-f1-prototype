// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "Templates/SharedPointer.h"
#include "GenericPlatform/GenericPlatformFile.h"

class OMNIVERSERUNTIME_API FOmniverseFileHandle : public IFileHandle
{
public:
	FOmniverseFileHandle(TSharedPtr<struct FOmniverseContent> InContent);
	~FOmniverseFileHandle();

	virtual int64		Tell();

	virtual bool		Seek(int64 NewPosition);

	virtual bool		SeekFromEnd(int64 NewPositionRelativeToEnd = 0);

	virtual bool		Read(uint8* Destination, int64 BytesToRead);

	virtual bool		Write(const uint8* Source, int64 BytesToWrite);

	virtual bool		Flush(const bool bFullFlush = false);

	virtual bool		Truncate(int64 NewSize);

	virtual int64		Size();

private:
	TSharedPtr<struct FOmniverseContent> Content;
	int64 CurrentPosition;
};

