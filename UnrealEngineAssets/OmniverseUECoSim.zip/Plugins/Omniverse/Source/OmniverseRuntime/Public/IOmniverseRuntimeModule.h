// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"
#include "Stats/Stats.h"
#include "Containers/UnrealString.h"

DECLARE_DELEGATE(FOnOmniverseConnected);

// Server connection status
enum class EOmniverseServerConnectionChange
{
	Connecting,
	Connected,
	Disconnected,
	ConnectionError
};

struct FOmniverseServer
{
	FString Address; // Server name
	EOmniverseServerConnectionChange Status;
	FString UserName; // Logged user name.
};

/**
 * The public interface to this module.  In most cases, this interface is only public to sibling modules 
 * within this plugin.
 */
class OMNIVERSERUNTIME_API IOmniverseRuntimeModule : public IModuleInterface
{
public:
	/**
	 * Singleton-like access to this module's interface.  This is just for convenience!
	 * Beware of calling this during the shutdown phase, though.  Your module might have been unloaded already.
	 *
	 * @return Returns singleton instance.
	 */
	static inline IOmniverseRuntimeModule& Get()
	{
		return FModuleManager::GetModuleChecked< IOmniverseRuntimeModule >("OmniverseRuntime");
	}

	/**
	 * Checks to see if this module is loaded and ready.  It is only valid to call Get() if IsAvailable() returns true.
	 *
	 * @return True if the module is loaded and ready to use
	 */
	static inline bool IsAvailable()
	{
		return FModuleManager::Get().IsModuleLoaded("OmniverseRuntime");
	}

	// Add server into watch list for listing
	// Return false if it's not watched before.
	virtual bool WatchServer(const FString& Server) = 0;

	// Return false if all servers have been watched already.
	virtual bool WatchServers(const TArray<FString>& Servers, bool bResetList = false) = 0;

	virtual void RemoveServer(const FString& Server) = 0;

	virtual const TArray<FOmniverseServer>& GetWatchList() const = 0;

	virtual void PingAndWait() = 0;

	virtual bool IsUpdatingUSD() = 0;

	virtual void EnableDeveloperLog(bool bEnable) = 0;

	virtual void EnableLiveUpdate(bool bEnabled) = 0;

	virtual bool IsLiveUpdateEnabled() const = 0;

	virtual FString GetOmniClientVersion() const = 0;

	virtual FString GetOmniResolverVersion() const = 0;

	virtual FString GetUsdVersion() const = 0;

	virtual FString GetCheckpointComment() const = 0;

	virtual void SetCheckpointComment(const FString& Comment) = 0;

	// Connection change status event
	// This event is sent when server connection is changed. 
	// For omni client, the server connection status is managed
	// inside the internal implementation.
	DECLARE_MULTICAST_DELEGATE_TwoParams(FOnServerConnectionChanged, const FString&, EOmniverseServerConnectionChange);
	FOnServerConnectionChanged OnServerConnectionChanged;

	// The event will be event if user calls WatchServer or WatchServers
	// to add servers that's not watched before.
	DECLARE_MULTICAST_DELEGATE(FOnServerWatchListChanged);
	FOnServerWatchListChanged OnServerWatchListChanged;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnAssetDeleted, const TArray<FString>&);
	FOnAssetDeleted OnAssetDeleted;

	DECLARE_MULTICAST_DELEGATE_TwoParams(FOnAssetDownload, const FString &, bool);
	FOnAssetDownload OnAssetDownload;
};

DECLARE_STATS_GROUP(TEXT("Omniverse"), STATGROUP_Omniverse, STATCAT_Advanced);
