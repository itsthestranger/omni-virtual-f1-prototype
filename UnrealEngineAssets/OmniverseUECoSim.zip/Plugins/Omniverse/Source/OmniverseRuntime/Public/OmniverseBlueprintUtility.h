// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "OmniverseBlueprintUtility.generated.h"

/**
 * Blueprint utility functions for Omniverse
 */
UCLASS()
class OMNIVERSERUNTIME_API UOmniverseBlueprintUtility : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * Return the list of all the assets found in the DirectoryPath.
	 * @param	FolderURL		URL folder to list contents.  Format: omniverse://server/folder
	 * @return	The list of files and folders found.
	 */
	UFUNCTION(BlueprintCallable, Category = "Omniverse", meta = (DisplayName = "List Omniverse Files"))
	static TArray<FString> ListOmniverseFiles(const FString& FolderURL);
};
