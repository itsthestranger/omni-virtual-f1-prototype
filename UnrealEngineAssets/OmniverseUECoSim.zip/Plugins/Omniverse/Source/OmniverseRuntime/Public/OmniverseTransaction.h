// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "UObject/Object.h"
#include "Misc/ITransaction.h"
#include "OmniverseTransaction.generated.h"

UCLASS()
class OMNIVERSERUNTIME_API UOmniverseTransaction: public UObject
{
	GENERATED_BODY()

public:
	enum class EUndoType
	{
		Undo,
		Redo,
	};

	enum class ETransactionChange
	{
		Beginned,
		Ending,
	};

	DECLARE_DELEGATE_OneParam(FUndoDelegate, EUndoType)

	UOmniverseTransaction();

	bool AddTransaction(const FUndoDelegate& UndoDelegate);

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnTransactionChanged, ETransactionChange)
	FOnTransactionChanged OnTransactionChanged;

	UPROPERTY()
	int32 ChangedTransaction = 0;

protected:
	void OnUndo(const FTransactionContext& TransactionContext, bool Succeeded);
	void OnRedo(const FTransactionContext& TransactionContext, bool Succeeded);
	void OnTransactionStateChanged(const FTransactionContext& TransactionContext, ETransactionStateEventType TransactionState);

	TArray<TArray<FUndoDelegate>> UndoBuffer;
	TArray<TArray<FUndoDelegate>> RedoBuffer;
};