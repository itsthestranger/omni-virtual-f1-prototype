// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.


#pragma once

#include "CoreMinimal.h"

#include "EditorFramework/AssetImportData.h"
#include "OmniverseAssetImportData.generated.h"

/**
* Base class for import asset and options used when importing any asset from Omniverse
*/
UCLASS()
class OMNIVERSERUNTIME_API UOmniverseAssetImportData : public UAssetImportData
{
	GENERATED_BODY()
public:
	UPROPERTY()
	FString PrimPath;

	UPROPERTY()
	FString SubPrimPath;

};
