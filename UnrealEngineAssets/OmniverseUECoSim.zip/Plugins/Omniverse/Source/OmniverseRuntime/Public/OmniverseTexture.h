// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "OmniverseAsset.h"
#include "Engine/Texture.h"
#include "OmniverseTexture.generated.h"

UCLASS()
class OMNIVERSERUNTIME_API UOmniverseTexture: public UOmniverseAsset
{
	GENERATED_BODY()

public:
	DECLARE_MULTICAST_DELEGATE(FOnImageUpdated);
	FOnImageUpdated OnImageUpdated;

	virtual void SaveToDisk() const override;

	static class UTexture* CreateTextureFromBuffer(const uint8* Buffer, uint64 Size, UObject* Parent, FName Name, EObjectFlags Flags, const FString& SourceFile = TEXT(""));
	static class UTexture* CreateTextureFromFile(const FString& File, UObject* Parent, FName Name, EObjectFlags Flags);
	//static void OnReadCallback(const FOmniverseReadResult & ReadResult);

protected:
	virtual TArray<FString> GetFileTypes()const override;
	virtual void OnRead(const TSharedOmniContentPtr& content)override;
	virtual void CreateUnrealAsset() override;
	virtual bool AllowAutoSavingEtag() override { return false; }
	void ImportOtherTypeTexture(const TSharedOmniContentPtr& Content);
	bool IsLightProfile(const FString& FileExtension);

	static void UpdatePixels(UTexture& Texture, int32 SizeX, int32 SizeY, int32 BitDepth, const TArray<uint8>& Pixles, bool bCallPostEditChange = true);
};
