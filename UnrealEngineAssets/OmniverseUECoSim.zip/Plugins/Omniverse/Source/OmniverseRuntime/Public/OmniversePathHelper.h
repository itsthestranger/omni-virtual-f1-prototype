// Copyright(c) 2020, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"

static const FString OMNIVERSE_FOLDER("/Game/Omniverse");
static const FString OMNIVERSE_BRANCH("_Branch_");
static const FString OMNIVERSE_CHECKPOINT("_Checkpoint_");

class OMNIVERSERUNTIME_API FOmniversePathHelper
{
public:
	// Splits path in format domain://username@server/asset_path
	//filename.png
	//filename.png?&42
	//filename.png?branch&42
	//filename.png?checkpoint=42
	//filename.png?branch=default
	//filename.png?branch=default&checkpoint=42
	static void SplitUrlPath(const FString& Url, FString& UserName, FString& Server, FString& AssetPath, FString& Branch, FString& CheckPoint);

	// Is old omni path in format omni:/other_parts.
	static bool IsOldOmniPath(const FString& Path);

	// Is new omni url path in format: omniverse://other_parts or omni://other_parts
	static bool IsNewOmniPath(const FString& Path);

	// Checks if path is prefixed with "omni:" or "omniverse:".
	static bool IsOmniPath(const FString& Path);

	// Is absolute path or omniverse path
	static bool IsValidAbsolutePath(const FString& Path);

	// Convert omni path into separate parts.
	static void ConvertOmniPath(const FString& OmniPath, FString& PackagePath, FString& AssetName, FString& Extension,
		bool IncludeExtensionInPackagePath = true);

	// Get the URL part only for full omniverse path.
	// For omniverse://server_address/part1/part2, it will return /part1/part2.
	// For omniverse:/part1/part2, it will return 
	static FString GetAssetPathOnServer(const FString& OmniPath);

	// Computes absolute path of OtherPath based on BasePath.
	// NOTE: This function fails when BasePath is an omni URL and OtherPath is an absolute file path (S:\a b\c\d) with spaces.
	//       It will encode the space as %20, which is a valid string file path, changing it...
	static FString ComputeAbsolutePath(const FString& BasePath, const FString& OtherPath);
	
	// Compute relative path of target path relative to SourcePath.
	// So ComputeRelativePath(omniverse:/a/b/c, omniverse:/a/c/d) will return ../b/c
	// while ComputeRelativePath(omniverse:/a/b/c, omniverse:/a/c/d/) will return ../../b/c
	// If source path and target path are not in the same domain or server, it will
	// return target path directly.
	static FString ComputeRelativePath(const FString& TargetPath, const FString& SourcePath, bool TargetIsDirectory = false, bool SourceIsDirectory = false);

	// Get the folder URL for root live path: .live
	static FString GetLiveRootPath(const FString& OmniPath);

	// Get the folder URL for holding live syncing files
	static FString GetLiveFolderPath(const FString& OmniPath);
	
	// Get live folder path by the live session name
	static FString GetLiveSessionPath(const FString& OmniPath, const FString& SessionName);

	// Get live file path by the live session name
	static FString GetLiveSessionLayerPath(const FString& OmniPath, const FString& SessionName);

	// Get channel file path by the live session name
	static FString GetLiveSessionChannelPath(const FString& OmniPath, const FString& SessionName);

	// Get toml file path by the live session name
	static FString GetLiveSessionConfigPath(const FString& OmniPath, const FString& SessionName);

	static FString UniformOmniPath(const FString& OmniPath);

	// Remove query from URL, such as the branch and checkpoint
	static FString RemoveQuery(const FString& InOmniPath);

	static void ManglePath(const FString& OmniPath, FString& OutUE4Path, bool bStartWithSlash = true); // only used for mangling folder path
	
	static void UnmanglePath(const FString& UE4Path, FString& OutOmniPath, bool bStartWithSlash = true);

	static FString PrimPathToKey(const FString& PrimPath);

	static FString KeyToPrimPath(const FString& Key);

	static FString NormalizeUrl(const FString& Url);

	static void FixAssetName(FString& AssetName);

	// usdz package path
	static bool IsPackagePath(const FString& Path);
	static FString GetPackageRoot(const FString& Path);
	static FString GetPackagedSubPath(const FString& Path);

	// Parse string version to integer
	static bool ParseVersion(const FString& Version, int32& MajorVersion, int32& MinorVersion);
};