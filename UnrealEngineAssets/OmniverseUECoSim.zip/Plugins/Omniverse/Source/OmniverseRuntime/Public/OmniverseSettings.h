// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "OmniverseSettings.generated.h"

UENUM()
enum class ERenderContext : uint8
{
	ERC_DEFAULT UMETA(DisplayName="Default"),
	ERC_MDL		UMETA(DisplayName="MDL"),
};

UCLASS(Config=Engine, DefaultConfig)
class OMNIVERSERUNTIME_API UOmniverseSettings:public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(Config, EditAnywhere, Category = Settings, meta = (DisplayName = "Server List"))
	TArray<FString> WatchServers;

	UPROPERTY(Config)
	bool bUserWantsToConnect = false;

	// Material Import/Render Setting: Default - USD Preview surface, MDL - MDL materials
	UPROPERTY(Config, EditAnywhere, Category=Settings)
	ERenderContext RenderContext = ERenderContext::ERC_MDL;

	UPROPERTY(Config, EditAnywhere, Category = Settings)
	bool bDisableMaterialLoading = false;

	// Show developer log messages in the editor log
	UPROPERTY(Config, EditAnywhere, Category = Settings)
	bool bOpenDeveloperLog = false;

	// Effectively remove this capability.  
	// Not sure it's supported any longer and it caused problems with DX12 in the past
	//UPROPERTY(Config, EditAnywhere, Category = Settings)
	bool bShowDownloadNotifications = false;

	// If enabled, meshes will have query collision enabled on import
	UPROPERTY(Config, EditAnywhere, Category = Settings)
	bool bEnableQueryCollision = false;

	// If enabled, changes to a stage made to an open USD stage while in Play-In-Editor mode will persist and broadcast over a live connection
	UPROPERTY(Config, EditAnywhere, Category = Settings, meta = (DisplayName="Keep Changes During Play in Editor Sessions"))
	bool bEnablePlayInEditorChanges = false;

	// When enabled, if both old and new UsdLuxLight schema attributes are authored on a light prim, read the new schema attributes
	UPROPERTY(Config, EditAnywhere, Category = Settings, meta = (DisplayName="Prefer New USD LuxLight Schema on Import"))
	bool bPreferNewUsdLuxLightSchemaOnImport = true;

	UOmniverseSettings();

#if WITH_EDITOR
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
};
