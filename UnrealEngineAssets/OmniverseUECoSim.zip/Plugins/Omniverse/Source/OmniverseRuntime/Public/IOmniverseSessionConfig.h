// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"

class OMNIVERSERUNTIME_API IOmniverseSessionConfig
{
public:
    enum class Key
    {
        Version,
        UserName,
        StageUrl,
        Description,
        Mode,
        Name,
        INVALID,
    };

	static TSharedRef<IOmniverseSessionConfig> Get();

	virtual ~IOmniverseSessionConfig() {}

	virtual bool CreateSessionConfig(const FString& SessionConfigPath, const TMap<IOmniverseSessionConfig::Key, FString>& ConfigMap) = 0;
	virtual bool LoadSessionConfig(const FString& SessionConfigPath, TMap<IOmniverseSessionConfig::Key, FString>& ConfigMap) = 0;
	virtual bool IsCompatible(const int32 MajorVersion, const int32 MinorVersion) = 0;
};