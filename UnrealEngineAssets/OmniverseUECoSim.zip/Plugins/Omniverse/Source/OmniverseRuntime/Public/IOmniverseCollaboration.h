// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"
#include "IOmniverseCollaboration.generated.h"

UENUM()
enum class EOmniverseMessageType
{
	UserJoin UMETA(DisplayName = "JOIN"),
	UserHello UMETA(DisplayName = "HELLO"),
	UserGetUsers UMETA(DisplayName = "GET_USERS"),
	UserLeft UMETA(DisplayName = "LEFT"),
	MergeStarted UMETA(DisplayName = "MERGE_STARTED"),
	MergeFinished UMETA(DisplayName = "MERGE_FINISHED"),
	UserMessage UMETA(DisplayName = "MESSAGE"),
	Unknown UMETA(DisplayName = "Unknown")
};

USTRUCT()
struct FOmniverseContentMessage
{
	GENERATED_BODY()

	UPROPERTY()
	FString version;

	UPROPERTY()
	FString message;
};

USTRUCT()
struct FOmniverseMessage
{
	GENERATED_BODY()

	UPROPERTY()
	FString version;

	UPROPERTY()
	FString from_user_name;

	UPROPERTY()
	FString app;

	UPROPERTY()
	TMap<FString, FOmniverseContentMessage> content;

	UPROPERTY()
	FString message_type;
};

DECLARE_MULTICAST_DELEGATE_TwoParams(FOnOmniverseMessageReceived, const FString&, const FOmniverseMessage&);

class OMNIVERSERUNTIME_API IOmniverseCollaboration
{
public:
	static TSharedRef<IOmniverseCollaboration> Get();

	virtual ~IOmniverseCollaboration() {}

	virtual void Subscribe(const FString& Channel) = 0;

	virtual void Unsubscribe() = 0;

	virtual void SendMessage(const FOmniverseMessage& Message) = 0;

	virtual void SendMessage(EOmniverseMessageType MessageType) = 0;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnUserJoined, const FOmniverseMessage&);
	FOnUserJoined OnUserJoined;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnUserHelloed, const FOmniverseMessage&);
	FOnUserHelloed OnUserHelloed;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnGetUsers, const FOmniverseMessage&);
	FOnGetUsers OnGetUsers;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnUserLeft, const FOmniverseMessage&);
	FOnUserLeft OnUserLeft;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnMergeStarted, const FOmniverseMessage&);
	FOnMergeStarted OnMergeStarted;

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnMergeFinished, const FOmniverseMessage&);
	FOnMergeFinished OnMergeFinished;

	DECLARE_MULTICAST_DELEGATE(FOnSubscribed);
	FOnSubscribed OnSubscribed;

	DECLARE_MULTICAST_DELEGATE(FOnUnsubscribed);
	FOnUnsubscribed OnUnsubscribed;
};