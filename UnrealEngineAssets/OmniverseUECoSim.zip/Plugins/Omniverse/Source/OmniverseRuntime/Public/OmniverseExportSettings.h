// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once
#include "CoreMinimal.h"

struct OMNIVERSERUNTIME_API FOmniverseExportTextureSettings
{
	bool bTextureSource;
	bool bDDSExport;

	FOmniverseExportTextureSettings();
};

struct OMNIVERSERUNTIME_API FOmniverseExportMaterialSettings
{
	bool bCopyTemplate;
	bool bRayTracingTranslucency;
	bool bRayTracingRefraction;
	FString DestTemplatePath; // NOTE: always folder path, not file path
	bool bExportTwoSidedSign;

	FOmniverseExportTextureSettings TextureSettings;

	FOmniverseExportMaterialSettings();
};

struct OMNIVERSERUNTIME_API FOmniverseExportCommandletSettings
{
	FString CommandletExportPath;

	FOmniverseExportCommandletSettings();
};

struct OMNIVERSERUNTIME_API FOmniverseExportSettings
{
	bool bModular;
	bool bAsciiFormat;
	bool bAddExtraExtension;
	bool bMDL;
	bool bPreviewSurface;
	bool bExportAssetToSeperateUSD;
	bool bExportPhysics;
	bool bMeshInstanced;
	bool bCustomLayer;
	bool bExportInvisible;
	bool bPayloads;
	bool bExportSublayers;
	bool bUpYAxis;
	bool bExportDecalActors;
	bool bMaterialOverSublayer;
	bool bExportPreviewMesh;
	bool bForceShared;
	bool bExportLandscapeGrass;
	bool bNanite;
	bool bRootIdentity;

	FOmniverseExportMaterialSettings MaterialSettings;

	FOmniverseExportCommandletSettings CommandletSettings;

	FOmniverseExportSettings();
};