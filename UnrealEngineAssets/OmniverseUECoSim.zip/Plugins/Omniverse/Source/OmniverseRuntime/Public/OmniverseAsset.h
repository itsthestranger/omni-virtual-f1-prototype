// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "UObject/Object.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "OmniverseConnectionHelper.h"
#include "UObject/UObjectHash.h"
#include "OmniverseAsset.generated.h"

UCLASS(Abstract, BlueprintType)
class OMNIVERSERUNTIME_API UOmniverseAsset: public UObject
{
	GENERATED_BODY()

protected:
	// Full Omniverse path, with domain and server info, like omniverse://ov-content/Users/xxx.usd
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Omniverse)
	FString OmniPath;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Omniverse)
	FString OmniVersion;

	FString OmniReceivedLatestVersion;

private:
	// Package path locally with prefix /Game/Omniverse
	mutable FString PackagePath;

	mutable FString AssetName;

	mutable FString Extension;

	// Asset path without server or domain info, like /Users/xxx/xxx.usd
	mutable FString AssetPathOnServer;

	// Server this asset locates at, like ov-content.
	mutable FString OmniServer;

	mutable FString Branch;

	mutable FString Checkpoint;

	DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnUpdatedScript);

	UPROPERTY(BlueprintAssignable, Category = "Omniverse")
	FOnUpdatedScript AssetUpdated;

	UFUNCTION(BlueprintCallable, Category = "Omniverse", meta = (DisplayName = "Get Omni Asset"))
	static UOmniverseAsset* GetOmniverseAssetScript(UObject* Object);

	UFUNCTION(BlueprintCallable, Category = "Omniverse", meta = (DisplayName = "Load Asset"))
	static void LoadAssetScript(UPARAM(DisplayName = "Omni Path") FString InOmniPath, UOmniverseAsset*& OmniAsset, UPARAM(DisplayName = "UE4 Asset") UObject*& UE4Asset);

	FString GenerateContentHash(const TSharedOmniContentPtr& Content);

public:
	DECLARE_MULTICAST_DELEGATE(FOnUpdated);
	FOnUpdated OnUpdated;
	
	UPROPERTY()
	bool bValidAsset = false;	// Asset finished loading from Omniverse, it's a valid asset.

	UPROPERTY()
	bool bIsMount = false;

	UPROPERTY()
	bool bIsWritable = false;

	UOmniverseAsset();
	~UOmniverseAsset();

	// Returns full omniverse path, like "omniverse://ov-content/Users/xxxx.usd".
	const FString& GetOmniPath()const { return OmniPath; }

	const FString& GetPackagePath() const;

	const FString& GetAssetServer() const;

	const FString& GetAssetName() const;

	const FString& GetAssetExtension() const;

	bool IsCheckpoint() const;

	static void RegisterConnectionListener();

	static UOmniverseAsset* LoadAsset(FString InOmniPath, bool CreateIfNotFound = true);
	template<typename T>
	static T* LoadAsset(FString InOmniPath, bool CreateIfNotFound = true);

	static UOmniverseAsset* GetOmniverseAsset(UObject& Object);
	template<typename T>
	static T* GetOmniverseAsset(UObject& Object) { return Cast<T>(GetOmniverseAsset(Object)); }

	static void ShowMaxPathNotification(const FString& InText);
	static void HandleMaxPathHyperlinkNavigate();

	virtual bool IsAsset() const override;
	virtual void PostLoad() override;
	virtual void PostSave();
	virtual void SaveToOmniverse() {}
	virtual void SaveToDisk() const;
	virtual void Load();

	virtual void OmniReadCallback(const FOmniverseReadResult& ReadResult);
	virtual void OmniListCallback(const FOmniverseListFileResult& ListResult);
	virtual void OmniSubscribeCallback(const FOmniverseSubscribeResult& SubscribeResult);
	virtual void OmniListCheckpointCallback(const FOmniverseListCheckpointResult& ListCheckpointResult);

#if WITH_EDITORONLY_DATA
	virtual void GetAssetRegistryTags(TArray<FAssetRegistryTag>& OutTags) const override;
#endif

	static bool bSavingCache;	// Indicates whether it's a user saving or a Omniverse saving.


protected:
	void HandleError(OmniClientResult Status);

	virtual TArray<FString> GetFileTypes()const { return {}; }
	virtual void OnRead(const TSharedOmniContentPtr& content) {}
	virtual void CreateUnrealAsset() PURE_VIRTUAL(UOmniverseAsset::CreateUnrealAsset,);
	virtual bool AllowAutoSavingEtag() { return true; }
	template<typename T>
	T* NewUnrealAsset(FName Name = NAME_None);
	void CreateAssetUserData(UObject* Owner);
	void ReadVersion(const FString& NewVersion);

	void StartSubscribe();
	void StopSubscribe();

	const FString& GetAssetPathOnServer() const;
	//UPROPERTY()
	//FString OmniETag;
	
	FOmniverseReadCallback OmniReadDelegate;
	FOmniverseListFileCallback OmniListDelegate;
	FOmniverseSubscribeCallback OmniSubscribeDelegate;
	FOmniverseListCheckpointCallback OmniListCheckpointDelegate;
	TSharedOmniverseAyncTask ListSubscribeTask;
	bool bSubscribeStopped = true;

	bool bDelayedTrigger = false;
};

OMNIVERSERUNTIME_API extern const FString OmniverseContentFolder;

template<typename T>
T* UOmniverseAsset::LoadAsset(FString InOmniPath, bool CreateIfNotFound)
{
	auto OmniAsset = LoadAsset(InOmniPath, CreateIfNotFound);
	if(!OmniAsset)
	{
		return nullptr;
	}

	TArray<UObject*> Objects;
	GetObjectsWithOuter(OmniAsset->GetOuter(), Objects, false);

	for(UObject* Object : Objects)
	{
		if(Object->IsA<T>())
		{
			return StaticCast<T*>(Object);
		}
	}

	return nullptr;
}

template<typename T>
T * UOmniverseAsset::NewUnrealAsset(FName Name)
{
	if(Name == NAME_None)
	{
		Name = *GetAssetName();
	}

	if(GetFName() == Name)
	{
		auto NewName = MakeUniqueObjectName(GetOuter(), GetClass(), Name);
		Rename(*NewName.ToString(), nullptr, REN_DontCreateRedirectors | REN_NonTransactional);
	}

	auto NewAsset = NewObject<T>(GetOuter(), Name, GetFlags() | EObjectFlags::RF_Standalone | EObjectFlags::RF_Public | EObjectFlags::RF_Transactional);

	CreateAssetUserData(NewAsset);

	FAssetRegistryModule::AssetCreated(NewAsset);

	return NewAsset;
}
