// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"

class OMNIVERSERUNTIME_API FOmniverseNotificationHelper
{
public:
	static TSharedPtr<class SNotificationItem> ShowInstantNotification(const FString& Text, SNotificationItem::ECompletionState CompletionState = SNotificationItem::CS_Fail,
		float ExpireDuration = 2.f, float FadeOutDuration = 2.f, bool bDismissButton = false, FSimpleDelegate OnDismiss = nullptr);

	static void NotifyError(const FString& Error);

	static TWeakPtr<class SNotificationItem> NotifySelection(const FString& Message, const FString& OKMessage, const FString& OKTip, FSimpleDelegate OKDelegate, const FString& CancelMessage, const FString& CancelTip, FSimpleDelegate CancelDelegate);

};