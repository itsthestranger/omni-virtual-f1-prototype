// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

using System.IO;

namespace UnrealBuildTool.Rules
{
	public class OmniverseRuntime : ModuleRules
	{
		public OmniverseRuntime(ReadOnlyTargetRules Target) : base(Target)
		{
			bUseRTTI = true;    // For boost
			PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;    // For game module
			bEnableExceptions = true;   // For game build
			AddEngineThirdPartyPrivateStaticDependencies(Target, "OpenSSL");
			PrivateDependencyModuleNames.AddRange(new string[]
			{
				"Core",
				"CoreUObject",
				"Engine",
				"RHI",
                "RenderCore",
                "ImageCore",
				"ImageWrapper",
				"TextureCompressor",
				"Projects",
				"OmniverseAddDLLDirectory",
				"HTTP",
			});

			PublicDependencyModuleNames.AddRange(new string[]
			{
				"Engine",
				"UnrealUSDWrapper",
			});

			if (Target.Type == TargetType.Editor)
			{
				PublicDependencyModuleNames.AddRange(new string[]
				{
					"EditorStyle",
					"MaterialEditor",
					"MDL",
					"UnrealEd",
					"SlateCore",
					"Slate",
					"Json",
					"JsonUtilities",
					"MessageLog",
                });
			}

			// ModuleDirectory is where this file (the Build.cs file) is located
			// Going up two folders gets to the root of the plugin (We are in Source/OmniverseEditor)
			string ThirdPartyPath = Path.Combine(ModuleDirectory, "..", "..", "ThirdParty");

			string OmniverseConfig = Target.Platform.ToString() + (Target.Configuration == UnrealTargetConfiguration.Debug && Target.bDebugBuildsActuallyUseDebugCRT ? "_debug" : "_release");

			string BoostVersion = "1_70";

			PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "omni_client_library", OmniverseConfig, "include"));
			PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "omni_usd_resolver", OmniverseConfig, "include"));
			PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "nvtt", OmniverseConfig, "include"));
			PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "tinytoml", "include"));

			string OmniverseClientLibPath = Path.Combine(ThirdPartyPath, "omni_client_library", OmniverseConfig, "release");
            foreach (string FileName in Directory.EnumerateFiles(OmniverseClientLibPath, "*.dll", SearchOption.AllDirectories))
            {
                RuntimeDependencies.Add(Path.Combine(OmniverseClientLibPath, FileName));
            }

			string OmniverseResolverLibPath = Path.Combine(ThirdPartyPath, "omni_usd_resolver", OmniverseConfig, "release");
			foreach (string FileName in Directory.EnumerateFiles(OmniverseResolverLibPath, "*.dll", SearchOption.AllDirectories))
			{
				RuntimeDependencies.Add(Path.Combine(OmniverseResolverLibPath, FileName));
			}

			string NvttLibPath = Path.Combine(ThirdPartyPath, "nvtt", OmniverseConfig, "lib/x64-v142");
			PublicAdditionalLibraries.Add(Path.Combine(NvttLibPath, "nvtt30106.lib"));
			PublicDelayLoadDLLs.Add("cudart64_110.dll");
			PublicDelayLoadDLLs.Add("nvtt30106.dll");
			string NvttDllPath = Path.Combine(ThirdPartyPath, "nvtt", OmniverseConfig);
			RuntimeDependencies.Add(Path.Combine(NvttDllPath, "cudart64_110.dll"));
			RuntimeDependencies.Add(Path.Combine(NvttDllPath, "nvtt30106.dll"));

			PublicAdditionalLibraries.Add(Path.Combine(OmniverseClientLibPath, "omniclient.lib"));
			PublicAdditionalLibraries.Add(Path.Combine(OmniverseResolverLibPath, "omni_usd_resolver.lib"));

			// We're copying boost from the USD dep to the resolver folder
			string BoostLib = Path.Combine(OmniverseResolverLibPath, "boost_python39-vc141-mt-x64-" + BoostVersion + ".lib");
			PublicAdditionalLibraries.Add(BoostLib);

			var EngineDir = Path.GetFullPath(Target.RelativeEnginePath);

			// The following copied from Engine\Plugins\Importers\USDImporter\Source\UnrealUSDWrapper\UnrealUSDWrapper.Build.cs

			// Python 3
			var PythonSourceTPSDir = Path.Combine(EngineDir, "Source", "ThirdParty", "Python3", Target.Platform.ToString());
			var PythonBinaryTPSDir = Path.Combine(EngineDir, "Binaries", "ThirdParty", "Python3", Target.Platform.ToString());
			PublicIncludePaths.Add(Path.Combine(PythonSourceTPSDir, "include"));
			PublicSystemLibraryPaths.Add(Path.Combine(PythonSourceTPSDir, "libs"));
			RuntimeDependencies.Add(Path.Combine("$(TargetOutputDir)", "python39.dll"), Path.Combine(PythonBinaryTPSDir, "python39.dll"));

			// USD
			// Engine\Plugins\Importers\USDImporter\Source\ThirdParty\USD
			var UnrealUSDWrapperModuleDirectory = Path.Combine(EngineDir, "Plugins", "Importers", "USDImporter");
			string USDLibsDir = Path.Combine(UnrealUSDWrapperModuleDirectory, "Source", "ThirdParty", "USD", "lib");
			PublicIncludePaths.Add(Path.Combine(UnrealUSDWrapperModuleDirectory, "Source", "ThirdParty", "USD", "include"));
			PublicSystemLibraryPaths.Add(USDLibsDir);
			foreach (string UsdLib in Directory.EnumerateFiles(USDLibsDir, "*.lib", SearchOption.AllDirectories))
			{
				PublicAdditionalLibraries.Add(UsdLib);
			}
			var USDBinDir = Path.Combine(UnrealUSDWrapperModuleDirectory, "Source", "ThirdParty", "USD", "bin");
			foreach (string UsdDll in Directory.EnumerateFiles(USDBinDir, "*.dll", SearchOption.AllDirectories))
			{
				// We can't delay-load the USD dlls as they contain data and vtables: They need to be next to the executable and implicitly linked
				RuntimeDependencies.Add(Path.Combine("$(TargetOutputDir)", Path.GetFileName(UsdDll)), UsdDll);
			}

			if (Target.Platform.IsInGroup(UnrealPlatformGroup.Windows))
			{
				PublicDefinitions.Add("BOOST_LIB_TOOLSET=\"vc142\"");

				// Intel TBB
				string IntelTBBPath = Path.Combine(Target.UEThirdPartySourceDirectory, "Intel", "TBB", "IntelTBB-2019u8");
				string IntelTBBIncludePath = Path.Combine(IntelTBBPath, "include");
				string IntelTBBLibPath = Path.Combine(IntelTBBPath, "lib");

				PublicSystemIncludePaths.Add(IntelTBBIncludePath);

				string PlatformSubPath = "Win64";
				string IntelTBBBinaries = Path.Combine(Target.UEThirdPartyBinariesDirectory, "Intel", "TBB", "Win64");

				string LibDirTBB = Path.Combine(IntelTBBLibPath, PlatformSubPath, "vc14");
				string LibDirTBBMalloc = LibDirTBB;

				if (Target.WindowsPlatform.Architecture == WindowsArchitecture.ARM64)
				{
					LibDirTBBMalloc = Path.Combine(LibDirTBBMalloc, Target.WindowsPlatform.GetArchitectureSubpath());
				}

				PublicSystemLibraryPaths.Add(LibDirTBB);
				PublicSystemLibraryPaths.Add(LibDirTBBMalloc);

				// Disable the #pragma comment(lib, ...) used by default in TBB & MallocTBB...
				// We want to explicitly include the libraries.
				PublicDefinitions.Add("__TBBMALLOC_NO_IMPLICIT_LINKAGE=1");
				PublicDefinitions.Add("__TBB_NO_IMPLICIT_LINKAGE=1");

				if (Target.Configuration == UnrealTargetConfiguration.Debug && Target.bDebugBuildsActuallyUseDebugCRT)
				{
					PublicDefinitions.Add("TBB_USE_DEBUG=1");
					PublicAdditionalLibraries.Add(Path.Combine(LibDirTBB, "tbb_debug.lib"));
					PublicAdditionalLibraries.Add(Path.Combine(LibDirTBBMalloc, "tbbmalloc_debug.lib"));
					if (Target.Platform != UnrealTargetPlatform.HoloLens)
					{
						RuntimeDependencies.Add(Path.Combine("$(TargetOutputDir)", "tbb_debug.dll"), Path.Combine(LibDirTBB, "tbb_debug.dll"));
					}
				}
				else
				{
					PublicAdditionalLibraries.Add(Path.Combine(LibDirTBB, "tbb.lib"));
					PublicAdditionalLibraries.Add(Path.Combine(LibDirTBBMalloc, "tbbmalloc.lib"));
					if (Target.Platform != UnrealTargetPlatform.HoloLens)
					{
						RuntimeDependencies.Add(Path.Combine("$(TargetOutputDir)", "tbb.dll"), Path.Combine(IntelTBBBinaries, "tbb.dll"));
					}
				}
			}
		}
	}
}