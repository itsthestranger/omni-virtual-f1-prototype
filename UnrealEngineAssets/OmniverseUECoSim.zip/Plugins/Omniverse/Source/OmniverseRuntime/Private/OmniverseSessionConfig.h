// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "CoreMinimal.h"
#include "IOmniverseSessionConfig.h"

class FOmniverseSessionConfig : public IOmniverseSessionConfig
{
public:
    FOmniverseSessionConfig() {};
    virtual ~FOmniverseSessionConfig() {};

	static TSharedRef<FOmniverseSessionConfig> Get();

	virtual bool CreateSessionConfig(const FString& SessionConfigPath, const TMap<IOmniverseSessionConfig::Key, FString>& ConfigMap) override;
	virtual bool LoadSessionConfig(const FString& SessionConfigPath, TMap<IOmniverseSessionConfig::Key, FString>& ConfigMap) override;
	virtual bool IsCompatible(const int32 MajorVersion, const int32 MinorVersion) override;

private:
	FString ToString(IOmniverseSessionConfig::Key Key);
	IOmniverseSessionConfig::Key ToKey(const FString& KeyStr);
};

