// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseConnectionHelper.h"
#include "Async/Async.h"
#include "Misc/CoreDelegates.h"
#include "Misc/Paths.h"
#include "OmniversePathHelper.h"
#include "OmniverseRuntimeModule.h"
#include "OmniverseRuntimePrivate.h"
#include "OmniClient.h"
#include "OmniUsdResolver.h"
#include <openssl/sha.h>

class OmniverseAsyncTask : public IOmniverseAsyncTask
{
public:
	OmniverseAsyncTask(OmniClientRequestId Id) :IOmniverseAsyncTask(Id) {}

	virtual void Stop()
	{
		omniClientStop(GetId());
	}
};

template<typename T>
class OmniverseSubscribeAsyncTask : public OmniverseAsyncTask
{
public:
	OmniverseSubscribeAsyncTask(const TSharedPtr<T, ESPMode::ThreadSafe>& AllocatedContext)
		: OmniverseAsyncTask(-1), Context(AllocatedContext)
	{
	}

	~OmniverseSubscribeAsyncTask()
	{
		Stop();
	}

	
	void SetRequestId(OmniClientRequestId Id)
	{
		RequestId = Id;
	}

	TSharedPtr<T, ESPMode::ThreadSafe> GetContext() const
	{
		return Context;
	}

	virtual void Stop()
	{
		OmniverseAsyncTask::Stop();
		Context.Reset();
	}

private:
	TSharedPtr<T, ESPMode::ThreadSafe> Context;
};

void FOmniverseConnectionHelper::Init()
{
}

void FOmniverseConnectionHelper::Shutdown()
{
}

bool FOmniverseConnectionHelper::IsConnected()
{
	return true;
}

struct FSHA256
{
	uint8 Digest[SHA256_DIGEST_LENGTH];

	FString ToString() const
	{
		ANSICHAR Buffer[SHA256_DIGEST_LENGTH * 2 + 1] = {0};
		for (int Idx = 0; Idx < SHA256_DIGEST_LENGTH; Idx++)
		{
			FCStringAnsi::Sprintf(Buffer + (Idx * 2), "%02x", Digest[Idx]);
		}
		return Buffer;
	}
};

FSHA256 Sha256(const uint8* Input, size_t InputLen)
{
	FSHA256 Output;
	SHA256(Input, InputLen, Output.Digest);
	return Output;
}

FString FOmniverseConnectionHelper::GetFileHash(void* Content, uint64 Size)
{
	const static FString DefaultHashType = FString(TEXT("sha-256-flat"));
	const uint64 DefaultHashSize = 1048576;

	uint64 LeftSize = Size;
	uint8_t * ReadContent = (uint8_t*)Content;
	TArray<FSHA256> HashArray;
	while(LeftSize > 0)
	{
		uint64 ReadSize = LeftSize < DefaultHashSize ? LeftSize : DefaultHashSize;
		HashArray.Add(Sha256(ReadContent, ReadSize));
		ReadContent += ReadSize;
		LeftSize -= ReadSize;
	}
	
	FSHA256 Output;
	SHA256_CTX ShaContext;
	SHA256_Init(&ShaContext);

	for (auto Hash : HashArray)
	{
		SHA256_Update(&ShaContext, Hash.Digest, SHA256_DIGEST_LENGTH);
	}

	SHA256_Final(Output.Digest, &ShaContext);
	const FString Separator = TEXT(";");
	return DefaultHashType + Separator + FString::FromInt(DefaultHashSize) + Separator + Output.ToString();
}

bool FOmniverseConnectionHelper::DeleteSync(const FString & Path)
{
	struct DeleteContext
	{
		bool Success = false;
	} Context;

	omniClientWait(omniClientDelete(TCHAR_TO_UTF8(*Path), &Context, [](void* UserData, OmniClientResult result)
		{
			DeleteContext* Context = (DeleteContext *)UserData;
			{
				if (result == eOmniClientResult_Ok)
				{
					Context->Success = true;
				}
				else
				{
					Context->Success = false;
				}
			}
		}));

	return Context.Success;
}

bool FOmniverseConnectionHelper::CreateFolderSync(const FString & Path)
{
	struct WriteContext
	{
		bool Success = false;
	} Context;

	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	omniClientWait(omniClientCreateFolder(TCHAR_TO_UTF8(*OmniversePath), &Context, [](void* UserData, OmniClientResult result)
		{
			WriteContext* Context = (WriteContext *)UserData;
			{
				if (result == eOmniClientResult_Ok)
				{
					Context->Success = true;
				}
				else
				{
					Context->Success = false;
				}
			}
		}));

	return Context.Success;
}

bool FOmniverseConnectionHelper::WriteFileSync(const FString& Path, const TArrayView<const uint8>& Content)
{
	return WriteFileSync(Path, const_cast<uint8_t*>(Content.GetData()), Content.Num());
}

bool FOmniverseConnectionHelper::WriteFileSync(const FString & Path, const TArray64<uint8>& Content)
{
	return WriteFileSync(Path, const_cast<uint8_t*>(Content.GetData()), Content.Num());
}

bool FOmniverseConnectionHelper::WriteFileSync(const FString & Path, void * Content, uint64 Size)
{
	if (Content == nullptr || Size == 0)
	{
		return false;
	}

	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	FOmniverseListFileResult ListResult;
	if (ListFileSync(OmniversePath, ListResult))
	{
		FString Hash = GetFileHash(Content, Size);
		if (ListResult.ListItem.Hash.Equals(Hash))
		{
			return true;
		}
	}

	struct WriteContext
	{
		bool Success = false;
	} Context;

	OmniClientContent OmniContent{ Content, Size, nullptr };
	omniClientWait(omniClientWriteFile(TCHAR_TO_UTF8(*OmniversePath), &OmniContent, &Context, [](void* UserData, OmniClientResult result)
		{
			WriteContext* Context = (WriteContext *)UserData;
			{
				if (result == eOmniClientResult_Ok)
				{
					Context->Success = true;
				}
				else
				{
					Context->Success = false;
				}
			}
		}));

	CreateCheckpointSync(OmniversePath);

	return Context.Success;
}

void FOmniverseConnectionHelper::CreateCheckpointSync(const FString& OmniverseURL)
{
	bool bCheckpointsSupported = false;
	omniClientWait(omniClientGetServerInfo(TCHAR_TO_UTF8(*OmniverseURL), &bCheckpointsSupported, 
		[](void* UserData, OmniClientResult Result, OmniClientServerInfo const * Info)
		{
			if (Result == eOmniClientResult_Ok && Info && UserData)
			{
				bool* bCheckpointsSupported = static_cast<bool*>(UserData);
				*bCheckpointsSupported = Info->checkpointsEnabled;
			}
		}));

	if (bCheckpointsSupported)
	{
		/*usd save or write file will create an empty checkpoint, no need to force to create*/
		bool bForceCheckpoint = IOmniverseRuntimeModule::Get().GetCheckpointComment().IsEmpty() ? false : true;
		omniClientWait(omniClientCreateCheckpoint(TCHAR_TO_UTF8(*OmniverseURL), TCHAR_TO_UTF8(*IOmniverseRuntimeModule::Get().GetCheckpointComment()), bForceCheckpoint, nullptr, [](void* userData, OmniClientResult result, char const * checkpointQuery)
		{}));
	}
}

bool FOmniverseConnectionHelper::ListFileSync(const FString & Path, FOmniverseListFileResult& FileResult)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct ListContext
	{
		FString Path;
		FOmniverseListFileResult* Result;
		bool Success = false;
	} Context;
	Context.Path = OmniversePath;
	Context.Result = &FileResult;

	omniClientWait(omniClientStat(TCHAR_TO_UTF8(*OmniversePath), &Context, [](void* UserData, OmniClientResult Result, struct OmniClientListEntry const* Entry)
		{
			ListContext* Context = (ListContext *)UserData;
			{
				if (Result == eOmniClientResult_Ok)
				{
					if (Entry)
					{
						Context->Success = true;
						Context->Result->Status = Result;
						Context->Result->ListItem.Path = Context->Path / UTF8_TO_TCHAR(Entry->relativePath);
						Context->Result->ListItem.Access = Entry->access;
						Context->Result->ListItem.Flags = Entry->flags;
						Context->Result->ListItem.Size = Entry->size;
						Context->Result->ListItem.Version = Entry->version;
						Context->Result->ListItem.Hash = Entry->hash;
					}
					else
					{
						Context->Success = false;
					}
				}
				else
				{
					Context->Success = false;
				}
			}
		}));

	return Context.Success;
}

bool FOmniverseConnectionHelper::ListFolderSync(const FString & Path, TArray<FOmniverseListItem>& ListingResult)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct ListContext
	{
		FString Path;
		TArray<FOmniverseListItem>* Result;
		bool Success = false;
	} Context;
	Context.Path = OmniversePath;
	Context.Result = &ListingResult;

	omniClientWait(omniClientList(TCHAR_TO_UTF8(*OmniversePath), &Context, [](void* UserData, OmniClientResult Result, uint32_t NumEntries, struct OmniClientListEntry const* Entries)
		{
			ListContext* Context = (ListContext *)UserData;
			{
				if (Result == eOmniClientResult_Ok)
				{
					Context->Success = true;
				}
				else
				{
					Context->Success = false;
				}

				for (uint32_t EntryIndex = 0; EntryIndex < NumEntries; EntryIndex++)
				{
					const auto& Entry = Entries[EntryIndex];
					const auto& AbsolutePath = Context->Path / UTF8_TO_TCHAR(Entry.relativePath);

					FOmniverseListItem ListItem;
					ListItem.Path = AbsolutePath;
					ListItem.Access = Entry.access;
					ListItem.Flags = Entry.flags;
					ListItem.Size = Entry.size;
					ListItem.Version = Entry.version;
					ListItem.Hash = Entry.hash;

					Context->Result->Add(ListItem);
				}
			}
		}));

	return Context.Success;
}

bool FOmniverseConnectionHelper::CopySync(const FString & FromPath, const FString & ToPath)
{
	const FString& OmniverseFromPath = FOmniversePathHelper::UniformOmniPath(FromPath);
	const FString& OmniverseToPath = FOmniversePathHelper::UniformOmniPath(ToPath);

	struct CopyContext
	{
		bool Success = false;
	} Context;

	omniClientWait(omniClientCopy(TCHAR_TO_UTF8(*OmniverseFromPath), TCHAR_TO_UTF8(*OmniverseToPath), &Context, [](void* UserData, OmniClientResult result)
		{
			CopyContext* Context = (CopyContext *)UserData;
			{
				if (result == eOmniClientResult_Ok)
				{
					Context->Success = true;
				}
				else
				{
					Context->Success = false;
				}
			}
		}));

	return Context.Success;
}

bool FOmniverseConnectionHelper::ReadSync(const FString & Path, TSharedOmniContentPtr & ContentPtr)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct ReadContext
	{
		TSharedOmniContentPtr* Content;
		bool Success = false;
	} Context;
	Context.Content = &ContentPtr;

	omniClientWait(omniClientReadFile(TCHAR_TO_UTF8(*OmniversePath), &Context, [](void* UserData,
		OmniClientResult Result,
		const char* Version,
		struct OmniClientContent* Content)
		{
			ReadContext* Context = (ReadContext *)UserData;
			{
				if (Result == eOmniClientResult_Ok)
				{
					*Context->Content = TSharedOmniContentPtr(new FOmniverseContent(*Content));
					Context->Success = true;
				}
				else
				{
					Context->Success = false;
				}
			}
		}));

	return Context.Success;
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::DeleteAsync(const FString & Path, const FOmniverseDeleteCallback & OnDeleteCallback)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct DeleteContext
	{
		FOmniverseDeleteCallback Callback;
	};
	DeleteContext* Context = new DeleteContext;
	Context->Callback = OnDeleteCallback;

	OmniClientRequestId RequestId = omniClientDelete(TCHAR_TO_UTF8(*OmniversePath), Context, [](void* UserData, OmniClientResult Result)
		{
			DeleteContext* Context = (DeleteContext *)UserData;
			if (Context->Callback.IsBound())
			{
				AsyncTask(ENamedThreads::GameThread, [Context, Result]()
				{
					Context->Callback.ExecuteIfBound(Result);
					delete Context;
				});
			}
			else
			{
				delete Context;
			}
		});

	return TSharedOmniverseAyncTask(new OmniverseAsyncTask(RequestId));
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::ListFolderAsync(const FString & Path, const FOmniverseListFolderCallback & OnListCallback)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct ListContext
	{
		FString Path;
		FOmniverseListFolderCallback Callback;
	};

	ListContext* Context = new ListContext;
	Context->Path = OmniversePath;
	Context->Callback = OnListCallback;
	
	OmniClientRequestId RequestId = omniClientList(TCHAR_TO_UTF8(*OmniversePath), Context, [](void* UserData, OmniClientResult Result,
		uint32_t NumEntries, struct OmniClientListEntry const* Entries)
		{
			ListContext* Context = (ListContext *)UserData;
			if (Context->Callback.IsBound())
			{
				FOmniverseListFolderResult ListResult;
				ListResult.Status = Result;
				for (uint32_t EntryIndex = 0; EntryIndex < NumEntries; EntryIndex++)
				{
					const auto& Entry = Entries[EntryIndex];
					FOmniverseListItem Item;
					const auto& AbsolutePath = Context->Path / UTF8_TO_TCHAR(Entry.relativePath);
					Item.Path = AbsolutePath;
					Item.Access = Entry.access;
					Item.Flags = Entry.flags;
					Item.Size = Entry.size;
					Item.Version = Entry.version;
					Item.Hash = Entry.hash;
					ListResult.ListItems.Add(Item);
				}

				TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
				FDelegateHandle ListResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, ListResult]()
				{
					Context->Callback.ExecuteIfBound(ListResult);
					delete Context;
					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				});
				*DelegateHandle = ListResultDelegate;
			}
			else
			{
				delete Context;
			}
		});

	return TSharedOmniverseAyncTask(new OmniverseAsyncTask(RequestId));
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::ListFileSubscribe(const FString & Path, const FOmniverseListFileCallback & OnListCallback, const FOmniverseSubscribeCallback& OnSubscribeCallback)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct ListContext
	{
		FString Path;
		FOmniverseListFileCallback ListCallback;
		FOmniverseSubscribeCallback SubscribeCallback;
	};
	TSharedPtr<ListContext, ESPMode::ThreadSafe> Context(new ListContext);
	Context->Path = OmniversePath;
	Context->ListCallback = OnListCallback;
	Context->SubscribeCallback = OnSubscribeCallback;

	auto Task = new OmniverseSubscribeAsyncTask<ListContext>(Context);

	// Delay the lifecycle
	OmniClientRequestId RequestId = omniClientStatSubscribe(TCHAR_TO_UTF8(*OmniversePath), Task,
		[](void* UserData, OmniClientResult Result, struct OmniClientListEntry const* Entry)
		{
			auto Task = (OmniverseSubscribeAsyncTask<ListContext>*)UserData;
			auto Context = Task->GetContext();
			if (Context->ListCallback.IsBound())
			{
				FOmniverseListFileResult ListResult;
				ListResult.Status = Result;

				ListResult.ListItem.Path = Context->Path / UTF8_TO_TCHAR(Entry->relativePath);
				ListResult.ListItem.Access = Entry->access;
				ListResult.ListItem.Flags = Entry->flags;
				ListResult.ListItem.Size = Entry->size;
				ListResult.ListItem.Version = Entry->version;
				ListResult.ListItem.Hash = Entry->hash;

				TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
				FDelegateHandle ListResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, ListResult]()
				{
					Context->ListCallback.ExecuteIfBound(ListResult);
					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				});
				*DelegateHandle = ListResultDelegate;
			}
		},
		[](void* UserData, OmniClientResult Result, OmniClientListEvent ListEvent, struct OmniClientListEntry const* Entry)
		{
			auto Task = (OmniverseSubscribeAsyncTask<ListContext>*)UserData;
			auto Context = Task->GetContext();
			if (Context->SubscribeCallback.IsBound())
			{
				FOmniverseSubscribeResult SubscribeResult;
				SubscribeResult.Status = Result;
				SubscribeResult.ListEvent = ListEvent;
				FOmniverseListItem Item;
				if (Entry)
				{
					const auto& AbsolutePath = Context->Path / UTF8_TO_TCHAR(Entry->relativePath);
					Item.Path = AbsolutePath;
					Item.Access = Entry->access;
					Item.Flags = Entry->flags;
					Item.Size = Entry->size;
					Item.Version = Entry->version;
					Item.Hash = Entry->hash;
					SubscribeResult.ListItem = Item;
				}

				TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
				FDelegateHandle ListResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, SubscribeResult]()
				{
					Context->SubscribeCallback.ExecuteIfBound(SubscribeResult);
					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				});
				*DelegateHandle = ListResultDelegate;
			}
		});

	Task->SetRequestId(RequestId);
	return TSharedOmniverseAyncTask(Task);
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::ListFolderSubscribe(const FString & Path, const FOmniverseListFolderCallback & OnListCallback, const FOmniverseSubscribeCallback& OnSubscribeCallback)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct ListContext
	{
		FString Path;
		FOmniverseListFolderCallback ListCallback;
		FOmniverseSubscribeCallback SubscribeCallback;
	};
	TSharedPtr<ListContext, ESPMode::ThreadSafe> Context(new ListContext);
	Context->Path = OmniversePath;
	Context->ListCallback = OnListCallback;
	Context->SubscribeCallback = OnSubscribeCallback;

	auto Task = new OmniverseSubscribeAsyncTask<ListContext>(Context);

	// Delay the lifecycle
	OmniClientRequestId RequestId = omniClientListSubscribe(TCHAR_TO_UTF8(*OmniversePath), Task,
		[](void* UserData, OmniClientResult Result, uint32_t NumEntries, struct OmniClientListEntry const* Entries)
		{
			auto Task = (OmniverseSubscribeAsyncTask<ListContext>*)UserData;
			auto Context = Task->GetContext();
			if (Context->ListCallback.IsBound())
			{
				FOmniverseListFolderResult ListResult;
				ListResult.Status = Result;
				for (uint32_t EntryIndex = 0; EntryIndex < NumEntries; EntryIndex++)
				{
					const auto& Entry = Entries[EntryIndex];
					FOmniverseListItem Item;
					const auto& AbsolutePath = Context->Path / UTF8_TO_TCHAR(Entry.relativePath);
					Item.Path = AbsolutePath;
					Item.Access = Entry.access;
					Item.Flags = Entry.flags;
					Item.Size = Entry.size;
					Item.Version = Entry.version;
					Item.Hash = Entry.hash;
					ListResult.ListItems.Add(Item);
				}

				TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
				FDelegateHandle ListResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, ListResult]()
				{
					Context->ListCallback.ExecuteIfBound(ListResult);
					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				});
				*DelegateHandle = ListResultDelegate;
			}
		},
		[](void* UserData, OmniClientResult Result, OmniClientListEvent ListEvent, struct OmniClientListEntry const* Entry)
		{
			auto Task = (OmniverseSubscribeAsyncTask<ListContext>*)UserData;
			auto Context = Task->GetContext();
			if (Context->SubscribeCallback.IsBound())
			{
                FOmniverseSubscribeResult SubscribeResult;
				SubscribeResult.Status = Result;
				SubscribeResult.ListEvent = ListEvent;
				FOmniverseListItem Item;
				if (Entry)
				{
					const auto& AbsolutePath = Context->Path / UTF8_TO_TCHAR(Entry->relativePath);
					Item.Path = AbsolutePath;
					Item.Access = Entry->access;
					Item.Flags = Entry->flags;
					Item.Size = Entry->size;
					Item.Version = Entry->version;
					Item.Hash = Entry->hash;
					SubscribeResult.ListItem = Item;
				}

				TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
				FDelegateHandle ListResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, SubscribeResult]()
				{
					Context->SubscribeCallback.ExecuteIfBound(SubscribeResult);
					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				});
				*DelegateHandle = ListResultDelegate;
			}
		});

	Task->SetRequestId(RequestId);
	return TSharedOmniverseAyncTask(Task);
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::ListCheckpointsAsync(const FString& Path, const FOmniverseListCheckpointCallback& OnListCallback)
{
	const FString& OmniversePath = FOmniversePathHelper::RemoveQuery(FOmniversePathHelper::UniformOmniPath(Path));

	struct ListContext
	{
		FString Path;
		FOmniverseListCheckpointCallback Callback;
	};
	ListContext* Context = new ListContext;
	Context->Path = OmniversePath;
	Context->Callback = OnListCallback;

	OmniClientRequestId RequestId = omniClientListCheckpoints(TCHAR_TO_UTF8(*OmniversePath), Context, [](void* UserData, OmniClientResult Result,
		uint32_t NumEntries, struct OmniClientListEntry const* Entries)
	{
		ListContext* Context = (ListContext*)UserData;
		if (Context->Callback.IsBound())
		{
			FOmniverseListCheckpointResult ListResult;
			ListResult.Status = Result;
			for (uint32_t EntryIndex = 0; EntryIndex < NumEntries; EntryIndex++)
			{
				const auto& Entry = Entries[EntryIndex];
				FOmniverseListItem Item;
				const auto& AbsolutePath = Context->Path + TEXT("?") + UTF8_TO_TCHAR(Entry.relativePath);
				Item.Path = AbsolutePath;
				Item.Access = Entry.access;
				Item.Flags = Entry.flags;
				Item.Size = Entry.size;
				Item.Version = Entry.version;
				Item.Hash = Entry.hash;
				ListResult.ListItems.Add(Item);
			}

			TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
			FDelegateHandle ListResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, ListResult]()
			{
				Context->Callback.ExecuteIfBound(ListResult);
				delete Context;
				FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
			});
			*DelegateHandle = ListResultDelegate;
		}
		else
		{
			delete Context;
		}
	});

	return TSharedOmniverseAyncTask(new OmniverseAsyncTask(RequestId));
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::ReadAsync(const FString & Path, const FOmniverseReadCallback & OnReadCallback)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct ReadContext
	{
		FOmniverseReadCallback Callback;
	};
	ReadContext* Context = new ReadContext;
	Context->Callback = OnReadCallback;

	OmniClientRequestId RequestId = omniClientReadFile(TCHAR_TO_UTF8(*OmniversePath), Context, [](void* UserData,
		OmniClientResult Result,
		const char* Version,
		struct OmniClientContent* Content)
		{
			ReadContext* Context = (ReadContext *)UserData;
			if (Context->Callback.IsBound())
			{
				FOmniverseReadResult ReadResult;
				ReadResult.Status = Result;
				ReadResult.Version = Version;
				if (Result == eOmniClientResult_Ok)
				{
					auto ContentPtr = TSharedOmniContentPtr(new FOmniverseContent(*Content));
					ReadResult.Content = ContentPtr;
				}

				TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
				FDelegateHandle ReadResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, ReadResult]()
				{
					Context->Callback.ExecuteIfBound(ReadResult);
					delete Context;
					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				});
				*DelegateHandle = ReadResultDelegate;
			}
			else
			{
				delete Context;
			}
		});

	return TSharedOmniverseAyncTask(new OmniverseAsyncTask(RequestId));
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::JoinChannel(const FString & Path, const FOmniverseJoinChannelCallback & OnJoinChannelCallback)
{
	const FString& OmniversePath = FOmniversePathHelper::UniformOmniPath(Path);

	struct JoinChannelContext
	{
		FString Path;
		FOmniverseJoinChannelCallback Callback;
	};

	TSharedPtr<JoinChannelContext, ESPMode::ThreadSafe> Context(new JoinChannelContext);
	Context->Path = OmniversePath;
	Context->Callback = OnJoinChannelCallback;
	
	auto Task = new OmniverseSubscribeAsyncTask<JoinChannelContext>(Context);

	OmniClientRequestId RequestId = omniClientJoinChannel(TCHAR_TO_UTF8(*OmniversePath), Task,
		[](void* UserData, OmniClientResult Result, OmniClientChannelEvent EventType,
			const char* From, struct OmniClientContent* Content)
		{
			auto Task = (OmniverseSubscribeAsyncTask<JoinChannelContext>*)UserData;
			auto Context = Task->GetContext();
			if (Context->Callback.IsBound())
			{
				FOmniverseJoinChannelResult ChannelResult;
				ChannelResult.Status = Result;
				ChannelResult.From = From;
				ChannelResult.EventType = EventType;
				auto ContentPtr = TSharedOmniContentPtr(new FOmniverseContent(*Content));
				ChannelResult.Content = ContentPtr;

				TSharedPtr<FDelegateHandle> DelegateHandle = MakeShareable<FDelegateHandle>(new FDelegateHandle());
				FDelegateHandle ChannelResultDelegate = FCoreDelegates::OnBeginFrame.AddLambda([Context, DelegateHandle, ChannelResult]()
				{
					Context->Callback.ExecuteIfBound(ChannelResult);
					FCoreDelegates::OnBeginFrame.Remove(*DelegateHandle);
				});
				*DelegateHandle = ChannelResultDelegate;
			}
		});

	Task->SetRequestId(RequestId);
	return TSharedOmniverseAyncTask(Task);
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::SendMessageToChannel(OmniClientRequestId JoinRequestId, OmniClientContent * Content, const FOmniverseSendMessageCallback & OnSendMessageCallback)
{
	struct SendMessageContext
	{
		FOmniverseSendMessageCallback Callback;
	};
	SendMessageContext* Context = new SendMessageContext;
	Context->Callback = OnSendMessageCallback;

	OmniClientRequestId RequestId = omniClientSendMessage(JoinRequestId, Content, Context, [](void* UserData,
		OmniClientResult Result)
		{
			SendMessageContext* Context = (SendMessageContext *)UserData;
			if (Context->Callback.IsBound())
			{
				AsyncTask(ENamedThreads::GameThread, [Context, Result]()
				{
					Context->Callback.ExecuteIfBound(Result);
					delete Context;
				});
			}
			else
			{
				delete Context;
			}
		});

	return TSharedOmniverseAyncTask(new OmniverseAsyncTask(RequestId));
}

TSharedOmniverseAyncTask FOmniverseConnectionHelper::GetServerInfo(const FString & ServerUrl, const FOmniverseGetServerInfoCallback & OnGetServerInfoCallback)
{
	struct GetServerInfoContext
	{
		FOmniverseGetServerInfoCallback Callback;
	};
	GetServerInfoContext* Context = new GetServerInfoContext;
	Context->Callback = OnGetServerInfoCallback;

	OmniClientRequestId RequestId = omniClientGetServerInfo(TCHAR_TO_UTF8(*ServerUrl), Context, [](void* UserData,
		OmniClientResult Result, struct OmniClientServerInfo const * ServerInfo)
		{
			GetServerInfoContext* Context = (GetServerInfoContext *)UserData;
			if (Context->Callback.IsBound() && ServerInfo)
			{
				FOmniverseGetServerInfoResult ServerInfoResult;
				ServerInfoResult.Status = Result;
				ServerInfoResult.UserName = ServerInfo->username;
				ServerInfoResult.AuthToken = ServerInfo->authToken;
				AsyncTask(ENamedThreads::GameThread, [Context, ServerInfoResult]()
					{
						Context->Callback.ExecuteIfBound(ServerInfoResult);
						delete Context;
					});
			}
			else
			{
				delete Context;
			}
		});

	return TSharedOmniverseAyncTask(new OmniverseAsyncTask(RequestId));
}

void FOmniverseConnectionHelper::Wait(OmniClientRequestId RequestId)
{
	omniClientWait(RequestId);
}

void FOmniverseConnectionHelper::LiveUpdate()
{
	omniClientLiveProcess();
}

void FOmniverseConnectionHelper::SetCheckpointToResolver(const FString& Message)
{
	omniUsdResolverSetCheckpointMessage(TCHAR_TO_UTF8(*Message));
}