#include "OmniverseSessionConfig.h"
#include "OmniverseConnectionHelper.h"
THIRD_PARTY_INCLUDES_START
#include <toml/toml.h>
#include <sstream>
THIRD_PARTY_INCLUDES_END

#define OV_SESSION_CONFIG_MAJOR_VERSION 1
#define OV_SESSION_CONFIG_MINOR_VERSION 0


static TSharedPtr<FOmniverseSessionConfig> OmniverseSessionConfigInstance = nullptr;
TSharedRef<IOmniverseSessionConfig> IOmniverseSessionConfig::Get()
{
	return FOmniverseSessionConfig::Get();
}

TSharedRef<FOmniverseSessionConfig> FOmniverseSessionConfig::Get()
{
	if (!OmniverseSessionConfigInstance)
	{
		OmniverseSessionConfigInstance = MakeShareable(new FOmniverseSessionConfig());
	}

	return OmniverseSessionConfigInstance.ToSharedRef();
}

//
//
bool FOmniverseSessionConfig::LoadSessionConfig(const FString& SessionConfigPath, TMap<IOmniverseSessionConfig::Key, FString>& ConfigMap)
{
	TSharedOmniContentPtr Content;
	if (FOmniverseConnectionHelper::ReadSync(SessionConfigPath, Content))
	{
		std::istringstream iss(std::string((char*)Content->GetData(), Content->Size()));

		toml::ParseResult Result = toml::parse(iss);
		if (Result.valid())
		{
			ConfigMap.Reset();
			for (IOmniverseSessionConfig::Key Index = IOmniverseSessionConfig::Key::Version; Index < IOmniverseSessionConfig::Key::INVALID;)
			{
				const toml::Value* Value = Result.value.find(TCHAR_TO_UTF8(*ToString(Index)));
				if (Value && Value->is<std::string>())
				{
					std::string KeyValue = Value->as<std::string>();
					ConfigMap.Add(Index, KeyValue.c_str());
				}
				Index = (IOmniverseSessionConfig::Key)((int32)Index + 1);
			}

			return true;
		}
	}

	return false;
}

bool FOmniverseSessionConfig::CreateSessionConfig(const FString& SessionConfigPath, const TMap<IOmniverseSessionConfig::Key, FString>& ConfigMap)
{
    toml::Value Root((toml::Table()));
    for (auto Config : ConfigMap)
    {
        Root.setChild(TCHAR_TO_UTF8(*ToString(Config.Key)), TCHAR_TO_UTF8(*Config.Value));
    }

	FString Version = FString::Printf(TEXT("%d.%d"), OV_SESSION_CONFIG_MAJOR_VERSION, OV_SESSION_CONFIG_MINOR_VERSION);
    Root.setChild(TCHAR_TO_UTF8(*ToString(Key::Version)), TCHAR_TO_UTF8(*Version));

    std::ostringstream oss;
    Root.write(&oss);
	return FOmniverseConnectionHelper::WriteFileSync(SessionConfigPath, const_cast<char*>(oss.str().data()), (uint64)oss.str().length());
}

bool FOmniverseSessionConfig::IsCompatible(const int32 MajorVersion, const int32 MinorVersion)
{
	return MajorVersion == OV_SESSION_CONFIG_MAJOR_VERSION;
}

FString FOmniverseSessionConfig::ToString(IOmniverseSessionConfig::Key Key)
{
    switch (Key)
    {
		case(Key::Version): return "version";
		case(Key::UserName): return "user_name";
		case(Key::StageUrl): return "stage_url";
		case(Key::Description): return "description";
		case(Key::Mode): return "mode";
		case(Key::Name): return "name";
		default: return "";
    }
}

IOmniverseSessionConfig::Key FOmniverseSessionConfig::ToKey(const FString& KeyStr)
{
    if (KeyStr == "version")
	{
		return Key::Version;
	}
    else if (KeyStr == "user_name")
	{
		return Key::UserName;
	}
    else if (KeyStr == "stage_url")
	{
		return Key::StageUrl;
	}
    else if (KeyStr == "description")
	{
		return Key::Description;
	}
    else if (KeyStr == "mode")
	{
		return Key::Mode;
	}
    else if (KeyStr == "name")
	{
		return Key::Name;
	}
    else
	{
		return Key::INVALID;
	}
}
