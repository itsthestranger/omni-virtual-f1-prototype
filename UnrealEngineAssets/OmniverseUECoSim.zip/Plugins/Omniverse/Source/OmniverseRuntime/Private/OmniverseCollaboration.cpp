// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseCollaboration.h"
#include "CoreMinimal.h"
#include "HAL/UnrealMemory.h"
#include "Misc/CoreDelegates.h"
#include "Misc/ScopedSlowTask.h"
#include "JsonObjectConverter.h"
#include "Runtime/Launch/Resources/Version.h"
#include "UObject/UObjectGlobals.h"

#include "OmniverseRuntimePrivate.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseNotificationHelper.h"
#include "OmniverseRuntimeModule.h"
#include "OmniversePathHelper.h"

const static FString UserJoin = "JOIN";
const static FString UserHello = "HELLO";
const static FString UserGetUsers = "GET_USERS";
const static FString UserLeft = "LEFT";
const static FString UserMessage = "MESSAGE";
const static FString MergeStarted = "MERGE_STARTED";
const static FString MergeFinished = "MERGE_FINISHED";
const static FString InvalidType = "INVALID";
const static FString SessionManagement = "__SESSION_MANAGEMENT__";
const static char* MESSAGE_HEADER = "__OVUM__";

#define OV_MESSAGE_MAJOR_VERSION 3
#define OV_MESSAGE_MINOR_VERSION 0

#define OV_SESSION_MESSAGE_MAJOR_VERSION 1
#define OV_SESSION_MESSAGE_MINOR_VERSION 0


struct FOmniverseMessageHeader
{
	uint64 Id;
};

struct FOmniverseReceiveMessage
{
	FOmniverseMessageHeader Header;
	FOmniverseMessage Message;
};

class FOmniverseChannel
{
public:
	FOmniverseChannel(const FString& InChannel)
		: ChannelPath(InChannel)
	{
		FString UserName;
		FString AssetPath;
		FString Branch;
		FString Checkpoint;
		FOmniversePathHelper::SplitUrlPath(ChannelPath, UserName, ChannelServer, AssetPath, Branch, Checkpoint);

		const auto& WatchServerList = IOmniverseRuntimeModule::Get().GetWatchList();
		for (auto WatchServer : WatchServerList)
		{
			if (ChannelServer.Equals(WatchServer.Address))
			{
				ChannelUserName = WatchServer.UserName;
				break;
			}
		}
	}

	~FOmniverseChannel()
	{
		StopListening();
	}

	void OnMessageReceived(const FOmniverseJoinChannelResult& MessageResult)
	{
		if (MessageResult.Status != eOmniClientResult_Ok && MessageResult.Status != eOmniClientResult_OkLatest)
		{
			StopListening();

			return;
		}

		if (MessageResult.EventType == eOmniClientChannelEvent_Message)
		{
			FOmniverseMessage Message;
			if (ParseResponse(MessageResult, Message))
			{
				int32 MajorVersion = 0;
				int32 MinorVersion = 0;
				FOmniversePathHelper::ParseVersion(Message.version, MajorVersion, MinorVersion);

				if (MajorVersion == OV_MESSAGE_MAJOR_VERSION)
				{
					switch(GetMessageType(Message.message_type))
					{
					case EOmniverseMessageType::UserJoin:
						SendMessage(EOmniverseMessageType::UserHello);
						FOmniverseCollaboration::Get()->OnUserJoined.Broadcast(Message);
						break;
					case EOmniverseMessageType::UserHello:
						FOmniverseCollaboration::Get()->OnUserHelloed.Broadcast(Message);
						break;
					case EOmniverseMessageType::UserGetUsers:
						SendMessage(EOmniverseMessageType::UserHello);
						FOmniverseCollaboration::Get()->OnGetUsers.Broadcast(Message);
						break;
					case EOmniverseMessageType::UserLeft:
						FOmniverseCollaboration::Get()->OnUserLeft.Broadcast(Message);
						break;
					case EOmniverseMessageType::UserMessage:
						auto SessionMessage = Message.content.Find(SessionManagement);
						if (SessionMessage)
						{
							int32 SessionMessageMajorVersion = 0;
							int32 SessionMessageMinorVersion = 0;
							FOmniversePathHelper::ParseVersion(SessionMessage->version, SessionMessageMajorVersion, SessionMessageMinorVersion);
							if (SessionMessageMajorVersion == OV_SESSION_MESSAGE_MAJOR_VERSION)
							{
								switch(GetMessageType(SessionMessage->message))
								{
								case EOmniverseMessageType::MergeStarted:
									FOmniverseCollaboration::Get()->OnMergeStarted.Broadcast(Message);
									break;
								case EOmniverseMessageType::MergeFinished:
									FOmniverseCollaboration::Get()->OnMergeFinished.Broadcast(Message);
									break;
								}
							}
						}
						break;
					}
				}
			}
		}
	}

	void StartListening()
	{
		// Start listening
		if (ListenTask)
		{
			ListenTask->Stop();
		}

		if (FOmniverseConnectionHelper::IsConnected())
		{
			ListenChannelCallback = FOmniverseJoinChannelCallback::CreateRaw(this, &FOmniverseChannel::OnMessageReceived);
			ListenTask = FOmniverseConnectionHelper::JoinChannel(ChannelPath, ListenChannelCallback);
			FOmniverseConnectionHelper::Wait(ListenTask->GetId());
		}
	}

	void StopListening()
	{
		if (ListenTask)
		{
			ListenChannelCallback.Unbind();
			FOmniverseConnectionHelper::Wait(MessageTask->GetId());
			ListenTask->Stop();
			ListenTask.Reset();
		}
	}

	void SendMessage(const FOmniverseMessage& Message)
	{
		if (ListenTask)
		{
			FString JsonString;
			bool bSuccess = FJsonObjectConverter::UStructToJsonObjectString(Message, JsonString);
			if (bSuccess)
			{
				JsonString = MESSAGE_HEADER + JsonString;
				FTCHARToUTF8 ConvertedContent(*JsonString);
				OmniClientContent Content = omniClientAllocContent(ConvertedContent.Length());
				FMemory::Memmove(Content.buffer, (uint8*)ConvertedContent.Get(), ConvertedContent.Length());
				//! This function takes ownership of the content
				//! it calls content->free(content->buffer) when it's finished with it (which may be some time in the future)
				MessageTask = FOmniverseConnectionHelper::SendMessageToChannel(ListenTask->GetId(), &Content, nullptr);
			}
		}
	}

	FORCEINLINE bool IsCustomMessage(EOmniverseMessageType MessageType)
	{
		return (MessageType == EOmniverseMessageType::MergeStarted
		|| MessageType == EOmniverseMessageType::MergeFinished);
	}

	void SendMessage(EOmniverseMessageType MessageType)
	{
		FOmniverseMessage Message;
		Message.version = FString::Printf(TEXT("%d.%d"), OV_MESSAGE_MAJOR_VERSION, OV_MESSAGE_MINOR_VERSION);
		Message.app = FString::Printf(TEXT("%s %d.%d"), *FString(EPIC_PRODUCT_NAME), ENGINE_MAJOR_VERSION, ENGINE_MINOR_VERSION);
		Message.from_user_name = ChannelUserName;
		if (IsCustomMessage(MessageType))
		{
			Message.message_type = UserMessage;
			FString session_message_version = FString::Printf(TEXT("%d.%d"), OV_SESSION_MESSAGE_MAJOR_VERSION, OV_SESSION_MESSAGE_MINOR_VERSION);
			Message.content.Add(SessionManagement, {session_message_version,  GetMessageType(MessageType)});
		}
		else
		{
			Message.message_type = GetMessageType(MessageType);
		}
		SendMessage(Message);
	}

	const FString& GetPath() const { return ChannelPath; }

private:
	static FString GetMessageType(EOmniverseMessageType MessageType)
	{
		switch(MessageType)
		{
		case EOmniverseMessageType::UserJoin: return UserJoin;
		case EOmniverseMessageType::UserHello: return UserHello;
		case EOmniverseMessageType::UserLeft: return UserLeft;
		case EOmniverseMessageType::UserGetUsers: return UserGetUsers;
		case EOmniverseMessageType::MergeStarted: return MergeStarted;
		case EOmniverseMessageType::MergeFinished: return MergeFinished;
		case EOmniverseMessageType::UserMessage: return UserMessage;
		default: return InvalidType;
		}
	}

	static EOmniverseMessageType GetMessageType(const FString& MessageType)
	{
		if (MessageType == UserJoin)
		{
			return EOmniverseMessageType::UserJoin;
		}
		else if (MessageType == UserHello)
		{
			return EOmniverseMessageType::UserHello;
		}
		else if (MessageType == UserLeft)
		{
			return EOmniverseMessageType::UserLeft;
		}
		else if (MessageType == UserGetUsers)
		{
			return EOmniverseMessageType::UserGetUsers;
		}
		else if (MessageType == UserMessage)
		{
			return EOmniverseMessageType::UserMessage;
		}
		else if (MessageType == MergeStarted)
		{
			return EOmniverseMessageType::MergeStarted;
		}		
		else if (MessageType == MergeFinished)
		{
			return EOmniverseMessageType::MergeFinished;
		}

		return EOmniverseMessageType::Unknown;
	}

	static bool ParseResponse(const FOmniverseJoinChannelResult& Result, FOmniverseMessage& Message)
	{
		if (!Result.Content || Result.Content->Size() == 0)
		{
			return false;
		}

		bool ValidFormat = false;
		if (Result.Content->Size() > sizeof(FOmniverseMessageHeader))
		{
			const FOmniverseMessageHeader* Header = reinterpret_cast<FOmniverseMessageHeader*>(Result.Content->GetData());
			ValidFormat = (Header->Id == *reinterpret_cast<const uint64*>(MESSAGE_HEADER));
		}

		if (ValidFormat)
		{
			const uint8_t* Data = Result.Content->GetData();
			Data += sizeof(FOmniverseMessageHeader);
			TArray<uint8> Content(Data, Result.Content->Size() - sizeof(FOmniverseMessageHeader));
			Content.Add(0);
			FString JsonStr(UTF8_TO_TCHAR(Content.GetData()));
			return (FJsonObjectConverter::JsonObjectStringToUStruct(JsonStr, &Message, 0, 0));
		}

		return false;
	}
	
	FString ChannelPath;

	FString ChannelServer;

	FString ChannelUserName;

	FOmniverseJoinChannelCallback ListenChannelCallback;

	TSharedOmniverseAyncTask ListenTask;
	TSharedOmniverseAyncTask MessageTask;
};

static TSharedPtr<FOmniverseCollaboration> OmniverseCollaborationInstance = nullptr;
TSharedRef<IOmniverseCollaboration> IOmniverseCollaboration::Get()
{
	return FOmniverseCollaboration::Get();
}

TSharedRef<FOmniverseCollaboration> FOmniverseCollaboration::Get()
{
	if (!OmniverseCollaborationInstance)
	{
		OmniverseCollaborationInstance = MakeShareable(new FOmniverseCollaboration());
	}

	return OmniverseCollaborationInstance.ToSharedRef();
}

FOmniverseCollaboration::FOmniverseCollaboration()
{
}

FOmniverseCollaboration::~FOmniverseCollaboration()
{
}

void FOmniverseCollaboration::StartListening()
{
	if (!ConnectionChanged.IsValid())
	{
		ConnectionChanged = IOmniverseRuntimeModule::Get().OnServerConnectionChanged.AddRaw(this,
			&FOmniverseCollaboration::OnConnectionChanged);
	}
}

void FOmniverseCollaboration::StopListening()
{
	if (ConnectionChanged.IsValid())
	{
		IOmniverseRuntimeModule::Get().OnServerConnectionChanged.Remove(ConnectionChanged);
		ConnectionChanged.Reset();
	}
}

void FOmniverseCollaboration::Subscribe(const FString & Channel)
{
	ListensingChannel = MakeShared<FOmniverseChannel>(Channel);
	ListensingChannel->StartListening();
	OnSubscribed.Broadcast();
}

void FOmniverseCollaboration::Unsubscribe()
{
	if (ListensingChannel)
	{
		ListensingChannel->StopListening();
		ListensingChannel.Reset();
		OnUnsubscribed.Broadcast();
	}
}

void FOmniverseCollaboration::SendMessage(const FOmniverseMessage& Message)
{
	if (ListensingChannel)
	{
		ListensingChannel->SendMessage(Message);
	}
}

void FOmniverseCollaboration::SendMessage(EOmniverseMessageType MessageType)
{
	if (ListensingChannel)
	{
		ListensingChannel->SendMessage(MessageType);
	}
}

void FOmniverseCollaboration::OnConnectionChanged(const FString& Server, EOmniverseServerConnectionChange ConnectionChange)
{
	if (ConnectionChange == EOmniverseServerConnectionChange::Connected)
	{
		StartListeningInternal();
	}
	else
	{
		StopListeningInternal();
	}
}

void FOmniverseCollaboration::StopListeningInternal()
{
	if (ListensingChannel)
	{
		FString ListeningText = FString::Printf(TEXT("Disconnect Channel %s..."), *ListensingChannel->GetPath());
		FScopedSlowTask ListeningTask(1.0f, FText::FromString(ListeningText));
		ListeningTask.MakeDialog(false);
		ListensingChannel->StopListening();
	}
}

void FOmniverseCollaboration::StartListeningInternal()
{
	if (ListensingChannel)
	{
		ListensingChannel->StartListening();
	}
}
