// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "IOmniverseRuntimeModule.h"
#include "OmniverseAutoSaver.h"
#include "OmniverseConnectionHelper.h"
#include <OmniClient.h>
#include <OmniUsdResolver.h>

class FOmniverseRuntimeModule : public IOmniverseRuntimeModule
{
public: // IModuleInterface
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

public: // IOmniverseRuntimeModule
	// Add server into watch list for listing
	virtual bool WatchServer(const FString& Server) override;

	virtual bool WatchServers(const TArray<FString>& Servers, bool bResetList = false) override;

	virtual void RemoveServer(const FString& Server) override;

	virtual const TArray<FOmniverseServer>& GetWatchList() const override;

	virtual void PingAndWait() override;

	virtual bool IsUpdatingUSD() override { return bIsUpdatingUSD;  }

	virtual void EnableDeveloperLog(bool bEnable) override;

	virtual void EnableLiveUpdate(bool bEnabled) override;

	virtual bool IsLiveUpdateEnabled() const override;

	virtual FString GetOmniClientVersion() const override;
	
	virtual FString GetOmniResolverVersion() const override;

	virtual FString GetUsdVersion() const override;

	virtual FString GetCheckpointComment() const override;

	virtual void SetCheckpointComment(const FString& Comment) override;

public: // FOmniverseRuntimeModule
	static FOmniverseRuntimeModule & Get() { return *Singleton; }

	void SetIsUpdatingUSD(bool b) { bIsUpdatingUSD = b; }

private:
	bool UpdateServerStatus(const FString& UserName, const FString& Server, EOmniverseServerConnectionChange Status, bool WatchIfNotExists);

	static void OmniConnectionStatusCallback(void* userData, const char* Url, OmniClientConnectionStatus Status);

	void OnGetServerInfoCallback(const FOmniverseGetServerInfoCallback& ServerInfoCallback);

	static FOmniverseRuntimeModule * Singleton;

	FDelegateHandle TickDelegateHandle;

	bool bIsUpdatingUSD = false;

	bool bLiveUpdateEnabled = false;

	static bool bEnableDeveloperLog;

	TUniquePtr<FOmniverseAutoSaver> OmniverseAutoSaver;

	TArray<FOmniverseServer> WatchServerList;
	FString CheckpointComment;

	void* nvCudartHandle;
	void* nvTextureToolsHandle;
};
