// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseRuntimeModule.h"

#include "Async/Async.h"
#include "HAL/Event.h"
#include "HAL/PlatformProcess.h"
#include "Engine/EngineBaseTypes.h"
#include "Interfaces/IPluginManager.h"
#include "Interfaces/IProjectManager.h"
#include "Misc/CoreDelegates.h"
#include "UObject/UObjectGlobals.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"

#include "OmniversePxr.h"
#include "OmniverseRuntimePrivate.h"
#include "OmniversePathHelper.h"
#include "OmniverseSettings.h"
#include "OmniverseAsset.h"
#include "OmniverseLayerDataSource.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseNotificationHelper.h"
#include "OmniverseMDLExporter.h"
#include "Misc/ScopedSlowTask.h"
#include "OmniverseCollaboration.h"
#include "UObject/UObjectGlobals.h"

DEFINE_LOG_CATEGORY(LogOmniverse);

FOmniverseRuntimeModule * FOmniverseRuntimeModule::Singleton;

bool FOmniverseRuntimeModule::bEnableDeveloperLog = false;

bool FOmniverseRuntimeModule::UpdateServerStatus(const FString& UserName, const FString & Server, EOmniverseServerConnectionChange Status, bool WatchIfNotExists)
{
	// We get reconnect loops so put a stop to that here (OM-26381)
	if (Status == EOmniverseServerConnectionChange::ConnectionError)
	{
		FString ServerURL("omniverse://");
		ServerURL.Append(Server);
		omniClientSignOut(TCHAR_TO_UTF8(*ServerURL));
	}

	bool Found = false;
	for (auto& ServerStatus : WatchServerList)
	{
		if (Server == ServerStatus.Address)
		{
			ServerStatus.Status = Status;
			ServerStatus.UserName = UserName;
			Found = true;
			break;
		}
	}

	if (!Found)
	{
		FOmniverseServer OmniverseServer = { Server, Status, UserName };
		WatchServerList.Add(OmniverseServer);
	}

	return true;
}

void FOmniverseRuntimeModule::OmniConnectionStatusCallback(void* userData, const char* Url, OmniClientConnectionStatus Status)
{
	// Extract server name only
	FString UrlCopy = Url;
	FString UserName;
	FString ServerUrl;
	FString AssetPath;
	FString Branch;
	FString Checkpoint;
	FOmniversePathHelper::SplitUrlPath(UrlCopy, UserName, ServerUrl, AssetPath, Branch, Checkpoint);

	switch (Status)
	{
	case eOmniClientConnectionStatus_Connecting:
		UE_LOG(LogOmniverse, Log, TEXT("Connecting server %s..."), ANSI_TO_TCHAR(Url));
		AsyncTask(ENamedThreads::GameThread, [UserName, ServerUrl]() {
			FOmniverseRuntimeModule::Get().UpdateServerStatus(UserName, ServerUrl, EOmniverseServerConnectionChange::Connecting, false);
			FOmniverseRuntimeModule::Get().OnServerConnectionChanged.Broadcast(ServerUrl, EOmniverseServerConnectionChange::Connecting);
		});
		break;
	case eOmniClientConnectionStatus_Connected: // Successfully connected
		UE_LOG(LogOmniverse, Log, TEXT("Connect to server %s successfully..."), ANSI_TO_TCHAR(Url));
		AsyncTask(ENamedThreads::GameThread, [UrlCopy, UserName, ServerUrl]() {
			FOmniverseGetServerInfoCallback GetServerInfoCallback = FOmniverseGetServerInfoCallback::CreateLambda([UserName, ServerUrl](const FOmniverseGetServerInfoResult& Result)
				{
					if (Result.Status == eOmniClientResult_Ok)
					{
						FOmniverseRuntimeModule::Get().UpdateServerStatus(Result.UserName, ServerUrl, EOmniverseServerConnectionChange::Connected, false);
						FOmniverseRuntimeModule::Get().OnServerConnectionChanged.Broadcast(ServerUrl, EOmniverseServerConnectionChange::Connected);
					}
					else
					{
						FOmniverseRuntimeModule::Get().UpdateServerStatus(UserName, ServerUrl, EOmniverseServerConnectionChange::ConnectionError, false);
						FOmniverseRuntimeModule::Get().OnServerConnectionChanged.Broadcast(ServerUrl, EOmniverseServerConnectionChange::ConnectionError);
					}
				});

			FOmniverseConnectionHelper::GetServerInfo(UrlCopy, GetServerInfoCallback);
		});
		break;
	case eOmniClientConnectionStatus_ConnectError: // Error trying to connect (will attempt reconnection)
		UE_LOG(LogOmniverse, Log, TEXT("Connect to server %s failed..."), ANSI_TO_TCHAR(Url));
		AsyncTask(ENamedThreads::GameThread, [UserName, ServerUrl]() {
			FOmniverseRuntimeModule::Get().UpdateServerStatus(UserName, ServerUrl, EOmniverseServerConnectionChange::ConnectionError, false);
			FOmniverseRuntimeModule::Get().OnServerConnectionChanged.Broadcast(ServerUrl, EOmniverseServerConnectionChange::ConnectionError);
		});
		break;
	case eOmniClientConnectionStatus_Disconnected:
		UE_LOG(LogOmniverse, Log, TEXT("Disconnect from server %s..."), *ServerUrl);
		AsyncTask(ENamedThreads::GameThread, [UserName, ServerUrl]() {
			FOmniverseRuntimeModule::Get().UpdateServerStatus(UserName, ServerUrl, EOmniverseServerConnectionChange::Disconnected, false);
			FOmniverseRuntimeModule::Get().OnServerConnectionChanged.Broadcast(ServerUrl, EOmniverseServerConnectionChange::Disconnected);
		});
		break;
	default:
		break;
	}
}

void FOmniverseRuntimeModule::OnGetServerInfoCallback(const FOmniverseGetServerInfoCallback& ServerInfoCallback)
{
}

void FOmniverseRuntimeModule::StartupModule()
{
	Singleton = this;

	bEnableDeveloperLog = GetDefault<UOmniverseSettings>()->bOpenDeveloperLog;

	auto LogCallback = [](const char* ThreadName, const char* Component, OmniClientLogLevel ClientLogLevel, const char* Message)
	{
		if (FOmniverseRuntimeModule::bEnableDeveloperLog)
		{
			const char* LevelString = omniClientGetLogLevelString(ClientLogLevel);
			UE_LOG(LogOmniverse, Log, TEXT("%s: %s: %s: %s"), ANSI_TO_TCHAR(ThreadName), ANSI_TO_TCHAR(Component),
				ANSI_TO_TCHAR(LevelString), ANSI_TO_TCHAR(Message));
		}
	};
	omniClientSetLogLevel(eOmniClientLogLevel_Debug);
	omniClientSetLogCallback(LogCallback);
	omniClientRegisterConnectionStatusCallback(nullptr, OmniConnectionStatusCallback);
	if (!omniClientInitialize(kOmniClientVersion))
	{
		UE_LOG(LogOmniverse, Error, TEXT("Omniverse Client Initialization Failed!"))
	}
	auto Settings = GetDefault<UOmniverseSettings>();

	UOmniverseAsset::RegisterConnectionListener();

	IOmniverseLayerDataSource::Init();

	FOmniverseConnectionHelper::Init();

	FOmniverseMDLExporter::Init();

#if WITH_EDITOR
	FOmniverseCollaboration::Get()->StartListening();
#endif

	OmniverseAutoSaver.Reset(new FOmniverseAutoSaver());

	WatchServers(Settings->WatchServers);

	TickDelegateHandle = FCoreDelegates::OnBeginFrame.AddLambda(
		[]()
		{
			{
				DECLARE_SCOPE_CYCLE_COUNTER(TEXT("OmniUsdPluginProcessUpdates"), STAT_OmniUsdPluginProcessUpdates, STATGROUP_Omniverse);
				FOmniverseRuntimeModule::Get().SetIsUpdatingUSD(true);
				FOmniverseConnectionHelper::LiveUpdate();
				FOmniverseRuntimeModule::Get().SetIsUpdatingUSD(false);
			}
		}
	);

#if PLATFORM_WINDOWS && PLATFORM_64BITS
	const FString BaseDir = IPluginManager::Get().FindPlugin("Omniverse")->GetBaseDir() / "ThirdParty";
	nvCudartHandle = FPlatformProcess::GetDllHandle(*(BaseDir / "nvtt/win64_release/cudart64_110.dll"));
	nvTextureToolsHandle = FPlatformProcess::GetDllHandle(*(BaseDir / "nvtt/win64_release/nvtt30106.dll"));
#endif
}

void FOmniverseRuntimeModule::ShutdownModule()
{
#if PLATFORM_WINDOWS && PLATFORM_64BITS	
	FPlatformProcess::FreeDllHandle(nvTextureToolsHandle);
	FPlatformProcess::FreeDllHandle(nvCudartHandle);
	nvTextureToolsHandle = nullptr;
	nvCudartHandle = nullptr;
#endif

#if WITH_EDITOR
	FOmniverseCollaboration::Get()->StopListening();
#endif

	FOmniverseMDLExporter::Shutdown();
	FOmniverseConnectionHelper::Shutdown();

	FCoreDelegates::OnBeginFrame.Remove(TickDelegateHandle);
	omniClientLiveWaitForPendingUpdates();
	omniClientShutdown();

	FTaskGraphInterface::Get().ProcessThreadUntilIdle(ENamedThreads::GameThread);

	IOmniverseLayerDataSource::Shutdown();

	Singleton = nullptr;
}

bool FOmniverseRuntimeModule::WatchServer(const FString & Server)
{
	return WatchServers({ Server });
}

bool FOmniverseRuntimeModule::WatchServers(const TArray<FString>& Servers, bool bResetList)
{

	bool bChanged = false;
	TArray<FOmniverseServer> NewWatchServerList;

	// Sometimes the entire list is updated and we need to remove things from the list
	if (bResetList && Servers.Num() == 0 && WatchServerList.Num() > 0)
	{
		bChanged = true;
	}

	for (auto Server : Servers)
	{
		int32 Position = Server.Find(TEXT(":"));
		if (Position != INDEX_NONE)
		{
			Server = Server.Left(Position);
		}

		bool Found = false;
		for (auto& ServerStatus : WatchServerList)
		{
			if (Server == ServerStatus.Address)
			{
				Found = true;
				break;
			}
		}

		if (!Found)
		{
			FOmniverseServer OmniverseServer = { Server, EOmniverseServerConnectionChange::Disconnected, "" };
			if (bResetList)
			{
				NewWatchServerList.Add(OmniverseServer);
			}
			else
			{
				WatchServerList.Add(OmniverseServer);
			}
			bChanged = true;
				
			// attempt a connect/reconnect
			FString ServerURL("omniverse://");
			ServerURL.Append(Server);
			omniClientReconnect(TCHAR_TO_UTF8(*ServerURL));
		}
	}
	if (bResetList)
	{
		WatchServerList = NewWatchServerList;
	}

	if (bChanged)
	{
		OnServerWatchListChanged.Broadcast();
	}

	return bChanged;
}

void FOmniverseRuntimeModule::RemoveServer(const FString& Server)
{
	size_t FoundIndex = -1;
	for (size_t i = 0; i < WatchServerList.Num(); i++)
	{
		if (Server == WatchServerList[i].Address)
		{
			FoundIndex = i;
		}
	}

	if (FoundIndex != -1)
	{
		WatchServerList.RemoveAt(FoundIndex);
	}

	// We can't just search here, sometimes the settings servers have ports
	const TArray<FString>& SettingsWatchServers = GetDefault<UOmniverseSettings>()->WatchServers;
	for (int32 i = 0; i < SettingsWatchServers.Num(); i++)
	{
		FString SettingsServer = SettingsWatchServers[i];
		int32 Position = Server.Find(TEXT(":"));
		if (Position != INDEX_NONE)
		{
			SettingsServer = SettingsServer.Left(Position);
		}
		if (Server == SettingsServer)
		{
			auto OmniSettings = GetMutableDefault<UOmniverseSettings>();
			OmniSettings->WatchServers.RemoveAt(i);
			OmniSettings->TryUpdateDefaultConfigFile();
			break;
		}
	}

	FString ServerURL("omniverse://");
	ServerURL.Append(Server);
	omniClientSignOut(TCHAR_TO_UTF8(*ServerURL));

	OnServerWatchListChanged.Broadcast();
}

const TArray<FOmniverseServer>& FOmniverseRuntimeModule::GetWatchList() const
{
	return WatchServerList;
}

void FOmniverseRuntimeModule::PingAndWait()
{
	omniClientLiveWaitForPendingUpdates();
}

void FOmniverseRuntimeModule::EnableDeveloperLog(bool bEnable)
{
	bEnableDeveloperLog = bEnable;
}

void FOmniverseRuntimeModule::EnableLiveUpdate(bool bEnabled)
{
	bLiveUpdateEnabled = bEnabled;
	// TODO live
}

bool FOmniverseRuntimeModule::IsLiveUpdateEnabled() const
{
	return bLiveUpdateEnabled;
}

FString FOmniverseRuntimeModule::GetOmniClientVersion() const
{
	return FString(omniClientGetVersionString());
}

FString FOmniverseRuntimeModule::GetOmniResolverVersion() const
{
	return FString(omniUsdResolverGetVersionString());
}

FString FOmniverseRuntimeModule::GetUsdVersion() const
{
	return FString::Printf(TEXT("%i.%i"), PXR_MINOR_VERSION, PXR_PATCH_VERSION);
}

FString FOmniverseRuntimeModule::GetCheckpointComment() const
{
	return CheckpointComment;
}

void FOmniverseRuntimeModule::SetCheckpointComment(const FString& Comment)
{
	CheckpointComment = Comment;
}

IMPLEMENT_MODULE(FOmniverseRuntimeModule, OmniverseRuntime)
