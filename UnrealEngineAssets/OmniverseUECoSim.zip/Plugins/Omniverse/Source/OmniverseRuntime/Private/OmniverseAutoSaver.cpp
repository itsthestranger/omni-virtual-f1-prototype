// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseAutoSaver.h"
#include "Misc/Paths.h"
#include "UObject/UObjectGlobals.h"
#include "UObject/Package.h"
#include "UObject/ObjectSaveContext.h"
#include "OmniverseAsset.h"
#include "OmniversePathHelper.h"

DEFINE_LOG_CATEGORY_STATIC(OmniverseAutoSaver, Log, All);

FOmniverseAutoSaver::FOmniverseAutoSaver()
{
	// Register for the "MarkPackageDirty" callback to catch packages that have been modified and need to be saved
	UPackage::PackageMarkedDirtyEvent.AddRaw(this, &FOmniverseAutoSaver::OnMarkPackageDirty);

	// Register for the package modified callback to catch packages that have been saved
	UPackage::PackageSavedWithContextEvent.AddRaw(this, &FOmniverseAutoSaver::OnPackageSaved);
}

FOmniverseAutoSaver::~FOmniverseAutoSaver()
{
	UPackage::PackageMarkedDirtyEvent.RemoveAll(this);
	UPackage::PackageSavedWithContextEvent.RemoveAll(this);
}

void FOmniverseAutoSaver::OnMarkPackageDirty(UPackage* Pkg, bool bWasDirty)
{
	UpdateDirtyListsForPackage(Pkg);
}

void FOmniverseAutoSaver::OnPackageSaved(const FString& PackageFileName, UPackage* Package,
	FObjectPostSaveContext ObjectSaveContext)
{
	if (Package == nullptr)
	{
		return;
	}

	const FString AutoSaveDir = FPaths::ProjectSavedDir() / TEXT("Autosaves");

	if (PackageFileName.StartsWith(AutoSaveDir))
	{
		return;
	}

	if(!UOmniverseAsset::bSavingCache && Package->GetName().StartsWith(OMNIVERSE_FOLDER))
	{
		//UE_LOG(OmniverseAutoSaver, Log, TEXT("%s"), *Pkg->GetName());
		if (DirtyOmniContentForUpload.Find(Package))
		{
			FString Path, Name, Ext;
			FPaths::Split(Package->GetName(), Path, Name, Ext);

			UOmniverseAsset* OmniAsset = FindObject<UOmniverseAsset>(Package, *(Name));

			if(OmniAsset)
			{
				OmniAsset->PostSave();
			}
		}
	}

	UpdateDirtyListsForPackage(Package);
}

void FOmniverseAutoSaver::UpdateDirtyListsForPackage(UPackage* Pkg)
{
	const UPackage* TransientPackage = GetTransientPackage();

	// Don't auto-save the transient package or packages with the transient flag.
	if ( Pkg == TransientPackage || Pkg->HasAnyFlags(RF_Transient) || Pkg->HasAnyPackageFlags(PKG_CompiledIn) )
	{
		return;
	}

	if(Pkg->GetName().StartsWith(OMNIVERSE_FOLDER))
	{
		if ( Pkg->IsDirty() )
		{
			DirtyOmniContentForUpload.Add(Pkg);
		}
		else
		{
			DirtyOmniContentForUpload.Remove(Pkg);
		}
	}
}

