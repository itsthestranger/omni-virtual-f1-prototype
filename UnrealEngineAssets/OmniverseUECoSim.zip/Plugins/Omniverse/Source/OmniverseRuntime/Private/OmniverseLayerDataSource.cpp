// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseLayerDataSource.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Misc/CoreDelegates.h"
#include "OmniverseRuntimePrivate.h"
#if WITH_EDITOR
#include "Editor.h"
#endif

static TSharedPtr<IOmniverseLayerDataSource> CurrentLayerDataSource = nullptr;
static IOmniverseLayerDataSource::FOnLayerDataSourceChanged LayerDataSourceChanged;
static FDelegateHandle DelegateHandleRefresh;
static FDelegateHandle DelegateActorCreated;
static FDelegateHandle DelegateActorDestroyed;
static FDelegateHandle DelegateActorLabelChanged;
static FDelegateHandle DelegateEnginePostInit;
#if WITH_EDITOR
static FDelegateHandle DelegateMapOpened;
#endif

TMap<FString, FString> IOmniverseLayerDataSource::ActorNameLabelMap;
void IOmniverseLayerDataSource::SetCurrentLayerDataSource(const TSharedPtr<IOmniverseLayerDataSource>& DataSource)
{
	CurrentLayerDataSource = DataSource;
	if (!DelegateHandleRefresh.IsValid())
	{
		DelegateHandleRefresh = FCoreDelegates::OnEndFrame.AddLambda([]()
		{
			LayerDataSourceChanged.Broadcast(CurrentLayerDataSource);
			FCoreDelegates::OnEndFrame.Remove(DelegateHandleRefresh);
			DelegateHandleRefresh.Reset();
		});
	}
}

TSharedPtr<IOmniverseLayerDataSource> IOmniverseLayerDataSource::GetCurrentLayerDataSource()
{
	return CurrentLayerDataSource;
}

IOmniverseLayerDataSource::FOnLayerDataSourceChanged & IOmniverseLayerDataSource::OnLayerDataSourceChanged()
{
	return LayerDataSourceChanged;
}

void IOmniverseLayerDataSource::Init()
{
#if	WITH_EDITOR
	if (!DelegateEnginePostInit.IsValid())
	{
		DelegateEnginePostInit = FCoreDelegates::OnPostEngineInit.AddLambda([]()
		{

			if (!DelegateMapOpened.IsValid())
			{
				DelegateMapOpened = FEditorDelegates::OnMapOpened.AddLambda([](const FString& FileName, bool bAsTemplate)
				{
					ActorNameLabelMap.Empty();

					for (TObjectIterator<AActor> ActorIter; ActorIter; ++ActorIter)
					{
						auto Actor = *ActorIter;
						if (Actor)
						{
							ActorNameLabelMap.Add(Actor->GetName(), Actor->GetActorLabel());
						}
					}

					if (GEngine)
					{
						if (!DelegateActorCreated.IsValid())
						{
							DelegateActorCreated = GEngine->OnLevelActorAdded().AddLambda([](AActor * Actor)
							{
								ActorNameLabelMap.Add(Actor->GetName(), Actor->GetActorLabel());
							});
						}

						if (!DelegateActorDestroyed.IsValid())
						{
							DelegateActorDestroyed = GEngine->OnLevelActorDeleted().AddLambda([](AActor * Actor)
							{
								ActorNameLabelMap.Remove(Actor->GetName());
							});
						}
					}

				});
			}
		});
	}

	if (!DelegateActorLabelChanged.IsValid())
	{
		DelegateActorLabelChanged = FCoreDelegates::OnActorLabelChanged.AddLambda([](AActor * Actor)
		{
			ActorNameLabelMap.Add(Actor->GetName(), Actor->GetActorLabel());
		});
	}
#endif
}

void IOmniverseLayerDataSource::Shutdown()
{
	FCoreDelegates::OnPostEngineInit.Remove(DelegateEnginePostInit);
	DelegateActorCreated.Reset();
	DelegateActorDestroyed.Reset();
	FCoreDelegates::OnActorLabelChanged.Remove(DelegateActorLabelChanged);
	FCoreDelegates::OnEndFrame.Remove(DelegateHandleRefresh);
	DelegateHandleRefresh.Reset();
#if	WITH_EDITOR
	FEditorDelegates::OnMapOpened.Remove(DelegateMapOpened);
	DelegateMapOpened.Reset();
#endif
	ActorNameLabelMap.Empty();
}

void IOmniverseLayerDataSource::CleanupIfEquals(const TSharedPtr<IOmniverseLayerDataSource>& DataSource)
{
	if (DataSource == CurrentLayerDataSource)
	{
		CurrentLayerDataSource = nullptr;
		LayerDataSourceChanged.Broadcast(CurrentLayerDataSource);
		FCoreDelegates::OnEndFrame.Remove(DelegateHandleRefresh);
		DelegateHandleRefresh.Reset();
	}
}
