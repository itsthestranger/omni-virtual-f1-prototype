// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseAsset.h"
#include "Async/Async.h"
#include "Misc/Paths.h"
#include "Misc/ScopedSlowTask.h"
#include "Misc/SecureHash.h"
#include "Misc/GUID.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Interfaces/Interface_AssetUserData.h"
#include "UObject/UObjectIterator.h"
#include "UObject/UObjectHash.h"
#include "GenericPlatform/GenericPlatformHttp.h"
#include "UObject/SavePackage.h"
#if WITH_EDITOR
#include "FileHelpers.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Editor/EditorEngine.h"
#include "Settings/EditorLoadingSavingSettings.h"
#endif
#include "OmniverseRuntimeModule.h"
#include "OmniverseRuntimePrivate.h"
#include "OmniverseAssetUserData.h"
#include "OmniverseConnectionHelper.h"
#include "OmniversePathHelper.h"
#include "OmniverseNotificationHelper.h"

bool OMNIVERSERUNTIME_API GListingAssetsForEditor = false;
OMNIVERSERUNTIME_API const FString OmniverseContentFolder(OMNIVERSE_FOLDER);

bool UOmniverseAsset::bSavingCache = false;

UOmniverseAsset::UOmniverseAsset()
{
	OnUpdated.AddLambda([this]() {AssetUpdated.Broadcast(); });
	OmniReadDelegate.BindUObject(this, &UOmniverseAsset::OmniReadCallback);
	OmniListDelegate.BindUObject(this, &UOmniverseAsset::OmniListCallback);
	OmniSubscribeDelegate.BindUObject(this, &UOmniverseAsset::OmniSubscribeCallback);
	OmniListCheckpointDelegate.BindUObject(this, &UOmniverseAsset::OmniListCheckpointCallback);
}

UOmniverseAsset::~UOmniverseAsset()
{
	OmniReadDelegate.Unbind();
	OmniListDelegate.Unbind();
	OmniSubscribeDelegate.Unbind();
	OmniListCheckpointDelegate.Unbind();
}

const FString & UOmniverseAsset::GetPackagePath() const
{
	if (PackagePath.Len() == 0)
	{
		FOmniversePathHelper::ConvertOmniPath(OmniPath, PackagePath, AssetName, Extension);
	}

	return PackagePath;
}

const FString & UOmniverseAsset::GetAssetName() const
{
	if (AssetName.Len() == 0)
	{
		FOmniversePathHelper::ConvertOmniPath(OmniPath, PackagePath, AssetName, Extension);
	}

	return AssetName;
}

const FString & UOmniverseAsset::GetAssetExtension() const
{
	if (Extension.Len() == 0)
	{
		FOmniversePathHelper::ConvertOmniPath(OmniPath, PackagePath, AssetName, Extension);
	}

	return Extension;
}

#if WITH_EDITORONLY_DATA
void UOmniverseAsset::GetAssetRegistryTags(TArray<FAssetRegistryTag>& OutTags) const
{
	OutTags.Add( FAssetRegistryTag("Omniverse Path", OmniPath, FAssetRegistryTag::TT_Alphabetical));
	Super::GetAssetRegistryTags(OutTags);
}
#endif

void UOmniverseAsset::RegisterConnectionListener()
{
	FOmniverseRuntimeModule::Get().OnServerConnectionChanged.AddLambda(
		[](const FString& Server, EOmniverseServerConnectionChange ConnectionChange)
		{
			if (ConnectionChange == EOmniverseServerConnectionChange::Connecting)
			{
				return;
			}
			if (ConnectionChange == EOmniverseServerConnectionChange::Connected)
			{
				for (TObjectIterator<UOmniverseAsset> ObjItr; ObjItr; ++ObjItr)
				{
					const FString& AssetServer = ObjItr->GetAssetServer();
					if (AssetServer == Server)
					{
						ObjItr->Load();
					}
				}
			}
			else
			{
				for (TObjectIterator<UOmniverseAsset> ObjItr; ObjItr; ++ObjItr)
				{
					const FString& AssetServer = ObjItr->GetAssetServer();
					if (AssetServer == Server)
					{
						ObjItr->StopSubscribe();
					}
				}
			}
		}
	);
}

void UOmniverseAsset::HandleMaxPathHyperlinkNavigate()
{
	FPlatformProcess::LaunchURL(TEXT("https://docs.microsoft.com/en-us/windows/win32/fileio/maximum-file-path-limitation?tabs=cmd#enable-long-paths-in-windows-10-version-1607-and-later"), nullptr, nullptr);
}

void UOmniverseAsset::ShowMaxPathNotification(const FString& InText)
{
	const FText NotificationText = FText::FromString(InText);
	FNotificationInfo Notification(NotificationText);
	Notification.bFireAndForget = true;
	Notification.bUseLargeFont = false;
	Notification.bUseSuccessFailIcons = false;
	Notification.bUseThrobber = false;
	Notification.ExpireDuration = 10.0f;
	Notification.Hyperlink = FSimpleDelegate::CreateStatic(&UOmniverseAsset::HandleMaxPathHyperlinkNavigate);
	Notification.HyperlinkText = FText::FromString(TEXT("Show Solution"));
	FSlateNotificationManager::Get().AddNotification(Notification);
}

UOmniverseAsset* UOmniverseAsset::LoadAsset(FString OmniPath, bool CreateIfNotFound)
{
	OmniPath = FOmniversePathHelper::UniformOmniPath(FGenericPlatformHttp::UrlDecode(OmniPath));

	FString PkgLongName, AssetName, Extension;
	FOmniversePathHelper::ConvertOmniPath(OmniPath, PkgLongName, AssetName, Extension);

	// Avoid a crash in CreatePackage() if package long name is not valid
	if(!FPackageName::IsValidLongPackageName(PkgLongName))
	{
		UE_LOG(LogOmniverse, Error, TEXT("Package path is invalid. PackagePath:%s, OmniPath:%s"), *PkgLongName, *OmniPath);

		return nullptr;
	}

	const int32 MaxPathLength = FPlatformMisc::GetMaxPathLength();
	const int32 ShortFileNameLen = 128;
	auto LongNameWarning = [&](const FString& InFileName)
	{
		const int32 FileNameLength = InFileName.Len();
		FString NotifyFileNameShortened(TEXT("..."));
		NotifyFileNameShortened.Append(InFileName.Mid(FileNameLength - ShortFileNameLen));
		FString WarningText = FString::Printf(TEXT("Couldn't save package, filename is too long (%d >= %d): %s"), FileNameLength, MaxPathLength, *InFileName);
		UE_LOG(LogOmniverse, Warning, TEXT("%s"), *WarningText);
		WarningText = FString::Printf(TEXT("Couldn't save package, filename is too long (%d >= %d): %s"), FileNameLength, MaxPathLength, *NotifyFileNameShortened);
		ShowMaxPathNotification(WarningText);
	};

	// Avoid a crash in saving the file if the file-on-disk name is too long
	const FString FileName = FPackageName::LongPackageNameToFilename(PkgLongName, FString(TEXT(".uasset")));
	if (FileName.Len() >= MaxPathLength)
	{
		LongNameWarning(FileName);
		return nullptr;
	}

	const FString FullFilename = FPaths::ConvertRelativePathToFull(FileName);
	if (FullFilename.Len() >= MaxPathLength)
	{
		LongNameWarning(FullFilename);
		return nullptr;
	}

	// Return existing object
	UPackage* Pkg = CreatePackage(*PkgLongName);
	Pkg->FullyLoad();

	if(auto OmniAsset = StaticCast<UOmniverseAsset*>(FindObjectWithOuter(Pkg, UOmniverseAsset::StaticClass())))
	{
		// Return valid asset
		if(IsValidChecked(OmniAsset) && !OmniAsset->IsUnreachable())
		{
			OmniAsset->SetFlags(EObjectFlags::RF_Public);

			if (!GListingAssetsForEditor && OmniAsset->IsAsset())
			{
				OmniAsset->Load();
			}

			return OmniAsset;
		}
	}

	if (!CreateIfNotFound)
	{
		return nullptr;
	}

	// Find asset type
	TArray<UClass*> OmniAssetClasses;
	GetDerivedClasses(StaticClass(), OmniAssetClasses, true);

	auto FoundClass = OmniAssetClasses.FindByPredicate(
		[&](UClass* Class)
		{
			auto OmniAsset = GetDefault<UOmniverseAsset>(Class);
			auto TypeList = OmniAsset->GetFileTypes();

			auto FoundType = TypeList.FindByPredicate(
				[&](const FString& Type)
				{
					return Extension.Compare(Type, ESearchCase::IgnoreCase) == 0;
				}
			);

			return FoundType;
		}
	);

	if(!FoundClass)
	{
		return nullptr;
	}

	// Create asset and load
	auto OmniAsset = NewObject<UOmniverseAsset>(Pkg, *FoundClass, *AssetName);

	OmniAsset->OmniPath = OmniPath;
	OmniAsset->PackagePath = PkgLongName;
	// check mount
	FOmniverseListFileResult Result;
	if (FOmniverseConnectionHelper::ListFileSync(OmniPath, Result))
	{
		OmniAsset->bIsMount = Result.ListItem.Flags & fOmniClientItem_IsMount || Result.ListItem.Flags & fOmniClientItem_IsInsideMount;
		OmniAsset->bIsWritable = Result.ListItem.Access & fOmniClientAccess_Write;
	}

	OmniAsset->CreateUnrealAsset();

	if(!GListingAssetsForEditor /*|| (*FoundClass)->HasMetaData("OmniListingNeedsLoading")*/)
	{
		OmniAsset->Load();
	}

	// Must save to disk after creating new omniverse asset
	// Fix after the textures were broken during downloading, the textures will be missing from the omniverse material 
	OmniAsset->SaveToDisk();

	return OmniAsset;
}

UOmniverseAsset * UOmniverseAsset::GetOmniverseAssetScript(UObject * Object)
{
	if(Object)
	{
		return GetOmniverseAsset(*Object);
	}
	else
	{
		return nullptr;
	}
}

void UOmniverseAsset::StartSubscribe()
{
	if (ListSubscribeTask == nullptr)
	{
		ListSubscribeTask = FOmniverseConnectionHelper::ListFileSubscribe(OmniPath, OmniListDelegate, OmniSubscribeDelegate);
	}
}

void UOmniverseAsset::StopSubscribe()
{
	if (ListSubscribeTask)
	{
		bSubscribeStopped = true;
		ListSubscribeTask->Stop();
		ListSubscribeTask = nullptr;
	}
}

void UOmniverseAsset::LoadAssetScript(FString InOmniPath, UOmniverseAsset*& OmniAsset, UObject*& UE4Asset)
{
	OmniAsset = LoadAsset(InOmniPath);
	if(OmniAsset)
	{
		TArray<UObject*> Objects;
		GetObjectsWithOuter(OmniAsset->GetOuter(), Objects, false);

		for(UObject* Object : Objects)
		{
			if(Object->HasAllFlags(EObjectFlags::RF_Public))
			{
				UE4Asset = Object;
				break;
			}
		}
	}
}

UOmniverseAsset * UOmniverseAsset::GetOmniverseAsset(UObject& Object)
{
	auto OmniverseAsset = Cast<UOmniverseAsset>(&Object);
	if(OmniverseAsset)
	{
		return OmniverseAsset;
	}

	OmniverseAsset = Cast<UOmniverseAsset>(Object.GetOuter());
	if(OmniverseAsset)
	{
		return OmniverseAsset;
	}

	if(!Object.GetPathName().StartsWith(OmniverseContentFolder + "/"))
	{
		return nullptr;
	}

	return StaticCast<UOmniverseAsset*>(FindObjectWithOuter(Object.GetOuter(), StaticClass()));
}

bool UOmniverseAsset::IsAsset() const
{
	return false;
}

void UOmniverseAsset::PostLoad()
{
	Super::PostLoad();

	if(!GListingAssetsForEditor)
	{
		Load();
	}
}

void UOmniverseAsset::Load()
{
	if (bSubscribeStopped)
	{
		bSubscribeStopped = false;

		UE_LOG(LogOmniverse, Log, TEXT("Start asset downloading: %s"), *OmniPath);
		FOmniverseRuntimeModule::Get().OnAssetDownload.Broadcast(OmniPath, true);
		
		if (FOmniversePathHelper::IsOmniPath(OmniPath))
		{
			if (IsCheckpoint())
			{
				//FOmniverseConnectionHelper::ListCheckpointsAsync(OmniPath, OmniListCheckpointDelegate);
				FOmniverseConnectionHelper::ReadAsync(OmniPath, OmniReadDelegate);
			}
			else
			{
				StartSubscribe();
			}
		}
		else
		{
			FOmniverseConnectionHelper::ReadAsync(OmniPath, OmniReadDelegate);
		}
	}
}

void UOmniverseAsset::SaveToDisk() const
{
#if WITH_EDITOR
	UPackage* Package = GetPackage();
	FString FileName = FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension());
	FSavePackageArgs SaveArgs;
	SaveArgs.TopLevelFlags = RF_Standalone;
	SaveArgs.SaveFlags = SAVE_NoError;
	UPackage::SavePackage(Package, nullptr, *FileName, SaveArgs);
#endif
}

void UOmniverseAsset::CreateAssetUserData(UObject* Owner)
{
	if (IInterface_AssetUserData* AssetUserDataInterface = Cast<IInterface_AssetUserData>(Owner))
	{
		UOmniverseAssetUserData* UserData = NewObject<UOmniverseAssetUserData>(Owner, NAME_None);
		UserData->OmniAsset = this;
		AssetUserDataInterface->AddAssetUserData(UserData);
	}
}

void UOmniverseAsset::OmniReadCallback(const FOmniverseReadResult & ReadResult)
{
	FOmniverseRuntimeModule::Get().OnAssetDownload.Broadcast(GetOmniPath(), false);

	switch (ReadResult.Status)
	{
	case eOmniClientResult_Ok:
	case eOmniClientResult_OkLatest:
		break;
	default:	// Errors happen
		HandleError(ReadResult.Status);
		StopSubscribe();

		// Trigger callback
		OnUpdated.Broadcast();

		auto Package = Cast<UPackage>(GetOuter());
		if (Package && Package->GetName().StartsWith(OmniverseContentFolder + "/"))
		{
			TArray<UObject*> Objects;
			GetObjectsWithOuter(Package, Objects, false);

			for (auto Object : Objects)
			{
				Object->ClearFlags(EObjectFlags::RF_Standalone);
			}
		}

		// Stop reading
		bValidAsset = false;

		// Revert back version so it could be loaded next time again
		OmniReceivedLatestVersion = OmniVersion;

		return;
	}

	// For mount data, there is no version. Generate hash for versioning it.
	if (OmniReceivedLatestVersion.IsEmpty())
	{
		OmniReceivedLatestVersion = GenerateContentHash(ReadResult.Content);
	}

	// No update
	if (OmniReceivedLatestVersion == OmniVersion)
	{
		return;
	}

	OnRead(ReadResult.Content);

	// Save cache
	if (AllowAutoSavingEtag())
	{
		// Save ETag
		OmniVersion = OmniReceivedLatestVersion;
		bValidAsset = true;

		// Cache to disk
		FString Text = FString::Printf(TEXT("Saving Asset: %s..."), *OmniPath);
		FScopedSlowTask SavingAssetTask(1.0f, FText::FromString(Text));
		SavingAssetTask.MakeDialog(false);
		SavingAssetTask.EnterProgressFrame();

		SaveToDisk();
	}

	// Trigger event
	UE_LOG(LogOmniverse, Log, TEXT("Finished asset downloading: %s"), *GetOmniPath());
	if (!bDelayedTrigger)
	{
		OnUpdated.Broadcast();
	}
}

void UOmniverseAsset::OmniListCallback(const FOmniverseListFileResult& ListResult)
{
	if (ListResult.Status != eOmniClientResult_Ok && ListResult.Status != eOmniClientResult_OkLatest)
	{
		HandleError(ListResult.Status);
		StopSubscribe();
		return;
	}

	ReadVersion(ListResult.ListItem.Version);
}

void UOmniverseAsset::OmniSubscribeCallback(const FOmniverseSubscribeResult & SubscribeResult)
{
	if (SubscribeResult.Status != eOmniClientResult_Ok && SubscribeResult.Status != eOmniClientResult_OkLatest)
	{
		HandleError(SubscribeResult.Status);
		StopSubscribe();
		return;
	}

	if (OmniReceivedLatestVersion.IsEmpty() || OmniReceivedLatestVersion != SubscribeResult.ListItem.Version)
	{
		ReadVersion(SubscribeResult.ListItem.Version);
	}
}

void UOmniverseAsset::OmniListCheckpointCallback(const FOmniverseListCheckpointResult& ListCheckpointResult)
{
	// TODO
}

void UOmniverseAsset::ReadVersion(const FString & NewVersion)
{
	// Version does not match
	if (OmniReceivedLatestVersion.IsEmpty() || OmniReceivedLatestVersion != NewVersion)
	{
		OmniReceivedLatestVersion = NewVersion;
		UE_LOG(LogOmniverse, Log, TEXT("Start asset downloading: %s"), *OmniPath);
		FOmniverseRuntimeModule::Get().OnAssetDownload.Broadcast(OmniPath, true);
		FOmniverseConnectionHelper::ReadAsync(OmniPath, OmniReadDelegate);
	}
}

const FString & UOmniverseAsset::GetAssetPathOnServer() const
{
	if (AssetPathOnServer.Len() == 0)
	{
		FString UserName;
		FOmniversePathHelper::SplitUrlPath(OmniPath, UserName, OmniServer, AssetPathOnServer, Branch, Checkpoint);
	}

	return AssetPathOnServer;
}

const FString & UOmniverseAsset::GetAssetServer() const
{
	if (OmniServer.Len() == 0)
	{
		FString UserName;
		FOmniversePathHelper::SplitUrlPath(OmniPath, UserName, OmniServer, AssetPathOnServer, Branch, Checkpoint);
	}

	return OmniServer;
}

bool UOmniverseAsset::IsCheckpoint() const
{
	if (Checkpoint.IsEmpty())
	{
		FString UserName;
		FOmniversePathHelper::SplitUrlPath(OmniPath, UserName, OmniServer, AssetPathOnServer, Branch, Checkpoint);
	}

	return !Checkpoint.IsEmpty();
}

void UOmniverseAsset::PostSave()
{
}

void UOmniverseAsset::HandleError(OmniClientResult Status)
{
	// error switch
	switch (Status)
	{
	case eOmniClientResult_ErrorNotFound:
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Invalid Path, failed to find %s."), *OmniPath));
		break;
	case eOmniClientResult_ErrorBadVersion:
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Bad Version, failed to load %s."), *OmniPath));
		break;
	case eOmniClientResult_ErrorAccessDenied:
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Access Denied, failed to load %s."), *OmniPath));
		break;
	default:
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Unknown Error, failed to load %s."), *OmniPath));
		break;
	}
}

FString UOmniverseAsset::GenerateContentHash(const TSharedOmniContentPtr& Content)
{
	uint32 Hash[5];
	FSHA1::HashBuffer(Content->GetData(), Content->Size(), reinterpret_cast<uint8*>(Hash));
	auto OutLutGuid = FGuid(Hash[0] ^ Hash[4], Hash[1], Hash[2], Hash[3]);

	return OutLutGuid.ToString();
}

#if WITH_EDITOR



#endif