// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"

class FOmniverseAutoSaver
{
public:
	FOmniverseAutoSaver();
	~FOmniverseAutoSaver();

private:
	/**
	 * Called when a package is marked as dirty
	 *
	 * @param Pkg The package that was marked as dirty
	 * @param bWasDirty Whether the package was previously dirty before the call to MarkPackageDirty
	 */
	void OnMarkPackageDirty(UPackage* Pkg, bool bWasDirty);
	/**
	 * Called when a package has been saved
	 *
	 * @param PackageFileName The filename the package was saved to
	 * @param Package The package that was saved
	 */
	void OnPackageSaved(const FString& PackageFileName, class UPackage* Package,
	class FObjectPostSaveContext ObjectSaveContext);

	void UpdateDirtyListsForPackage(UPackage* Pkg);

	/** Packages that have been dirtied and not saved by the user */
	TSet<TWeakObjectPtr<UPackage>> DirtyOmniContentForUpload;
};
