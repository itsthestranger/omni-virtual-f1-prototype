// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseExportSettings.h"

FOmniverseExportTextureSettings::FOmniverseExportTextureSettings()
	: bTextureSource(false)
	, bDDSExport(false)
{
}

FOmniverseExportMaterialSettings::FOmniverseExportMaterialSettings()
	: bCopyTemplate(true)
	, bRayTracingTranslucency(false)
	, bRayTracingRefraction(true)
	, bExportTwoSidedSign(false)
{
}

FOmniverseExportCommandletSettings::FOmniverseExportCommandletSettings()
	: CommandletExportPath{"/Users/commandlet"}
{
}

FOmniverseExportSettings::FOmniverseExportSettings()
	: bModular(false)
	, bAsciiFormat(false)
	, bAddExtraExtension(false)
	, bMDL(true)
	, bPreviewSurface(false)
	, bExportAssetToSeperateUSD(true)
	, bExportPhysics(true)
	, bMeshInstanced(false)
	, bCustomLayer(true)
	, bExportInvisible(false)
	, bPayloads(false)
	, bExportSublayers(false)
	, bUpYAxis(false)
	, bExportDecalActors(false)
	, bMaterialOverSublayer(false)
	, bExportPreviewMesh(false)
	, bForceShared(false)
	, bExportLandscapeGrass(true)
	, bNanite(false)
	, bRootIdentity(false)
{
}