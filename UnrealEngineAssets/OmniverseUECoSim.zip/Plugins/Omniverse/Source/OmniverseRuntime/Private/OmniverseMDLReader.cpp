// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseMDLReader.h"
#include "OmniverseFileHandle.h"
#include "OmniverseRuntimePrivate.h"
#include "OmniverseConnectionHelper.h"
#include "OmniversePathHelper.h"
#include "Misc/Paths.h"
#include "HAL/PlatformFileManager.h"


bool FOmniverseMDLReader::FileExists(const FString& InPath, const FString& InMask)
{
	FString FullPath = InPath;
	FString* OutPath = nullptr;
	
	if (!InMask.IsEmpty())
	{
		FullPath = InPath / InMask;
		OutPath	= OmniDependencies.Find(InMask);
	}

	if (OutPath)
	{
		return (FullPath.Equals(*OutPath));
	}
	else
	{
		FOmniverseListFileResult FileResult;
		bool bFound = FOmniverseConnectionHelper::ListFileSync(FullPath, FileResult);

		if (bFound && !InMask.IsEmpty())
		{
			OmniDependencies.Add(InMask, FullPath);
		}

		return bFound;
	}
}

IFileHandle* FOmniverseMDLReader::OpenRead(const FString& InPath)
{
	TSharedOmniContentPtr Content;
	if (FOmniverseConnectionHelper::ReadSync(InPath, Content))
	{
		return new FOmniverseFileHandle(Content);
	}

	return nullptr;
}

bool FOmniverseMDLReader::GetOmniDependencies(TArray<FString> & OutOmniDependencies)
{
	if (OmniDependencies.Num() > 0)
	{
		OmniDependencies.GenerateValueArray(OutOmniDependencies);
		return true;
	}

	return false;
}

void FOmniverseMDLReader::ClearOmniDependencies()
{
	OmniDependencies.Reset();
}

