// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "DDSLoader.h"
THIRD_PARTY_INCLUDES_START
	#include "nvtt/nvtt.h"
THIRD_PARTY_INCLUDES_END


class FOmniverseDDSLoadHelper : public FDDSLoadHelper
{
public:
	/** @param Buffer must not be 0 */
	FOmniverseDDSLoadHelper(const uint8* Buffer, uint32 Length);

	uint32 ComputeMipMapSize(uint32 MipMap) const;
	uint32 GetDepth() const;
	uint32 GetBlockSize() const;
	nvtt::Format GetNVTTFormat() const;
	const uint8* GetData() const;
	bool LoadRawData(TArray64<uint8>& RawData);
};
