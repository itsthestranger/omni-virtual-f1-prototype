// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseMDL.h"
#include "Misc/Paths.h"
#include "Misc/ScopedSlowTask.h"
#include "UObject/UObjectHash.h"
#include "Interfaces/IPluginManager.h"
#include "HAL/Filemanager.h"

#if WITH_EDITOR
#include "MDLSettings.h"
#include "NodeArrangement.h"
#include "MDLModule.h"
#include "MDLImporter.h"
#include "MDLImporterUtility.h"
#include "MDLExporterUtility.h"

#include "AssetToolsModule.h"
#include "IMaterialEditor.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "MaterialEditorModule.h"
#include "EditorFramework/AssetImportData.h"
#endif

#include "Materials/Material.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialExpressionTextureBase.h"
#include "Materials/MaterialExpressionTextureObject.h"
#include "Materials/MaterialExpressionTextureObjectParameter.h"
#include "Materials/MaterialExpressionClearCoatNormalCustomOutput.h"
#include "Engine/TextureCube.h"

#include "OmniverseRuntimePrivate.h"
#include "OmniverseAssetUserData.h"
#include "OmniversePathHelper.h"
#include "OmniverseTexture.h"
#include "OmniverseSettings.h"
#include "OmniverseRuntimeModule.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseMDLHelper.h"
#include "OmniverseAssetExportHelper.h"
#include "OmniverseMDLReader.h"
#include "OmniverseNotificationHelper.h"
#include "OmniverseMessageLogContext.h"
#include "IOmniversePackageReader.h"
#include "OmniverseAssetImportData.h"
#include "OmniverseAssetImportHelper.h"

TMap<FString, FMDLParametersList> UOmniverseMDL::ImportedParametersSheet;

#if WITH_EDITOR
template <typename ReturnType, typename MDLType>
static ReturnType GetExpressionConstant(mi::base::Handle<mi::neuraylib::IExpression const> const& Expression)
{
	check(Expression->get_kind() == mi::neuraylib::IExpression::EK_CONSTANT);

	mi::base::Handle<mi::neuraylib::IValue const> const& Value = mi::base::make_handle(Expression.get_interface<mi::neuraylib::IExpression_constant const>()->get_value());
	check(Value.get_interface<MDLType const>());

	return Value.get_interface<MDLType const>()->get_value();
}

template <typename ReturnType, typename MDLType>
static TArray<ReturnType> GetExpressionConstant(mi::base::Handle<mi::neuraylib::IExpression_list const> ExpressionList)
{
	TArray<ReturnType> ReturnValues;
	for (mi::Size ExpressionListIndex = 0, ExpressionListSize = ExpressionList->get_size(); ExpressionListIndex < ExpressionListSize; ExpressionListIndex++)
	{
		ReturnValues.Add(GetExpressionConstant<ReturnType, MDLType>(mi::base::make_handle(ExpressionList->get_expression(ExpressionListIndex))));
	}
	return ReturnValues;
}

void CloseAssetEditor(UObject* Asset)
{
	auto* AssetEditor = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(Asset, false);
	if (AssetEditor)
	{
		GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->CloseAllEditorsForAsset(Asset);
	}
}

void RefreshMaterialEditor(UMaterialInterface* Interface)
{
	auto* MaterialEditor = (IMaterialEditor*)GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->FindEditorForAsset(Interface, false);
	if (MaterialEditor)
	{
		IMaterialEditorModule* MaterialEditorModule = &FModuleManager::LoadModuleChecked<IMaterialEditorModule>( "MaterialEditor" );
		if (MaterialEditorModule)
		{
			if(UMaterialInstance* Instance = Cast<UMaterialInstance>(Interface))
			{
				TSharedRef<IMaterialEditor> NewEditor = MaterialEditorModule->CreateMaterialInstanceEditor(EToolkitMode::Standalone, nullptr, Instance);
				GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->CloseOtherEditors(Interface, &NewEditor.Get());
			}
			else if(UMaterial* Material = Cast<UMaterial>(Interface))
			{
				TSharedRef<IMaterialEditor> NewEditor = MaterialEditorModule->CreateMaterialEditor(EToolkitMode::Standalone, nullptr, Material);
				GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->CloseOtherEditors(Interface, &NewEditor.Get());
			}
		}
	}
}
#endif

UOmniverseMDL::UOmniverseMDL()
{
	static bool bInitialized = false;
	if(!bInitialized)
	{
		bInitialized = true;
	}
}

template<typename T>
T * UOmniverseMDL::FindMaterial(FName Name)
{
	// Find material by name. 
	return StaticCast<T*>(FindObjectWithOuter(GetOuter(), T::StaticClass(), Name));
}

UMaterialInterface* UOmniverseMDL::FindMaterial(FName Name)
{
	UMaterialInterface* Material = FindMaterial<UMaterialInstanceConstant>(Name);
	if (Material == nullptr)
	{
		return FindMaterial<UMaterial>(Name);
	}

	return Material;
}

bool UOmniverseMDL::LoadModule()
{
	auto MDLPluginModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");
	auto AddExtraModule = [&](const FString& ProtocolName)
	{
		if (OmniPath.StartsWith(ProtocolName))
		{
			MDLPluginModule->AddModulePath(ProtocolName + GetAssetServer() + FString(TEXT("/")));
		}
	};

	if (FOmniversePathHelper::IsOmniPath(OmniPath))
	{
		AddExtraModule(TEXT("omniverse://"));
	}
	AddExtraModule(TEXT("https://"));
	AddExtraModule(TEXT("http://"));

	if (ModuleName.IsEmpty())
	{
		PrepareModuleName();
	}

	if (!MDLReader.IsValid())
	{
		MDLReader = MakeShareable<FOmniverseMDLReader>(new FOmniverseMDLReader());
	}
	MDLReader->ClearOmniDependencies();

	auto MDLModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");

	MDLModule->SetExternalFileReader(MDLReader);
	int32 Result = MDLModule->LoadModule(ModuleName);
	MDLModule->SetExternalFileReader(nullptr);

	return (Result >= 0);
}

void UOmniverseMDL::UnloadModule()
{
	if (ModuleName.IsEmpty())
	{
		PrepareModuleName();
	}
	auto MDLModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");
	MDLModule->RemoveModule(ModuleName);
	MDLModule->CommitAndCreateTransaction();

	auto MDLPluginModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");
	auto RemoveExtraModule = [&](const FString& ProtocolName)
	{
		if (OmniPath.StartsWith(ProtocolName))
		{
			MDLPluginModule->RemoveModulePath(ProtocolName + GetAssetServer() + FString(TEXT("/")));
		}
	};

	if (FOmniversePathHelper::IsOmniPath(OmniPath))
	{
		RemoveExtraModule(TEXT("omniverse://"));
	}
	RemoveExtraModule(TEXT("https://"));
	RemoveExtraModule(TEXT("http://"));
}

TArray<FString> UOmniverseMDL::GetFileTypes() const
{
	return {"mdl"};
}

#if WITH_EDITOR
void LoadTextureBySamplerType(TObjectPtr<class UTexture>& Texture, EMaterialSamplerType SamplerType)
{
	switch(SamplerType)
	{
	case SAMPLERTYPE_Grayscale:
		Texture = LoadObject<UTexture2D>(nullptr, TEXT("/MDL/Textures/DefaultGrayscale"), nullptr, LOAD_None, nullptr);
		break;
	case SAMPLERTYPE_Normal:
		Texture = LoadObject<UTexture2D>(nullptr, TEXT("/MDL/Textures/DefaultNormal"), nullptr, LOAD_None, nullptr);
		break;
	case SAMPLERTYPE_Masks:
		Texture = LoadObject<UTexture2D>(nullptr, TEXT("/MDL/Textures/DefaultMask"), nullptr, LOAD_None, nullptr);
		break;
	case SAMPLERTYPE_LinearColor:
		Texture = LoadObject<UTexture2D>(nullptr, TEXT("/MDL/Textures/DefaultLinearColor"), nullptr, LOAD_None, nullptr);
		break;
	case SAMPLERTYPE_LinearGrayscale:
		Texture = LoadObject<UTexture2D>(nullptr, TEXT("/MDL/Textures/DefaultLinearGrayscale"), nullptr, LOAD_None, nullptr);
		break;
	case SAMPLERTYPE_Color:
	default:
		Texture = LoadObject<UTexture2D>(nullptr, TEXT("/MDL/Textures/DefaultColor"), nullptr, LOAD_None, nullptr);
	}
}

void UOmniverseMDL::OverrideTextureSRGB(TWeakObjectPtr<class UMaterialInstanceConstant> MaterialInstancePtr, FString ParamName, bool SRGB)
{
	if (!MaterialInstancePtr.IsValid())
	{
		return;
	}

	UTexture* Texture = nullptr;
	if (MaterialInstancePtr->GetTextureParameterValue(*ParamName, Texture))
	{
		UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(Texture->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
		if (OmniverseAssetUserData)
		{
			UOmniverseTexture* OmniTexture = CastChecked<UOmniverseTexture>(OmniverseAssetUserData->OmniAsset);
			OmniTexture->OnImageUpdated.RemoveAll(this);

			if (Texture->SRGB != SRGB)
			{
				Texture->SRGB = SRGB;
				Texture->PostEditChange();
				Texture->MarkPackageDirty();
			}
		}

		UMaterial* Parent = MaterialInstancePtr->GetMaterial();

		if (Parent)
		{
			UOmniverseAssetUserData* AssetUserData = Cast<UOmniverseAssetUserData>(Parent->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
			if (AssetUserData)
			{
				UOmniverseMDL* BaseMDL = CastChecked<UOmniverseMDL>(AssetUserData->OmniAsset);

				if (BaseMDL->bValidAsset)
				{
					CorrectTextureSampler(MaterialInstancePtr, ParamName);
				}
				// not need, because base mdl is guaranteed to be loaded.
				else
				{
					BaseMDL->OnUpdated.AddUObject(this, &UOmniverseMDL::CorrectTextureSampler, MaterialInstancePtr, ParamName);
				}
			}
		}
	}
}

void UOmniverseMDL::CorrectTextureSampler(TWeakObjectPtr<class UMaterialInstanceConstant> MaterialInstancePtr, FString ParamName)
{
	if (!MaterialInstancePtr.IsValid())
	{
		return;
	}

	UTexture* SourceTexture = nullptr;
	UTexture* Texture = nullptr;
	UMaterial* Parent = MaterialInstancePtr->GetMaterial();

	bool bSamplerChanged = false;
	if (Parent && MaterialInstancePtr->GetTextureParameterValue(*ParamName, SourceTexture)
	&& Parent->GetTextureParameterValue(*ParamName, Texture))
	{
		if (Texture && Texture != SourceTexture 
			&& Texture->GetOuter()->GetName() == TEXT("/MDL/Textures/DefaultColor")
			&& (Texture->CompressionSettings != SourceTexture->CompressionSettings || Texture->SRGB != SourceTexture->SRGB))
		{
			EMaterialSamplerType SamplerType = UMaterialExpressionTextureBase::GetSamplerTypeForTexture(SourceTexture);

			for (auto Expression : Parent->GetExpressions())
			{
				if (Expression->IsA<UMaterialExpressionTextureObjectParameter>())
				{
					auto TextureExpression = Cast<UMaterialExpressionTextureObjectParameter>(Expression);
					if (TextureExpression->ParameterName.ToString() == ParamName)
					{
						if (TextureExpression->SamplerType != SamplerType)
						{
							TextureExpression->SamplerType = SamplerType;
							if (TextureExpression->SamplerType == SAMPLERTYPE_Normal)
							{
								ReplaceNormalTextureLookup(Parent->GetExpressions(), TextureExpression);
							}
							LoadTextureBySamplerType(TextureExpression->Texture, SamplerType);	
							bSamplerChanged = true;
						}
					}		
				}
			}
		}

		if (bSamplerChanged)
		{
			// The material might be compiled multiple times, it should be blocked until the former one was finished.
			//Parent->GetMaterialResource(GMaxRHIFeatureLevel)->FinishCompilation();
			Parent->PostEditChange();
			Parent->MarkPackageDirty();
			UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(Parent->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
			if (OmniverseAssetUserData)
			{
				UOmniverseMDL* BaseMDL = CastChecked<UOmniverseMDL>(OmniverseAssetUserData->OmniAsset);
				BaseMDL->SaveToDisk();
			}

			FMaterialUpdateContext UpdateContext;
			UpdateContext.AddMaterial(Parent);
		}
	}
}

void UOmniverseMDL::PrepareModuleName()
{
	const FString& Path = GetAssetPathOnServer();
	ModuleName = FPaths::GetPath(Path) / FPaths::GetBaseFilename(Path);
	ModuleName.ReplaceInline(TEXT("/"), TEXT("::"));
}

UOmniverseMDL* UOmniverseMDL::LoadMDLDependency(const FString& InMDLFile, bool bCreateIfNotFound)
{
	TArray<FString> OmniDependencies;
	if (MDLReader.IsValid() && MDLReader->GetOmniDependencies(OmniDependencies))
	{
		for (auto Name : OmniDependencies)
		{
			if (Name.Contains(InMDLFile))
			{
				Name = FOmniversePathHelper::ComputeAbsolutePath(OmniPath, Name);
				return UOmniverseAsset::LoadAsset<UOmniverseMDL>(Name, bCreateIfNotFound);
			}
		}
	}

	return nullptr;
}
#endif

void UOmniverseMDL::LoadMDL()
{
	TArray<FString> NotLoadedParents;
	struct MDLIdentifier
	{
		FString FilePath;
		FString MaterialName;
	};
	TMap<UMaterialInstanceConstant*, MDLIdentifier> DelayCoreMaterialLoadList;
#if WITH_EDITOR
	auto MDLPluginModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");
	{
		if (LoadModule())
		{
			mi::base::Handle<const mi::neuraylib::IModule> MDLModule = MDLPluginModule->GetLoadedModule(ModuleName);

			if (MDLModule.is_valid_interface())
			{
				const int32 Amount = 2 * MDLModule->get_material_count() + 1;
				FScopedSlowTask MDLLoadingTask(Amount, FText::FromString(GetDefault<UMDLSettings>()->bDistillation ? TEXT("Distilling MDL...") : TEXT("Compiling MDL...")));
				MDLLoadingTask.MakeDialog(false);

				TArray<FString> ValidMaterialNames;
				bool PackageClean = false;

				// Convert MDL to Unreal material
				for (auto MaterialIdx = 0; MaterialIdx < MDLModule->get_material_count(); ++MaterialIdx)
				{
					MDLLoadingTask.EnterProgressFrame();
					// Compile
					mi::base::Handle<const mi::neuraylib::IFunction_definition> MaterialDefinition = mi::base::make_handle(MDLPluginModule->GetTransaction()->access<mi::neuraylib::IFunction_definition>(MDLModule->get_material(MaterialIdx)));

					// Get prototype to check if preset
					FString Prototype = FMDLImporterUtility::GetPrototype(MDLModule->get_material(MaterialIdx));

					FString MDLHeader, SubMDL;
					FString(Prototype).Split("::", &MDLHeader, &SubMDL, ESearchCase::CaseSensitive, ESearchDir::FromStart);

					FString MaterialName = MDLModule->get_material(MaterialIdx);
					MaterialName = MaterialName.Left(MaterialName.Find(TEXT("(")));
					FString(MoveTemp(MaterialName)).Split("::", nullptr, &MaterialName, ESearchCase::CaseSensitive, ESearchDir::FromEnd);
					ValidMaterialNames.Add(MaterialName);

					if (!Prototype.IsEmpty() && !IsMDLLibrary(MDLHeader))
					{
						// Convert mdl path to Omni path
						FString BaseMaterialFile, BaseMaterialName;
						FString(Prototype).Split("::", &BaseMaterialFile, &BaseMaterialName, ESearchCase::CaseSensitive, ESearchDir::FromEnd);
						BaseMaterialFile.RemoveFromStart(TEXT("mdl"));
						BaseMaterialFile.ReplaceInline(TEXT("::"), TEXT("/"));

						auto MaterialInstance = Cast<UMaterialInstanceConstant>(FindMaterial(*MaterialName));
						// If can't find the material, the material name might be changed at mdl file
						// we created a new one and start package clean
						if (MaterialInstance == nullptr)
						{
							// check if there's a same name material in the path. that material might be created with error.
							if (auto SameNameMaterial = Cast<UMaterial>(FindMaterial(*MaterialName)))
							{
								UE_LOG(LogOmniverse, Error, TEXT("The material instance can't be created because the same name material was in the package, please remove it and refresh."));
								continue;
							}

							MaterialInstance = NewUnrealAsset<UMaterialInstanceConstant>(FName(*MaterialName));
							PackageClean = true;
						}

						// Load Base MDL
						BaseMaterialFile = BaseMaterialFile + TEXT(".mdl");
						UMaterialInterface* ParentMaterial = nullptr;
						bool IsLocalBaseMDL = UOmniverseMDL::IsLocalBaseMDL(BaseMaterialFile);
						if (IsLocalBaseMDL)
						{
							// Can't directly load mdl module inside another mdl loading
							ParentMaterial = UOmniverseMDL::FindLocalBaseMDL(BaseMaterialFile, BaseMaterialName);
							if (ParentMaterial == nullptr)
							{
								// Delay loading the local core material
								DelayCoreMaterialLoadList.Add(MaterialInstance, { BaseMaterialFile, BaseMaterialName });
							}
						}
						else
						{
							UOmniverseMDL* BaseMDL = LoadMDLDependency(BaseMaterialFile, false);
							if (BaseMDL == nullptr || !BaseMDL->bValidAsset)
							{
								// Test if there's the parent material
								NotLoadedParents.Add(BaseMaterialFile);
								continue;
							}
							BaseMDL->OnUpdated.RemoveAll(this);
							ParentMaterial = BaseMDL->FindMaterial(*BaseMaterialName);
						}
						
						//InitStaticParameters(MaterialInstance);
						MaterialInstance->ClearParameterValuesEditorOnly();
						MaterialInstance->SetParentEditorOnly(ParentMaterial);
						MaterialInstance->SetScalarParameterValueEditorOnly(TEXT("World-Aligned Textures"), 0);

						static FLoadInstanceTextureCallback LoadInstanceTexture;
						LoadInstanceTexture = [&](const FString& InTextureName, const FString& DisplayName, float Gamma)
						{
							FString TextureName = InTextureName;
							FPaths::NormalizeDirectoryName(TextureName);

							auto OmniTextureName = FOmniversePathHelper::ComputeAbsolutePath(OmniPath, TextureName);

							if (!OmniTextureName.IsEmpty())
							{
								auto Texture = UOmniverseAsset::LoadAsset<UTexture>(OmniTextureName);
								if (Texture)
								{
									MaterialInstance->SetTextureParameterValueEditorOnly(*DisplayName, Texture);

									auto TextureAsset = UOmniverseAsset::LoadAsset<UOmniverseTexture>(OmniTextureName);
									
									if (Gamma != 0.0f && MaterialInstance->GetMaterial())
									{
										if (TextureAsset->bValidAsset)
										{
											OverrideTextureSRGB(MaterialInstance, DisplayName, (Gamma != 1.0f));
											
											if (TextureAsset->GetOutermost()->IsDirty())
											{
												TextureAsset->SaveToDisk();
											}
										}
										else
										{
											TextureAsset->OnImageUpdated.AddUObject(this, &UOmniverseMDL::OverrideTextureSRGB, TWeakObjectPtr<UMaterialInstanceConstant>(MaterialInstance), DisplayName, (Gamma != 1.0f));
										}
									}			
								}
							}
						};

						static FGetDisplayNameCallback GetDisplayName;
						GetDisplayName = [&](const FString& InMaterialName, const FString& ParameterName, FString& DisplayName) -> bool
						{
							if (IsLocalBaseMDL)
							{
								return UOmniverseMDL::GetDisplayNameFromLocalBaseMDL(InMaterialName, ParameterName, DisplayName);
							}
							else
							{
								return GetUnrealDisplayName(InMaterialName, ParameterName, DisplayName);
							}
						};

						FMDLImporterUtility::CreateInstanceFromBaseMDL(MaterialInstance, MaterialDefinition, GetDisplayName, LoadInstanceTexture);
						//UpdateStaticParameters(MaterialInstance);

						MaterialInstance->PostEditChange();
						MaterialInstance->MarkPackageDirty();

						RefreshMaterialEditor(MaterialInstance);
						
						MDLLoadingTask.EnterProgressFrame();
						continue;
					}

					UMDLSettings* Settings = GetMutableDefault<UMDLSettings>();
					const mi::base::Handle<const mi::neuraylib::IFunction_call> MaterialInstance(MaterialDefinition->create_function_call(nullptr));
					if (!MaterialInstance.is_valid_interface())
					{
						continue;
					}
					mi::base::Handle<const mi::neuraylib::IMaterial_instance> MaterialInstance2(MaterialInstance->get_interface<mi::neuraylib::IMaterial_instance>());
					mi::Uint32 flags = Settings->bInstanceCompilation ? mi::neuraylib::IMaterial_instance::DEFAULT_OPTIONS : mi::neuraylib::IMaterial_instance::CLASS_COMPILATION;
					mi::base::Handle<mi::neuraylib::IMdl_execution_context> Context(MDLPluginModule->GetFactory()->create_execution_context());
					Context->set_option(TCHAR_TO_ANSI(TEXT("meters_per_scene_unit")), Settings->MetersPerSceneUnit);
					mi::base::Handle<const mi::neuraylib::ICompiled_material> CompiledMaterial(MaterialInstance2->create_compiled_material(flags, Context.get()));
					if (!CompiledMaterial.is_valid_interface())
					{
						continue;
					}					

					// Convert to Unreal material
					auto MaterialPointer = Cast<UMaterial>(FindMaterial(*MaterialName));
					// If can't find the material, the material name might be changed at mdl file,
					// we created a new one and start package clean
					if (MaterialPointer == nullptr)
					{
						// check if there's a same name material instance in the path. that material instance might be created with error.
						if (auto SameNameMaterialInstance = Cast<UMaterialInstanceConstant>(FindMaterial(*MaterialName)))
						{
							UE_LOG(LogOmniverse, Error, TEXT("The material can't be created because the same name material instance was in the package, please remove it and refresh."));
							continue;
						}

						MaterialPointer = NewUnrealAsset<UMaterial>(FName(*MaterialName));
						PackageClean = true;
					}

					static FLoadTextureCallback LoadOmniTexture;
					LoadOmniTexture = [&](UTexture*& OutTexture, const FString& TexturePath, float Gamma, TextureCompressionSettings Compression)
					{
						FString AbsoluteTexturePath = FOmniversePathHelper::ComputeAbsolutePath(OmniPath, TexturePath);
						OutTexture = UOmniverseAsset::LoadAsset<UTexture>(AbsoluteTexturePath);

						UOmniverseTexture* OmniTexture = UOmniverseAsset::LoadAsset<UOmniverseTexture>(AbsoluteTexturePath);
						if (OmniTexture)
						{
							OmniTexture->OnImageUpdated.AddUObject(this, &UOmniverseMDL::OnTextureUpdated, TWeakObjectPtr<UMaterial>(MaterialPointer), OutTexture, Gamma, Compression);
						}
					};

					TArray<FString> DistillErrors;
					if (!FMDLImporterUtility::DistillCompiledMaterial(MaterialPointer, MaterialDefinition, CompiledMaterial, true, &DistillErrors, LoadOmniTexture))
					{
						FString OuterPackageName;
						if (!FPackageName::TryConvertFilenameToLongPackageName(MaterialPointer->GetPathName(), OuterPackageName))
						{
							OuterPackageName = MaterialPointer->GetPathName();
						}

						for (auto Error : DistillErrors)
						{
							TSharedRef<FTokenizedMessage> Message = FTokenizedMessage::Create(EMessageSeverity::Error, FText());
							Message->AddToken(FAssetNameToken::Create(OuterPackageName));
							Message->AddToken(FTextToken::Create(FText::FromString(TEXT(":"))));
							Message->AddToken(FTextToken::Create(FText::FromString(Error)));
							FOmniverseMessageLogContext::AddMessage(Message);
							FOmniverseNotificationHelper::NotifyError(Error);
						}
						
						TSharedRef<FTokenizedMessage> Message = FTokenizedMessage::Create(EMessageSeverity::Error, FText());
						Message->AddToken(FAssetNameToken::Create(OuterPackageName));
						Message->AddToken(FTextToken::Create(FText::FromString(TEXT(":"))));
						Message->AddToken(FTextToken::Create(FText::FromString(FString::Printf(TEXT("Failed to distill material")))));
						FOmniverseMessageLogContext::AddMessage(Message);
                        FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Failed to distill %s"), *OmniPath));

						continue;
					}

					FMDLParametersList List;
					FMDLImporterUtility::UpdateParametersSheet(MaterialDefinition, CompiledMaterial, List);
					FMDLImporterUtility::MappingParameters(MaterialPointer, List);
					ParametersSheet.Add(MaterialName, List);

					RefreshMaterialEditor(MaterialPointer);
					MDLLoadingTask.EnterProgressFrame();
				}

				// The package has materials need to be clean
				if (PackageClean)
				{
					TArray<UObject*> AllObjects;
					GetObjectsWithOuter(GetOuter(), AllObjects);

					for(auto Object : AllObjects)
					{
						if(Object->IsAsset())
						{
							UMaterialInterface* Material = Cast<UMaterialInterface>(Object);
							if(Material && ValidMaterialNames.Find(Material->GetName()) == INDEX_NONE)
							{
								// Close the material editor
								CloseAssetEditor(Material);
								Material->MarkAsGarbage();
							}
						}
					}
				}

				MDLLoadingTask.EnterProgressFrame(MDLLoadingTask.TotalAmountOfWork - MDLLoadingTask.CompletedWork - 1.0f);
			}
		}
		else
		{
			FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("Failed to distill %s"), *OmniPath));
		}
	}

	UnloadModule();
#endif

	bDelayedTrigger = NotLoadedParents.Num() > 0;
	for (auto Name : NotLoadedParents)
	{
		UOmniverseMDL* BaseMDL = LoadMDLDependency(Name);
		if (BaseMDL == nullptr)
		{
			continue;
		}

		BaseMDL->OnUpdated.AddUObject(this, &UOmniverseMDL::OnMDLCreated);
	}

	for (auto Pair : DelayCoreMaterialLoadList)
	{
		Pair.Key->SetParentEditorOnly(UOmniverseMDL::LoadLocalBaseMDL(Pair.Value.FilePath, Pair.Value.MaterialName));
		Pair.Key->PostEditChange();
	}
}

void UOmniverseMDL::OnRead(const TSharedOmniContentPtr& Content)
{
	// Load MDL
	if(!GIsEditor)
	{
		return;
	}

	if(!Content || Content->Size() == 0)
	{
		return;
	}

	LoadMDL();

	if (bIsAsset)
	{
		bIsAsset = false;
		ClearFlags(EObjectFlags::RF_Public | EObjectFlags::RF_Transactional | EObjectFlags::RF_Standalone);
		CloseAssetEditor(this);
	}

	SaveToDisk();
}

bool UOmniverseMDL::IsAsset() const
{
	return bIsAsset;
}

void UOmniverseMDL::CreateUnrealAsset()
{
	bIsAsset = true;
	SetFlags(EObjectFlags::RF_Public | EObjectFlags::RF_Transactional | EObjectFlags::RF_Standalone);
}

#if WITH_EDITOR
void UOmniverseMDL::OnMDLCreated()
{
	LoadMDL();
	SaveToDisk();
	OnUpdated.Broadcast();
}

#if 0
void UOmniverseMDL::InitStaticParameters(UMaterialInstanceConstant* MaterialInstance)
{
	FStaticParameterSet OutStaticParameters;
	MaterialInstance->GetStaticParameterValues(OutStaticParameters);

	bool NeedUpdate = false;

	for (auto& StaticSwitchParameter : OutStaticParameters.StaticSwitchParameters)
	{
		if (StaticSwitchParameter.bOverride != false)
		{
			StaticSwitchParameter.bOverride = false;
			NeedUpdate = true;
		}
	}

	if (NeedUpdate)
	{
		FlushRenderingCommands();
		MaterialInstance->UpdateStaticPermutation(OutStaticParameters);
	}
}

bool UOmniverseMDL::UpdateStaticParameters(UMaterialInstanceConstant* MaterialInstance)
{
	// Update all the static parameters
	FStaticParameterSet OutStaticParameters;
	if (StaticParameters.Num() > 0) {
		MaterialInstance->GetStaticParameterValues(OutStaticParameters);
	}

	bool NeedUpdate = false;
	for (TMap<FName, bool>::TIterator It(StaticParameters); It; ++It)
	{
		for (auto& StaticSwitchParameter : OutStaticParameters.StaticSwitchParameters)
		{
			if (It.Key() == StaticSwitchParameter.ParameterInfo.Name)
			{
				if (StaticSwitchParameter.Value != It.Value())
				{
					StaticSwitchParameter.Value = It.Value();
					StaticSwitchParameter.bOverride = It.Value();
					NeedUpdate = true;
				}
			}
		}
	}

	if (NeedUpdate)
	{
		FlushRenderingCommands();
		MaterialInstance->UpdateStaticPermutation(OutStaticParameters);
		StaticParameters.Empty();
		return true;
	}
	return false;
}
#endif

bool UOmniverseMDL::IsMDLLibrary(const FString& Header)
{
	return (Header == TEXT("adobe")
		|| Header == TEXT("alg")
		|| Header == TEXT("iray_for_rhino")
		|| Header == TEXT("nvidia"));
}

bool UOmniverseMDL::GetUnrealDisplayName(const FString& InMaterialName, const FString& InParameterName, FString& DisplayName)
{
	auto ParametersList = ParametersSheet.Find(InMaterialName);
	if (ParametersList)
	{
		for(auto Parameter : ParametersList->ParametersList)
		{
			if (Parameter.ParameterName == InParameterName)
			{
				DisplayName = Parameter.DisplayName;
				return true;
			}
		}
	}

	return false;
}

bool UOmniverseMDL::IsParameterUsed(const FString& InMaterialName, const FString& InParameterName)
{
	auto ParametersList = ParametersSheet.Find(InMaterialName);
	if (ParametersList)
	{
		for (auto Parameter : ParametersList->ParametersList)
		{
			if (Parameter.ParameterName == InParameterName)
			{
				return Parameter.bUsedInUnreal;
			}
		}
	}

	return false;
}

bool UOmniverseMDL::GetMdlParameterTypeAndName(const FString& InMaterialName, const FString& InDisplayName, EMdlValueType& ValueType, FString& ParameterName)
{
	auto ParametersList = ParametersSheet.Find(InMaterialName);
	if (ParametersList)
	{
		for(auto Parameter : ParametersList->ParametersList)
		{
			if (Parameter.DisplayName == InDisplayName)
			{
				ValueType = Parameter.ParameterType;
				ParameterName = Parameter.ParameterName;
				return true;
			}
		}
	}				

	return false;
}

bool UOmniverseMDL::ExportPreset(UMaterialInstanceConstant* InMaterialInstance, const FString& ExportName, bool bOmniUpload, FString& OutMDL)
{
	TSharedOmniContentPtr Content;
	if (FOmniverseConnectionHelper::ReadSync(OmniPath, Content))
	{
		const FString ExportFilename = ExportName.IsEmpty() ? FPaths::GetBaseFilename(OmniPath) : ExportName;
		const FString ExportPath = FPaths::GetPath(OmniPath);

		UE_LOG(LogOmniverse, Display, L"Exporting %s", *ExportPath);

		TSharedPtr<FOmniverseMDLHelper> MDLHelper = MakeShareable<FOmniverseMDLHelper>(new FOmniverseMDLHelper(Content->GetData(), Content->Size()));

		auto MDLPluginModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");
		{
			if (LoadModule())
			{
				mi::base::Handle<const mi::neuraylib::IModule> MDLModule = MDLPluginModule->GetLoadedModule(ModuleName);

				if (MDLModule.is_valid_interface())
				{
					for (auto MaterialIdx = 0; MaterialIdx < MDLModule->get_material_count(); ++MaterialIdx)
					{
						// Compile
						mi::base::Handle<const mi::neuraylib::IFunction_definition> MaterialDefinition = mi::base::make_handle(MDLPluginModule->GetTransaction()->access<mi::neuraylib::IFunction_definition>(MDLModule->get_material(MaterialIdx)));

						FString MaterialName = MDLModule->get_material(MaterialIdx);
						MaterialName = MaterialName.Left(MaterialName.Find(TEXT("(")));
						FString(MoveTemp(MaterialName)).Split("::", nullptr, &MaterialName, ESearchCase::CaseSensitive, ESearchDir::FromEnd);
						UMaterialInstanceConstant* Instance = InMaterialInstance;

						if (Instance)
						{
							if (Instance->GetName() != MaterialName)
							{
								continue;
							}

							MDLHelper->SetExportName(ExportName);
						}
						else
						{
							Instance = Cast<UMaterialInstanceConstant>(FindMaterial(*MaterialName));
							if (!Instance)
							{
								continue;
							}
						}
					
						if (MDLHelper->ExtractMaterial(MaterialName))
						{
							const mi::base::Handle<const mi::neuraylib::IExpression_list> Defaults(MaterialDefinition->get_defaults());

							FStaticParameterSet OutStaticParameters;
							Instance->GetStaticParameterValues(OutStaticParameters);

							// Create Expressions
							for (mi::Size i = 0; i < Defaults->get_size(); ++i)
							{
								FString ParamName = Defaults->get_name(i);
								FString DisplayName;
								bool bLastParam = (i == Defaults->get_size() - 1);
								if (FMDLImporterUtility::FindDisplayNameByParameterName(MaterialDefinition, Defaults->get_name(i), DisplayName))
								{
									mi::base::Handle<const mi::neuraylib::IExpression> DefaultExpression(Defaults->get_expression(i));
									if (DefaultExpression->get_kind() == mi::neuraylib::IExpression::EK_CONSTANT)
									{
										mi::base::Handle<const mi::neuraylib::IValue> DefaultValue(DefaultExpression.get_interface<const mi::neuraylib::IExpression_constant>()->get_value());

										switch (DefaultValue->get_kind())
										{
										case mi::neuraylib::IValue::Kind::VK_BOOL:
										{
											//for (auto& StaticSwitchParameter : OutStaticParameters.StaticSwitchParameters)
											//{
											//	if (StaticSwitchParameter.ParameterInfo.Name.Compare((*DisplayName)) == 0)
											//	{
											//		MDLHelper->SetValue(ParamName, StaticSwitchParameter.Value, bLastParam);
											//		break;
											//	}
											//}
											float OutValue = 0.0f;
											if (!Instance->GetScalarParameterValue(*DisplayName, OutValue))
											{
												continue;
											}
											MDLHelper->SetValue(ParamName, (OutValue != 0.0f), bLastParam);
										}
										break;
										case mi::neuraylib::IValue::Kind::VK_INT:
										{
											float OutValue = 0.0f;
											if (!Instance->GetScalarParameterValue(*DisplayName, OutValue))
											{
												continue;
											}
											MDLHelper->SetValue(ParamName, (int32)OutValue, bLastParam);
										}
										break;
										case mi::neuraylib::IValue::Kind::VK_FLOAT:
										{
											float OutValue = 0.0f;
											if (!Instance->GetScalarParameterValue(*DisplayName, OutValue))
											{
												continue;
											}
											MDLHelper->SetValue(ParamName, OutValue, bLastParam);
										}
										break;
										case mi::neuraylib::IValue::Kind::VK_STRING:
										case mi::neuraylib::IValue::Kind::VK_MATRIX:
										{
											continue;
										}
										break;
										case mi::neuraylib::IValue::Kind::VK_VECTOR:
										{
											FLinearColor OutValue(EForceInit::ForceInitToZero);
											if (!Instance->GetVectorParameterValue(*DisplayName, OutValue))
											{
												continue;
											}

											mi::base::Handle<mi::neuraylib::IValue_vector const> NewValue(DefaultValue->get_interface<mi::neuraylib::IValue_vector>());
											MDLHelper->SetValue(ParamName, OutValue, NewValue->get_size(), false, bLastParam);
										}
										break;
										case mi::neuraylib::IValue::Kind::VK_COLOR:
										{
											FLinearColor OutValue(EForceInit::ForceInitToZero);
											if (!Instance->GetVectorParameterValue(*DisplayName, OutValue))
											{
												continue;
											}
											MDLHelper->SetValue(ParamName, OutValue, 3, true, bLastParam);
										}
										break;
										case mi::neuraylib::IValue::Kind::VK_TEXTURE:
										{
											UTexture* OutTexture = nullptr;

											bool bOverrideTexture = false;
											for (auto TextureParameter : Instance->TextureParameterValues)
											{
												if (TextureParameter.ParameterInfo.Name.ToString() == DisplayName)
												{
													bOverrideTexture = true;
													break;
												}
											}

											if (!Instance->GetTextureParameterValue(*DisplayName, OutTexture))
											{
												continue;
											}

											FString TexturePath = TEXT("./") + ExportFilename;
											UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(OutTexture->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
											if (OmniverseAssetUserData && OmniverseAssetUserData->OmniAsset)
											{
												UOmniverseTexture* OmniverseTexture = CastChecked<UOmniverseTexture>(OmniverseAssetUserData->OmniAsset);
												TexturePath = FPaths::GetPath(OmniverseTexture->GetOmniPath());
											}

											FString RelativePath = FOmniversePathHelper::ComputeRelativePath(TexturePath, OmniPath);
											if (!RelativePath.StartsWith(TEXT(".")) && !RelativePath.StartsWith(TEXT("..")))
											{
												RelativePath = RelativePath.IsEmpty() ? TEXT(".") : TEXT(".") / RelativePath;
											}

											MDLHelper->SetValue(ParamName, bOverrideTexture ? OutTexture : nullptr, RelativePath, OutTexture->IsA<UTextureCube>(), bLastParam);

											if (OutTexture && bOmniUpload)
											{
												if (OmniverseAssetUserData && OmniverseAssetUserData->OmniAsset)
												{
													// for single DDS
													FOmniverseExportTextureSettings DDSSetting;
													DDSSetting.bDDSExport = true;
													FOmniverseAssetExportHelper::ExportTextureToPath(OutTexture, TexturePath, DDSSetting);
												}
												else
												{
													// Don't upload textures from Engine resources
													if(OutTexture->GetOutermost() == GetTransientPackage()
													|| OutTexture->GetOutermost()->GetName().StartsWith(TEXT("/Engine/"))
													|| OutTexture->GetOutermost()->GetName().StartsWith(TEXT("/MDL/")))
													{
														continue;
													}

													// local empty texture to generate MDL
													FString OmniTexturePath = ExportPath / ExportFilename / OutTexture->GetName() + TEXT(".") + FMDLExporterUtility::GetFileExtension(OutTexture);
													if (FOmniverseAssetExportHelper::ExportTextureToPath(OutTexture, OmniTexturePath))
													{
														if (Instance)
														{
															auto Texture = UOmniverseAsset::LoadAsset<UTexture>(OmniTexturePath);
															Texture->SRGB = OutTexture->SRGB;
															Instance->SetTextureParameterValueEditorOnly(*(DisplayName), Texture);
															RefreshMaterialEditor(Instance);
														}
													}
												}
											}
										}
										break;
										}
									}
								}		
							}
						}

						// Instance has been exported, quit the loop
						if (InMaterialInstance == Instance)
						{
							break;
						}
					}
				}
			}
		}

		UnloadModule();

		OutMDL = MDLHelper->GetFinalOutput();

		return !OutMDL.IsEmpty();
	}


	return false;
}
#endif

void UOmniverseMDL::PostSave()
{
	Super::PostSave();

	FString OutMDL;
	ExportPreset(nullptr, FString(), true, OutMDL);

#if 0
	FString log = OutMDL;
	UE_LOG(LogOmniverse, Log, TEXT("%s"), *log);
#endif

	if (!OutMDL.IsEmpty())
	{
		FOmniverseConnectionHelper::WriteFileSync(OmniPath, (uint8_t*)TCHAR_TO_UTF8(*OutMDL), OutMDL.Len());
	}
}

void UOmniverseMDL::ReplaceNormalTextureLookup(const TConstArrayView<TObjectPtr<UMaterialExpression>>& Expressions, UMaterialExpression* TextureObject)
{
	// search for material function
	for (auto Expression : Expressions)
	{
		if (Expression->IsA<UMaterialExpressionMaterialFunctionCall>())
		{
			auto Function = Cast<UMaterialExpressionMaterialFunctionCall>(Expression);
			if (Function->MaterialFunction &&
				Function->FunctionInputs.Num() > 0 && Function->FunctionInputs[0].Input.Expression && Function->FunctionInputs[0].Input.Expression == TextureObject)
			{
				auto FunctionName = Function->MaterialFunction->GetName();
				if (FunctionName.StartsWith(TEXT("mdl_tex_lookup")))
				{
					FunctionName.RemoveFromEnd(TEXT("2d"));
					FunctionName += TEXT("normal");
					Function->SetMaterialFunction(FMDLImporterUtility::LoadMDLFunction(FMDLImporterUtility::GetProjectFunctionPath(), *FunctionName));
				}
                else if (FunctionName.StartsWith("mdl_base_file_texture"))
                {
                    FunctionName += TEXT("_normal");
                    Function->SetMaterialFunction(FMDLImporterUtility::LoadMDLFunction(FMDLImporterUtility::GetProjectFunctionPath(), *FunctionName));
                }
			}
		}
	}
}

#if WITH_EDITOR
// NOTE: Texture (depending on type) might be recreated by TextureFactory, so can't use weakptr here. Or the ptr will be stale.
void UOmniverseMDL::OnTextureUpdated(TWeakObjectPtr<UMaterial> InMaterial, UTexture* InTexture, float Gamma, TextureCompressionSettings Compression)
{
	if (!InMaterial.IsValid() || !(InTexture && InTexture->IsValidLowLevel()))
	{
		return;
	}

	UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(InTexture->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
	if (!OmniverseAssetUserData)
	{
		return;
	}

	UOmniverseTexture* OmniTexture = CastChecked<UOmniverseTexture>(OmniverseAssetUserData->OmniAsset);
	OmniTexture->OnImageUpdated.RemoveAll(this);

	bool bTextureChanged = false;
	if (InTexture->CompressionSettings == TC_Default && InTexture->CompressionSettings != Compression)
	{
		InTexture->CompressionSettings = Compression;
		bTextureChanged = true;
	}

	if (Gamma > 0.0f)
	{
		bool SRGB = (Gamma != 1.0f);
		if (InTexture->SRGB != SRGB)
		{
			InTexture->SRGB = SRGB;
			// check current CompressionSettings accepts srgb
			if (InTexture->SRGB && InTexture->CompressionSettings == TC_Normalmap)
			{
				InTexture->CompressionSettings = TC_Default;
			}
			bTextureChanged = true;
		}
	}

	if (bTextureChanged)
	{
		InTexture->PostEditChange();
		InTexture->MarkPackageDirty();
	}

	bool bMaterialChanged = false;

	EMaterialSamplerType SamplerType = UMaterialExpressionTextureBase::GetSamplerTypeForTexture(InTexture);
	{
		for (auto Expression : InMaterial->GetExpressions())
		{
			if (Expression->IsA<UMaterialExpressionTextureObject>())
			{
				auto TextureExpression = Cast<UMaterialExpressionTextureObject>(Expression);
				if (TextureExpression->Texture == InTexture)
				{
					if (TextureExpression->SamplerType != SamplerType)
					{
						TextureExpression->SamplerType = SamplerType;
						if (TextureExpression->SamplerType == SAMPLERTYPE_Normal)
						{
							ReplaceNormalTextureLookup(InMaterial->GetExpressions(), TextureExpression);
						}
						bMaterialChanged = true;
					}
				}
			}
			else if (Expression->IsA<UMaterialExpressionTextureObjectParameter>())
			{
				auto TextureExpression = Cast<UMaterialExpressionTextureObjectParameter>(Expression);
				if (TextureExpression->Texture == InTexture)
				{
					if (TextureExpression->SamplerType != SamplerType)
					{
						TextureExpression->SamplerType = SamplerType;
						if (TextureExpression->SamplerType == SAMPLERTYPE_Normal)
						{
							ReplaceNormalTextureLookup(InMaterial->GetExpressions(), TextureExpression);
						}
						bMaterialChanged = true;
					}
				}		
			}
		}
	}

	if (bMaterialChanged)
	{
		// The material might be compiled multiple times, it should be blocked until the former one was finished.
		//InMaterial->GetMaterialResource(GMaxRHIFeatureLevel)->FinishCompilation();
		InMaterial->PostEditChange();
		InMaterial->MarkPackageDirty();
		SaveToDisk();
		RefreshMaterialEditor(InMaterial.Get());
		FMaterialUpdateContext UpdateContext;
		UpdateContext.AddMaterial(InMaterial.Get());
	}
}

bool UOmniverseMDL::IsLocalBaseMDL(const FString& InPath)
{
	return FMDLImporterUtility::IsBaseModule(InPath);
}

UMaterialInterface* UOmniverseMDL::GetLocalBaseMaterial(UMaterialInterface* MaterialInterface)
{
	return FMDLImporterUtility::GetBaseMaterial(MaterialInterface);
}

UMaterialInterface* UOmniverseMDL::FindLocalBaseMDL(const FString& FileName, const FString& MaterialName)
{
	return FMDLImporterUtility::FindBaseModule(FileName, MaterialName);
}

UMaterialInterface* UOmniverseMDL::LoadLocalBaseMDL(const FString& FileName, const FString& MaterialName)
{
	return FMDLImporterUtility::LoadBaseModule(FileName, MaterialName);
}

bool UOmniverseMDL::GetDisplayNameFromLocalBaseMDL(const FString& MaterialName, const FString& ParameterName, FString& DisplayName)
{
	return FMDLImporterUtility::GetDisplayNameFromBaseModule(MaterialName, ParameterName, DisplayName);
}

bool UOmniverseMDL::GetMdlParameterTypeAndNameFromLocalBaseMDL(const FString& InMaterialName, const FString& InDisplayName, EMdlValueType& ValueType, FString& ParameterName)
{
	return FMDLImporterUtility::GetMdlParameterTypeAndNameFromBaseModule(InMaterialName, InDisplayName, ValueType, ParameterName);
}

bool UOmniverseMDL::GetMDLModuleByMaterialName(const FString& InMaterialName, FString& ModuleName)
{
	return FMDLImporterUtility::GetBaseModuleByMaterialName(InMaterialName, ModuleName);
}

bool UOmniverseMDL::GetMDLModuleByMaterial(const UMaterialInterface* Material, FString& ModuleName)
{
	return FMDLImporterUtility::GetBaseModuleByMaterial(Material, ModuleName);
}

void UOmniverseMDL::LoadMaterialGraphDefinitions()
{
	FMDLImporterUtility::LoadMaterialGraphDefinitions();
}

void UOmniverseMDL::UnloadMaterialGraphDefinitions()
{
	FMDLImporterUtility::UnloadMaterialGraphDefinitions();
}

bool UOmniverseMDL::CreateMdlInstance(const FString& ModuleName, const FString& FunctionName, const FString& InstanceName)
{
	return FMDLImporterUtility::CreateMdlInstance(ModuleName, FunctionName, InstanceName);
}

bool UOmniverseMDL::SetCall(const FString& InstanceTarget, const FString& ParameterName, const FString& InstanceCall)
{
	return FMDLImporterUtility::SetCall(InstanceTarget, ParameterName, InstanceCall);
}

bool UOmniverseMDL::DistillMaterialInstance(UMaterial* Material, const FString& MaterialInstanceName, bool bUseDisplayName)
{
	return FMDLImporterUtility::DistillMaterialInstance(Material, MaterialInstanceName, bUseDisplayName);
}

bool UOmniverseMDL::IsParameterUsedFromLocalBaseMDL(const FString& MaterialName, const FString& ParameterName)
{
	return FMDLImporterUtility::IsParameterUsedFromBaseModule(MaterialName, ParameterName);
}

int32 UOmniverseMDL::SceneDataStringToEnum(const FString& SceneData)
{
	return FMDLImporterUtility::SceneDataStringToEnum(SceneData);
}

UMaterialInterface* UOmniverseMDL::ImportMDL(UObject* InPackage, const FString& InModuleName, const FString& InMaterialName, const TArray<FString>& ModulePaths, 
	TSharedPtr<IMDLExternalReader> ExternalReader, FName Name, EObjectFlags Flags, const FString& SourceFile, TFunction<void(const uint8*, uint64, const FString&, UTexture*&)> Callback)
{
	UMaterialInterface* OutMaterial = nullptr;
	auto MDLPluginModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");
	{
		for (auto Module : ModulePaths)
		{
			MDLPluginModule->AddModulePath(Module, true);
		}

		if (ExternalReader == nullptr)
		{
			ExternalReader = MakeShareable<FOmniverseMDLReader>(new FOmniverseMDLReader());
		}
		MDLPluginModule->SetExternalFileReader(ExternalReader);
		
		int32 Result = MDLPluginModule->LoadModule(InModuleName);
		MDLPluginModule->SetExternalFileReader(nullptr);
		if (Result >= 0)
		{		
			mi::base::Handle<const mi::neuraylib::IModule> MDLModule = MDLPluginModule->GetLoadedModule(InModuleName);

			if (MDLModule.is_valid_interface())
			{
				// Convert MDL to Unreal material
				for (auto MaterialIdx = 0; MaterialIdx < MDLModule->get_material_count(); ++MaterialIdx)
				{
					FString MaterialName = MDLModule->get_material(MaterialIdx);
					MaterialName = MaterialName.Left(MaterialName.Find(TEXT("(")));
					FString(MoveTemp(MaterialName)).Split("::", nullptr, &MaterialName, ESearchCase::CaseSensitive, ESearchDir::FromEnd);

					if (MaterialName != InMaterialName)
					{
						continue;
					}

					// Compile
					mi::base::Handle<const mi::neuraylib::IFunction_definition> MaterialDefinition = mi::base::make_handle(MDLPluginModule->GetTransaction()->access<mi::neuraylib::IFunction_definition>(MDLModule->get_material(MaterialIdx)));
					UMDLSettings* Settings = GetMutableDefault<UMDLSettings>();
					const mi::base::Handle<const mi::neuraylib::IFunction_call> MaterialInstance(MaterialDefinition->create_function_call(nullptr));
					if (!MaterialInstance.is_valid_interface())
					{
						break;
					}
					mi::base::Handle<const mi::neuraylib::IMaterial_instance> MaterialInstance2(MaterialInstance->get_interface<mi::neuraylib::IMaterial_instance>());
					mi::Uint32 flags = Settings->bInstanceCompilation ? mi::neuraylib::IMaterial_instance::DEFAULT_OPTIONS : mi::neuraylib::IMaterial_instance::CLASS_COMPILATION;
					mi::base::Handle<mi::neuraylib::IMdl_execution_context> Context(MDLPluginModule->GetFactory()->create_execution_context());
					Context->set_option(TCHAR_TO_ANSI(TEXT("meters_per_scene_unit")), Settings->MetersPerSceneUnit);
					mi::base::Handle<const mi::neuraylib::ICompiled_material> CompiledMaterial(MaterialInstance2->create_compiled_material(flags, Context.get()));
					if (!CompiledMaterial.is_valid_interface())
					{
						break;
					}

					FMDLParametersList List;
					FMDLImporterUtility::UpdateParametersSheet(MaterialDefinition, CompiledMaterial, List);
					ImportedParametersSheet.Add(Name.ToString(), List);

					auto Material = NewObject<UMaterial>(InPackage, Name, Flags);
						
					static FLoadTextureCallback LoadTexture;
					LoadTexture = [&](UTexture*& OutTexture, const FString& TexturePath, float Gamma, TextureCompressionSettings Compression)
					{
						IFileHandle* TextureHandle = ExternalReader->OpenRead(TexturePath);
						if (TextureHandle)
						{
							int64 Size = TextureHandle->Size();
							uint8* Buffer = new uint8[Size];
							TextureHandle->Read(Buffer, Size);

							if (Callback)
							{
								Callback(Buffer, Size, TexturePath, OutTexture);
							}

							if (OutTexture)
							{
								bool bTextureChanged = false;
								if (OutTexture->CompressionSettings == TC_Default && OutTexture->CompressionSettings != Compression)
								{
									OutTexture->CompressionSettings = Compression;
									bTextureChanged = true;
								}

								if (Gamma > 0.0f)
								{
									bool SRGB = (Gamma != 1.0f);
									if (OutTexture->SRGB != SRGB)
									{
										OutTexture->SRGB = SRGB;
										// check current CompressionSettings accepts srgb
										if (OutTexture->SRGB && OutTexture->CompressionSettings == TC_Normalmap)
										{
											OutTexture->CompressionSettings = TC_Default;
										}
										bTextureChanged = true;
									}
								}

								if (bTextureChanged)
								{
									OutTexture->PostEditChange();
								}

								OutTexture->MarkPackageDirty();
							}

							delete[] Buffer;					
						}
					};
						
					if (FMDLImporterUtility::DistillCompiledMaterial(Material, MaterialDefinition, CompiledMaterial, true, nullptr, LoadTexture))
					{
						// Update AssetImportData
						FOmniverseAssetImportHelper::UpdateAssetImportData(Material, SourceFile, InModuleName, InMaterialName);
						OutMaterial = Material;
						Material->PostEditChange();
						Material->MarkPackageDirty();
						FAssetRegistryModule::AssetCreated(Material);
					}
					else
					{
						Material->ClearFlags(RF_Standalone);
						Material->Rename(NULL, GetTransientPackage(), REN_DontCreateRedirectors);
					}
					break;
				}
			}
		}
	}

	MDLPluginModule->RemoveModule(InModuleName);
	MDLPluginModule->CommitAndCreateTransaction();
	for (auto Module : ModulePaths)
	{
		MDLPluginModule->RemoveModulePath(Module);
	}
	return OutMaterial;
}

void UOmniverseMDL::ImportMdlParameters(const FString& InModuleName, const FString& InMaterialName, const TArray<FString>& ModulePaths, 
	TSharedPtr<IMDLExternalReader> ExternalReader, const FString& InMaterialAssetName)
{
	UMaterialInterface* OutMaterial = nullptr;
	auto MDLPluginModule = FModuleManager::GetModulePtr<IMDLModule>("MDL");
	{
		for (auto Module : ModulePaths)
		{
			MDLPluginModule->AddModulePath(Module, true);
		}

		if (ExternalReader == nullptr)
		{
			ExternalReader = MakeShareable<FOmniverseMDLReader>(new FOmniverseMDLReader());
		}
		MDLPluginModule->SetExternalFileReader(ExternalReader);
		
		int32 Result = MDLPluginModule->LoadModule(InModuleName);
		MDLPluginModule->SetExternalFileReader(nullptr);
		if (Result >= 0)
		{		
			mi::base::Handle<const mi::neuraylib::IModule> MDLModule = MDLPluginModule->GetLoadedModule(InModuleName);

			if (MDLModule.is_valid_interface())
			{
				// Convert MDL to Unreal material
				for (auto MaterialIdx = 0; MaterialIdx < MDLModule->get_material_count(); ++MaterialIdx)
				{
					FString MaterialName = MDLModule->get_material(MaterialIdx);
					MaterialName = MaterialName.Left(MaterialName.Find(TEXT("(")));
					FString(MoveTemp(MaterialName)).Split("::", nullptr, &MaterialName, ESearchCase::CaseSensitive, ESearchDir::FromEnd);

					if (MaterialName != InMaterialName)
					{
						continue;
					}

					// Compile
					mi::base::Handle<const mi::neuraylib::IFunction_definition> MaterialDefinition = mi::base::make_handle(MDLPluginModule->GetTransaction()->access<mi::neuraylib::IFunction_definition>(MDLModule->get_material(MaterialIdx)));
					UMDLSettings* Settings = GetMutableDefault<UMDLSettings>();
					const mi::base::Handle<const mi::neuraylib::IFunction_call> MaterialInstance(MaterialDefinition->create_function_call(nullptr));
					if (!MaterialInstance.is_valid_interface())
					{
						break;
					}
					mi::base::Handle<const mi::neuraylib::IMaterial_instance> MaterialInstance2(MaterialInstance->get_interface<mi::neuraylib::IMaterial_instance>());
					mi::Uint32 flags = Settings->bInstanceCompilation ? mi::neuraylib::IMaterial_instance::DEFAULT_OPTIONS : mi::neuraylib::IMaterial_instance::CLASS_COMPILATION;
					mi::base::Handle<mi::neuraylib::IMdl_execution_context> Context(MDLPluginModule->GetFactory()->create_execution_context());
					Context->set_option(TCHAR_TO_ANSI(TEXT("meters_per_scene_unit")), Settings->MetersPerSceneUnit);
					mi::base::Handle<const mi::neuraylib::ICompiled_material> CompiledMaterial(MaterialInstance2->create_compiled_material(flags, Context.get()));
					if (!CompiledMaterial.is_valid_interface())
					{
						break;
					}

					FMDLParametersList List;
					FMDLImporterUtility::UpdateParametersSheet(MaterialDefinition, CompiledMaterial, List);
					ImportedParametersSheet.Add(InMaterialAssetName, List);
			
					break;
				}
			}
		}
	}

	MDLPluginModule->RemoveModule(InModuleName);
	MDLPluginModule->CommitAndCreateTransaction();
	for (auto Module : ModulePaths)
	{
		MDLPluginModule->RemoveModulePath(Module);
	}
}

void UOmniverseMDL::ResetImportParametersSheet()
{
	ImportedParametersSheet.Reset();
}

bool UOmniverseMDL::GetImportDisplayName(const FString& InMaterialName, const FString& InParameterName, FString& DisplayName)
{
	auto ParametersList = ImportedParametersSheet.Find(InMaterialName);
	if (ParametersList)
	{
		for(auto Parameter : ParametersList->ParametersList)
		{
			if (Parameter.ParameterName == InParameterName)
			{
				DisplayName = Parameter.DisplayName;
				return true;
			}
		}
	}

	return false;
}

#endif