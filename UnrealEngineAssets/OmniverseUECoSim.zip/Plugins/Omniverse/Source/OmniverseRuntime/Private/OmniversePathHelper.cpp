// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniversePathHelper.h"

#include "Misc/Paths.h"
#include "Misc/SecureHash.h"

#include "OmniverseRuntimePrivate.h"

#include <OmniClient.h>
#include <string>

static const FString MangledPathPostfix = TEXT("_MANGLED");
static const FString KeySeparator = TEXT("@@");
static const FString LiveSessionFileName = TEXT("root.live");
static const FString LiveSessionChannelFileName = TEXT("__session__.channel");
static const FString LiveSessionTomlFileName = TEXT("__session__.toml");


class FCharAllocator
{
public:
	FCharAllocator(SIZE_T InSize)
	{
		Data = (char*)FMemory::Malloc(InSize);
	}

	~FCharAllocator()
	{
		FMemory::Free(Data);
	}

	char* GetData() { return Data; }

	char* Data;
};

static bool IsValidUE4PathChar(TCHAR c)
{
	const FString InvalidChars = INVALID_LONGPACKAGE_CHARACTERS TEXT("/[]");
	FString Char;
	Char += c;
	return !(InvalidChars.Contains(Char));
}

void FOmniversePathHelper::SplitUrlPath(const FString& Url, FString& UserName, FString& Server, FString& AssetPath, FString& Branch, FString& CheckPoint)
{
	auto ClientUrl = omniClientBreakUrl(TCHAR_TO_UTF8(*Url));
	if (!ClientUrl)
	{
		return;
	}

	if (ClientUrl->host)
	{
		Server = ClientUrl->host;
	}

	if (ClientUrl->user)
	{
		UserName = ClientUrl->user;
	}

	if (ClientUrl->path)
	{
		AssetPath = UTF8_TO_TCHAR(ClientUrl->path);
	}

	if (ClientUrl->query)
	{
		OmniClientBranchAndCheckpoint* OmniBranchCheckpoint = omniClientGetBranchAndCheckpointFromQuery(ClientUrl->query);
		if (OmniBranchCheckpoint)
		{
			Branch = UTF8_TO_TCHAR(OmniBranchCheckpoint->branch);
			CheckPoint = FString::Printf(TEXT("%llu"), OmniBranchCheckpoint->checkpoint); //uint64

			omniClientFreeBranchAndCheckpoint(OmniBranchCheckpoint);
		}
	}

	omniClientFreeUrl(ClientUrl);
}

bool FOmniversePathHelper::IsOldOmniPath(const FString & Path)
{
	return !IsNewOmniPath(Path) && Path.StartsWith("omni:/");
}


bool FOmniversePathHelper::IsNewOmniPath(const FString & Path)
{
	return Path.StartsWith("omniverse://") || Path.StartsWith("omni://");
}

bool FOmniversePathHelper::IsOmniPath(const FString& Path)
{
	return Path.StartsWith("omniverse:") || Path.StartsWith("omni:");
}

bool FOmniversePathHelper::IsValidAbsolutePath(const FString& Path)
{
	// including omniverse: http: and local:
	return Path.Contains(TEXT(":"));
}

void FOmniversePathHelper::FixAssetName(FString& AssetName)
{
	if (!AssetName.IsEmpty())
	{
		FString OriginalPath = AssetName;
		ManglePath(OriginalPath, AssetName, false);
	}
}

void FOmniversePathHelper::ConvertOmniPath(const FString & OmniPath, FString & PackagePath, FString & AssetName, FString & Extension, bool IncludeExtensionInPackagePath)
{
	FString ServerPath;
	FString AssetPath;
	FString UserName;
	FString Branch;
	FString CheckPoint;
	FOmniversePathHelper::SplitUrlPath(OmniPath, UserName, ServerPath, AssetPath, Branch, CheckPoint);

	FString MangledServerPath;
	ManglePath(ServerPath, MangledServerPath);

	FString PackageFolder;
	FPaths::Split(AssetPath, PackageFolder, AssetName, Extension);

	FString Leaf = FPaths::GetPathLeaf(PackageFolder);
	bool bHiddenFolder = Leaf.StartsWith(TEXT("."));
	if (!bHiddenFolder) // .thumbs .git, those hidden folders should skip converting
	{
		// Mangling the folder name
		FString MangledPackageFolder;
		ManglePath(PackageFolder, MangledPackageFolder);
		PackageFolder = MangledPackageFolder;

		FixAssetName(AssetName);
	}

	PackagePath = OMNIVERSE_FOLDER / MangledServerPath / PackageFolder / AssetName;

	if (!AssetName.IsEmpty())
	{
		if (!Extension.IsEmpty() && IncludeExtensionInPackagePath)
		{
			PackagePath += "_" + Extension;
		}

		if (!Branch.IsEmpty())
		{
			PackagePath += OMNIVERSE_BRANCH + Branch;
		}

		if (!CheckPoint.IsEmpty())
		{
			PackagePath += OMNIVERSE_CHECKPOINT + CheckPoint;
		}
	}

	PackagePath.RemoveFromEnd("/");
}

FString FOmniversePathHelper::GetAssetPathOnServer(const FString& OmniPath)
{
	FString ServerPath;
	FString AssetPath;
	FString UserName;
	FString Branch;
	FString CheckPoint;
	FOmniversePathHelper::SplitUrlPath(OmniPath, UserName, ServerPath, AssetPath, Branch, CheckPoint);

	return ServerPath;
}

static bool IsOmniDomain(const FString& Domain)
{
	return Domain == "omni" || Domain == "omniverse";
}

// Computes absolute path of OtherPath based on BasePath.
// NOTE: This function fails when BasePath is an omni URL and OtherPath is an absolute file path (S:\a b\c\d) with spaces.
//       It will encode the space as %20, which is a valid string file path, changing it...
FString FOmniversePathHelper::ComputeAbsolutePath(const FString & BasePath, const FString & OtherPath)
{
	FString BasePathCopy = BasePath.Replace(TEXT("\\"), TEXT("/"));
	FString OtherPathCopy = OtherPath.Replace(TEXT("\\"), TEXT("/"));
	bool IsBaseOmniPath = BasePathCopy.StartsWith("omni:") || BasePathCopy.StartsWith("omniverse:");
	if (IsBaseOmniPath && OtherPathCopy.StartsWith("omni:"))
	{
		OtherPathCopy = OtherPathCopy.RightChop(5);
	}

	if (IsBaseOmniPath && OtherPathCopy.StartsWith("omniverse:/") && !OtherPathCopy.StartsWith("omniverse://"))
	{
		OtherPathCopy = OtherPathCopy.RightChop(10);
	}

	if (BasePathCopy.Contains(OtherPathCopy))
	{
		return BasePathCopy;
	}

	size_t ExpectedSize = 0;
	omniClientCombineUrls(TCHAR_TO_UTF8(*BasePathCopy), TCHAR_TO_UTF8(*OtherPathCopy), nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientCombineUrls(TCHAR_TO_UTF8(*BasePathCopy), TCHAR_TO_UTF8(*OtherPathCopy), Buffer.GetData(), &ExpectedSize);

	FString ResultString = Buffer.GetData();
	ResultString = ResultString.Replace(TEXT("\\"), TEXT("/"));

	return ResultString;
}

FString FOmniversePathHelper::ComputeRelativePath(const FString& TargetPath, const FString& SourcePath, bool TargetIsDirectory, bool SourceIsDirectory)
{
	FString SourcePathCopy = SourcePath;
	if (SourceIsDirectory && !SourcePathCopy.EndsWith("/"))
	{
		SourcePathCopy += "/";
	}
	FString TargetPathCopy = TargetPath;
	if (TargetIsDirectory && !TargetPathCopy.EndsWith("/"))
	{
		TargetPathCopy += "/";
	}

	size_t ExpectedSize = 0;
	omniClientMakeRelativeUrl(TCHAR_TO_UTF8(*SourcePathCopy), TCHAR_TO_UTF8(*TargetPathCopy), nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientMakeRelativeUrl(TCHAR_TO_UTF8(*SourcePathCopy), TCHAR_TO_UTF8(*TargetPathCopy), Buffer.GetData(), &ExpectedSize);

	FString ResultString = Buffer.GetData();
	ResultString = ResultString.Replace(TEXT("\\"), TEXT("/"));
	
	return ResultString;
}

FString FOmniversePathHelper::RemoveQuery(const FString& OmniPath)
{
	FString OmniversePath = OmniPath;
	int32 SearchIndex = OmniversePath.Find("?");
	if (SearchIndex != INDEX_NONE)
	{
		OmniversePath = OmniversePath.Left(SearchIndex);
	}

	return OmniversePath;
}

FString FOmniversePathHelper::UniformOmniPath(const FString & OmniPath)
{
	FString OmniversePath;
	FOmniversePathHelper::UnmanglePath(OmniPath, OmniversePath);

	if (FPaths::IsDrive(OmniPath.Left(2)))
	{
		return OmniversePath;
	}

	if (OmniversePath.StartsWith(TEXT("http:")) || OmniversePath.StartsWith(TEXT("https:")))
	{
		return OmniversePath;
	}

	if (!OmniversePath.StartsWith("omniverse:") && !OmniversePath.StartsWith("omni:"))
	{
		if (OmniversePath.StartsWith("//"))
		{
			OmniversePath = "omniverse:" + OmniversePath;
		}
		else if (OmniversePath.StartsWith("/"))
		{
			OmniversePath = "omniverse:/" + OmniversePath;
		}
		else
		{
			OmniversePath = "omniverse://" + OmniversePath;
		}
	}

	FString Server = OmniversePath;
	FString AssetPath;
	Server.RemoveFromStart("omniverse://");
	int32 Index = Server.Find("/");
	if (Index != INDEX_NONE)
	{
		AssetPath = Server.RightChop(Index);
		Server = Server.Left(Index);
	}
	else
	{
		AssetPath = "/";
	}

	Index = Server.Find(":");
	if (Index != INDEX_NONE)
	{
		Server = Server.Left(Index);
	}

	return FString("omniverse://") + Server + AssetPath;
}

void FOmniversePathHelper::ManglePath(const FString& OmniPath, FString& OutUE4Path, bool bStartWithSlash)
{
	OutUE4Path.Empty();

	FString OmniPathWithoutPrefix = OmniPath;
	OmniPathWithoutPrefix.RemoveFromStart("omniverse:/");
	OmniPathWithoutPrefix.RemoveFromStart("omni:/");

	TArray<FString> OutFolderNames;
	OmniPathWithoutPrefix.ParseIntoArray(OutFolderNames, TEXT("/"));

	for (auto FolderName : OutFolderNames)
	{
		bool bMangledChar = false;
		auto CharArray = FolderName.GetCharArray();
		FString MangledFolderName;
		for (int32 Index = 0; Index < CharArray.Num() - 1; ++Index) // Skip the last \0
		{
			auto Char = CharArray[Index];
			if (IsValidUE4PathChar(Char))
			{
				MangledFolderName += Char;
			}
			else
			{
				MangledFolderName += TEXT("_") + FString::FromInt(Char) + TEXT("_");
				bMangledChar = true;
			}
		}

		// Force mangle if it's None FName, such as _0, _1
		if (FName(*FolderName).IsNone())
		{
			bMangledChar = true;
		}

		if (bMangledChar)
		{
			MangledFolderName += MangledPathPostfix;
		}

		OutUE4Path += ((OutUE4Path.IsEmpty() && !bStartWithSlash) ? TEXT("") : TEXT("/")) + MangledFolderName;
	}
}

void FOmniversePathHelper::UnmanglePath(const FString& UE4Path, FString& OmniPath, bool bStartWithSlash)
{
	OmniPath.Empty();

	TArray<FString> OutFolderNames;
	UE4Path.ParseIntoArray(OutFolderNames, TEXT("/"));

	for (auto FolderName : OutFolderNames)
	{
		if (FolderName.EndsWith(MangledPathPostfix))
		{
			FolderName.RemoveFromEnd(MangledPathPostfix);
			auto CharArray = FolderName.GetCharArray();
			FString MangledChar;
			bool bUnmangleChar = false;
			FString MangledFolderName;
			FString MangleFailed;
			for (int32 Index = 0; Index < CharArray.Num() - 1; ++Index) // Skip the last \0
			{
				auto Char = CharArray[Index];
				if (Char == '_')
				{
					if (!bUnmangleChar)
					{
						MangledChar.Empty();
						MangleFailed.Empty();
						MangleFailed += Char; // For in case unmanlge failed
						bUnmangleChar = true;
					}
					else
					{
						TCHAR* End = nullptr;
						TCHAR AtoiChar = TCHAR(FCString::Strtoi(*MangledChar, &End, 10));
						if (!IsValidUE4PathChar(AtoiChar))
						{
							// Found mangled
							MangledFolderName += AtoiChar;
							bUnmangleChar = false;
						}
						else
						{
							MangledFolderName += MangleFailed;
							// it's a new start
							MangledChar.Empty();
							MangleFailed.Empty();
							MangleFailed += Char; // For in case unmanlge failed
						}
					}
				}
				else if (bUnmangleChar)
				{
					MangledChar += Char;
					MangleFailed += Char;
				}
				else
				{
					MangledFolderName += Char;
				}
			}

			if (bUnmangleChar)
			{
				MangledFolderName += MangleFailed;
			}

			OmniPath += ((OmniPath.IsEmpty() && !bStartWithSlash) ? TEXT("") : TEXT("/")) + MangledFolderName;
		}
		else if (FolderName.EndsWith(TEXT(":")))
		{
			OmniPath += FolderName + TEXT("/");
		}
		else
		{
			OmniPath += ((OmniPath.IsEmpty() && !bStartWithSlash) ? TEXT("") : TEXT("/")) + FolderName;
		}
	}
}

FString FOmniversePathHelper::PrimPathToKey(const FString& PrimPath)
{
	FSHA1 HashState;
	FSHAHash OutHash;
	HashState.UpdateWithString(*PrimPath, PrimPath.Len());
	HashState.Final();
	HashState.GetHash(&OutHash.Hash[0]);
	FString OutKey = PrimPath + KeySeparator +OutHash.ToString();
	return OutKey;
}

FString FOmniversePathHelper::KeyToPrimPath(const FString& Key)
{
	int Index = Key.Find(KeySeparator);
	if (Index == INDEX_NONE)
	{
		return Key;
	}

	FString PrimPath = Key.Left(Index);
	FString HashString = Key.RightChop(Index + KeySeparator.Len());
	// Check PrimPath
	FSHA1 HashState;
	FSHAHash OutHash;
	HashState.UpdateWithString(*PrimPath, PrimPath.Len());
	HashState.Final();
	HashState.GetHash(&OutHash.Hash[0]);

	if (HashString == OutHash.ToString())
	{
		return PrimPath;
	}

	return Key;
}

FString FOmniversePathHelper::NormalizeUrl(const FString& Url)
{
	FString ReturnUrl = Url;
	size_t BufferSize = 0;
    omniClientNormalizeUrl(TCHAR_TO_UTF8(*Url), nullptr, &BufferSize);
    if (BufferSize != 0)
	{
		FCharAllocator Buffer(BufferSize);
		const char* NormalizedUrl = omniClientNormalizeUrl(TCHAR_TO_UTF8(*Url), Buffer.GetData(), &BufferSize);
		ReturnUrl = Buffer.GetData();
	}
	
	return ReturnUrl;
}

bool FOmniversePathHelper::IsPackagePath(const FString& Path)
{
	return (Path.Contains("[") && Path.EndsWith("]"));
}

FString FOmniversePathHelper::GetPackageRoot(const FString& Path)
{
	if (IsPackagePath(Path))
	{
		int32 End = Path.Find("[");
		return Path.Mid(0, End);
	}

	return FString();
}

FString FOmniversePathHelper::GetPackagedSubPath(const FString& Path)
{
	if (IsPackagePath(Path))
	{
		int32 Start = Path.Find("[") + 1;
		return Path.Mid(Start, Path.Len() - 1 - Start);
	}

	return FString();
}

FString FOmniversePathHelper::GetLiveRootPath(const FString& OmniPath)
{
	auto ClientUrl = omniClientBreakUrl(TCHAR_TO_UTF8(*OmniPath));
	if (!ClientUrl)
	{
		return FString();
	}
	FString LiveFolder = FPaths::GetPath(ClientUrl->path) / TEXT(".live");
	// convert string macro declare have very short lifetimes, must save to std::string
	std::string FolderStr = TCHAR_TO_UTF8(*LiveFolder);
	ClientUrl->path = FolderStr.c_str();
	size_t ExpectedSize = 0;
	omniClientMakeUrl(ClientUrl, nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientMakeUrl(ClientUrl, Buffer.GetData(), &ExpectedSize);
	return Buffer.GetData();
}

FString FOmniversePathHelper::GetLiveFolderPath(const FString& OmniPath)
{
	auto ClientUrl = omniClientBreakUrl(TCHAR_TO_UTF8(*OmniPath));
	if (!ClientUrl)
	{
		return FString();
	}
	FString LiveFolder = FPaths::GetPath(ClientUrl->path) / TEXT(".live") / FPaths::GetBaseFilename(ClientUrl->path) + TEXT(".live");
	// convert string macro declare have very short lifetimes, must save to std::string
	std::string FolderStr = TCHAR_TO_UTF8(*LiveFolder);
	ClientUrl->path = FolderStr.c_str();
	size_t ExpectedSize = 0;
	omniClientMakeUrl(ClientUrl, nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientMakeUrl(ClientUrl, Buffer.GetData(), &ExpectedSize);
	return Buffer.GetData();
}

FString FOmniversePathHelper::GetLiveSessionPath(const FString& OmniPath, const FString& SessionName)
{
	auto ClientUrl = omniClientBreakUrl(TCHAR_TO_UTF8(*OmniPath));
	if (!ClientUrl)
	{
		return FString();
	}

	FString SessionFolder = FPaths::GetPath(ClientUrl->path) / TEXT(".live") / (FPaths::GetBaseFilename(ClientUrl->path) + TEXT(".live")) / (SessionName + TEXT(".live/"));
	// convert string macro declare have very short lifetimes, must save to std::string
	std::string SessionStr = TCHAR_TO_UTF8(*SessionFolder);
	ClientUrl->path = SessionStr.c_str();
	size_t ExpectedSize = 0;
	omniClientMakeUrl(ClientUrl, nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientMakeUrl(ClientUrl, Buffer.GetData(), &ExpectedSize);
	return Buffer.GetData();
}

FString FOmniversePathHelper::GetLiveSessionLayerPath(const FString& OmniPath, const FString& SessionName)
{
	auto ClientUrl = omniClientBreakUrl(TCHAR_TO_UTF8(*OmniPath));
	if (!ClientUrl)
	{
		return FString();
	}

	FString SessionFile = FPaths::GetPath(ClientUrl->path) / TEXT(".live") / (FPaths::GetBaseFilename(ClientUrl->path) + TEXT(".live")) / (SessionName + TEXT(".live")) / LiveSessionFileName;
	// convert string macro declare have very short lifetimes, must save to std::string
	std::string SessionStr = TCHAR_TO_UTF8(*SessionFile);
	ClientUrl->path = SessionStr.c_str();
	size_t ExpectedSize = 0;
	omniClientMakeUrl(ClientUrl, nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientMakeUrl(ClientUrl, Buffer.GetData(), &ExpectedSize);
	return Buffer.GetData();
}

FString FOmniversePathHelper::GetLiveSessionChannelPath(const FString& OmniPath, const FString& SessionName)
{
	auto ClientUrl = omniClientBreakUrl(TCHAR_TO_UTF8(*OmniPath));
	if (!ClientUrl)
	{
		return FString();
	}

	FString ChannelFile = FPaths::GetPath(ClientUrl->path) / TEXT(".live") / (FPaths::GetBaseFilename(ClientUrl->path) + TEXT(".live")) / (SessionName + TEXT(".live")) / LiveSessionChannelFileName;
	// convert string macro declare have very short lifetimes, must save to std::string
	std::string ChannelStr = TCHAR_TO_UTF8(*ChannelFile);
	ClientUrl->path = ChannelStr.c_str();
	size_t ExpectedSize = 0;
	omniClientMakeUrl(ClientUrl, nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientMakeUrl(ClientUrl, Buffer.GetData(), &ExpectedSize);
	return Buffer.GetData();
}

FString FOmniversePathHelper::GetLiveSessionConfigPath(const FString& OmniPath, const FString& SessionName)
{
	auto ClientUrl = omniClientBreakUrl(TCHAR_TO_UTF8(*OmniPath));
	if (!ClientUrl)
	{
		return FString();
	}

	FString TomlFile = FPaths::GetPath(ClientUrl->path) / TEXT(".live") / (FPaths::GetBaseFilename(ClientUrl->path) + TEXT(".live")) / (SessionName + TEXT(".live")) / LiveSessionTomlFileName;
	// convert string macro declare have very short lifetimes, must save to std::string
	std::string TomlStr = TCHAR_TO_UTF8(*TomlFile);
	ClientUrl->path = TomlStr.c_str();
	size_t ExpectedSize = 0;
	omniClientMakeUrl(ClientUrl, nullptr, &ExpectedSize);
	FCharAllocator Buffer(ExpectedSize);
	omniClientMakeUrl(ClientUrl, Buffer.GetData(), &ExpectedSize);
	return Buffer.GetData();
}

bool FOmniversePathHelper::ParseVersion(const FString& Version, int32& MajorVersion, int32& MinorVersion)
{
	MajorVersion = 0;
	MinorVersion = 0;
	TArray<FString> OutParsedArray;
	Version.ParseIntoArray(OutParsedArray, TEXT("."));
	if (OutParsedArray.Num() > 1)
	{
		// Only take the first 2 string
		MajorVersion = FCString::Atoi(*OutParsedArray[0]);
		MinorVersion = FCString::Atoi(*OutParsedArray[1]);
		return true;
	}

	return false;
}