// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseSettings.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseRuntimePrivate.h"
#include "OmniverseCollaboration.h"

UOmniverseSettings::UOmniverseSettings()
{
	// WatchServers.AddUnique(OMNIVERSE_LOCAL_SERVER);
}

#if WITH_EDITOR
void UOmniverseSettings::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	IOmniverseRuntimeModule::Get().EnableDeveloperLog(bOpenDeveloperLog);

	// Check if server setting changed
	static const TArray<FString> Properties = {
		GET_MEMBER_NAME_STRING_CHECKED(UOmniverseSettings, WatchServers),
	};

	if (PropertyChangedEvent.MemberProperty != nullptr
		&& Properties.Find(PropertyChangedEvent.MemberProperty->GetName()) >= 0
		)
	{
		IOmniverseRuntimeModule& OmniModule = IOmniverseRuntimeModule::Get();
		OmniModule.WatchServers(WatchServers, true);
	}
}
#endif
