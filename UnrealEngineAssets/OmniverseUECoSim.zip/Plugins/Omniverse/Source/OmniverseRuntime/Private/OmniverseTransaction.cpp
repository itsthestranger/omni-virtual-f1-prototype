// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseTransaction.h"
#include "Editor/EditorEngine.h"
#include "Editor/TransBuffer.h"

UOmniverseTransaction::UOmniverseTransaction()
{
	SetFlags(EObjectFlags::RF_Transactional);

	if(HasAllFlags(EObjectFlags::RF_ClassDefaultObject))
	{
		return;
	}

	UEditorEngine* EditorEngine = Cast<UEditorEngine>(GEngine);
	if(!EditorEngine)
	{
		return;
	}

	UTransBuffer* TransBuffer = Cast<UTransBuffer>(EditorEngine->Trans);
	if(!TransBuffer)
	{
		return;
	}

	TransBuffer->OnUndo().AddUObject(this, &UOmniverseTransaction::OnUndo);
	TransBuffer->OnRedo().AddUObject(this, &UOmniverseTransaction::OnRedo);
	TransBuffer->OnTransactionStateChanged().AddUObject(this, &UOmniverseTransaction::OnTransactionStateChanged);
}

bool UOmniverseTransaction::AddTransaction(const FUndoDelegate& UndoDelegate)
{
	if(!Super::Modify())
	{
		return false;
	}

	// NOTE: Mark the transaction isn't transient.
	// See GUndo->IsTransient() in EditorTransaction.cpp
	++ChangedTransaction;

	if(UndoBuffer.Num() > 0)
	{
		UndoBuffer.Last().Push(UndoDelegate);
	}

	RedoBuffer.Empty();

	return true;
}

void UOmniverseTransaction::OnUndo(const FTransactionContext& TransactionContext, bool Succeeded)
{
	if(!Succeeded || UndoBuffer.Num() < 1)
	{
		return;
	}

	auto Delegates = UndoBuffer.Pop();

	for(int I = Delegates.Num() - 1; I >= 0; --I)
	{
		Delegates[I].ExecuteIfBound(EUndoType::Undo);
	}

	RedoBuffer.Push(MoveTemp(Delegates));
}

void UOmniverseTransaction::OnRedo(const FTransactionContext& TransactionContext, bool Succeeded)
{
	if(!Succeeded || RedoBuffer.Num() < 1)
	{
		return;
	}

	auto Delegates = RedoBuffer.Pop();
	for(auto& Delegate : Delegates)
	{
		Delegate.ExecuteIfBound(EUndoType::Redo);
	}

	UndoBuffer.Push(MoveTemp(Delegates));
}

void UOmniverseTransaction::OnTransactionStateChanged(const FTransactionContext& TransactionContext, ETransactionStateEventType TransactionState)
{
	switch(TransactionState)
	{
	case ETransactionStateEventType::TransactionStarted:
		UndoBuffer.AddDefaulted();
		OnTransactionChanged.Broadcast(ETransactionChange::Beginned);
		break;
	case ETransactionStateEventType::TransactionFinalized:
		OnTransactionChanged.Broadcast(ETransactionChange::Ending);
		break;
	case ETransactionStateEventType::TransactionCanceled:
		OnTransactionChanged.Broadcast(ETransactionChange::Ending);
		UndoBuffer.Pop();
		break;
	}
}
