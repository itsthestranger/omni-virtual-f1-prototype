// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseMDLExporter.h"
#include "OmniverseMDL.h"
#include "OmniverseAssetUserData.h"
#include "Materials/Material.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceConstant.h"
#include "MDLExporterUtility.h"


bool FOmniverseMDLExporter::ExportMDL(UMaterialInterface* InMaterial, const FString& InName, FString& MDL)
{
	auto MaterialInstance = Cast<UMaterialInstanceConstant>(InMaterial);

	if (MaterialInstance)
	{
		UOmniverseAssetUserData* OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(MaterialInstance->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
		if (!OmniverseAssetUserData)
		{
			auto Material = MaterialInstance->Parent;
			// check if parent was from Omniverse
			while(auto Instance = Cast<UMaterialInstanceConstant>(Material))
			{
				Material = Instance->Parent;
			}

			if (Material)
			{
				OmniverseAssetUserData = Cast<UOmniverseAssetUserData>(Material->GetAssetUserDataOfClass(UOmniverseAssetUserData::StaticClass()));
			}
		}

		if (OmniverseAssetUserData && OmniverseAssetUserData->OmniAsset)
		{
			UOmniverseMDL* OmniverseMDL = CastChecked<UOmniverseMDL>(OmniverseAssetUserData->OmniAsset);
			if (OmniverseMDL)
			{
				return OmniverseMDL->ExportPreset(MaterialInstance, InName, false, MDL);
			}
		}
	}
	return false;
}

void FOmniverseMDLExporter::Init()
{
	FMDLExporterUtility::ExternalExporter = MakeShareable<FOmniverseMDLExporter>(new FOmniverseMDLExporter());
}

void FOmniverseMDLExporter::Shutdown()
{
	FMDLExporterUtility::ExternalExporter = nullptr;
}