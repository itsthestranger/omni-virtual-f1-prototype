// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseSlowTask.h"
#include "Misc/FeedbackContext.h"
#include "CoreGlobals.h"

FOmniverseSlowTask& FOmniverseSlowTask::Get()
{
	static FOmniverseSlowTask Singleton;
	return Singleton;
}

FOmniverseSlowTask::FOmniverseSlowTask()
{
}

FOmniverseSlowTask::~FOmniverseSlowTask()
{
}

void FOmniverseSlowTask::BeginProgress(float InAmountOfWork, const FText& InDefaultMessage, bool ShowProgressDialog, bool bShowCancelButton)
{
	TUniquePtr<FSlowTask> TempTask(new FSlowTask(InAmountOfWork, InDefaultMessage));
	SlowTask = MoveTemp(TempTask);
	SlowTask->Initialize();

	if (ShowProgressDialog)
	{
		SlowTask->Visibility = ESlowTaskVisibility::ForceVisible;
		SlowTask->MakeDialog(bShowCancelButton);
	}
}

bool FOmniverseSlowTask::IsProgressCancelled()
{
	if (SlowTask.IsValid())
	{
		return SlowTask->ShouldCancel();
	}

	return GWarn->ReceivedUserCancel();
}

void FOmniverseSlowTask::UpdateProgress(float ExpectedWorkThisFrame, const FText& Text)
{
	if (SlowTask.IsValid())
	{
		SlowTask->EnterProgressFrame(ExpectedWorkThisFrame, Text);
	}
}

void FOmniverseSlowTask::EndProgress()
{
	if (SlowTask.IsValid())
	{
		SlowTask->Destroy();
		SlowTask.Reset();
	}
}
