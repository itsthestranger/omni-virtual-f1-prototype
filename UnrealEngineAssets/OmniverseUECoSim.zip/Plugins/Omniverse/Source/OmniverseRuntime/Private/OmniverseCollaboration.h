// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "IOmniverseCollaboration.h"
#include "IOmniverseRuntimeModule.h"

class FOmniverseChannel;
class FOmniverseCollaboration : public IOmniverseCollaboration
{
public:
	static TSharedRef<FOmniverseCollaboration> Get();

	virtual ~FOmniverseCollaboration();

	void StartListening();

	void StopListening();

	virtual void Subscribe(const FString& Channel) override;

	virtual void Unsubscribe() override;

	virtual void SendMessage(const FOmniverseMessage& Message) override;

	virtual void SendMessage(EOmniverseMessageType MessageType) override;

private:
	FOmniverseCollaboration();

	void StopListeningInternal();

	void StartListeningInternal();

	void OnConnectionChanged(const FString& Server, EOmniverseServerConnectionChange ConnectionChange);

	TSharedPtr<FOmniverseChannel> ListensingChannel;

	FDelegateHandle ConnectionChanged;
};