// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseMessageLogContext.h"
#include "MessageLogModule.h"
#include "IMessageLogListing.h"
#include "Modules/ModuleManager.h"

void FOmniverseMessageLogContext::AddMessage(EMessageSeverity::Type MessageSeverity, FText Message)
{
	const TCHAR* LogTitle = TEXT("Omniverse");
	FMessageLogModule& MessageLogModule = FModuleManager::LoadModuleChecked<FMessageLogModule>("MessageLog");
	TSharedPtr<class IMessageLogListing> LogListing = MessageLogModule.GetLogListing(LogTitle);

	LogListing->AddMessage(FTokenizedMessage::Create(MessageSeverity, Message));
}

void FOmniverseMessageLogContext::AddMessage(const TSharedRef< class FTokenizedMessage >& Message)
{
	const TCHAR* LogTitle = TEXT("Omniverse");
	FMessageLogModule& MessageLogModule = FModuleManager::LoadModuleChecked<FMessageLogModule>("MessageLog");
	TSharedPtr<class IMessageLogListing> LogListing = MessageLogModule.GetLogListing(LogTitle);

	LogListing->AddMessage(Message);
}

void FOmniverseMessageLogContext::ClearMessages()
{
	const TCHAR* LogTitle = TEXT("Omniverse");
	FMessageLogModule& MessageLogModule = FModuleManager::LoadModuleChecked<FMessageLogModule>("MessageLog");
	TSharedPtr<class IMessageLogListing> LogListing = MessageLogModule.GetLogListing(LogTitle);
	LogListing->ClearMessages();
}

void FOmniverseMessageLogContext::DisplayMessages()
{
	//Always clear the old message after an import or re-import
	const TCHAR* LogTitle = TEXT("Omniverse");
	FMessageLogModule& MessageLogModule = FModuleManager::LoadModuleChecked<FMessageLogModule>("MessageLog");
	TSharedPtr<class IMessageLogListing> LogListing = MessageLogModule.GetLogListing(LogTitle);
	LogListing->SetLabel(FText::FromString(LogTitle));
	if (LogListing->NumMessages(EMessageSeverity::Info) > 0)
	{
		MessageLogModule.OpenMessageLog(LogTitle);
	}
}