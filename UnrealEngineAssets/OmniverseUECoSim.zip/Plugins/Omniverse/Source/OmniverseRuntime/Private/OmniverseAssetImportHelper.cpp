// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseAssetImportHelper.h"

#include "Animation/Skeleton.h"
#include "Modules/ModuleManager.h"
#include "Engine/StaticMesh.h"
#include "Engine/SkeletalMesh.h"
#include "Rendering/SkeletalMeshLODModel.h"
#include "Rendering/SkeletalMeshModel.h"
#include "Rendering/SkeletalMeshRenderData.h"
#include "Rendering/SkeletalMeshLODRenderData.h"
#include "Rendering/SkeletalMeshLODImporterData.h"
#include "Factories/FbxSkeletalMeshImportData.h"
#include "ImportUtils/SkeletalMeshImportUtils.h"
#include "MeshUtilities.h"

DEFINE_LOG_CATEGORY(LogOmniverseAssetImport);

USkeletalMesh* FOmniverseAssetImportHelper::CreateSkeletalMeshFromImportData(UPackage* Package, FName Name, EObjectFlags Flag, FSkeletalMeshImportData& SkelMeshImportData, const FString& SkelMeshName)
{
	USkeletalMesh* SkeletalMesh = NewObject<USkeletalMesh>(Package, Name, Flag);

	if (LoadSkeletalMeshFromImportData(SkeletalMesh, SkelMeshImportData, SkelMeshName))
	{
		return SkeletalMesh;
	}

	SkeletalMesh->ClearFlags(RF_Standalone);
	SkeletalMesh->Rename(NULL, GetTransientPackage(), REN_DontCreateRedirectors);
	return nullptr;
}

bool FOmniverseAssetImportHelper::LoadSkeletalMeshFromImportData(USkeletalMesh* SkeletalMesh, FSkeletalMeshImportData& SkelMeshImportData, const FString& SkelMeshName)
{
	if (SkeletalMesh == nullptr)
	{
		return false;
	}

	// One-to-one mapping from import to raw. Needed for BuildSkeletalMesh
	SkelMeshImportData.PointToRawMap.AddUninitialized(SkelMeshImportData.Points.Num());
	for (int32 PointIndex = 0; PointIndex < SkelMeshImportData.Points.Num(); ++PointIndex)
	{
		SkelMeshImportData.PointToRawMap[PointIndex] = PointIndex;
	}

	// Create initial bounding box based on expanded version of reference pose for meshes without physics assets
	FBox3f BoundingBox(SkelMeshImportData.Points.GetData(), SkelMeshImportData.Points.Num());
	FBox3f Temp = BoundingBox;
	FVector3f MidMesh = 0.5f*(Temp.Min + Temp.Max);
	BoundingBox.Min = Temp.Min + 1.0f*(Temp.Min - MidMesh);
	BoundingBox.Max = Temp.Max + 1.0f*(Temp.Max - MidMesh);
	BoundingBox.Min[2] = Temp.Min[2] + 0.1f*(Temp.Min[2] - MidMesh[2]);
	const FVector3f BoundingBoxSize = BoundingBox.GetSize();

	if (SkelMeshImportData.Points.Num() > 2 && BoundingBoxSize.X < THRESH_POINTS_ARE_SAME && BoundingBoxSize.Y < THRESH_POINTS_ARE_SAME && BoundingBoxSize.Z < THRESH_POINTS_ARE_SAME)
	{
		return false;
	}

	SkeletalMesh->PreEditChange(nullptr);
	//Dirty the DDC Key for any imported Skeletal Mesh
	SkeletalMesh->InvalidateDeriveDataCacheGUID();

	FSkeletalMeshModel* ImportedModel = SkeletalMesh->GetImportedModel();
	ImportedModel->LODModels.Empty();
	ImportedModel->EmptyOriginalReductionSourceMeshData();
	ImportedModel->LODModels.Add(new FSkeletalMeshLODModel());
	FSkeletalMeshLODModel& LODModel = ImportedModel->LODModels[0];

	// Process materials from import data
	//ProcessImportMeshMaterials(SkeletalMesh->Materials, SkelMeshImportData);
	{
		SkeletalMesh->GetMaterials().Empty();
		for (int32 MatIndex = 0; MatIndex < SkelMeshImportData.Materials.Num(); ++MatIndex)
		{
			const SkeletalMeshImportData::FMaterial& ImportedMaterial = SkelMeshImportData.Materials[MatIndex];
			UMaterialInterface* Material = ImportedMaterial.Material.Get() ? ImportedMaterial.Material.Get() : LoadObject<UMaterialInterface>(nullptr, TEXT("/Omniverse/DefaultMaterial"));
			FString MaterialNameNoSkin = ImportedMaterial.MaterialImportName;	
			SkeletalMesh->GetMaterials().Add(FSkeletalMaterial(Material, true, false, FName(*ImportedMaterial.MaterialImportName), FName(*ImportedMaterial.MaterialImportName)));
		}
	}

	// Process reference skeleton from import data
	int32 SkeletalDepth = 0;
	if (!SkeletalMeshImportUtils::ProcessImportMeshSkeleton(nullptr, SkeletalMesh->GetRefSkeleton(), SkeletalDepth, SkelMeshImportData))
	{
		return false;
	}

	// Process bones influence (normalization and optimization); this is not strictly needed for SkeletalMesh to work
	SkeletalMeshImportUtils::ProcessImportMeshInfluences(SkelMeshImportData, SkelMeshName);

	// Serialize the import data when needed
	//LODModel.RawSkeletalMeshBulkData.SaveRawMesh(SkelMeshImportData);

	SkeletalMesh->ResetLODInfo();
	FSkeletalMeshLODInfo& NewLODInfo = SkeletalMesh->AddLODInfo();
	NewLODInfo.ReductionSettings.NumOfTrianglesPercentage = 1.0f;
	NewLODInfo.ReductionSettings.NumOfVertPercentage = 1.0f;
	NewLODInfo.ReductionSettings.MaxDeviationPercentage = 0.0f;
	NewLODInfo.LODHysteresis = 0.02f;
	NewLODInfo.BuildSettings.bUseFullPrecisionUVs = true;
	NewLODInfo.BuildSettings.bUseHighPrecisionTangentBasis = true;

	SkeletalMesh->SetImportedBounds(FBoxSphereBounds((FBox)BoundingBox));

	// Store whether or not this mesh has vertex colors
	SkeletalMesh->SetHasVertexColors(SkelMeshImportData.bHasVertexColors);
	SkeletalMesh->SetVertexColorGuid(SkeletalMesh->GetHasVertexColors() ? FGuid::NewGuid() : FGuid());

	// Pass the number of texture coordinate sets to the LODModel.  Ensure there is at least one UV coord
	LODModel.NumTexCoords = FMath::Max<uint32>(1, SkelMeshImportData.NumTexCoords);

	// Create the render data
	{
		TArray<FVector3f> LODPoints;
		TArray<SkeletalMeshImportData::FMeshWedge> LODWedges;
		TArray<SkeletalMeshImportData::FMeshFace> LODFaces;
		TArray<SkeletalMeshImportData::FVertInfluence> LODInfluences;
		TArray<int32> LODPointToRawMap;
		SkelMeshImportData.CopyLODImportData(LODPoints, LODWedges, LODFaces, LODInfluences, LODPointToRawMap);

		IMeshUtilities::MeshBuildOptions BuildOptions;
		// #ueent_todo: Normals and tangents shouldn't need to be recomputed when they are retrieved from USD
		BuildOptions.bComputeNormals = !SkelMeshImportData.bHasNormals;
		BuildOptions.bComputeTangents = !SkelMeshImportData.bHasTangents;

		IMeshUtilities& MeshUtilities = FModuleManager::Get().LoadModuleChecked<IMeshUtilities>("MeshUtilities");

		TArray<FText> WarningMessages;
		TArray<FName> WarningNames;

		bool bBuildSuccess = MeshUtilities.BuildSkeletalMesh(ImportedModel->LODModels[0], SkelMeshName, SkeletalMesh->GetRefSkeleton(), LODInfluences, LODWedges, LODFaces, LODPoints, LODPointToRawMap, BuildOptions, &WarningMessages, &WarningNames);
		        
        for (int32 WarningIndex = 0; WarningIndex < FMath::Max(WarningMessages.Num(), WarningNames.Num()); ++WarningIndex)
        {
            const FText& Text = WarningMessages.IsValidIndex(WarningIndex) ? WarningMessages[WarningIndex] : FText::GetEmpty();
            const FName& Name = WarningNames.IsValidIndex(WarningIndex) ? WarningNames[WarningIndex] : NAME_None;

            if (bBuildSuccess)
            {
                UE_LOG(LogOmniverseAssetImport, Warning, TEXT("When trying to build skeletal mesh from USD: '%s': '%s'"), *Name.ToString(), *Text.ToString());
            }
            else
            {
                UE_LOG(LogOmniverseAssetImport, Error, TEXT("When trying to build skeletal mesh from USD: '%s': '%s'"), *Name.ToString(), *Text.ToString());
            }
        }
		
		if (!bBuildSuccess)
		{
			return false;
		}

		SkeletalMesh->CalculateInvRefMatrices();
		SkeletalMesh->PostEditChange();
	}

	if (SkeletalMesh->GetRefSkeleton().GetRawBoneNum() == 0)
	{
		return false;
	}

	return true;
}

void FOmniverseAssetImportHelper::InitStaticMeshRenderData(UStaticMesh& StaticMesh)
{
	// Initialize static mesh render data in OmniverseRuntime module to avoid USD memory allocation
	// Create render data
	if (!StaticMesh.GetRenderData())
	{
		StaticMesh.SetRenderData(MakeUnique<FStaticMeshRenderData>());
	}

	// Release resources
	StaticMesh.ReleaseResources();

	// Create necessary LOD and vertex factory
	if (StaticMesh.GetRenderData()->LODResources.Num() <= 0)
	{
		StaticMesh.GetRenderData()->AllocateLODResources(1);
	}

	FStaticMeshLODResources& LODRes = StaticMesh.GetRenderData()->LODResources[0];
	LODRes.VertexBuffers.StaticMeshVertexBuffer.SetUseHighPrecisionTangentBasis(true);
	LODRes.VertexBuffers.StaticMeshVertexBuffer.SetUseFullPrecisionUVs(true);
}