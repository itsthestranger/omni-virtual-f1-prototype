// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseFileHandle.h"
#include "OmniverseConnectionHelper.h"

FOmniverseFileHandle::FOmniverseFileHandle(TSharedOmniContentPtr InContent)
	: Content(InContent)
	, CurrentPosition(0)
{
}

FOmniverseFileHandle::~FOmniverseFileHandle()
{
	Content = nullptr;
}

int64 FOmniverseFileHandle::Tell()
{
	return 0;
}

bool FOmniverseFileHandle::Seek(int64 NewPosition)
{
	if (NewPosition >= 0 && NewPosition < Size())
	{
		CurrentPosition = NewPosition;
		return true;
	}
	return false;
}

bool FOmniverseFileHandle::SeekFromEnd(int64 NewPositionRelativeToEnd)
{
	if (NewPositionRelativeToEnd <= 0 && NewPositionRelativeToEnd > -Size())
	{
		CurrentPosition = Size() - 1 + NewPositionRelativeToEnd;
		return true;
	}
	return false;
}

bool FOmniverseFileHandle::Read(uint8* Destination, int64 BytesToRead)
{
	if (Destination == nullptr || BytesToRead <= 0)
	{
		return false;
	}

	if (BytesToRead > Size() - CurrentPosition)
	{
		BytesToRead = Size() - CurrentPosition;
	}

	FMemory::Memcpy(Destination, Content->GetData() + CurrentPosition, BytesToRead);
	return true;
}

bool FOmniverseFileHandle::Write(const uint8* Source, int64 BytesToWrite)
{
	return false;
}

bool FOmniverseFileHandle::Flush(const bool bFullFlush)
{
	return false;
}

bool FOmniverseFileHandle::Truncate(int64 NewSize)
{
	return false;
}

int64 FOmniverseFileHandle::Size()
{
	return Content->Size();
}