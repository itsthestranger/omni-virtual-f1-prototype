// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"

class FOmniverseMDLHelper
{
public:
	FOmniverseMDLHelper(uint8* Data, int32 Size);
	~FOmniverseMDLHelper();

	bool ExtractMaterial(const FString& MaterialName);
	void SetExportName(const FString& ExportName);
	void SetValue(const FString& Name, bool Value, bool bLastValue);
	void SetValue(const FString& Name, float Value, bool bLastValue);
	void SetValue(const FString& Name, int32 Value, bool bLastValue);
	void SetValue(const FString& Name, FLinearColor Value, int32 Channels, bool bColor, bool bLastValue);
	void SetValue(const FString& Name, class UTexture* Value, const FString& RelativePath, bool bCubemap, bool bLastValue);

	FString GetFinalOutput() { return FinalOutput; }
private:
	void RemoveComment(char* Start, int32 Size);
	void AppendParamToFinal(const FString& Param, bool bLastValue);

	FString OriginMDLWithoutComment;
	FString CustomExportName;
	FString FinalOutput;
	int32 SearchPosition;
};