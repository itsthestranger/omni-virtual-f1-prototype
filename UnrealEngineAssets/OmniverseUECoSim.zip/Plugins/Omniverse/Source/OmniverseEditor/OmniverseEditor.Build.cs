// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

namespace UnrealBuildTool.Rules
{
	public class OmniverseEditor : ModuleRules
	{
		public OmniverseEditor(ReadOnlyTargetRules Target) : base(Target)
		{
            bUseRTTI = true;
            PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;    // For game module

			PrivateDependencyModuleNames.AddRange(new string[]{
				"ApplicationCore",
				"Core",
				"CoreUObject",
				"Engine",
				"MainFrame",
				"InputCore",
				"SlateCore",
				"Slate",
				"LevelEditor",
				"ContentBrowser",
				"UnrealEd",
				"Kismet",
				"Projects",
				"EditorStyle",
				"MovieSceneCapture",
				"MovieScene",
				"LevelSequence",
				"SourceControl",
                "DesktopPlatform",
				"PropertyEditor",
				"TypedElementFramework",
				"ContentBrowserData",
			});

			PublicDependencyModuleNames.AddRange(new string[]{
				"Engine",
				"OmniverseRuntime",
				"OmniverseUSD",
			});
		}
	}
}
