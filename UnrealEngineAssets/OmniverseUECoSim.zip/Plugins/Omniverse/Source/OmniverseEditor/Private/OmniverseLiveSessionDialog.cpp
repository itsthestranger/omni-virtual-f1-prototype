// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseLiveSessionDialog.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SComboBox.h"
#include "Interfaces/IMainFrameModule.h"
#include "OmniverseEditorExportUtils.h"
#include "OmniverseContentManager.h" 
#include "OmniversePathHelper.h"
#include "Editor.h"
#include "Styling/AppStyle.h"
#include "OmniverseUSDHelper.h"
#include "OmniverseStageActor.h"
#include "OmniverseUSD.h"
#include "DesktopPlatformModule.h"
#include "OmniverseMessageLogContext.h"
#include "OmniverseLiveSessionNotifications.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseConnectionHelper.h"
#include "IOmniverseCollaboration.h"
#include "IOmniverseSessionConfig.h"
#include <regex>


#define LOCTEXT_NAMESPACE "OmniverseEditor"

TWeakPtr<class SOmniverseLiveSessionDialog> SOmniverseLiveSessionDialog::DialogPtr = nullptr;
FName SOmniverseLiveSessionDialog::LastSelectSession = NAME_None;
const std::regex LayerNamePattern("^[a-zA-Z][a-zA-Z0-9_-]*");

void SOmniverseLiveSessionDialog::Construct(const FArguments& InArgs, UOmniverseUSD* USD)
{
	const float MinWidth = 250.0f;
	USDAsset = USD;
	SessionAddedHandle = USDAsset->OnLiveSessionAdded.AddLambda(
	[]( const FName& Session)
	{
		SOmniverseLiveSessionDialog::AddSession(Session);
	} );
	SessionRemovedHandle = USDAsset->OnLiveSessionRemoved.AddLambda(
	[]( const FName& Session)
	{
		SOmniverseLiveSessionDialog::RemoveSession(Session);
	} );

	TickDelegateHandle = FSlateApplication::Get().GetOnModalLoopTickEvent().AddLambda(
		[](float DeltaTime)
		{
			FCoreDelegates::OnBeginFrame.Broadcast();
			FPlatformProcess::Sleep(0.01f);
			FCoreDelegates::OnEndFrame.Broadcast();
		}
	);

	auto OmniversePath = USDAsset->GetOmniPath();
	bool bFoundLastSelection = false;
	for(auto Name : USDAsset->GetLiveSessionList())
	{
		if (LastSelectSession.IsEqual(Name))
		{
			bFoundLastSelection = true;
		}
		SessionList.Add(MakeShared<FName>(Name));
	}
	if (!bFoundLastSelection)
	{
		LastSelectSession = NAME_None;
	}

	if (SessionList.Num() > 0)
	{
		LiveSessionChoices = ELiveSessionChoices::JoinSession;

		if (!LastSelectSession.IsNone())
		{
			SetSession(LastSelectSession);
		}
		else
		{
			SetSession(*SessionList[0]);
		}
	}
	else
	{
		LiveSessionChoices = ELiveSessionChoices::CreateSession;
	}

	SAssignNew(SessionCombobox, SComboBox<TSharedPtr<FName>>)
		.OptionsSource(&SessionList)
		.OnSelectionChanged_Lambda([&](TSharedPtr<FName> Item, ESelectInfo::Type SelectInfo)
		{
			if (Item)
			{
				SetSession(*Item);
			}
		})
		.OnGenerateWidget_Lambda([](TSharedPtr<FName> InItem)
		{
			return SNew(STextBlock).Text(FText::FromName(InItem.IsValid() ? *InItem : NAME_None));
		})
		.Content()
		[
			SNew(STextBlock)
			.Text_Lambda([&]()
			{
				return FText::FromName(LastSelectSession.IsNone() ? TEXT("No Existing Sessions") : LastSelectSession);
			})
		];

	SAssignNew( UserListView, SListView<TSharedPtr<FName>> )
	.ListItemsSource(&DisplayUserList)
	.SelectionMode(ESelectionMode::None)
	.OnGenerateRow_Lambda([](TSharedPtr<FName> Item, const TSharedRef<STableViewBase>& OwnerTable){
		return SNew( STableRow< TSharedPtr<FString> >, OwnerTable )
			.Style(FAppStyle::Get(), "DataTableEditor.CellListViewRow")
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				[
					SNew(STextBlock)
					.Text(FText::FromName(*Item.Get()))
				]
			];
	});

	TSharedRef<SWidgetSwitcher> WidgetSwitcher = SNew( SWidgetSwitcher )
		.WidgetIndex_Lambda( [&]() -> int32
			{
				if( LiveSessionChoices == ELiveSessionChoices::JoinSession )
				{
					return static_cast<int32>( ELiveSessionChoices::JoinSession );
				}
				else
				{
					return static_cast<int32>( ELiveSessionChoices::CreateSession );
				}
			} 
		);

	WidgetSwitcher->AddSlot( static_cast<int32>( ELiveSessionChoices::JoinSession ) )
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SessionCombobox.ToSharedRef()
		]
		+ SVerticalBox::Slot()
		.Padding(0, 20, 0, 0)
		[
			SNew(SHorizontalBox)
			+SHorizontalBox::Slot()
			.FillWidth(1)
			[
				SNew(SVerticalBox)
				+SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(STextBlock).Text(FText::FromString("Participants:"))
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.VAlign(VAlign_Top)
				.HAlign(HAlign_Left)
				[
					SNew(SBox)
					.MinDesiredHeight(32)
					.MaxDesiredHeight(32)
					.MinDesiredWidth(32)
					.MaxDesiredWidth(32)
					[
						SNew(SImage).Image(FSlateIcon("OmniverseEditorStyle", "OmniverseLiveSessionDialog.Participant").GetIcon())
					]
				]
			]
			+SHorizontalBox::Slot()
			.Padding(10, 0)
			.FillWidth(3)
			[
				SNew(SBox)
				.MinDesiredWidth(MinWidth)
				.MaxDesiredWidth(MinWidth)
				.MinDesiredHeight(100.0f)
				.MaxDesiredHeight(100.0f)
				[
					SNew(SBorder)
					.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
					[
						SNew(SScrollBox)
						+SScrollBox::Slot()
						[
							UserListView.ToSharedRef()
						]
					]
				]
			]
		]
	];

	WidgetSwitcher->AddSlot( static_cast<int32>( ELiveSessionChoices::CreateSession ) )
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SEditableTextBox)
			.MinDesiredWidth(MinWidth)
			.HintText(FText::FromString("New Session Name"))
			.SelectAllTextWhenFocused(true)
			.Text_Lambda([&]()
			{
				return FText::FromString(InputSession);
			})
			.OnTextCommitted_Lambda([&](const FText& InText, ETextCommit::Type InCommitType)
			{
				InputSession = InText.ToString();
				std::cmatch Match;
				if (std::regex_match(TCHAR_TO_UTF8(*InputSession), Match, LayerNamePattern))
				{
					WarningMessage.Empty();
				}
				else
				{
					WarningMessage = TEXT("Session name must start with an alphabetical character, but may contain alphanumeric, hyphen, or underscore characters.");
				}
			})
		]
	];


	SWindow::Construct(SWindow::FArguments()
		.Title(FText::FromString("Live Session"))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.SizingRule(ESizingRule::Autosized)
		.Content()
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(10, 20, 10, 0)
			[
				SNew(SUniformGridPanel).SlotPadding(FMargin(10, 0, 10, 0))
				+ SUniformGridPanel::Slot(0, 0)
				[
					SNew(SCheckBox)
					.Style(FAppStyle::Get(), "RadioButton")
					.IsChecked_Lambda([&]()
					{
						return (LiveSessionChoices == ELiveSessionChoices::JoinSession) ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
					})
					.OnCheckStateChanged_Lambda([&](ECheckBoxState NewCheckedState)
					{
						if (NewCheckedState == ECheckBoxState::Checked)
						{
							LiveSessionChoices = ELiveSessionChoices::JoinSession;
							WarningMessage.Empty();
						}
					})
					[
						SNew(STextBlock)
						.Text(FText::FromString(TEXT("Join Session")))
						.ToolTipText(FText::FromString(TEXT("Join the select session")))
					]
				]
				+ SUniformGridPanel::Slot(1, 0)
				[
					SNew(SCheckBox)
					.Style(FAppStyle::Get(), "RadioButton")
					.IsChecked_Lambda([&]()
					{
						return (LiveSessionChoices == ELiveSessionChoices::CreateSession) ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
					})
					.OnCheckStateChanged_Lambda([&](ECheckBoxState NewCheckedState)
					{
						if (NewCheckedState == ECheckBoxState::Checked)
						{
							LiveSessionChoices = ELiveSessionChoices::CreateSession;
							WarningMessage.Empty();
						}
					})
					[
						SNew(STextBlock)
						.Text(FText::FromString(TEXT("Create New Session")))
						.ToolTipText(FText::FromString(TEXT("Create a new live session")))
					]
				]
			]
			+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(10, 10, 10, 0)
			[
				SNew(STextBlock)
				.WrapTextAt(350.0f)
				.Text_Lambda([&](){
					return FText::FromString(WarningMessage);
				})
				.ColorAndOpacity(FLinearColor::Red)
			]
			+ SVerticalBox::Slot()
				.FillHeight(1)
				.Padding(10, 0, 10, 0)
			[
				SNew( SBox )
				[
					WidgetSwitcher
				]				
			]
			+ SVerticalBox::Slot()
				.AutoHeight()
			[
				SNew(SUniformGridPanel).SlotPadding(FMargin(10, 20, 10, 20))
				+ SUniformGridPanel::Slot(0, 0)
				[
					SNew(SButton)
					.Text_Lambda([&](){
						return LiveSessionChoices == ELiveSessionChoices::JoinSession ? FText::FromString("Join") : FText::FromString("Create");
					})
					.HAlign(EHorizontalAlignment::HAlign_Center)
					.OnClicked(this, &SOmniverseLiveSessionDialog::Confirm)
				]
				+ SUniformGridPanel::Slot(1, 0)
				[
					SNew(SButton)
					.Text(FText::FromString("Cancel"))
					.HAlign(EHorizontalAlignment::HAlign_Center)
					.OnClicked(FOnClicked::CreateLambda(
						[&]()
						{
							Destroy();
							return FReply::Handled();
						}
					))
				]
			]
		]);

	if (SessionList.Num() > 0)
	{
		GetUsersHandle = IOmniverseCollaboration::Get()->OnUserHelloed.AddLambda([&](const FOmniverseMessage& Message)
		{
			AddUserToListView(*GetUserDisplayName(Message.from_user_name, Message.app));
		});

		JoinHandle = IOmniverseCollaboration::Get()->OnUserJoined.AddLambda([&](const FOmniverseMessage& Message)
		{
			AddUserToListView(*GetUserDisplayName(Message.from_user_name, Message.app));
		});

		LeftHandle = IOmniverseCollaboration::Get()->OnUserLeft.AddLambda([&](const FOmniverseMessage& Message)
		{
			RemoveUserFromListView(*GetUserDisplayName(Message.from_user_name, Message.app));
		});
	}

	SetOnWindowClosed(FOnWindowClosed::CreateLambda([&](const TSharedRef<SWindow>&)
	{
		IOmniverseCollaboration::Get()->OnUserHelloed.Remove(GetUsersHandle);
		IOmniverseCollaboration::Get()->OnUserJoined.Remove(JoinHandle);
		IOmniverseCollaboration::Get()->OnUserLeft.Remove(LeftHandle);
		IOmniverseCollaboration::Get()->Unsubscribe();

		USDAsset->OnLiveSessionAdded.Remove(SessionAddedHandle);
		USDAsset->OnLiveSessionRemoved.Remove(SessionRemovedHandle);
		FSlateApplication::Get().GetOnModalLoopTickEvent().Remove(TickDelegateHandle);
	}));
}

void SOmniverseLiveSessionDialog::OutputWarning(UOmniverseUSD::ESessionResult Result)
{
	switch (Result)
	{
		case UOmniverseUSD::ESessionResult::Error_ExistSession: 
			WarningMessage = TEXT("Session is existed."); 
			break;
		case UOmniverseUSD::ESessionResult::Error_WriteToml: 
			WarningMessage = TEXT("Failed to write toml."); 
			break;
		case UOmniverseUSD::ESessionResult::Error_LayerCreate:
			WarningMessage = TEXT("Failed to create session layer.");
			break;
		case UOmniverseUSD::ESessionResult::Error_InvalidStage: 
			WarningMessage = TEXT("Stage controller is invalid."); 
			break;
		case UOmniverseUSD::ESessionResult::Error_InvalidToml: 
			WarningMessage = TEXT("Failed to load toml."); 
			break;
		case UOmniverseUSD::ESessionResult::Error_TomlVersionNotFound: 
			WarningMessage = TEXT("Version can not be found in toml."); 
			break;
		case UOmniverseUSD::ESessionResult::Error_InvalidTomlVersion: 
			WarningMessage = TEXT("Toml version isn't compatible."); 
			break;
		case UOmniverseUSD::ESessionResult::Error_LayerOpen: 
			WarningMessage = TEXT("Failed to open session layer."); 
			break;
		case UOmniverseUSD::ESessionResult::Error_NonLivable:
			WarningMessage = TEXT("Cannot create session for non-livable layer. A livable layer must be in Nucleus server and not with .live extension.");
			break;
	}
}

void SOmniverseLiveSessionDialog::SetSession(const FName& Session)
{
	WarningMessage.Empty();
	LastSelectSession = Session;
	DisplayUserList.Reset();
	JoinedUserList.Reset();
	auto OmniversePath = USDAsset->GetOmniPath();
	TMap<IOmniverseSessionConfig::Key, FString> ConfigMap;
	IOmniverseSessionConfig::Get()->LoadSessionConfig(FOmniversePathHelper::GetLiveSessionConfigPath(OmniversePath, LastSelectSession.ToString()), ConfigMap);
	if (auto UserName = ConfigMap.Find(IOmniverseSessionConfig::Key::UserName))
	{
		SessionOwner = *UserName;
	}
	IOmniverseCollaboration::Get()->Subscribe(FOmniversePathHelper::GetLiveSessionChannelPath(OmniversePath, LastSelectSession.ToString()));
	IOmniverseCollaboration::Get()->SendMessage(EOmniverseMessageType::UserGetUsers);
}

FString SOmniverseLiveSessionDialog::GetUserDisplayName(const FString& User, const FString& App)
{
	FString FullName = User + TEXT(" - ") + App;
	if (User.Equals(SessionOwner))
	{
		FullName += TEXT(" (owner)");
	}
	return FullName;
}

void SOmniverseLiveSessionDialog::Destroy()
{
	RequestDestroyWindow();
}

FReply SOmniverseLiveSessionDialog::Confirm()
{
	if (LiveSessionChoices == ELiveSessionChoices::JoinSession)
	{
		if (!LastSelectSession.IsNone())
		{
			auto Result = USDAsset->JoinSession(LastSelectSession.ToString(), 
			[&]() {
				Destroy();
			});
			if (Result == UOmniverseUSD::ESessionResult::OK)
			{
				FOmniverseLiveSessionNotifications::Get()->Start(USDAsset);
			}
			else
			{
				OutputWarning(Result);
			}
		}
		else
		{
			WarningMessage = TEXT("No Session is selected.");
		}
	}
	else
	{
		if (!InputSession.IsEmpty())
		{
			// NOTE: Don't use UE FRegexMatcher, it had issue
			//static const FRegexPattern LayerNamePattern(TEXT("^[a-zA-Z][a-zA-Z0-9_-]*"));
			//FRegexMatcher Matcher(LayerNamePattern, InputSession);
			std::cmatch Match;
			if (std::regex_match(TCHAR_TO_UTF8(*InputSession), Match, LayerNamePattern))
			{
				auto Result = USDAsset->CreateSession(InputSession,
				[&]() {
					Destroy();
				});
				if (Result == UOmniverseUSD::ESessionResult::OK)
				{
					LastSelectSession = *InputSession;
					FOmniverseLiveSessionNotifications::Get()->Start(USDAsset);
				}
				else
				{
					OutputWarning(Result);
				}
			}
			else
			{
				WarningMessage = TEXT("Session name must start with an alphabetical character, but may contain alphanumeric, hyphen, or underscore characters.");
			}
		}
		else
		{
			WarningMessage = TEXT("Session name must be given.");
		}
	}

	return FReply::Handled();
}

void SOmniverseLiveSessionDialog::ShowDialog(UOmniverseUSD* USD)
{
	// Create the window to pick the class
	TSharedRef<SOmniverseLiveSessionDialog> LiveSessionDialog = SNew(SOmniverseLiveSessionDialog, USD);

	TSharedPtr<SWindow> ParentWindow;
	if( FModuleManager::Get().IsModuleLoaded( "MainFrame" ) )
	{
		IMainFrameModule& MainFrame = FModuleManager::LoadModuleChecked<IMainFrameModule>( "MainFrame" );
		ParentWindow = MainFrame.GetParentWindow();
	}

	DialogPtr = LiveSessionDialog;
	FSlateApplication::Get().AddModalWindow(LiveSessionDialog, ParentWindow, false);
	DialogPtr = nullptr;
}

void SOmniverseLiveSessionDialog::AddSessionToComboBox(const FName& Session)
{
	SessionList.Add(MakeShared<FName>(Session));
}

void SOmniverseLiveSessionDialog::RemoveSessionFromComboBox(const FName& Session)
{
	for(int32 SessionIndex = 0; SessionIndex < SessionList.Num(); ++SessionIndex)
	{
		if (Session.IsEqual(*SessionList[SessionIndex]))
		{
			SessionList.RemoveAt(SessionIndex);
			break;
		}
	}

	if (LastSelectSession.IsEqual(Session))
	{
		if (SessionList.Num() > 0)
		{
			LastSelectSession = *SessionList[0];
		}
		else
		{
			LastSelectSession = NAME_None;
		}
	}
}

void SOmniverseLiveSessionDialog::AddUserToListView(const FName& User)
{
	if (!JoinedUserList.Find(User))
	{
		JoinedUserList.Add(User);
		DisplayUserList.Add(MakeShared<FName>(User));
		UserListView->RebuildList();
	}
}

void SOmniverseLiveSessionDialog::RemoveUserFromListView(const FName& User)
{
	for(int32 UserIndex = 0; UserIndex < DisplayUserList.Num(); ++UserIndex)
	{
		if (User.IsEqual(*DisplayUserList[UserIndex]))
		{
			DisplayUserList.RemoveAt(UserIndex);
			break;
		}
	}
	JoinedUserList.Remove(User);
	UserListView->RebuildList();
}

void SOmniverseLiveSessionDialog::AddSession(const FName& Session)
{
	if (DialogPtr.IsValid())
	{
		DialogPtr.Pin()->AddSessionToComboBox(Session);
	}
}
	
void SOmniverseLiveSessionDialog::RemoveSession(const FName& Session)
{
	if (DialogPtr.IsValid())
	{
		DialogPtr.Pin()->RemoveSessionFromComboBox(Session);
	}
}

void SOmniverseLiveSessionDialog::AddUser(const FName& User)
{
	if (DialogPtr.IsValid())
	{
		DialogPtr.Pin()->AddUserToListView(User);
	}
}

void SOmniverseLiveSessionDialog::RemoveUser(const FName& User)
{
	if (DialogPtr.IsValid())
	{
		DialogPtr.Pin()->RemoveUserFromListView(User);
	}
}

#undef LOCTEXT_NAMESPACE
