// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseStageActor.h"
#include "OmniverseExporterDialog.h"
#include "OmniverseEditorExportUtils.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseContentManager.h"
#include "OmniversePathHelper.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseNotificationHelper.h"
#include "LevelEditor.h"
#include "ContentBrowserModule.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "EngineUtils.h"
#include "HAL/PlatformApplicationMisc.h"
#include "OmniverseAsset.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequence.h"
#include "OmniverseImporterDialog.h"
#include "OmniverseAssetImportData.h"
#include "OmniverseUSDImporter.h"

#define IMPORT_USD_AS_UASSET_FEATURE_ENABLED 1

void InitializeLevelEditorMenu()
{
	// Add Omniverse menu section
	TSharedRef< FExtender > Extender(new FExtender());

	Extender->AddMenuExtension(
		"FileLoadAndSave",
		EExtensionHook::After,
		MakeShareable(new FUICommandList),
		FMenuExtensionDelegate::CreateLambda(
			[](FMenuBuilder& MenuBuilder)
			{
				if (FOmniverseConnectionHelper::IsConnected())
				{
					MenuBuilder.BeginSection("FileOmniverse", FText::FromString(L"Omniverse"));
					MenuBuilder.EndSection();
				}
			}
		)
	);

	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	LevelEditorModule.GetMenuExtensibilityManager()->AddExtender(Extender);
}

static void CopyAssetOmniUrlToClipboard(const TArray<FAssetData>& SelectedAssets)
{
	if (SelectedAssets.Num() > 0)
	{
		if (UOmniverseAsset* OmniverseAsset = Cast<UOmniverseAsset>(SelectedAssets[0].GetAsset()))
		{
			if (!OmniverseAsset->GetOmniPath().IsEmpty())
			{
				FPlatformApplicationMisc::ClipboardCopy(*OmniverseAsset->GetOmniPath());
			}
		}
	}
}

void InitializeContenBrowserMenu()
{
	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
	ContentBrowserModule.GetAllAssetViewContextMenuExtenders().Add(FContentBrowserMenuExtender_SelectedAssets::CreateLambda([=](const TArray<FAssetData>& SelectedAssets)
		{
			TSharedRef<FExtender> Extender = MakeShared<FExtender>();
			Extender->AddMenuExtension(
				"CommonAssetActions",
				EExtensionHook::Before,
				TSharedPtr<FUICommandList>(),
				FMenuExtensionDelegate::CreateLambda(
					[SelectedAssets](FMenuBuilder& MenuBuilder)
					{
						if(SelectedAssets.Num() == 0 || !FOmniverseConnectionHelper::IsConnected())
						{
							return;
						}

						TArray<UObject*> SelectedObjects;
						for(auto Asset : SelectedAssets)
						{
							SelectedObjects.Add(Asset.GetAsset());
						}

						if(FOmniverseEditorExportUtils::AreObjectsFromTheSameClass(SelectedObjects))
						{
							MenuBuilder.BeginSection("OmniverseAssetActions", FText::FromString("Omniverse"));

							if(SelectedObjects[0]->IsA<UWorld>())
							{
								MenuBuilder.AddMenuEntry(FText::FromString(L"Export to Omniverse"), FText(), FSlateIcon(), FUIAction(FExecuteAction::CreateLambda(
									[SelectedObjects]()
									{
										TArray<UObject*> WorldObjects;
										for(auto Object : SelectedObjects)
										{
											bool bExported = false;
											auto World = Cast<UWorld>(SelectedObjects[0]);
											for(FActorIterator It(World); It; ++It)
											{
												AActor* Actor = *It;
												if(Actor->IsA<AOmniverseStageActor>())
												{
													bExported = true;
													FString Message = FString::Printf(TEXT("This map %s has already been linked to Omniverse."),
														*Object->GetFullName());
													FOmniverseNotificationHelper::ShowInstantNotification(Message);
													break;
												}
											}

											if(!bExported)
											{
												WorldObjects.Add(Object);
											}
										}

										if(WorldObjects.Num() > 0)
										{
											SOmniverseExporterDialog::ShowDialog(EDialogType::Level, WorldObjects);
										}
									}
								)));
							}
							else if (!SelectedObjects[0]->IsA<UOmniverseAsset>()) // Omniverse asset can't be exported again, only allowing vanilla UE4 asset
							{
								MenuBuilder.AddMenuEntry(FText::FromString(L"Export to Omniverse"), FText(), FSlateIcon(), FUIAction(FExecuteAction::CreateLambda(
									[SelectedObjects]()
									{
										if(SelectedObjects[0]->IsA<UTexture>())
										{
											SOmniverseExporterDialog::ShowDialog(EDialogType::Texture, SelectedObjects);
										}
										else if (SelectedObjects[0]->IsA<UMaterialInterface>())
										{
											SOmniverseExporterDialog::ShowDialog(EDialogType::Material, SelectedObjects);
										}
										else if (SelectedObjects[0]->IsA<UAnimSequence>() || SelectedObjects[0]->IsA<UAnimMontage>())
										{
											SOmniverseExporterDialog::ShowDialog(EDialogType::Animation, SelectedObjects);
										}
										else
										{
											SOmniverseExporterDialog::ShowDialog(EDialogType::Object, SelectedObjects);
										}
									}
								)));
							}

							// Add an option to copy the Omniverse URL to clipboard
							FString SelectedAssetFullPath = SelectedAssets[0].PackageName.ToString();
							if (SelectedAssets.Num() == 1 &&
								SelectedAssetFullPath.StartsWith(OMNIVERSE_FOLDER))
							{
								MenuBuilder.AddMenuEntry(
									FText::FromString(L"Copy Omniverse URL"),
									FText(),
									FSlateIcon(),
									FUIAction(FExecuteAction::CreateLambda(
										[SelectedAssets]()
										{
											CopyAssetOmniUrlToClipboard(SelectedAssets);
										}
								)));
							}

							auto IsImportAvailable = [SelectedObjects]()
							{
								for(auto Object : SelectedObjects)
								{
									if (Object->IsA<UOmniverseAsset>())
									{
										return true;
									}
								}

								return false;
							};

							if (IsImportAvailable())
							{
#if IMPORT_USD_AS_UASSET_FEATURE_ENABLED
								MenuBuilder.AddMenuEntry(
									FText::FromString(TEXT("Import USD")),
									FText::FromString(TEXT("Import usd as uasset.")),
									FSlateIcon(),
									FUIAction(FExecuteAction::CreateLambda(
										[SelectedObjects]()
									{
										FString SelectedPath;
										for(auto SelectedObj : SelectedObjects)
										{
											auto OmniAsset = Cast<UOmniverseAsset>(SelectedObj);
											if (OmniAsset)
											{
												if (!SelectedPath.IsEmpty())
												{
													SelectedPath += ";";
												}
												SelectedPath += OmniAsset->GetOmniPath();
											}
										}

										SOmniverseImporterDialog::ShowDialog(EOmniImporterType::OIT_USD, EOmniSourceType::OST_Nucleus, SelectedPath);								
									}
								)));
#endif

								MenuBuilder.AddMenuEntry(
									FText::FromString(L"Import Facial Animation"),
									FText(),
									FSlateIcon(),
									FUIAction(FExecuteAction::CreateLambda(
										[SelectedObjects]()
									{
										FString SelectedPath;
										for(auto SelectedObj : SelectedObjects)
										{
											auto OmniAsset = Cast<UOmniverseAsset>(SelectedObj);
											if (OmniAsset)
											{
												if (!SelectedPath.IsEmpty())
												{
													SelectedPath += ";";
												}
												SelectedPath += OmniAsset->GetOmniPath();
											}
										}

										SOmniverseImporterDialog::ShowDialog(EOmniImporterType::OIT_Facial, EOmniSourceType::OST_Nucleus, SelectedPath);								
									}
								)));
							}

							auto IsReimportAvailable = [SelectedObjects]()
							{
								for(auto Object : SelectedObjects)
								{
									if (Object->IsA<UStaticMesh>())
									{
										auto StaticMesh = Cast<UStaticMesh>(Object);
										if (StaticMesh->AssetImportData && StaticMesh->AssetImportData->IsA<UOmniverseAssetImportData>())
										{
											return true;
										}
									}
									else if (Object->IsA<USkeletalMesh>())
									{
										auto SkeletalMesh = Cast<USkeletalMesh>(Object);
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 26
										if (SkeletalMesh->AssetImportData && SkeletalMesh->AssetImportData->IsA<UOmniverseAssetImportData>())
#else
										if (SkeletalMesh->GetAssetImportData() && SkeletalMesh->GetAssetImportData()->IsA<UOmniverseAssetImportData>())
#endif
										{
											return true;
										}
									}
									else if (Object->IsA<UAnimSequence>())
									{
										auto AnimSequence = Cast<UAnimSequence>(Object);
										if (AnimSequence->AssetImportData && AnimSequence->AssetImportData->IsA<UOmniverseAssetImportData>())
										{
											return true;
										}
									}
									else if (Object->IsA<UMaterialInterface>())
									{
										auto Material = Cast<UMaterialInterface>(Object);
										if (Material->AssetImportData && Material->AssetImportData->IsA<UOmniverseAssetImportData>())
										{
											return true;
										}
									}
									else if (Object->IsA<UTexture>())
									{
										auto Texture = Cast<UTexture>(Object);
										if (Texture->AssetImportData && Texture->AssetImportData->IsA<UOmniverseAssetImportData>())
										{
											return true;
										}
									}
								}

								return false;
							};

							if (IsReimportAvailable())
							{
								MenuBuilder.AddMenuEntry(
									FText::FromString(TEXT("Reimport")),
									FText::FromString(TEXT("Reimport uasset.")),
									FSlateIcon(),
									FUIAction(FExecuteAction::CreateLambda(
										[SelectedObjects]()
									{
										FString SelectedPath;
										for(auto SelectedObj : SelectedObjects)
										{
											FOmniverseUSDImporter::Reimport(SelectedObj);
										}
									}
								)));
							}

							if (SelectedObjects.Num() == 1 && 
								SelectedObjects[0]->IsA<UOmniverseAsset>() &&
								Cast<UOmniverseAsset>(SelectedObjects[0])->bIsWritable)
							{
								MenuBuilder.AddMenuEntry(
									FText::FromString(L"Save to Omniverse"),
									FText(),
									FSlateIcon(),
									FUIAction(FExecuteAction::CreateLambda(
										[SelectedObjects]()
									{
										// Get a checkpoint comment
										FString CheckpointComment;
										bool bLiveCheckpointDialog = false;
										if (FOmniverseEditorExportUtils::GetCheckpointComment(CheckpointComment, bLiveCheckpointDialog))
										{
											Cast<UOmniverseAsset>(SelectedObjects[0])->SaveToOmniverse();

											// The save already creates a checkpoint.  Only checkpoint if we have a comment.
											if (CheckpointComment.Len())
											{
												IOmniverseRuntimeModule::Get().SetCheckpointComment(CheckpointComment);
												FOmniverseConnectionHelper::CreateCheckpointSync(Cast<UOmniverseAsset>(SelectedObjects[0])->GetOmniPath());
												IOmniverseRuntimeModule::Get().SetCheckpointComment("");
											}
										}
									}
								)));
							}

							MenuBuilder.EndSection();
						}
					}
				)
			);

			return Extender;
		}));

	ContentBrowserModule.GetAllAssetContextMenuExtenders().Add(FContentBrowserMenuExtender_SelectedPaths::CreateLambda([=](const TArray<FString>& SelectedPaths)
		{
			TSharedRef<FExtender> Extender = MakeShared<FExtender>();
			Extender->AddMenuExtension(
				"ContentBrowserNewFolder",
				EExtensionHook::Before,
				TSharedPtr<FUICommandList>(),
				FMenuExtensionDelegate::CreateLambda(
					[SelectedPaths](FMenuBuilder& MenuBuilder)
					{
						MenuBuilder.BeginSection("ContentBrowserOmniverse", FText::FromString(L"Omniverse"));
						if (FOmniverseConnectionHelper::IsConnected())
						{
							MenuBuilder.AddMenuEntry(FText::FromString(L"Refresh"), FText(), FSlateIcon(), FUIAction(FExecuteAction::CreateLambda(
								[SelectedPaths]()
								{
									for(const FString& Path : SelectedPaths)
									{
										GetMutableDefault<UOmniverseContentManager>()->RefreshFolder(Path, false, true);
									}
								}
							)));
						}

#if IMPORT_USD_AS_UASSET_FEATURE_ENABLED
						MenuBuilder.AddMenuEntry(
							FText::FromString("Import USD"),
							FText::FromString("Import usd as uasset."),
							FSlateIcon(),
							FUIAction(FExecuteAction::CreateLambda(
								[SelectedPaths]()
								{
									for(const FString& Path : SelectedPaths)
									{
										SOmniverseImporterDialog::ShowDialog(EOmniImporterType::OIT_USD, EOmniSourceType::OST_Local, Path);
										break;
									}
								}
							)));
#endif

						MenuBuilder.AddMenuEntry(
							FText::FromString("Import Facial Animation"),
							FText::FromString("Import usd animtion as the MetaHumans facial animation."),
							FSlateIcon(),
							FUIAction(FExecuteAction::CreateLambda(
								[SelectedPaths]()
								{
									for(const FString& Path : SelectedPaths)
									{
										SOmniverseImporterDialog::ShowDialog(EOmniImporterType::OIT_Facial, EOmniSourceType::OST_Local, Path);
										break;
									}
								}
							)));

						MenuBuilder.EndSection();
					}
				)
			);

			return Extender;
		}));

	ContentBrowserModule.GetAllPathViewContextMenuExtenders().Add(FContentBrowserMenuExtender_SelectedPaths::CreateLambda([=](const TArray<FString>& SelectedPaths)
		{
			TSharedRef<FExtender> Extender = MakeShared<FExtender>();
			Extender->AddMenuExtension(
				"PathViewFolderOptions",
				EExtensionHook::Before,
				TSharedPtr<FUICommandList>(),
				FMenuExtensionDelegate::CreateLambda(
					[SelectedPaths](FMenuBuilder& MenuBuilder)
					{
						if (SelectedPaths.Num() != 1)
						{
							return;
						}
						FString ServerPath;
						FOmniversePathHelper::UnmanglePath(SelectedPaths[0], ServerPath);
						if (ServerPath.RemoveFromStart(OMNIVERSE_FOLDER + TEXT("/")) && !ServerPath.Contains(TEXT("/")))
						{
							MenuBuilder.BeginSection("PathViewFolderOmniverse", FText::FromString(L"Omniverse"));

							MenuBuilder.AddMenuEntry(FText::FromString(L"Remove Server"), FText(), FSlateIcon(), FUIAction(FExecuteAction::CreateLambda(
								[ServerPath]()
								{
									IOmniverseRuntimeModule::Get().RemoveServer(ServerPath);
								}
							)));

							MenuBuilder.EndSection();
						}
					}
				)
			);

			return Extender;
		}));
}

static TSharedRef<FExtender> ExtendLevelViewportContextMenuForOmniverse(const TSharedRef<FUICommandList> CommandList, TArray<AActor*> SelectedActors)
{
	TSharedPtr<FExtender> Extender = MakeShareable(new FExtender);

	Extender->AddMenuExtension("LevelViewportAttach", EExtensionHook::Before, CommandList,
		FMenuExtensionDelegate::CreateLambda(
			[SelectedActors](FMenuBuilder& MenuBuilder)
			{
				if (FOmniverseConnectionHelper::IsConnected())
				{
					MenuBuilder.BeginSection("Omniverse", FText::FromString(L"Omniverse"));
					MenuBuilder.AddMenuEntry(FText::FromString(L"Export to Omniverse"), FText(), FSlateIcon(), FUIAction(FExecuteAction::CreateLambda(
						[SelectedActors]()
						{
							SOmniverseExporterDialog::ShowDialog(SelectedActors);
						}
					)));
					MenuBuilder.EndSection();
				}

			}
		)
	);

	return Extender.ToSharedRef();
}

TFunction<void()> InitializeViewportMenu()
{
	static auto LevelViewportContextMenuOmniverseExtender = FLevelEditorModule::FLevelViewportMenuExtender_SelectedActors::CreateStatic(&ExtendLevelViewportContextMenuForOmniverse);
	FLevelEditorModule& LevelEditorModule = FModuleManager::Get().LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	auto& MenuExtenders = LevelEditorModule.GetAllLevelViewportContextMenuExtenders();
	MenuExtenders.Add(LevelViewportContextMenuOmniverseExtender);
	auto LevelViewportContextMenuOmniverseExtenderDelegateHandle = MenuExtenders.Last().GetHandle();

	return [LevelViewportContextMenuOmniverseExtenderDelegateHandle]()
	{
		if(FModuleManager::Get().IsModuleLoaded("LevelEditor"))
		{
			FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
			LevelEditorModule.GetAllLevelViewportContextMenuExtenders().RemoveAll([&](const FLevelEditorModule::FLevelViewportMenuExtender_SelectedActors& Delegate) {
				return Delegate.GetHandle() == LevelViewportContextMenuOmniverseExtenderDelegateHandle;
				});
		}
	};
}
