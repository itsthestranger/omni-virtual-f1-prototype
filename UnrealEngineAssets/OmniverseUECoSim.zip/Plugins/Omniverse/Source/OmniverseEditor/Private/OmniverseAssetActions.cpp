// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseAssetActions.h"
#include "Engine/Engine.h"
#include "Editor.h"
#include "OmniverseStageActor.h"
#include "OmniverseSettings.h"
#include "IOmniverseRuntimeModule.h"
#include "Engine/ExponentialHeightFog.h"
#include "Engine/SkyLight.h"
#include "Engine/DirectionalLight.h"
#include "Components/SkyLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Interfaces/IMainFrameModule.h"
#include "Internationalization/Internationalization.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "EditorActorFolders.h"
#include "OmniverseUSD.h"
#include "Widgets/SWidget.h"
#include "Brushes/SlateImageBrush.h"
#include "Styling/SlateStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Interfaces/IPluginManager.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Misc/ConfigCacheIni.h"
#include "Widgets/Images/SImage.h"
#include "OmniverseMessageLogContext.h"


#define LOCTEXT_NAMESPACE "OmniverseAssetActions"

#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( StyleSet->RootToContentDir( RelativePath, TEXT( ".png" ) ), __VA_ARGS__ )
TSharedPtr<FSlateStyleSet> FUSDAssetTypeActions::StyleSet = nullptr;

FUSDAssetTypeActions::FUSDAssetTypeActions(EAssetTypeCategories::Type InAssetCategory)
	: MyAssetCategory(InAssetCategory)
{
	//StyleSet = MakeShared<FSlateStyleSet>(new FSlateStyleSet("OmniverseAssetActions"));
	StyleSet = MakeShareable(new FSlateStyleSet("OmniverseAssetActions"));

	//Content path of this plugin
	FString ContentDir = IPluginManager::Get().FindPlugin("Omniverse")->GetBaseDir();
	StyleSet->SetContentRoot(ContentDir);

	const FVector2D Icon16x16(16.0f, 16.0f);
	const FVector2D Icon128x128(128.0f, 128.0f);
	StyleSet->Set("OmniverseAssetActions.LockIcon", new IMAGE_BRUSH("Resources/MountLock", Icon16x16));
	StyleSet->Set("ClassThumbnail.OmniverseUSD", new IMAGE_BRUSH("Resources/Icon128", Icon128x128));
	

	//Register the created style
	FSlateStyleRegistry::RegisterSlateStyle(*StyleSet);
}

FUSDAssetTypeActions::~FUSDAssetTypeActions()
{
	if (StyleSet.IsValid())
	{
		FSlateStyleRegistry::UnRegisterSlateStyle(*StyleSet.Get());
		ensure(StyleSet.IsUnique());
		StyleSet.Reset();
	}
}

bool FUSDAssetTypeActions::HasActions(const TArray<UObject*>& InObjects) const
{
	return true;
}

void FUSDAssetTypeActions::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder & MenuBuilder)
{
	MenuBuilder.AddMenuEntry(
		FText::FromString("Edit properties."),
		FText(),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateLambda(
			[InObjects]()
			{
				FSimpleAssetEditor::CreateEditor(EToolkitMode::Standalone, nullptr, InObjects);
			}))
	);
}

FText FUSDAssetTypeActions::GetName() const
{
	return FText::FromString("Universal Scene Description");
}

UClass * FUSDAssetTypeActions::GetSupportedClass() const
{
	return UOmniverseUSD::StaticClass();
}

FColor FUSDAssetTypeActions::GetTypeColor() const
{
	return FColor::White;
}

uint32 FUSDAssetTypeActions::GetCategories()
{
	return MyAssetCategory;
}

void FUSDAssetTypeActions::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	auto USDAsset = Cast<UOmniverseUSD>(InObjects[0]);
	if(USDAsset == nullptr)
	{
		return;
	}

	if(!USDAsset->HasAllFlags(EObjectFlags::RF_Standalone | EObjectFlags::RF_Public))
	{
		return;
	}

	// Create a new scene
	bool bNewMap = false;

	auto DelegateHandle = FEditorDelegates::MapChange.AddLambda(
		[&](MapChangeEventFlags::Type Flag)
		{
			if(Flag == MapChangeEventFlags::NewMap)
			{
				bNewMap = true;
			}
		}
	);

	GEditor->CreateNewMapForEditing();

	FEditorDelegates::MapChange.Remove(DelegateHandle);

	if(!bNewMap)
	{
		return;
	}

	FOmniverseMessageLogContext::ClearMessages();

	auto& World = *GEditor->GetEditorWorldContext().World();
	World.Rename(*USDAsset->GetName(), nullptr, REN_NonTransactional | REN_DontCreateRedirectors);

	auto& MainFrameModule = FModuleManager::Get().LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));
	MainFrameModule.SetLevelNameForWindowTitle(World.GetName());

	// Spawn Omniverse stage actor
	auto& StageActor = AOmniverseStageActor::Get(World);
	StageActor.InitializePreviewEnvironment();
	StageActor.SetUSD(USDAsset);
	StageActor.SetFolderPath_Recursively("Omniverse");

	auto& Folders = FActorFolders::Get();
	if(auto FolderProp = Folders.GetFolderProperties(World, FFolder(FFolder::GetWorldRootFolder(&World).GetRootObject(), FName("Omniverse"))))
	{
		FolderProp->bIsExpanded = false;
	}
	if(auto FolderProp = Folders.GetFolderProperties(World, FFolder(FFolder::GetWorldRootFolder(&World).GetRootObject(), FName("Omniverse/Preview"))))
	{
		FolderProp->bIsExpanded = false;
	}

	World.GetOutermost()->SetDirtyFlag(false);

	FOmniverseMessageLogContext::DisplayMessages();
}

TSharedPtr<class SWidget> FUSDAssetTypeActions::GetThumbnailOverlay(const FAssetData& AssetData) const
{
	static const FLinearColor ReadOnlyColor(0.5f, 0.05f, 0.05f);
	FString ColorStr;
	if (StyleSet.IsValid() && GConfig->GetString(TEXT("PathColor"), *AssetData.PackagePath.ToString(), ColorStr, GEditorPerProjectIni))
	{
		FLinearColor Color;
		if (Color.InitFromString(ColorStr) && Color.Equals(ReadOnlyColor, 0.01f))
		{
			return SNew(SBox)
				.HAlign(HAlign_Right)
				.VAlign(VAlign_Bottom)
				.ToolTipText(LOCTEXT("USDAssetType_LockedFileToolTip", "This file is on a read-only mount"))
				.Padding(FMargin(0))
				[
					SNew(SBox)
					.MinDesiredWidth(16)
					.MinDesiredHeight(16)
					[
						SNew(SImage)
						.Image(StyleSet->GetBrush("OmniverseAssetActions.LockIcon"))
					]
				];

		}
	}

	return nullptr;
}

#undef LOCTEXT_NAMESPACE
