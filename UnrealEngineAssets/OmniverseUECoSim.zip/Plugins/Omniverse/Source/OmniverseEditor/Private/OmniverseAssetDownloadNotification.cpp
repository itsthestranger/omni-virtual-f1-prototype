// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseAssetDownloadNotification.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseSettings.h"
#include "Async/Async.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Styling/AppStyle.h"

void FOmniverseAssetDownloadNotification::Initialize()
{
	IOmniverseRuntimeModule& OmniRuntimeModule = IOmniverseRuntimeModule::Get();
	OmniRuntimeModule.OnAssetDownload.AddSP(this, &FOmniverseAssetDownloadNotification::OnAssetDownload);
}

void FOmniverseAssetDownloadNotification::CreateNotification(const FString& AssetName)
{
	if(!NotificationMap.Contains(AssetName))
	{
		// create a new notification
		TSharedPtr<SNotificationItem> NotificationItem;
		FNotificationInfo Info(FText::GetEmpty());
		Info.bFireAndForget = false;
		Info.ExpireDuration = 0;
		Info.FadeOutDuration = 0.5f;
		Info.bUseSuccessFailIcons = false;
		Info.bUseLargeFont = false;
		Info.Image = FAppStyle::GetBrush(TEXT("DetailsView.PulldownArrow.Down"));
		Info.ButtonDetails.Add(FNotificationButtonInfo(
			FText::FromString("Dismiss"),
			FText(),
			FSimpleDelegate::CreateSP(this, &FOmniverseAssetDownloadNotification::OnDismiss),
			SNotificationItem::CS_Pending
		));
		NotificationItem = FSlateNotificationManager::Get().AddNotification(Info);
		NotificationItem->SetCompletionState(SNotificationItem::CS_Pending);
		FString Message = FString::Printf(TEXT("Omniverse downloading %s"), *AssetName);
		NotificationItem->SetText(FText::FromString(Message));

		// add it to the notification map
		NotificationMap.Add(AssetName, NotificationItem);
	}
}

void FOmniverseAssetDownloadNotification::OnAssetDownload(const FString& AssetName, bool bDownloadStarted)
{
	if(!GetDefault<UOmniverseSettings>()->bShowDownloadNotifications)
	{
		return;
	}

	if(bDownloadStarted == true)
	{
		if(IsInGameThread())
		{
			CreateNotification(AssetName);
		}
		else
		{
			// Run on the main thread
			AsyncTask(ENamedThreads::GameThread, [this, AssetName]
				{
					CreateNotification(AssetName);
				});
		}
	}
	else
	{
		// find the notification in the map
		if(NotificationMap.Contains(AssetName))
		{
			TSharedPtr<SNotificationItem> NotificationItem = NotificationMap[AssetName];
			if(NotificationItem.IsValid())
			{
				// Download Finished notification
				FString Message = FString::Printf(TEXT("Omniverse finished downloading %s"), *AssetName);
				NotificationItem->SetExpireDuration(2);
				NotificationItem->SetText(FText::FromString(Message));
				NotificationItem->SetCompletionState(SNotificationItem::CS_Success);
				NotificationItem->ExpireAndFadeout();
				NotificationItem.Reset();
			}
			NotificationMap.Remove(AssetName);
		}
		else
		{
			// This notification doesn't exist
			return;
		}
	}
}

inline void FOmniverseAssetDownloadNotification::OnDismiss()
{
	// perhaps dismiss them ALL...
	TArray<TSharedPtr<SNotificationItem>> NotificationArray;
	NotificationMap.GenerateValueArray(NotificationArray);
	for(TSharedPtr<SNotificationItem> NotificationItem : NotificationArray)
	{
		if(NotificationItem.IsValid())
		{
			// Download Finished notification
			NotificationItem->SetExpireDuration(.01);
			NotificationItem->SetCompletionState(SNotificationItem::CS_Success);
			NotificationItem->ExpireAndFadeout();
			NotificationItem.Reset();
		}
	}
	NotificationMap.Empty();
}
