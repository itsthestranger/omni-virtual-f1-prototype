// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseExporterDialog.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SComboBox.h"
#include "Interfaces/IMainFrameModule.h"
#include "OmniverseEditorExportUtils.h"
#include "OmniverseContentManager.h" 
#include "OmniversePathHelper.h"
#include "Editor.h"
#include "Styling/AppStyle.h"
#include "OmniverseUSDHelper.h"
#include "DesktopPlatformModule.h"
#include "OmniverseMessageLogContext.h"
#include "IOmniverseRuntimeModule.h"

#define LOCTEXT_NAMESPACE "OmniverseEditor"
#define MDL_INCLUDE_DEPENDENCIES_OPTION "Include Dependencies"
#define MDL_USE_CORE_DEPENDENCIES_OPTION "Use Core Library Dependencies"

void SOmniverseExporterDialog::InitializeExportSettings()
{
	MDLOptions.Add(MakeShareable(new FName(TEXT(MDL_INCLUDE_DEPENDENCIES_OPTION))));
	MDLOptions.Add(MakeShareable(new FName(TEXT(MDL_USE_CORE_DEPENDENCIES_OPTION))));

	if (ExportSettings.MaterialSettings.bCopyTemplate)
	{
		MDLSelect = TEXT(MDL_INCLUDE_DEPENDENCIES_OPTION);
	}
	else
	{
		MDLSelect = TEXT(MDL_USE_CORE_DEPENDENCIES_OPTION);
	}

	if (ExportSettings.MaterialSettings.TextureSettings.bTextureSource)
	{
		TextureSizeChoice = ETextureSizeChoices::UseTextureSource;
	}
	else
	{
		TextureSizeChoice = ETextureSizeChoices::UseTextureSetting;
	}

	if (ExportSettings.bModular)
	{
		ExportMethodChoice = EExportMethodChoices::ModularExport;
	}
	else
	{
		ExportMethodChoice = EExportMethodChoices::SharedExport;
	}
}

void SOmniverseExporterDialog::ConstructDialog(EDialogType::Type InDialogType)
{
	InitializeExportSettings();

	TSharedPtr<SVerticalBox> ExportMethodWidget = 
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0, 10)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Export Method")))
			]
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			[
				SNew(SCheckBox)
				.Style(FAppStyle::Get(), "RadioButton")
				.IsChecked(this, &SOmniverseExporterDialog::ExportMethodIsChecked, EExportMethodChoices::SharedExport)
				.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportMethodChanged, EExportMethodChoices::SharedExport)
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Shared Export")))
					.ToolTipText(FText::FromString(TEXT("Organizes materials in a directory to be shared by many assets.")))
				]
			]

			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			[
				SNew(SCheckBox)
				.Style(FAppStyle::Get(), "RadioButton")
				.IsChecked(this, &SOmniverseExporterDialog::ExportMethodIsChecked, EExportMethodChoices::ModularExport)
				.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportMethodChanged, EExportMethodChoices::ModularExport)
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Modular Export")))
					.ToolTipText(FText::FromString(TEXT("Materials are exported for each assets. This allows an asset directory to be moved easily, as it's self contained.")))
				]
			];

	TSharedPtr<SVerticalBox> CheckpointWidget =
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			.Padding(0, 10)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Checkpoint Comment (Optional)")))
			]
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			.MaxHeight(30)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				//.MaxWidth(307)
				.HAlign(HAlign_Left)
				[
					//SAssignNew(CheckpointComment, SEditableTextBox)
					SNew(SEditableTextBox)
					//.IsEnabled(this, &SOmniverseExporterDialog::IsIncludeDependenciesSelected)
					//.Text(this, &SOmniverseExporterDialog::GetDestPath)
					.OnTextCommitted(this, &SOmniverseExporterDialog::OnCheckpointTextCommitted)
					.ToolTipText(FText::FromString(TEXT("Checkpoint Comment")))
					.MinDesiredWidth(350)
				]
			];

	TSharedPtr<SVerticalBox> MaterialWidget =
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Left)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.HAlign(HAlign_Left)
				[
					SNew(SCheckBox)
					.IsChecked(this, &SOmniverseExporterDialog::ShouldUseMDL)
					.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnUseMDLChanged)
					[
						SNew(STextBlock)
						.Text(FText::FromString(TEXT("Include MDL")))
						.ToolTipText(FText::FromString(TEXT("Generate MDL materials in the export")))
					]
				]

				+ SHorizontalBox::Slot()
				.AutoWidth()
				.HAlign(HAlign_Left)
				.Padding(50, 0)
				[
					SNew(SComboBox<TSharedPtr<FName>>)
					.OptionsSource(&MDLOptions)
					.OnSelectionChanged(this, &SOmniverseExporterDialog::OnComboBoxChanged, &MDLSelect)
					.OnGenerateWidget(this, &SOmniverseExporterDialog::OnGetComboBoxWidget)
					.Content()
					[
						SNew(STextBlock)
						.Text(this, &SOmniverseExporterDialog::GetComboBoxValueAsText, &MDLSelect)
						.ToolTipText(this, &SOmniverseExporterDialog::GetComboBoxValueToolTipAsText, &MDLSelect)
					]
				]
			]
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			.Padding(0, 10)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Destination Unreal Template Path (Optional)")))
			]
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			.MaxHeight(30)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.MaxWidth(307)
				.HAlign(HAlign_Left)
				[
					SNew(SEditableTextBox)
					.IsEnabled(this, &SOmniverseExporterDialog::IsIncludeDependenciesSelected)
					.Text(this, &SOmniverseExporterDialog::GetDestPath)
					.OnTextCommitted(this, &SOmniverseExporterDialog::OnDestPathTextCommitted)
					.ToolTipText(FText::FromString(TEXT("Default - Same Path as Unreal MDL")))
					.MinDesiredWidth(307)
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.HAlign(HAlign_Left)
				.Padding(5)
				[
					SNew(SButton)
					.IsEnabled(this, &SOmniverseExporterDialog::IsIncludeDependenciesSelected)
					.IsFocusable(false)
					.OnClicked(this, &SOmniverseExporterDialog::DestPathClicked)
					[
						SNew(STextBlock)
						.Text(FText::FromString(TEXT("...")))
					]
				]
			];

	TSharedPtr<SVerticalBox> TextureWidget =
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0, 10)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Texture Size")))
			]
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			[
				SNew(SCheckBox)
				.Style(FAppStyle::Get(), "RadioButton")
				.IsChecked(this, &SOmniverseExporterDialog::TextureSizeIsChecked, ETextureSizeChoices::UseTextureSetting)
				.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnTextureSizeChanged, ETextureSizeChoices::UseTextureSetting)
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Use texture setting as export resolution")))
				]
			]
			+ SVerticalBox::Slot()
			.HAlign(HAlign_Left)
			.AutoHeight()
			[
				SNew(SCheckBox)
				.Style(FAppStyle::Get(), "RadioButton")
				.IsChecked(this, &SOmniverseExporterDialog::TextureSizeIsChecked, ETextureSizeChoices::UseTextureSource)
				.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnTextureSizeChanged, ETextureSizeChoices::UseTextureSource)
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Use texture source as export resolution")))
				]
			];
			
	TSharedPtr<SCheckBox> DDSWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::IsExportDDS)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportDDSChanged)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Export Texture as DDS")))
				.ToolTipText(FText::FromString(TEXT("Save DDS Files to destination path and reference them from materials (WARNING, these cannot be reimported in Unreal, this is to save GPU texture memory in renderers)")))
			];

	TSharedPtr<SCheckBox> TwoSidedFoliageWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::ShouldExportTwoSidedFoliage)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportTwoSidedFoliageChanged)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Export Backfaces for Two-Sided Foliage")))
				.ToolTipText(FText::FromString(TEXT("Generate additional backface geometry and materials for meshes that use both Two-Sided Shading Model and the Two-Sided material expression.")))
			];

	TSharedPtr<SCheckBox> PreviewSurfaceWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::ShouldUsePreviewSurface)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnUsePreviewSurfaceChanged)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Include USD Preview Surface")))
				.ToolTipText(FText::FromString(TEXT("Generate USD Preview Surface materials in the export")))
			];
		
	TSharedPtr<SCheckBox> PhysicsWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::ShouldExportPhysics)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportPhysicsChanged)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Export physics data (collision)")))
				.ToolTipText(FText::FromString(TEXT("Include collision data with static meshes")))
			];
		
	TSharedPtr<SCheckBox> ScenegraphWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::ShouldInstanceMesh)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnInstanceMeshChanged)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("USD Scenegraph Instancing")))
				.ToolTipText(FText::FromString(TEXT("Make every referenced mesh in a stage an instance. If the stage has duplicate meshes this can greatly reduce geometric GPU memory in another renderer, but the editing workflow may be hampered.")))
			];

	TSharedPtr<SCheckBox> DecalActorExportWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::ShouldExportDecalActors)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportDecalActorsChanged)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Export Decal Actors as planes")))
				.ToolTipText(FText::FromString(TEXT("Convert Decal actors to plane meshes with a cutout material for downstream renderers to flatten.")))
			];

	TSharedPtr<SCheckBox> LevelExtWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::ShouldAddExtension)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnAddExtensionChanged)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Add extra extension to exported file, ie, .stage.usd, .prop.usd")))
				.ToolTipText(FText::FromString(TEXT("Stage files will be named .stage.usd, props will be named .prop.usd")))
			];

	TSharedPtr<SCheckBox> PayloadWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldExportPayload)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnPayloadChanged)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Export as Payloads")))
			.ToolTipText(FText::FromString(TEXT("Instead of references, each prop within a stage will be a payload.")))
		];

	TSharedPtr<SCheckBox> SublayersWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldExportSublayers)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportSublayers)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Export Sublevels as Sublayers")))
			.ToolTipText(FText::FromString(TEXT("Each sublevel will become a sublayer in the output USD stage")))
		];
		
	TSharedPtr<SCheckBox> UpYAxisWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldUpYAxis)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnUpYAxisChanged)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Export as Y-up Axis")))
			.ToolTipText(FText::FromString(TEXT("If checked, USD and MDL are exported with a Y - up stage up - axis rather than the default Z - up")))
		];
	TSharedPtr<SCheckBox> PreviewMeshWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldExportPreviewMesh)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportPreviewMesh)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Export Preview Mesh")))
		];

	TSharedPtr<SCheckBox> InvisibleLevelWidget =
			SNew(SCheckBox)
			.IsChecked(this, &SOmniverseExporterDialog::ShouldExportInvisible)
			.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportInvisible)
			[
				SNew(STextBlock)
				.Text(FText::FromString(TEXT("Include invisible levels")))
				.ToolTipText(FText::FromString(TEXT("If a sublevel is hidden it will still be exported.  The default behavior is to skip invisible sublevels.")))
			];

	TSharedPtr<SCheckBox> MaterialOverSublayerWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldCreateMaterialOverSublayer)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnCreateMaterialOverSublayer)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Create a material overrides sublayer")))
			.ToolTipText(FText::FromString(TEXT("Export a sublayer that contains all of the material reference overs for the stage. Also create USD files for each material rather than including them in the prop stages.")))
		];

	TSharedPtr<SCheckBox> LandscapeGrassWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldExportLandscapeGrass)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportLandscapeGrass)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Export Landscape Grass")))
			.ToolTipText(FText::FromString(TEXT("If checked Landscape Grass will be exported.  This option is provided because in some levels excess geometry can be exported.")))
		];

	TSharedPtr<SCheckBox> NaniteWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldExportNanite)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnExportNanite)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Export source geometry for Nanite high-poly detailed mesh")))
			.ToolTipText(FText::FromString(TEXT("Note, this can produce extremely dense USD geometry")))
		];

	TSharedPtr<SCheckBox> RootIdentityWidget =
		SNew(SCheckBox)
		.IsChecked(this, &SOmniverseExporterDialog::ShouldRootIdentity)
		.OnCheckStateChanged(this, &SOmniverseExporterDialog::OnRootIdentityChanged)
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Convert Skeleton root to identity transform")))
			.ToolTipText(FText::FromString(TEXT("This option will convert a Skeleton's root node to an identity transform to assist downstream tools that require this.  All animations exported during this export will be transformed properly so they'll work in downstream tools.")))
		];

	TSharedPtr<SUniformGridPanel> ConfirmWidget =
			SNew(SUniformGridPanel)
			.SlotPadding(FAppStyle::GetMargin("StandardDialog.SlotPadding"))
			.MinDesiredSlotWidth(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotWidth"))
			.MinDesiredSlotHeight(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotHeight"))
			+ SUniformGridPanel::Slot(0, 0)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
				.Text(LOCTEXT("OK", "OK"))
				.OnClicked(this, &SOmniverseExporterDialog::OkClicked)
			]
			+ SUniformGridPanel::Slot(1, 0)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
				.Text(LOCTEXT("Cancel", "Cancel"))
				.OnClicked(this, &SOmniverseExporterDialog::CancelClicked)
			];

	const int32 BaseSizeY = 150 + 40; // Confirm window + Checkpoint slot
	const int32 BaseMaterialSizeY = 110;
	const int32 BaseTextureSizeY = 80;
	const int32 BaseLevelSizeY = 90;
#if WITH_USD_PHYSICS
	const int32 ObjectNumItems = 9; // items except material and texture
#else
	const int32 ObjectNumItems = 8; // items except material and texture
#endif
	const int32 AnimationNumItems = 5;
	const int32 TextureNumItems = 1;
	const int32 MaterialNumItems = 1;
#if WITH_USD_PHYSICS
	const int32 LevelNumItems = 14;
#else
	const int32 LevelNumItems = 13;
#endif
	const int32 ItemSizeY = 30;
	const int32 LevelGroupingSizeY = 70;

	const int32 ClientSizeX = 500;
	int32 ClientSizeY = BaseSizeY;

	switch (InDialogType)
	{
	case EDialogType::Object:
		ClientSizeY += BaseMaterialSizeY + BaseTextureSizeY + ObjectNumItems * ItemSizeY;
		SWindow::Construct(SWindow::FArguments()
			.Title(LOCTEXT("OmniverseExporterDialogTitle", "Omniverse Exporter"))
			.SizingRule(ESizingRule::UserSized)
			.ClientSize(FVector2D(ClientSizeX, ClientSizeY))
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			.bDragAnywhere(false)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 10)
				[
					MaterialWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 10)
				[
					TextureWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					DDSWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					PreviewSurfaceWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					NaniteWidget.ToSharedRef()
				]			
#if WITH_USD_PHYSICS
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					PhysicsWidget.ToSharedRef()
				]
#endif
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					ScenegraphWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					PayloadWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					UpYAxisWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					RootIdentityWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					LandscapeGrassWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 0)
				[
					CheckpointWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Center)
				.Padding(30)
				[
					ConfirmWidget.ToSharedRef()
				]
			]
		);

		break;
	case EDialogType::Animation:
		ClientSizeY += AnimationNumItems * ItemSizeY;
		SWindow::Construct(SWindow::FArguments()
			.Title(LOCTEXT("OmniverseExporterDialogTitle", "Omniverse Exporter"))
			.SizingRule(ESizingRule::UserSized)
			.ClientSize(FVector2D(ClientSizeX, ClientSizeY))
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			.bDragAnywhere(false)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					PreviewMeshWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					ScenegraphWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					PayloadWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					UpYAxisWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					RootIdentityWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					CheckpointWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Center)
				.Padding(30)
				[
					ConfirmWidget.ToSharedRef()
				]
			]
		);
		break;
	case EDialogType::Material:
		ClientSizeY += BaseMaterialSizeY + BaseTextureSizeY + MaterialNumItems * ItemSizeY;
		SWindow::Construct(SWindow::FArguments()
			.Title(LOCTEXT("OmniverseExporterDialogTitle", "Omniverse Exporter"))
			.SizingRule(ESizingRule::UserSized)
			.ClientSize(FVector2D(ClientSizeX, ClientSizeY))
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			.bDragAnywhere(false)
			[
				SNew(SVerticalBox)
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 10)
				[
					MaterialWidget.ToSharedRef()
				]

				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 10)
				[
					TextureWidget.ToSharedRef()
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					DDSWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 0)
				[
					CheckpointWidget.ToSharedRef()
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Center)
				.Padding(30)
				[
					ConfirmWidget.ToSharedRef()
				]
			]
		);
		break;
	case EDialogType::Texture:
		ClientSizeY += BaseTextureSizeY + TextureNumItems * ItemSizeY;
		SWindow::Construct(SWindow::FArguments()
			.Title(LOCTEXT("OmniverseExporterDialogTitle", "Omniverse Exporter"))
			.SizingRule(ESizingRule::UserSized)
			.ClientSize(FVector2D(ClientSizeX, ClientSizeY))
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			.bDragAnywhere(false)
			[
				SNew(SVerticalBox)
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 10)
				[
					TextureWidget.ToSharedRef()
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 7)
				[
					DDSWidget.ToSharedRef()
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(100, 0)
				[
					CheckpointWidget.ToSharedRef()
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Center)
				.Padding(30)
				[
					ConfirmWidget.ToSharedRef()
				]
			]
		);
		break;
	case EDialogType::Level:
		ClientSizeY += BaseLevelSizeY + BaseMaterialSizeY + BaseTextureSizeY + LevelNumItems * ItemSizeY + LevelGroupingSizeY;
		SWindow::Construct(SWindow::FArguments()
			.Title(LOCTEXT("OmniverseExporterDialogTitle", "Omniverse Exporter"))
			.SizingRule(ESizingRule::UserSized)
			.ClientSize(FVector2D(ClientSizeX, ClientSizeY))
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			.bDragAnywhere(false)
			[
				SNew(SScrollBox)
				.Orientation(Orient_Vertical)
				+SScrollBox::Slot()
				[
				SNew(SVerticalBox)
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(50, 1)
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Material Settings")))
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(50, 10)
				[
					SNew(SBorder)
					.Padding(5)
					.Content()
					[
						SNew(SVerticalBox)
						+SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							ExportMethodWidget.ToSharedRef()
						]
						+SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							MaterialWidget.ToSharedRef()
						]
						+SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							TextureWidget.ToSharedRef()
						]
						+SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							DDSWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							PreviewSurfaceWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							MaterialOverSublayerWidget.ToSharedRef()
						]
					]
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(50, 1)
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Stage Settings")))
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(50, 10)
				[
					SNew(SBorder)
					.Padding(5)
					.Content()
					[
						SNew(SVerticalBox)
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							NaniteWidget.ToSharedRef()
						]
#if WITH_USD_PHYSICS
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							PhysicsWidget.ToSharedRef()
						]
#endif
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							ScenegraphWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							PayloadWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							UpYAxisWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							RootIdentityWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							SublayersWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							InvisibleLevelWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							DecalActorExportWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							LandscapeGrassWidget.ToSharedRef()
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.HAlign(HAlign_Left)
						.Padding(10, 7)
						[
							LevelExtWidget.ToSharedRef()
						]
					]
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Left)
				.Padding(50, 0)
				[
					CheckpointWidget.ToSharedRef()
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Center)
				.Padding(30)
				[
					ConfirmWidget.ToSharedRef()
				]
			]
			]
		);

		break;
	}
}

void SOmniverseExporterDialog::Construct(const FArguments& InArgs, EDialogType::Type InDialogType, const TArray<UObject*>& InExportedObjects, const FString& InExportPath)
{
	ExportedObjects = InExportedObjects;
	ExportPath = InExportPath;

	ConstructDialog(InDialogType);
}

void SOmniverseExporterDialog::Construct(const FArguments& InArgs, const TArray<AActor*>& InExportedActors, const FString& InExportPath)
{
	ExportedActors = InExportedActors;
	ExportPath = InExportPath;

	ConstructDialog(EDialogType::Object);
}

ECheckBoxState SOmniverseExporterDialog::ExportMethodIsChecked(EExportMethodChoices::Type Choice) const
{
	if (ExportMethodChoice == Choice)
	{
		return ECheckBoxState::Checked;
	}

	return ECheckBoxState::Unchecked; 
}

void SOmniverseExporterDialog::OnExportMethodChanged(ECheckBoxState NewCheckedState, EExportMethodChoices::Type Choice)
{
	if (NewCheckedState == ECheckBoxState::Checked)
	{
		ExportMethodChoice = Choice;
	}
}

ECheckBoxState SOmniverseExporterDialog::TextureSizeIsChecked(ETextureSizeChoices::Type Choice) const
{
	if (TextureSizeChoice == Choice)
	{
		return ECheckBoxState::Checked;
	}

	return ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnTextureSizeChanged(ECheckBoxState NewCheckedState, ETextureSizeChoices::Type Choice)
{
	if (NewCheckedState == ECheckBoxState::Checked)
	{
		TextureSizeChoice = Choice;
	}
}

ECheckBoxState SOmniverseExporterDialog::IsExportDDS() const
{
	return ExportSettings.MaterialSettings.TextureSettings.bDDSExport ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportDDSChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.MaterialSettings.TextureSettings.bDDSExport = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldAddExtension() const
{
	return ExportSettings.bAddExtraExtension ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnAddExtensionChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bAddExtraExtension = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportPhysics() const
{
	return ExportSettings.bExportPhysics ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportPhysicsChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bExportPhysics = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldInstanceMesh() const
{
	return ExportSettings.bMeshInstanced ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnInstanceMeshChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bMeshInstanced = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportTwoSidedFoliage() const
{
	return ExportSettings.MaterialSettings.bExportTwoSidedSign ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportTwoSidedFoliageChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.MaterialSettings.bExportTwoSidedSign = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldUsePreviewSurface() const
{
	return ExportSettings.bPreviewSurface ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnUsePreviewSurfaceChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bPreviewSurface = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportInvisible() const
{
	return ExportSettings.bExportInvisible ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportInvisible(ECheckBoxState NewCheckedState)
{
	ExportSettings.bExportInvisible = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldUseMDL() const
{
	return ExportSettings.bMDL ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnUseMDLChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bMDL = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportPayload() const
{
	return ExportSettings.bPayloads ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnPayloadChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bPayloads = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportSublayers() const
{
	return ExportSettings.bExportSublayers ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportSublayers(ECheckBoxState NewCheckedState)
{
	ExportSettings.bExportSublayers = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldUpYAxis() const
{
	return ExportSettings.bUpYAxis ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnUpYAxisChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bUpYAxis = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportDecalActors() const
{
	return ExportSettings.bExportDecalActors ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportDecalActorsChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bExportDecalActors = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportPreviewMesh() const
{
	return ExportSettings.bExportPreviewMesh ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportPreviewMesh(ECheckBoxState NewCheckedState)
{
	ExportSettings.bExportPreviewMesh = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportLandscapeGrass() const
{
	return ExportSettings.bExportLandscapeGrass ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportLandscapeGrass(ECheckBoxState NewCheckedState)
{
	ExportSettings.bExportLandscapeGrass = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldExportNanite() const
{
	return ExportSettings.bNanite ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnExportNanite(ECheckBoxState NewCheckedState)
{
	ExportSettings.bNanite = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldRootIdentity() const
{
	return ExportSettings.bRootIdentity ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}
void SOmniverseExporterDialog::OnRootIdentityChanged(ECheckBoxState NewCheckedState)
{
	ExportSettings.bRootIdentity = (NewCheckedState == ECheckBoxState::Checked);
}

ECheckBoxState SOmniverseExporterDialog::ShouldCreateMaterialOverSublayer() const
{
	return ExportSettings.bMaterialOverSublayer ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SOmniverseExporterDialog::OnCreateMaterialOverSublayer(ECheckBoxState NewCheckedState)
{
	ExportSettings.bMaterialOverSublayer = (NewCheckedState == ECheckBoxState::Checked);
}

TSharedRef<SWidget> SOmniverseExporterDialog::OnGetComboBoxWidget(TSharedPtr<FName> InItem)
{
	return SNew(STextBlock).Text(FText::FromName(InItem.IsValid() ? *InItem : NAME_None));
}

void SOmniverseExporterDialog::OnComboBoxChanged(TSharedPtr<FName> InItem, ESelectInfo::Type InSeletionInfo, FName* OutValue)
{
	*OutValue = *InItem;
}

FText SOmniverseExporterDialog::GetComboBoxValueAsText(FName* InValue) const
{
	return FText::FromName(*InValue);
}

FText SOmniverseExporterDialog::GetComboBoxValueToolTipAsText(FName* InValue) const
{
	if (InValue->Compare(FName(TEXT(MDL_USE_CORE_DEPENDENCIES_OPTION))) == 0)
	{
		return FText::FromString(TEXT("Library MDL files are referenced from the Core materials. All other material templates and collection dependencies are copied on export."));
	}
	else
	{
		return FText::FromString(TEXT("All material library items, templates and collection dependencies are copied on export."));
	}
}

bool SOmniverseExporterDialog::IsIncludeDependenciesSelected() const
{
	return (MDLSelect.Compare(TEXT(MDL_INCLUDE_DEPENDENCIES_OPTION)) == 0);
}

void SOmniverseExporterDialog::OnDestPathTextCommitted(const FText& Text, ETextCommit::Type CommitType)
{
	auto DestPath = Text.ToString();
	if (DestPath.StartsWith(OMNIVERSE_FOLDER))
	{
		ExportSettings.MaterialSettings.DestTemplatePath = GetDefault<UOmniverseContentManager>()->GetOmniServerPath(DestPath);
	}
	else
	{
		ExportSettings.MaterialSettings.DestTemplatePath = DestPath;
	}
}

FText SOmniverseExporterDialog::GetDestPath() const
{
	return FText::FromString(ExportSettings.MaterialSettings.DestTemplatePath);
}

FReply SOmniverseExporterDialog::DestPathClicked()
{
	//NOTE: ChooseOmniversePathForAsset only can return file path
	if (!ExportPath.IsEmpty())
	{
		IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
		if (DesktopPlatform)
		{
			DesktopPlatform->OpenDirectoryDialog(
				FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
				NSLOCTEXT("Omniverse", "ChooseADirectory", "ChooseADirectory").ToString(),
				ExportPath, ExportSettings.MaterialSettings.DestTemplatePath);
		}
	}
	else
	{
		ExportSettings.MaterialSettings.DestTemplatePath = GetDefault<UOmniverseContentManager>()->GetOmniServerPath(FPaths::GetPath(FOmniverseEditorExportUtils::ChooseOmniversePathForAsset("", true)));
	}

	return FReply::Handled();
}

void SOmniverseExporterDialog::OnCheckpointTextCommitted(const FText& Text, ETextCommit::Type CommitType)
{
	// Set the global checkpoint comment 
	Checkpoint = Text.ToString();
}

FReply SOmniverseExporterDialog::OkClicked()
{
	RequestDestroyWindow();
	ExportSettings.bModular = ExportMethodChoice == EExportMethodChoices::ModularExport;
	ExportSettings.MaterialSettings.bCopyTemplate = (MDLSelect.Compare(TEXT(MDL_INCLUDE_DEPENDENCIES_OPTION)) == 0);
	ExportSettings.MaterialSettings.TextureSettings.bTextureSource = TextureSizeChoice == ETextureSizeChoices::UseTextureSource;

	if (!ExportPath.IsEmpty() && FPaths::GetExtension(ExportPath).ToLower() == TEXT("usda"))
	{
		ExportSettings.bAsciiFormat = true;
	}

	FOmniverseMessageLogContext::ClearMessages();
	IOmniverseRuntimeModule::Get().SetCheckpointComment(Checkpoint);

	// For local export : convert to unmangled file name
	auto GetFullExportPath = [](const FString& ExportPath)
	{
		FString AbsolutePath = FPaths::ConvertRelativePathToFull(ExportPath);
		FString Path;
		FString Filename;
		FString Ext;
		FPaths::Split(AbsolutePath, Path, Filename, Ext);
		
		FString OutFilename;
		FOmniversePathHelper::UnmanglePath(Filename, OutFilename, false);
		if (Ext.IsEmpty())
		{
			return FString(Path / OutFilename);
		}
		else
		{
			return FString(Path / OutFilename + TEXT(".") + Ext);
		}
	};

	if (ExportedActors.Num() > 0)
	{
		if (!ExportPath.IsEmpty())
		{
			FOmniverseUSDHelper::ExportActorsAsUSDToPath(ExportedActors, GetFullExportPath(FPaths::ConvertRelativePathToFull(ExportPath)), ExportSettings);
		}
		else
		{
			FOmniverseEditorExportUtils::ExportActorsToOmniverse(ExportedActors, ExportSettings);
		}
	}
	
	if (ExportedObjects.Num() > 0)
	{
		if (!ExportPath.IsEmpty())
		{
			FString AbsoluteExportPath = GetFullExportPath(FPaths::ConvertRelativePathToFull(ExportPath));
			for (auto Object : ExportedObjects)
			{
				if (Object->IsA<UWorld>())
				{
					FOmniverseUSDHelper::ExportUWorldAsUSDToPath(Cast<UWorld>(Object), AbsoluteExportPath, ExportSettings);
				}
				else
				{
					FOmniverseUSDHelper::ExportObjectAsUSDToPath(Object, AbsoluteExportPath, FPaths::GetPath(AbsoluteExportPath), ExportSettings);
				}

				// Only the first object
				break;
			}
		}
		else
		{
			FOmniverseEditorExportUtils::ExportObjectsToOmniverse(ExportedObjects, ExportSettings);
		}
	}

	IOmniverseRuntimeModule::Get().SetCheckpointComment("");
	FOmniverseMessageLogContext::DisplayMessages();

	return FReply::Handled();
}

FReply SOmniverseExporterDialog::CancelClicked()
{
	RequestDestroyWindow();
	return FReply::Handled();
}

void SOmniverseExporterDialog::ShowDialog(EDialogType::Type DialogType, const TArray<UObject*>& InExportedObjects, const FString& InExportPath)
{
	// Create the window to pick the class
	TSharedRef<SOmniverseExporterDialog> OmniverseExporterDialog = SNew(SOmniverseExporterDialog, DialogType, InExportedObjects, InExportPath);

	TSharedPtr<SWindow> ParentWindow;
	if( FModuleManager::Get().IsModuleLoaded( "MainFrame" ) )
	{
		IMainFrameModule& MainFrame = FModuleManager::LoadModuleChecked<IMainFrameModule>( "MainFrame" );
		ParentWindow = MainFrame.GetParentWindow();
	}

	FSlateApplication::Get().AddModalWindow(OmniverseExporterDialog, ParentWindow, false);
}

void SOmniverseExporterDialog::ShowDialog(const TArray<AActor*>& InExportedActors, const FString& InExportPath)
{
	// Create the window to pick the class
	TSharedRef<SOmniverseExporterDialog> OmniverseExporterDialog = SNew(SOmniverseExporterDialog, InExportedActors, InExportPath);
	TSharedPtr<SWindow> ParentWindow;
	if( FModuleManager::Get().IsModuleLoaded( "MainFrame" ) )
	{
		IMainFrameModule& MainFrame = FModuleManager::LoadModuleChecked<IMainFrameModule>( "MainFrame" );
		ParentWindow = MainFrame.GetParentWindow();
	}

	FSlateApplication::Get().AddModalWindow(OmniverseExporterDialog, ParentWindow, false);
}
#undef LOCTEXT_NAMESPACE
