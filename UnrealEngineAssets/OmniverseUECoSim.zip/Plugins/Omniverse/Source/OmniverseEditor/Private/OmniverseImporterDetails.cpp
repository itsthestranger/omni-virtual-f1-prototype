// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseImporterDetails.h"

#include "Framework/Application/SlateApplication.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SEditableText.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SButton.h"
#include "PropertyHandle.h"
#include "IDetailChildrenBuilder.h"
#include "DetailWidgetRow.h"
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"
#include "PropertyCustomizationHelpers.h"
#include "DesktopPlatformModule.h"
#include "PropertyEditorModule.h"
#include "EditorDirectories.h"
#include "OmniverseImporterUI.h"
#include "OmniverseImporterDialog.h"
#include "Dialogs/DlgPickPath.h"

#define LOCTEXT_NAMESPACE "OmniverseEditor"

TSharedRef<IDetailCustomization> FOmniverseImporterDetails::MakeInstance()
{
	return MakeShareable( new FOmniverseImporterDetails );
}

void FOmniverseImporterDetails::CustomizeDetails( IDetailLayoutBuilder& DetailBuilder )
{
	IDetailCategoryBuilder& PathCategory = DetailBuilder.EditCategory( "Path" );

	FDetailWidgetRow& InfoWidget = PathCategory.AddCustomRow(FText::FromString(TEXT("Info Widget")));

	InfoWidget.NameContent()
	[
		SNew(STextBlock)
		.Text(this, &FOmniverseImporterDetails::GetInfoContentName)
	];
	InfoWidget.ValueContent()
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SEditableText)
			.Text(this, &FOmniverseImporterDetails::GetInfoPathText)
			.ToolTipText(this, &FOmniverseImporterDetails::GetInfoPathText)
			.IsReadOnly(true)
		]
	];

	FDetailWidgetRow& SelectWidget = PathCategory.AddCustomRow(FText::FromString(TEXT("Select Widget")));

	SelectWidget.NameContent()
	[
		SNew(STextBlock)
		.Text(this, &FOmniverseImporterDetails::GetSelectContentName)
	];
	SelectWidget.ValueContent()
	.MinDesiredWidth(200.0f)
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		[
			SNew(SEditableTextBox)
			.Text(this, &FOmniverseImporterDetails::GetSelectPathText)
			.OnTextCommitted(this, &FOmniverseImporterDetails::OnSelectPathTextCommitted)
			.ToolTipText(this, &FOmniverseImporterDetails::GetSelectPathText)
			.MinDesiredWidth(200.0f)
		]
		+ SHorizontalBox::Slot()
		.VAlign(VAlign_Center)
		.AutoWidth()
		.Padding(5)
		[
			SNew(SButton)
			.IsFocusable(false)
			.OnClicked(this, &FOmniverseImporterDetails::OnSelectPathClicked)
			.ToolTipText(this, &FOmniverseImporterDetails::GetSelectButtonTipText)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("...", "..."))
			]
		]
	];
}

FText FOmniverseImporterDetails::GetInfoContentName() const
{
	auto ImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	FString SelectName = ImporterUI->SourceType == EOmniSourceType::OST_Local ? TEXT("Asset Folder") : TEXT("Input USD File");
	return FText::FromString(SelectName);
}

FText FOmniverseImporterDetails::GetSelectContentName() const
{
	auto ImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	FString SelectName = ImporterUI->SourceType == EOmniSourceType::OST_Local ? TEXT("Input USD File") : TEXT("Asset Folder");
	return FText::FromString(SelectName);
}

FText FOmniverseImporterDetails::GetInfoPathText() const
{
	auto ImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	return FText::FromString(ImporterUI->SourceType == EOmniSourceType::OST_Local ? ImporterUI->AssetPath : ImporterUI->USDPath);
}

FText FOmniverseImporterDetails::GetSelectPathText() const
{
	auto ImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	return FText::FromString(ImporterUI->SourceType == EOmniSourceType::OST_Local ? ImporterUI->USDPath : ImporterUI->AssetPath);
}

FText FOmniverseImporterDetails::GetSelectButtonTipText() const
{
	auto ImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	return FText::FromString(ImporterUI->SourceType == EOmniSourceType::OST_Local ? "Browse for the usd files" : "Browse for the asset folder");
}

void FOmniverseImporterDetails::OnSelectPathTextCommitted(const FText& Text, ETextCommit::Type CommitType)
{
	auto ImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	if (ImporterUI->SourceType == EOmniSourceType::OST_Local)
	{
		ImporterUI->USDPath = Text.ToString();
		ImporterUI->PreUSDPath[ImporterUI->SourceType][ImporterUI->ImporterType] = ImporterUI->USDPath;
	}
	else
	{
		ImporterUI->AssetPath = Text.ToString();
		ImporterUI->PreAssetPath[ImporterUI->SourceType][ImporterUI->ImporterType] = ImporterUI->AssetPath;
	}
}

FReply FOmniverseImporterDetails::OnSelectPathClicked()
{
	auto ImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	if (ImporterUI->SourceType == EOmniSourceType::OST_Local)
	{
		IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
		if (DesktopPlatform)
		{
			TArray<FString> OpenFilenames;
			bool bOpened = false;

			const void* ParentWindowWindowHandle = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr);
			const FString FileTypes = TEXT("USD Files (*.usd; *.usda; *.usdc; *.usdz)|*.usd; *.usda; *.usdc; *.usdz|USD Binary File (*.usd)|*.usd|USD Text File (*.usda)|*.usda|USD Crate File (*.usdc)|*.usdc|USD Zip File (*.usdz)|*.usdz");

			bOpened = DesktopPlatform->OpenFileDialog(
				ParentWindowWindowHandle,
				LOCTEXT("ImportDialogTitle", "Import").ToString(),
				FEditorDirectories::Get().GetLastDirectory(ELastDirectory::GENERIC_IMPORT),
				TEXT(""),
				FileTypes,
				EFileDialogFlags::Multiple,
				OpenFilenames
				);

			if (bOpened && OpenFilenames.Num() > 0)
			{
				FString& OpenedFile = OpenFilenames[0];
				FEditorDirectories::Get().SetLastDirectory(ELastDirectory::GENERIC_IMPORT, FPaths::GetPath(OpenedFile));

				FString Filenames;
				for (auto OpenFile : OpenFilenames)
				{
					if (!OpenFile.IsEmpty())
					{
						Filenames += ";";
					}
					Filenames += OpenFile;
				}
			
				ImporterUI->USDPath = Filenames;
				ImporterUI->PreUSDPath[ImporterUI->SourceType][ImporterUI->ImporterType] = ImporterUI->USDPath;
			}
		}
	}
	else
	{
		TSharedRef<SDlgPickPath> PickContentPathDlg =
		SNew(SDlgPickPath)
		.Title(LOCTEXT("ChangePath_Tooltip", "Choose Location path for importing animations"));

		if (PickContentPathDlg->ShowModal() == EAppReturnType::Ok)
		{
			ImporterUI->AssetPath = PickContentPathDlg->GetPath().ToString();
			ImporterUI->PreAssetPath[ImporterUI->SourceType][ImporterUI->ImporterType] = ImporterUI->AssetPath;			
		}
	}

	if (SOmniverseImporterDialog::DialogPtr.IsValid())
	{
		auto DialogWindow = SOmniverseImporterDialog::DialogPtr.Pin();
		DialogWindow->BringToFront();
	}

	return FReply::Handled();
}

#undef LOCTEXT_NAMESPACE
