// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "Commandlets/Commandlet.h"

#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"
#include "Logging/LogMacros.h"
#include "UObject/ObjectMacros.h"
#include "Editor/UnrealEdEngine.h"

#include "OmniverseExportSettings.h"

#include "OmniverseCommandlet.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogOmniverseCommandlet, Log, All);

UCLASS()
class UOmniverseCommandlet : public UCommandlet
{
	GENERATED_UCLASS_BODY()

public:

	UOmniverseCommandlet();

	//~ Begin UCommandlet Interface
	int32 Main(const FString& Params) override;
	void CreateCustomEngine(const FString& Params) override;
	//~ End UCommandlet Interface

private:

	/** The list of switches that were passed on the commandline */
	TArray<FString> Switches;

	/** The Omniverse server. */
	FString OmniverseServer{};

	/** The user. */
	FString OmniverseUser{"admin"};

	/** The USD path of the export. */
	FString USDPath{};

	/** The USD file name. */
	FString USDFile{};

	/** Commandlet USD settings. */
	FOmniverseExportSettings Settings{};

	/** Convert actors to StaticMeshActors. */
	bool bConvertToStaticMeshActors{ false };

	/** Emit log messages. */
	bool bVerboseLogMessages{ !(UE_BUILD_SHIPPING || UE_BUILD_TEST) };

	/** Call BeginPlay. */
	bool bUseBeginPlay{ true };

	/** Test only. */
	bool bTestOnly{ false };

	/** Maps Package Names. */
	TArray<FString> MapNames;

	/** Initialize Commandlet. */
	void InitializeExportParameters();

	/** Create/Reset USD file before exporting. */
	void CreateUSD();

	/** Open a connection to OV. */
	bool ConnectToOmniverse();

	/** Export Level */
	bool ExportWorldToOmniverse(UWorld* World);

	/** Export Actors. */
	bool ExportActorsAsUSDToPath(const TArray<class AActor*>& Actors, const FString& ExportUSDPath);
	bool ExportActorsToOmniverse(const TArray<AActor*>& SelectedActors);
};


UCLASS(config = Engine, transient)
class UOmniverseEngine : public UUnrealEdEngine
{
	GENERATED_UCLASS_BODY()

public:

	UOmniverseEngine();

	//~ Begin UEditorEngine Interface
	bool ShouldThrottleCPUUsage() const override;
	//~ End UEditorEngine Interface
};
