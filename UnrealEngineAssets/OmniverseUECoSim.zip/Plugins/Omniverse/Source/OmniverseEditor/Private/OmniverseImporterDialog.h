// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once 

#include "Widgets/SWindow.h"
#include "OmniverseImporterUI.h"
#include "OmniverseImportSettings.h"

class SOmniverseImporterDialog : public SWindow
{
public:
	SLATE_BEGIN_ARGS(SOmniverseImporterDialog)
	{}

	SLATE_ARGUMENT(UOmniverseImporterUI*, ImporterUI)

	SLATE_END_ARGS()

	//~SOmniverseImporterDialog();

	/** 
	 * Constructs a new importer dialog. 
	 *
	 * @param InArgs Slate arguments. 
	 */
	void Construct(const FArguments& InArgs);


	// Show the dialog
	// SourceType = Local, FullPath is the content browser folder to save the asset
	// SourceType = Nucleus, FullPath is the Omniverse URL on Nucleus to be exported
	static void ShowDialog(EOmniImporterType DialogType, EOmniSourceType SourceType, const FString& FullPath);

	static TWeakPtr<class SOmniverseImporterDialog> DialogPtr;

private:
	FReply OkClicked();
	FReply CancelClicked();
	bool IsImporterReady() const;

private:
	void ConstructDialog();

	UOmniverseImporterUI*	ImporterUI;
	FOmniverseImportSettings ImportSettings;
	TSharedPtr<class IDetailsView> DetailsView;
};