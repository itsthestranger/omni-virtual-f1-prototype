// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseEditorStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Interfaces/IPluginManager.h"

FOmniverseEditorStyle FOmniverseEditorStyle::OmniverseEditorStyle;


FOmniverseEditorStyle::FOmniverseEditorStyle()
	:FSlateStyleSet("OmniverseEditorStyle")
{
	SetContentRoot(IPluginManager::Get().FindPlugin("Omniverse")->GetContentDir() / "Editor/Icons");

	const FVector2D Icon20x20(20.0f, 20.0f);
	const FVector2D Icon32x32(32.0f, 32.0f);
	const FVector2D Icon40x40(40.0f, 40.0f);
	const FVector2D Icon64x64(64.0f, 64.0f);

	Set("MainButton.Connected", new FSlateImageBrush(RootToContentDir(L"Connected.png"), Icon40x40));
	Set("MainButton.Connected.Small", new FSlateImageBrush(RootToContentDir(L"Connected.png"), Icon20x20));
	Set("MainButton.Connected_live", new FSlateImageBrush(RootToContentDir(L"Connected_live.png"), Icon40x40));
	Set("MainButton.Connected_live.Small", new FSlateImageBrush(RootToContentDir(L"Connected_live.png"), Icon20x20));
	Set("MainButton.Disconnected", new FSlateImageBrush(RootToContentDir(L"Disconnected.png"), Icon40x40));
	Set("MainButton.Disconnected.Small", new FSlateImageBrush(RootToContentDir(L"Disconnected.png"), Icon20x20));
	Set("OmniverseAboutScreen.Background", new FSlateImageBrush(RootToContentDir(L"OmniverseAboutBackground.png"), FVector2D(600, 332), FLinearColor::White, ESlateBrushTileType::Both));
	Set("OmniverseAboutScreen.LogoFlat", new FSlateImageBrush(RootToContentDir(L"nvidia-omniverse-viewer-flat-icon-64x64.png"), Icon64x64));
	Set("OmniverseAboutScreen.Logo", new FSlateImageBrush(RootToContentDir(L"nvidia-omniverse-viewer-icon-64x64.png"), Icon64x64));
	Set("OmniverseLiveSessionDialog.Participant", new FSlateImageBrush(RootToContentDir(L"Participants.png"), Icon32x32));
	Set("OmniverseLiveSessionDialog.User", new FSlateImageBrush(RootToContentDir(L"User.png"), Icon32x32));
	FSlateStyleRegistry::RegisterSlateStyle(*this);
}

FOmniverseEditorStyle::~FOmniverseEditorStyle()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*this);
}
