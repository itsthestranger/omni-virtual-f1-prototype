// Copyright(c) 2020, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

// Modified from AboutScreen.h
// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Layout/Margin.h"
#include "Input/Reply.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"

class ITableRow;
class SButton;
class STableViewBase;
struct FSlateBrush;

/**
 * About screen contents widget                   
 */
class SOmniverseAboutScreen : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SOmniverseAboutScreen)
		{}
	SLATE_END_ARGS()

	/**
	 * Constructs the about screen widgets                   
	 */
	void Construct(const FArguments& InArgs);

private:
	TSharedPtr<SButton> OmniverseButton;
	const FSlateBrush* GetOmniverseButtonBrush() const;
	FText GetOmniVersionText(bool bIncludeHeader = true);
	FReply OnOmniverseButtonClicked();
	FReply OnCopyToClipboard();
	FReply OnClose();
};

