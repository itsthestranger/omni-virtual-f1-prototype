// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseMainButton.h"
#include "OmniverseConnectionHelper.h"
#include "OmniverseSettings.h"
#include "IOmniverseRuntimeModule.h"
#include "LevelEditor.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Interfaces/IMainFrameModule.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/SUserWidget.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Misc/MessageDialog.h"
#include "Modules/ModuleManager.h"
#include "OmniverseContentManager.h"
#include "OmniverseAboutScreen.h"
#include "OmniverseEditorExportUtils.h"
#include "OmniverseExporterDialog.h"
#include "OmniverseStageActor.h"
#include "OmniverseUSD.h"
#include "OmniverseLiveSessionDialog.h"
#include "OmniverseMergeSessionDialog.h"
#include "OmniverseNotificationHelper.h"

static TSharedPtr<SHorizontalBox> NotificationUsersBox = nullptr;

TSharedPtr<SHorizontalBox> FOmniverseMainButton::GetUserBox()
{
	return NotificationUsersBox;
}

AOmniverseStageActor* GetValidStageActorFromWorld()
{
	if (GEditor->GetEditorWorldContext().World())
	{
		UWorld* WorldObject = GEditor->GetEditorWorldContext().World();
		if (WorldObject)
		{
			auto StageActor = AOmniverseStageActor::Find(*WorldObject);
			if (StageActor && StageActor->HasValidUSD() && !StageActor->GetUSDPath().IsEmpty())
			{
				return StageActor;
			}
		}
	}

	return nullptr;
}

void FOmniverseMainButton::Initialize()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	TSharedPtr<FExtender> Extender = MakeShared<FExtender>();
	LevelEditorModule.GetToolBarExtensibilityManager()->AddExtender(Extender);

	Extender->AddToolBarExtension("File", EExtensionHook::After, MakeShared<FUICommandList>(), FToolBarExtensionDelegate::CreateLambda(
		[this](FToolBarBuilder& ToolBarBuilder)
		{
			ToolBarBuilder.AddComboButton(
				FUIAction(),
				FOnGetContent::CreateSP(this, &FOmniverseMainButton::GetMenu),
				TAttribute<FText>::Create(TAttribute<FText>::FGetter::CreateSP(this, &FOmniverseMainButton::GetButtonText)),
				TAttribute<FText>::Create(TAttribute<FText>::FGetter::CreateSP(this, &FOmniverseMainButton::GetTooltip)),
				TAttribute<FSlateIcon>::Create(TAttribute<FSlateIcon>::FGetter::CreateSP(this, &FOmniverseMainButton::GetButtonIcon))
			);
		}
	));

	TSharedPtr<FExtender> NotificationExtender = MakeShared<FExtender>();
	NotificationExtender->AddToolBarExtension("ProjectSettings", EExtensionHook::Before, MakeShared<FUICommandList>(), FToolBarExtensionDelegate::CreateLambda(
		[this](FToolBarBuilder& ToolBarBuilder)
		{
			NotificationUsersBox = SNew(SHorizontalBox);
			ToolBarBuilder.AddWidget(
				NotificationUsersBox.ToSharedRef()
			);
		}
	));

	LevelEditorModule.GetToolBarExtensibilityManager()->AddExtender(NotificationExtender);

	IOmniverseRuntimeModule::Get().OnServerConnectionChanged.AddLambda(
		[this](const FString& Server, EOmniverseServerConnectionChange ConnectionChange)
		{
		});
}

FText FOmniverseMainButton::GetTooltip()
{
	const auto& WatchServerStatus = IOmniverseRuntimeModule::Get().GetWatchList();
	FString ServerString("Nucleus Servers:\n");
	for (auto ServerStatus : WatchServerStatus)
	{
		if (ServerStatus.Status == EOmniverseServerConnectionChange::Connected && ServerStatus.UserName.Len() > 0)
		{
			ServerString.Append(" " + ServerStatus.Address + " [" + ServerStatus .UserName + "]: connected\n");
		}
		else
		{
			ServerString.Append(" " + ServerStatus.Address + ": disconnected\n");
		}
	}

	FString LiveSessionString(TEXT(""));
	AOmniverseStageActor* OmniStageActor = GetValidStageActorFromWorld();
	if (OmniStageActor && IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled())
	{
		LiveSessionString = FString::Printf(TEXT("\nSession Name: %s\nSession Owner: %s"), *OmniStageActor->GetUSD()->GetSessionName().ToString(), *OmniStageActor->GetUSD()->GetSessionOwner().ToString());
	}

	auto Tooltip = FString()
		+ ServerString
		+ LiveSessionString;

	return FText::FromString(Tooltip);
}

FText FOmniverseMainButton::GetButtonText()
{
	return FText::FromString("Omniverse");
}

FSlateIcon FOmniverseMainButton::GetButtonIcon()
{
	if(FOmniverseConnectionHelper::IsConnected())
	{
		if(IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled())
		{
			return FSlateIcon("OmniverseEditorStyle", "MainButton.Connected_live");
		}
		else
		{
			return FSlateIcon("OmniverseEditorStyle", "MainButton.Connected");
		}
	}
	else
	{
		return FSlateIcon("OmniverseEditorStyle", "MainButton.Disconnected");
	}
}

void ShowLeaveSessionDialog()
{
	AOmniverseStageActor* OmniStageActor = GetValidStageActorFromWorld();
	if (OmniStageActor)
	{
		FText MessageTitle = FText::FromString(TEXT("Leave Session"));
		EAppReturnType::Type UserChoice = FMessageDialog::Open(EAppMsgType::OkCancel, EAppReturnType::Cancel, FText::Format(FText::FromString("You are about to leave '{0}' session"), FText::FromName(OmniStageActor->GetUSD()->GetSessionName())), &MessageTitle);

		if (UserChoice == EAppReturnType::Ok)
		{
			OmniStageActor->GetUSD()->LeaveSession();
		}
	}
}

TSharedRef<SWidget> FOmniverseMainButton::GetMenu()
{
	FMenuBuilder MenuBuilder(true, nullptr);

	MenuBuilder.AddMenuEntry(
		FText::FromString("Add Server"),
		FText::FromString("Add an Omniverse Nucleus server.  No need to for a complete URL, just the server works, like \"localhost\" or \"my_nucleus_server_address\""),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(this, &FOmniverseMainButton::ShowConnectionDialog))
	);

	if (IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled())
	{
		AOmniverseStageActor* OmniStageActor = GetValidStageActorFromWorld();
		if (OmniStageActor && OmniStageActor->GetUSD()->IsEmptySession())
		{
			MenuBuilder.AddMenuEntry(
				FText::FromString("Live Session"),
				FText::FromString("If the open level is a USD stage on Nucleus, this mode will transmit and receive all changes to/from other Omniverse clients"),
				FSlateIcon(),
				FUIAction(
					FExecuteAction::CreateLambda(
						[]()
						{
							AOmniverseStageActor* OmniStageActor = GetValidStageActorFromWorld();
							if (OmniStageActor)
							{
								OmniStageActor->GetUSD()->LeaveSession();
							}
						}
					), 
					FCanExecuteAction(), 
					FIsActionChecked::CreateLambda(
						[]()
						{
							return IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled();
						}
					)),
				NAME_None,
				EUserInterfaceActionType::ToggleButton
			);
		}
		else
		{
			MenuBuilder.AddSubMenu(
			FText::FromString("Live Session"),
			FText::FromString("If the open level is a USD stage on Nucleus, this mode will transmit and receive all changes to/from other Omniverse clients"),
			FNewMenuDelegate::CreateLambda([](FMenuBuilder& SubMenuBuilder)
			{
				SubMenuBuilder.AddMenuEntry(
					FText::FromString("Leave Session"),
					FText::FromString("Leave Session"),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateLambda(
					[]()
					{
						ShowLeaveSessionDialog();
					}))
				);
				SubMenuBuilder.AddMenuEntry(
					FText::FromString("End and Merge"),
					FText::FromString("End the session and Merge the change to root layer"),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateLambda(
					[]()
					{
						AOmniverseStageActor* OmniStageActor = GetValidStageActorFromWorld();
						if (OmniStageActor)
						{
							SOmniverseMergeSessionDialog::ShowDialog(OmniStageActor->GetUSD());
						}
					}))
				);
			}),
			FUIAction(
				FExecuteAction::CreateLambda(
					[]()
					{
						ShowLeaveSessionDialog();
					}), 
				FCanExecuteAction(), 
				FIsActionChecked::CreateLambda(
					[]()
					{
						return IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled();
					}
				)
			),
			NAME_None,
			EUserInterfaceActionType::ToggleButton
			);
		}
	}
	else
	{
		MenuBuilder.AddMenuEntry(
			FText::FromString("Live Session"),
			FText::FromString("If the open level is a USD stage on Nucleus, this mode will transmit and receive all changes to/from other Omniverse clients"),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateLambda(
					[]()
					{
						// See if there's a USD stage open and get the path
						AOmniverseStageActor* OmniStageActor = GetValidStageActorFromWorld();
						if (OmniStageActor)
						{
							SOmniverseLiveSessionDialog::ShowDialog(OmniStageActor->GetUSD());
						}
						else
						{
							FOmniverseNotificationHelper::NotifyError(TEXT("Only a stage in Nucleus can start a live-sync session."));
						}
					}
				), 
				FCanExecuteAction(), 
				FIsActionChecked::CreateLambda(
					[]()
					{
						return IOmniverseRuntimeModule::Get().IsLiveUpdateEnabled();
					}
				)),
			NAME_None,
			EUserInterfaceActionType::ToggleButton
		);
	}

	MenuBuilder.AddMenuEntry(
		FText::FromString("Export Level to Omniverse"),
		FText::FromString("Export the current level to Omniverse.  This doesn't work correctly when a USD stage is currently open, only with Unreal levels."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(this, &FOmniverseMainButton::ExportCurrentLevelToOmniverse))
	);

	MenuBuilder.AddMenuEntry(
		FText::FromString("Clean Local Assets"),
		FText::FromString("Silently remove all assets of each Omniverse Server, and MDL folders from the project, it might fail because of referenced assets."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(this, &FOmniverseMainButton::CleanLocalAssets))
	);

	MenuBuilder.AddMenuEntry(
		FText::FromString("About Plugin"),
		FText::FromString("Display information about the Omniverse Plugin"),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateSP(this, &FOmniverseMainButton::About))
	);

	return MenuBuilder.MakeWidget();
}

void FOmniverseMainButton::ExportCurrentLevelToOmniverse()
{
	TArray<UObject*> WorldObjects;
	if (GEditor->GetEditorWorldContext().World())
	{
		WorldObjects.Add(GEditor->GetEditorWorldContext().World());
		SOmniverseExporterDialog::ShowDialog(EDialogType::Level, WorldObjects);
	}
}

void FOmniverseMainButton::ShowConnectionDialog()
{
	TSharedPtr<SEditableTextBox> Server;
	ConnectionWnd = SNew(SWindow)
		.Title(FText::FromString("Add Omniverse Server"))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.SizingRule(ESizingRule::Autosized)
		.Content()
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(10, 20, 10, 0)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(EVerticalAlignment::VAlign_Center)
				.AutoWidth()
				[
					SNew(STextBlock).Text(FText::FromString("Server: "))
				]
				+ SHorizontalBox::Slot()
				[
					SAssignNew(Server, SEditableTextBox)
					.MinDesiredWidth(200)
					.Text(FText::FromString("localhost"))
					.SelectAllTextWhenFocused(true)
					.OnTextCommitted(FOnTextCommitted::CreateSP(this, &FOmniverseMainButton::ServerTextCommitted))
				]
			]
			+ SVerticalBox::Slot().AutoHeight()
			[
				SNew(SUniformGridPanel).SlotPadding(FMargin(10, 20, 10, 0))
				+ SUniformGridPanel::Slot(0, 0)
				[
					SNew(SButton).Text(FText::FromString("Add to Content Browser"))
					.HAlign(EHorizontalAlignment::HAlign_Center)
					.OnClicked(FOnClicked::CreateLambda([&]()
						{
							this->OnWatch(Server->GetText());
							ConnectionWnd->RequestDestroyWindow();
							return FReply::Handled();
						}
					))
				]
			]
		];

	// Set focus to Server text box
	ConnectionWnd->SetWidgetToFocusOnActivate(Server);

	FSlateApplication::Get().AddModalWindow(ConnectionWnd.ToSharedRef(), FGlobalTabmanager::Get()->GetRootWindow());
}

void FOmniverseMainButton::ServerTextCommitted(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType == ETextCommit::OnEnter)
	{
		OnWatch(NewText);
		ConnectionWnd->RequestDestroyWindow();
	}
}

void FOmniverseMainButton::CleanLocalAssets()
{
	GetMutableDefault<UOmniverseContentManager>()->CleanAssets();
}

void FOmniverseMainButton::About()
{
	// Pop up an "About" dialog with version information
	const FText AboutWindowTitle = FText::FromString(TEXT("About NVIDIA Omniverse USD and MDL Plugins"));

	TSharedPtr<SWindow> AboutWindow = 
		SNew(SWindow)
		.Title( AboutWindowTitle )
		.ClientSize(FVector2D(600.f, 250.f))
		.SupportsMaximize(false) .SupportsMinimize(false)
		.SizingRule( ESizingRule::FixedSize )
		[
			SNew(SOmniverseAboutScreen)
		];

	IMainFrameModule& MainFrame = FModuleManager::LoadModuleChecked<IMainFrameModule>( "MainFrame" );
	TSharedPtr<SWindow> ParentWindow = MainFrame.GetParentWindow();

	if ( ParentWindow.IsValid() )
	{
		FSlateApplication::Get().AddModalWindow(AboutWindow.ToSharedRef(), ParentWindow.ToSharedRef());
	}
	else
	{
		FSlateApplication::Get().AddWindow(AboutWindow.ToSharedRef());
	}
}

void FOmniverseMainButton::OnWatch(FText Server)
{
	FString ServerString = Server.ToString();

	// in case someone misunderstands the idea of a "server", remove any URL info first
	ServerString.RemoveFromStart(TEXT("omniverse://"));
	ServerString.RemoveFromStart(TEXT("omni://"));

	IOmniverseRuntimeModule::Get().WatchServer(ServerString);
	auto OmniSettings = GetMutableDefault<UOmniverseSettings>();
	OmniSettings->WatchServers.AddUnique(ServerString);
	OmniSettings->TryUpdateDefaultConfigFile();
}
