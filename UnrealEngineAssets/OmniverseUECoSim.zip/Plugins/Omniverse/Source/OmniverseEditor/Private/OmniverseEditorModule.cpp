// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseEditorModule.h"
#include "OmniverseEditorPrivate.h"
#include "ISettingsModule.h"
#include "AssetToolsModule.h"
#include "ISettingsSection.h"
#include "Editor/EditorPerformanceSettings.h"
#include "Settings/ContentBrowserSettings.h"
#include "Logging/LogMacros.h"
#include "OmniverseAssetDownloadNotification.h"
#include "OmniverseSettings.h"
#include "OmniverseAssetActions.h"
#include "OmniverseMDLAssetActions.h"
#include "OmniverseMainButton.h"
#include "OmniverseImporterDetails.h"
#include "PropertyEditorModule.h"

DEFINE_LOG_CATEGORY(LogOmniverseEditor);
#define LOCTEXT_NAMESPACE "OmniverseEditor"

void FOmniverseEditorModule::StartupModule()
{
	// Register settings
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		ISettingsSectionPtr SettingsSection = SettingsModule->RegisterSettings(
			"Project", "Plugins", "OmniverseSettings",
			FText::FromString("Omniverse"),
			FText::FromString("Configure Omniverse settings"),
			GetMutableDefault<UOmniverseSettings>());
	}

	// Asset actions for USD
	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	EAssetTypeCategories::Type USDAssetCategoryBit = AssetTools.RegisterAdvancedAssetCategory(FName(TEXT("Omniverse")), LOCTEXT("OmniverseAssetCategory", "Omniverse"));
	USDActions = MakeShareable(new FUSDAssetTypeActions(USDAssetCategoryBit));
	AssetTools.RegisterAssetTypeActions(USDActions->AsShared());

	// Asset actions for MDL
	EAssetTypeCategories::Type MDLAssetCategoryBit = AssetTools.RegisterAdvancedAssetCategory(FName(TEXT("OmniverseMDL")), LOCTEXT("OmniverseMDLAssetCategory", "OmniverseMDL"));
	MDLActions = MakeShareable(new FMDLAssetTypeActions(MDLAssetCategoryBit));
	AssetTools.RegisterAssetTypeActions(MDLActions->AsShared());

	// Editor menu extension
	extern void InitializeLevelEditorMenu();
	extern void InitializeContenBrowserMenu();
	extern TFunction<void()> InitializeViewportMenu();
	InitializeLevelEditorMenu();
	InitializeContenBrowserMenu();
	ShutdownViewportExtension = InitializeViewportMenu();

	// Initialize download notification
	AssetDownloadNotification = MakeShared<FOmniverseAssetDownloadNotification>();
	AssetDownloadNotification->Initialize();

	// Main button UI
	MainButton = MakeShared<FOmniverseMainButton>();
	MainButton->Initialize();

	// Disable Editor performance throttling
	UEditorPerformanceSettings* Settings = GetMutableDefault<UEditorPerformanceSettings>();
	Settings->bThrottleCPUWhenNotForeground = false;
	Settings->TryUpdateDefaultConfigFile();

	// Force-enable DisplayEmptyFolders, hiding empty folders breaks server browsing
	UContentBrowserSettings* ContentBrowserSettings = GetMutableDefault<UContentBrowserSettings>();
	ContentBrowserSettings->DisplayEmptyFolders = true;
	ContentBrowserSettings->TryUpdateDefaultConfigFile();

	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout("OmniverseImporterUI", FOnGetDetailCustomizationInstance::CreateStatic(&FOmniverseImporterDetails::MakeInstance));
	PropertyModule.NotifyCustomizationModuleChanged();
}

void FOmniverseEditorModule::ShutdownModule()
{
	// Asset actions for USD and MDL
	if(FAssetToolsModule* AssetToolsModule = FModuleManager::GetModulePtr<FAssetToolsModule>("AssetTools"))
	{
		IAssetTools& AssetTools = AssetToolsModule->Get();
		AssetTools.UnregisterAssetTypeActions(USDActions->AsShared());
		AssetTools.UnregisterAssetTypeActions(MDLActions->AsShared());
	}

	// Remove level viewport context menu extenders
	if(ShutdownViewportExtension)
	{
		ShutdownViewportExtension();
	}

	if (FModuleManager::Get().IsModuleLoaded("PropertyEditor"))
	{
		FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");

		// Unregister all classes customized by name
		PropertyModule.UnregisterCustomClassLayout("OmniverseImporterUI");
	
		PropertyModule.NotifyCustomizationModuleChanged();
	}
}

IMPLEMENT_MODULE(FOmniverseEditorModule, OmniverseEditor)

#undef LOCTEXT_NAMESPACE