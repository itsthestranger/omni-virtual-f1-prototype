// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once 

#include "Widgets/SWindow.h"


class SOmniverseMergeSessionDialog : public SWindow
{
public:
	SLATE_BEGIN_ARGS(SOmniverseMergeSessionDialog)
	{}

	SLATE_END_ARGS()

	//~SOmniverseMergeSessionDialog();

	/** 
	 * Constructs a new dialog. 
	 *
	 * @param InArgs Slate arguments. 
	 */
	void Construct(const FArguments& InArgs, class UOmniverseUSD* USD);
	
	// Show the dialog
	static void ShowDialog(class UOmniverseUSD* USD);

private:
	void Destroy();

private:
	TArray<TSharedPtr<FName>> Options;
	FName SelectOption;
	class UOmniverseUSD* USDAsset;
	FString Checkpoint;
	FString WarningMessage;
};