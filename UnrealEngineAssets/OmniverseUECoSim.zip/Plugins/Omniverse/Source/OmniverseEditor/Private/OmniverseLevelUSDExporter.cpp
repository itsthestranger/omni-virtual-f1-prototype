// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseLevelUSDExporter.h"
#include "EngineUtils.h"
#include "OmniverseSettings.h"
#include "OmniverseUSD.h"
#include "OmniverseStageActor.h"
#include "OmniverseContentManager.h"
#include "OmniverseUSDHelper.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseExporterDialog.h"
#include "OmniversePathHelper.h"

UOmniverseLevelUSDExporter::UOmniverseLevelUSDExporter(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SupportedClass = UWorld::StaticClass();
	FormatExtension.Add(TEXT("usda"));
	FormatExtension.Add(TEXT("usd"));	// Must be lower case. Otherwise Stage_Create() will fail.
	FormatDescription.Add(TEXT("Universe Scene Description Text File"));
	FormatDescription.Add(TEXT("Universe Scene Description Binary File"));
}

bool UOmniverseLevelUSDExporter::ExportBinary(UObject* Object, const TCHAR* Type, FArchive& Ar, FFeedbackContext* Warn, int32 FileIndex, uint32 PortFlags)
{
	return Export(*CastChecked<UWorld>(Object), CurrentFilename, true, false, true);
}

bool UOmniverseLevelUSDExporter::Export(UWorld& World, FString& Path, bool bSaveAs, bool bReplace, bool ExportUE4Objects) const
{
	if (bSelectedOnly) // path to export selected
	{
		TArray<AActor*> ActorsToExport;
		TArray<ALevelSequenceActor*> LevelSequenceActors;
		FOmniverseUSDHelper::GetActorsToExportFromWorld(&World, bSelectedOnly, FOmniverseExportSettings(), ActorsToExport, LevelSequenceActors);
		SOmniverseExporterDialog::ShowDialog(ActorsToExport, Path);
	}
	else
	{
		//// Export to local
		TArray<UObject*> UObjectsToExport;
		UObjectsToExport.Add(&World);
		SOmniverseExporterDialog::ShowDialog(EDialogType::Level, UObjectsToExport, Path);
	}
	return true;
}