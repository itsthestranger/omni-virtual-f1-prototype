// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseStaticMeshUSDExporter.h"
#include "OmniverseEditorPrivate.h"
#include "Engine/StaticMesh.h"
#include "OmniverseExporterDialog.h"


UOmniverseStaticMeshUSDExporter::UOmniverseStaticMeshUSDExporter(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SupportedClass = UStaticMesh::StaticClass();
	FormatExtension.Add(TEXT("usda"));
	FormatExtension.Add(TEXT("usd"));	// Must be lower case. Otherwise Stage_Create() will fail.
	FormatDescription.Add(TEXT("Universe Scene Description Text File"));
	FormatDescription.Add(TEXT("Universe Scene Description Binary File"));
}

bool UOmniverseStaticMeshUSDExporter::ExportBinary(UObject* Object, const TCHAR* Type, FArchive& Ar, FFeedbackContext* Warn, int32 FileIndex, uint32 PortFlags)
{
	TArray<UObject*> UObjectsToExport;
	UObjectsToExport.Add(Object);
	SOmniverseExporterDialog::ShowDialog(EDialogType::Object, UObjectsToExport, CurrentFilename);

	return true;
}