// Copyright(c) 2022, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseThumbnailUtils.h"
#include "OmniverseConnectionHelper.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "ImageUtils.h"
#include "Misc/Paths.h"
#include "ObjectTools.h"
#include "OmniverseAsset.h"

extern bool OMNIVERSERUNTIME_API GListingAssetsForEditor;

namespace OmniverseThumbnailUtils
{
	void LoadOmniThumbnail(const FString& OmniPath, const FString& ThumbnaiPath, const FString& ObjectFullName, const FString& PackageName)
	{
		FOmniverseReadCallback ReadCallback = FOmniverseReadCallback::CreateLambda(
			[OmniPath, ObjectFullName, PackageName](const FOmniverseReadResult& ReadResult)
			{
				if (ReadResult.Status == eOmniClientResult_Ok && ReadResult.Content)
				{
					const int32 DefaultThumbnailSize = 256;
					TArray64<uint8> RawImageData;
					int32 RawWidth = 0, RawHeight = 0;
					bool bGrayData = false;
					IImageWrapperModule* ImageWrapperModule = FModuleManager::GetModulePtr<IImageWrapperModule>(FName("ImageWrapper"));
					TSharedPtr<IImageWrapper> PngImageWrapper = ImageWrapperModule->CreateImageWrapper(EImageFormat::PNG);
					if (PngImageWrapper.IsValid() && PngImageWrapper->SetCompressed(ReadResult.Content->GetData(), ReadResult.Content->Size()))
					{
						int32 BitDepth = PngImageWrapper->GetBitDepth();
						ERGBFormat Format = PngImageWrapper->GetFormat();
						RawWidth = PngImageWrapper->GetWidth();
						RawHeight = PngImageWrapper->GetHeight();

						// Ignore 16 bit for thumbnail
						if (BitDepth > 8)
						{
							return;
						}

						if (Format == ERGBFormat::RGBA || Format == ERGBFormat::BGRA)
						{
							if (BitDepth <= 8)
							{
								Format = ERGBFormat::BGRA;
								BitDepth = 8;
							}

							if (!PngImageWrapper->GetRaw(Format, BitDepth, RawImageData))
							{
								return;
							}
						}
						else if (Format == ERGBFormat::Gray)
						{
							if (!PngImageWrapper->GetRaw(Format, 8, RawImageData))
							{
								return;
							}
							bGrayData = true;
						}
					}
					else
					{
						// if png was failed, try jpg next
						TSharedPtr<IImageWrapper> JpegImageWrapper = ImageWrapperModule->CreateImageWrapper(EImageFormat::JPEG);
						if (JpegImageWrapper.IsValid() && JpegImageWrapper->SetCompressed(ReadResult.Content->GetData(), ReadResult.Content->Size()))
						{
							int32 BitDepth = JpegImageWrapper->GetBitDepth();
							ERGBFormat Format = JpegImageWrapper->GetFormat();
							RawWidth = JpegImageWrapper->GetWidth();
							RawHeight = JpegImageWrapper->GetHeight();

							if (Format == ERGBFormat::RGBA)
							{
								if (BitDepth <= 8)
								{
									Format = ERGBFormat::BGRA;
									BitDepth = 8;
								}

								if (!JpegImageWrapper->GetRaw(Format, BitDepth, RawImageData))
								{
									return;
								}
							}
							else if (Format == ERGBFormat::Gray)
							{
								if (!JpegImageWrapper->GetRaw(Format, 8, RawImageData))
								{
									return;
								}
								bGrayData = true;
							}
						}
					}

					if (RawImageData.Num() > 0 && RawWidth > 0 && RawHeight > 0)
					{
						int32 RawImageSize = FMath::Min(RawWidth, RawHeight);
						// Check if it's square image, if not crop it
						bool bCrop = (RawWidth != RawHeight);

						TArray<FColor> BlendedImageData;
						int NumColor = RawImageSize * RawImageSize;
						int32 WidthOffset = bCrop ? (RawWidth - RawImageSize) / 2 : 0;
						int32 HeightOffset = bCrop ? (RawHeight - RawImageSize) / 2 : 0;
						int32 RawHeightIndex = HeightOffset;
						for (int32 ColorIndex = 0; ColorIndex < NumColor; ColorIndex++)
						{
							int32 RawDataOffset = RawHeightIndex * RawWidth + WidthOffset;
							int32 RawDataIndex = RawDataOffset + ColorIndex % RawImageSize;

							if (bGrayData)
							{
								BlendedImageData.Add(FColor(RawImageData[RawDataIndex], RawImageData[RawDataIndex], RawImageData[RawDataIndex]));
							}
							else
							{
								FLinearColor IconColor = FLinearColor(
									FColor(RawImageData[RawDataIndex * 4 + 2],	//B
										RawImageData[RawDataIndex * 4 + 1],		//G
										RawImageData[RawDataIndex * 4],			//R
										RawImageData[RawDataIndex * 4 + 3]));	//A
								float Alpha = IconColor.A;
								FColor FinalColor = (IconColor * Alpha + FLinearColor::Black * (1.0f - Alpha)).ToFColor(true);
								BlendedImageData.Add(FinalColor);
							}

							if ((ColorIndex + 1) % RawImageSize == 0)
							{
								++RawHeightIndex;
							}
						}

						int32 ThumbnailSize = FMath::Min(RawImageSize, DefaultThumbnailSize);
						//setup thumbnail
						FObjectThumbnail TempThumbnail;
						TempThumbnail.SetImageSize(ThumbnailSize, ThumbnailSize);
						TArray<uint8>& ThumbnailByteArray = TempThumbnail.AccessImageData();					
						int32 MemorySize = ThumbnailSize * ThumbnailSize * sizeof(FColor);
						ThumbnailByteArray.AddUninitialized(MemorySize);
					
						if (ThumbnailSize < RawImageSize)
						{
							// Resize
							TArray<FColor> ScaledImageData;
							FImageUtils::ImageResize(RawImageSize, RawImageSize, BlendedImageData, ThumbnailSize, ThumbnailSize, ScaledImageData, true);
							FMemory::Memcpy(ThumbnailByteArray.GetData(), ScaledImageData.GetData(), MemorySize);
						}
						else
						{
							//copy raw png to thumbnail
							FMemory::Memcpy(ThumbnailByteArray.GetData(), BlendedImageData.GetData(), MemorySize);
						}

						UPackage* AssetPackage = CreatePackage(*PackageName);
						if (ensure(AssetPackage))
						{
							// GListingAssetsForEditor need to be set, in case the Omniverse Asset is loaded
							GListingAssetsForEditor = true;
							auto OmniAsset = UOmniverseAsset::LoadAsset(OmniPath, false);
							GListingAssetsForEditor = false;
							if (OmniAsset && OmniAsset->IsAsset())
							{
								// cache to package
								FObjectThumbnail* NewThumbnail = ThumbnailTools::CacheThumbnail(ObjectFullName, &TempThumbnail, AssetPackage);
								if (ensure(NewThumbnail))
								{
									AssetPackage->MarkPackageDirty();
									NewThumbnail->MarkAsDirty();
									OmniAsset->PostEditChange();
									OmniAsset->SaveToDisk();
									NewThumbnail->SetCreatedAfterCustomThumbsEnabled();
								}
							}
						}
					}
				}
			});

		FOmniverseConnectionHelper::ReadAsync(ThumbnaiPath, ReadCallback);
	}
}

void FOmniverseThumbnailUtils::CacheThumbnailFromServer(const FString& OmniPath, const FString& ObjectFullName, const FString& PackageName)
{
	// TODO: Filter texture for now
	FString Extension = FPaths::GetExtension(OmniPath);
	if (Extension.Equals("png", ESearchCase::IgnoreCase) || Extension.Equals("tga", ESearchCase::IgnoreCase) || Extension.Equals("jpg", ESearchCase::IgnoreCase)
	|| Extension.Equals("jpeg", ESearchCase::IgnoreCase) || Extension.Equals("exr", ESearchCase::IgnoreCase) || Extension.Equals("bmp", ESearchCase::IgnoreCase)
	|| Extension.Equals("tif", ESearchCase::IgnoreCase) || Extension.Equals("hdr", ESearchCase::IgnoreCase) || Extension.Equals("dds", ESearchCase::IgnoreCase)
	|| Extension.Equals("ies", ESearchCase::IgnoreCase))
	{
		return;
	}

	GListingAssetsForEditor = true;
	auto OmniAsset = UOmniverseAsset::LoadAsset(OmniPath, false);
	GListingAssetsForEditor = false;
	if (!OmniAsset || !OmniAsset->IsAsset())
	{
		return;
	}

	FString ThumbnailName = FPaths::GetCleanFilename(OmniPath) + TEXT(".png");
	FString ThumbnalFolder = FPaths::GetPath(OmniPath) / TEXT(".thumbs") / TEXT("256x256");
	FString OmniThumbnailPath = ThumbnalFolder / ThumbnailName;

	FOmniverseListFileResult Result;
	if (!FOmniverseConnectionHelper::ListFileSync(OmniThumbnailPath, Result))
	{
		ThumbnailName = FPaths::GetCleanFilename(OmniPath) + TEXT(".auto.png");
		OmniThumbnailPath = ThumbnalFolder / ThumbnailName;
	}

	OmniverseThumbnailUtils::LoadOmniThumbnail(OmniPath, OmniThumbnailPath, ObjectFullName, PackageName);
}