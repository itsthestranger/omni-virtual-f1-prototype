// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseImporterDialog.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SComboBox.h"

#include "Editor.h"
#include "Styling/AppStyle.h"
#include "EditorDirectories.h"

#include "DesktopPlatformModule.h"
#include "PropertyEditorModule.h"
#include "IDetailsView.h"
#include "Modules/ModuleManager.h"
#include "Interfaces/IMainFrameModule.h"
#include "Misc/MessageDialog.h"

#include "OmniverseFacialAnimation.h"
#include "OmniverseUSDImporter.h"

#define LOCTEXT_NAMESPACE "OmniverseEditor"

void SOmniverseImporterDialog::ConstructDialog()
{
	FPropertyEditorModule& PropertyEditorModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs;
	DetailsViewArgs.bAllowSearch = false;
	DetailsViewArgs.NameAreaSettings = FDetailsViewArgs::HideNameArea;
	DetailsView = PropertyEditorModule.CreateDetailView(DetailsViewArgs);
	DetailsView->SetObject(ImporterUI);

	TSharedPtr<SUniformGridPanel> ConfirmWidget =
			SNew(SUniformGridPanel)
			.SlotPadding(FAppStyle::GetMargin("StandardDialog.SlotPadding"))
			.MinDesiredSlotWidth(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotWidth"))
			.MinDesiredSlotHeight(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotHeight"))
			+ SUniformGridPanel::Slot(0, 0)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
				.Text(LOCTEXT("OK", "OK"))
				.OnClicked(this, &SOmniverseImporterDialog::OkClicked)
				.IsEnabled(this, &SOmniverseImporterDialog::IsImporterReady)
			]
			+ SUniformGridPanel::Slot(1, 0)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
				.Text(LOCTEXT("Cancel", "Cancel"))
				.OnClicked(this, &SOmniverseImporterDialog::CancelClicked)
			];

	const int32 ClientSizeX = 500;
	const int32 ClientSizeY = ImporterUI->ImporterType == OIT_Facial ? 300 : 280;
	TSharedPtr<SBox> Box;
	const FText TitleText = ImporterUI->ImporterType == OIT_Facial ? LOCTEXT("OmniverseImporterDialogTitle", "Omniverse Facial Animation Importer") : LOCTEXT("OmniverseImporterDialogTitle", "Omniverse USD Importer");
	
	SWindow::Construct(SWindow::FArguments()
		.Title(TitleText)
		.SizingRule(ESizingRule::UserSized)
		.ClientSize(FVector2D(ClientSizeX, ClientSizeY))
		.SupportsMinimize(false)
		.SupportsMaximize(false)
		.bDragAnywhere(false)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(2)
			[
				SAssignNew(Box, SBox)
				.MaxDesiredHeight(ClientSizeY)
				.WidthOverride(ClientSizeX)
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Center)
			.Padding(30)
			[
				ConfirmWidget.ToSharedRef()
			]
		]
	);

	Box->SetContent(DetailsView->AsShared());
}

void SOmniverseImporterDialog::Construct(const FArguments& InArgs)
{
	ImporterUI = InArgs._ImporterUI;
	ConstructDialog();
}

bool SOmniverseImporterDialog::IsImporterReady() const
{
	if (ImporterUI->ImporterType == OIT_Facial)
	{
		return ImporterUI->Skeleton && !ImporterUI->USDPath.IsEmpty() && !ImporterUI->AssetPath.IsEmpty();
	}
	else
	{
		return !ImporterUI->USDPath.IsEmpty() && !ImporterUI->AssetPath.IsEmpty();
	}
}

FReply SOmniverseImporterDialog::OkClicked()
{
	RequestDestroyWindow();

	TArray<FString> Files;
	ImporterUI->USDPath.ParseIntoArray(Files, TEXT(";"), true);
	
	ImportSettings.bImportUnusedReferences = ImporterUI->bImportUnusedReferences;
	ImportSettings.bImportAsBlueprint = ImporterUI->bImportAsBlueprint;

	FString FailedFiles;
	for (auto File : Files)
	{
		bool bSuccess = true;
		if (ImporterUI->ImporterType == OIT_Facial)
		{
			bSuccess = FOmniverseFacialAnimation::LoadFacialAnimation(File, ImporterUI->AssetPath, ImporterUI->Skeleton, ImporterUI->Name);
		}
		else
		{
			bSuccess = FOmniverseUSDImporter::LoadUSD(File, ImporterUI->AssetPath, ImportSettings);
		}

		if (!bSuccess)
		{
			if (!FailedFiles.IsEmpty())
			{
				FailedFiles += ";";
			}
			FailedFiles += File;
		}
	}

	if (!FailedFiles.IsEmpty())
	{
		const FText Message = FText::Format(LOCTEXT("ImportFailed_Generic", "Failed to import '{0}'.\nPlease see Output Log for details."), FText::FromString(FailedFiles));
		FMessageDialog::Open(EAppMsgType::Ok, Message);
	}

	return FReply::Handled();
}

FReply SOmniverseImporterDialog::CancelClicked()
{
	RequestDestroyWindow();
	return FReply::Handled();
}

TWeakPtr<SOmniverseImporterDialog> SOmniverseImporterDialog::DialogPtr;
// SourceType = Local, FullPath is the content browser folder to save the asset
// SourceType = Nucleus, FullPath is the Omniverse URL on Nucleus to be exported
void SOmniverseImporterDialog::ShowDialog(EOmniImporterType DialogType, EOmniSourceType SourceType, const FString& FullPath)
{
	auto DefaultImporterUI = GetMutableDefault<UOmniverseImporterUI>();
	DefaultImporterUI->USDPath = DefaultImporterUI->PreUSDPath[SourceType][DialogType];
	DefaultImporterUI->AssetPath = DefaultImporterUI->PreAssetPath[SourceType][DialogType];
	DefaultImporterUI->ImporterType = DialogType;
	DefaultImporterUI->SourceType = SourceType;

	if (SourceType == EOmniSourceType::OST_Local)
	{
		DefaultImporterUI->AssetPath = FullPath;
	}
	else
	{
		DefaultImporterUI->USDPath = FullPath;
	}

	// Create the window to pick the class
	TSharedRef<SOmniverseImporterDialog> OmniverseImporterDialog = 
		SNew(SOmniverseImporterDialog)
		.ImporterUI(DefaultImporterUI);

	DialogPtr = OmniverseImporterDialog;
	FSlateApplication::Get().AddWindow(OmniverseImporterDialog);
}
#undef LOCTEXT_NAMESPACE
