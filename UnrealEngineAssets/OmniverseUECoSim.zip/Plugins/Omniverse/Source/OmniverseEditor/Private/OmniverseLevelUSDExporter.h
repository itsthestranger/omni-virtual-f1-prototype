// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

//~=============================================================================
// LevelExporterUSD
//~=============================================================================

#pragma once

#include "Exporters/Exporter.h"
#include "OmniverseLevelUSDExporter.generated.h"

UCLASS()
class UOmniverseLevelUSDExporter : public UExporter
{
public:
	GENERATED_BODY()

public:
	UOmniverseLevelUSDExporter(const FObjectInitializer& ObjectInitializer = FObjectInitializer());

	//~ Begin UExporter Interface
	virtual bool ExportBinary(UObject* Object, const TCHAR* Type, FArchive& Ar, FFeedbackContext* Warn, int32 FileIndex = 0, uint32 PortFlags = 0);
	bool Export(UWorld& World, FString& Path, bool bSaveAs, bool bReplace, bool ExportUE4Objects) const;
	//~ End UExporter Interface
};