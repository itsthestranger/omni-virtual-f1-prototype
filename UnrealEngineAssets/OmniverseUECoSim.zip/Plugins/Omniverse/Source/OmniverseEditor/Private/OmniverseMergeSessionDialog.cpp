// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseMergeSessionDialog.h"
#include "Framework/Application/SlateApplication.h"
#include "Misc/MessageDialog.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Input/SComboBox.h"
#include "Interfaces/IMainFrameModule.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniversePathHelper.h"
#include "OmniverseUSD.h"
#include "Editor.h"
#include "EditorStyleSet.h"
#include "OmniverseEditorExportUtils.h"

#define LOCTEXT_NAMESPACE "OmniverseEditor"

#define OPTION_MERGE_TO_CORRESPONDING "Merge to corresponding layers"
#define OPTION_MERGE_TO_NEW "Merge to a new layer"

void SOmniverseMergeSessionDialog::Construct(const FArguments& InArgs, UOmniverseUSD* USD)
{
	Options.Add(MakeShareable(new FName(TEXT(OPTION_MERGE_TO_CORRESPONDING))));
	Options.Add(MakeShareable(new FName(TEXT(OPTION_MERGE_TO_NEW))));

	SelectOption = TEXT(OPTION_MERGE_TO_CORRESPONDING);
	USDAsset = USD;

	if (USD->IsSessionOwner())
	{
		IOmniverseRuntimeModule::Get().SetCheckpointComment(TEXT(""));
		SWindow::Construct(SWindow::FArguments()
			.Title(FText::FromString("Merge Options"))
			.SupportsMaximize(false)
			.SupportsMinimize(false)
			.SizingRule(ESizingRule::FixedSize)
			.ClientSize(FVector2D(370, 320))
			.Content()
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10, 20, 10, 0)
					.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromString("Live Session is ending."))
				]
				+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10, 10, 10, 0)
					.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.WrapTextAt(350.0f)
					.Text_Lambda(
						[&]()
						{
							return FText::Format(FText::FromString("How do you want to merge changes from '{0}' session?"), FText::FromName(USDAsset->GetSessionName()));
						})
				]
				+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10, 10, 10, 0)
				[
					SNew(STextBlock)
					.WrapTextAt(350.0f)
					.Text_Lambda([&](){
						return FText::FromString(WarningMessage);
					})
					.ColorAndOpacity(FLinearColor::Red)
				]
				+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10, 0, 10, 0)
				[
					SNew(SComboBox<TSharedPtr<FName>>)
					.OptionsSource(&Options)
					.OnSelectionChanged_Lambda([&](TSharedPtr<FName> Item, ESelectInfo::Type SelectInfo)
					{
						if (Item)
						{
							SelectOption = (*Item);
							if (SelectOption == OPTION_MERGE_TO_NEW && !USDAsset->CanEndToNewLayer())
							{
								WarningMessage = TEXT("There are PrimSpecs defined in the root layer, changes from the live session could be hidden if they are copied to a new layer.");
							}
							else
							{
								WarningMessage = TEXT("");
							}
						}					
					})
					.OnGenerateWidget_Lambda([](TSharedPtr<FName> InItem)
					{
						return SNew(STextBlock).Text(FText::FromName(InItem.IsValid() ? *InItem : NAME_None));
					})
					.Content()
					[
						SNew(STextBlock)
						.Text_Lambda([&]()
						{
							return FText::FromName(SelectOption);
						})
					]
				]
				+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10, 20, 10, 0)
				[
					SNew(STextBlock)
					.Text(FText::FromString("Checkpoint Description"))
				]
				+ SVerticalBox::Slot()
					.FillHeight(1.0f)
					.Padding(10, 0, 10, 0)
				[
					SNew(SMultiLineEditableTextBox)
						.Text_Lambda([&]()
						{
							return FText::FromString(Checkpoint);
						})
						.OnTextCommitted_Lambda([&](const FText& InText, ETextCommit::Type InCommitType)
						{
							Checkpoint = InText.ToString();
						})
						.HintText(FText::FromString("Description"))
						.SelectAllTextWhenFocused(true)
				]

				+ SVerticalBox::Slot()
					.AutoHeight()
				[
					SNew(SUniformGridPanel).SlotPadding(FMargin(10, 50, 10, 10))
					+ SUniformGridPanel::Slot(0, 0)
					[
						SNew(SButton)
						.Text(FText::FromString("Continue"))
						.HAlign(EHorizontalAlignment::HAlign_Center)
						.OnClicked(FOnClicked::CreateLambda(
							[&]()
							{
								Destroy();
								if (SelectOption == OPTION_MERGE_TO_NEW)
								{
									FString ChoosedPath = FOmniverseEditorExportUtils::ChooseOmniversePathForAsset(TEXT(""), true, FPaths::GetPath(USDAsset->GetPackagePath()));
									FString MappingLocalPkgPath;
									FString MappingOmniPath;
									if (FOmniverseEditorExportUtils::GetMappingPaths(ChoosedPath, "usd", MappingLocalPkgPath, MappingOmniPath))
									{
										bool bSuccess = true;
										if (OmniUsdStageCtrl::IsLayerExist(TCHAR_TO_UTF8(*MappingOmniPath)))
										{
											const EAppReturnType::Type Choice = FMessageDialog::Open(EAppMsgType::YesNo, FText::Format(FText::FromString("File {0} already exists, do you want to overwrite it?"), FText::FromString(MappingOmniPath)));
											bSuccess = Choice == EAppReturnType::Yes;
										}
										
										if (bSuccess)
										{
											IOmniverseRuntimeModule::Get().SetCheckpointComment(Checkpoint);
											USDAsset->EndAndMergeSession(MappingOmniPath);
											IOmniverseRuntimeModule::Get().SetCheckpointComment("");
										}
									}
								}
								else
								{
									IOmniverseRuntimeModule::Get().SetCheckpointComment(Checkpoint);
									USDAsset->EndAndMergeSession();
									IOmniverseRuntimeModule::Get().SetCheckpointComment("");
								}
								return FReply::Handled();
							}
						))
					]
					+ SUniformGridPanel::Slot(1, 0)
					[
						SNew(SButton)
						.Text(FText::FromString("Cancel"))
						.HAlign(EHorizontalAlignment::HAlign_Center)
						.OnClicked(FOnClicked::CreateLambda(
							[&]()
							{
								Destroy();
								return FReply::Handled();
							}
						))
					]
				]
			]);

		USDAsset->StartMergeSession();
	}
	else
	{
		SWindow::Construct(SWindow::FArguments()
			.Title(FText::FromString("Permission Denied"))
			.SupportsMaximize(false)
			.SupportsMinimize(false)
			.SizingRule(ESizingRule::FixedSize)
			.ClientSize(FVector2D(370, 150))
			.Content()
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10, 20, 10, 0)
				[
					SNew(STextBlock)
					.WrapTextAt(350.0f)
					.Text_Lambda(
						[&]()
						{
							return FText::Format(FText::FromString("You currently do not have merge privilages, please contact '{0}' to merge any changes from the live session."), FText::FromName(USDAsset->GetSessionOwner()));
						})
				]
				+ SVerticalBox::Slot()
					.AutoHeight()
					.Padding(10, 20, 10, 0)
				[
					SNew(STextBlock)
					.Text(FText::FromString("Do you want to quit this live session?"))
				]

				+ SVerticalBox::Slot()
					.AutoHeight()
				[
					SNew(SUniformGridPanel).SlotPadding(FMargin(10, 20, 10, 10))
					+ SUniformGridPanel::Slot(0, 0)
					[
						SNew(SButton)
						.Text(FText::FromString("Yes"))
						.HAlign(EHorizontalAlignment::HAlign_Center)
						.OnClicked(FOnClicked::CreateLambda(
							[&]()
							{
								Destroy();
								USDAsset->LeaveSession();
								return FReply::Handled();
							}
						))
					]
					+ SUniformGridPanel::Slot(1, 0)
					[
						SNew(SButton)
						.Text(FText::FromString("No"))
						.HAlign(EHorizontalAlignment::HAlign_Center)
						.OnClicked(FOnClicked::CreateLambda(
							[&]()
							{
								Destroy();
								return FReply::Handled();
							}
						))
					]
				]
			]);
	}
}

void SOmniverseMergeSessionDialog::Destroy()
{
	RequestDestroyWindow();
}

void SOmniverseMergeSessionDialog::ShowDialog(UOmniverseUSD* USD)
{
	// Create the window to pick the class
	TSharedRef<SOmniverseMergeSessionDialog> MergeDialog = SNew(SOmniverseMergeSessionDialog, USD);

	TSharedPtr<SWindow> ParentWindow;
	if( FModuleManager::Get().IsModuleLoaded( "MainFrame" ) )
	{
		IMainFrameModule& MainFrame = FModuleManager::LoadModuleChecked<IMainFrameModule>( "MainFrame" );
		ParentWindow = MainFrame.GetParentWindow();
	}

	FSlateApplication::Get().AddModalWindow(MergeDialog, ParentWindow, false);
}

#undef LOCTEXT_NAMESPACE
