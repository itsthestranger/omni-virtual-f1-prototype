// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseEditorExportUtils.h"
#include "Editor.h"
#include "Engine/Engine.h"
#include "EngineUtils.h"
#include "FileHelpers.h"
#include "IContentBrowserSingleton.h"
#include "ContentBrowserModule.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Docking/TabManager.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Framework/Application/SlateApplication.h"
#include "Misc/FileHelper.h"
#include "Misc/MessageDialog.h"
#include "Misc/ScopedSlowTask.h"
#include "IContentBrowserDataModule.h"
#include "ContentBrowserDataSubsystem.h"

#include "OmniverseAsset.h"
#include "OmniverseUSD.h"
#include "OmniverseStageActor.h"
#include "OmniverseContentManager.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseLayerDataSource.h"
#include "OmniverseUSDHelper.h"
#include "OmniversePxr.h"
#include "OmniverseAssetExportHelper.h"
#include "OmniverseSettings.h"
#include "OmniverseNotificationHelper.h"
#include "OmniversePathHelper.h"

#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SCheckbox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SButton.h"

TSharedPtr<void> SetupOmniverseRefresh(FSharedAssetDialogConfig& Config)
{
	auto OnPathSelected = [](const FString& Path)
	{
		// NOTE: Path is virtual path now, need to be converted to internal path
		FName InternalPath;
		EContentBrowserPathType ConvertedType = IContentBrowserDataModule::Get().GetSubsystem()->TryConvertVirtualPath(Path, InternalPath);

		GetMutableDefault<UOmniverseContentManager>()->RefreshFolder(ConvertedType == EContentBrowserPathType::Internal ? InternalPath.ToString() : Path, false, false);
	};

	Config.OnPathSelected.BindLambda(OnPathSelected);
	
	// UE5.0 hax - there are issues with calling OnBeginFrame without OnEndFrame in the TypedElementRegistry
	// Maybe this is the best way with a Sleep() here?
	auto DelegateHandle = FSlateApplication::Get().GetOnModalLoopTickEvent().AddLambda(
		[](float DeltaTime)
		{
			FCoreDelegates::OnBeginFrame.Broadcast();
			GEngine->PerformGarbageCollectionAndCleanupActors();
			FPlatformProcess::Sleep(0.01f);
			FCoreDelegates::OnEndFrame.Broadcast();
		}
	);

	return MakeShareable<void>(nullptr, [DelegateHandle](auto)
		{
			FSlateApplication::Get().GetOnModalLoopTickEvent().Remove(DelegateHandle);
		}
	);
}

FString FOmniverseEditorExportUtils::ChooseOmniversePathForAsset(const FString& DefaultAssetName, bool ChooseFolder, const FString& DefaultPath)
{
	// Get save path
	static FString SavedDefaultPath = OmniverseContentFolder;

	FSaveAssetDialogConfig SaveAssetDialogConfig;
	SaveAssetDialogConfig.DefaultPath = DefaultPath.IsEmpty() ? SavedDefaultPath : DefaultPath;
	SaveAssetDialogConfig.DefaultAssetName = DefaultAssetName;
	SaveAssetDialogConfig.ExistingAssetPolicy = ESaveAssetDialogExistingAssetPolicy::AllowButWarn;
	if (ChooseFolder)
	{
		SaveAssetDialogConfig.DialogTitleOverride = FText::FromString(L"Create New or Choose Folder to Save");
	}
	else
	{
		SaveAssetDialogConfig.AssetClassNames.Add(UOmniverseUSD::StaticClass()->GetClassPathName());
		SaveAssetDialogConfig.DialogTitleOverride = FText::FromString(L"Input Filename or Choose File to Override");
	}

	auto Handle = SetupOmniverseRefresh(SaveAssetDialogConfig);

	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
	FString AssetPath = ContentBrowserModule.Get().CreateModalSaveAssetDialog(SaveAssetDialogConfig);
	// Update default path - only if OK was pressed, ignore if Cancel
	if (!AssetPath.IsEmpty())
	{
		SavedDefaultPath = FPaths::GetPath(AssetPath);
	}

	FString SavePackageName = FPackageName::ObjectPathToPackageName(AssetPath);
	return SavePackageName;
}

bool FOmniverseEditorExportUtils::ExportObjectsToOmniverse(const TArray<class UObject*>& Objects, const FOmniverseExportSettings& ExportSettings)
{
	if (Objects.Num() == 0)
	{
		return true;
	}

	if (!AreObjectsFromTheSameClass(Objects))
	{
		return false;
	}

	FString ExportPath;
	if (IsRunningCommandlet())
	{
		ExportPath = ExportSettings.CommandletSettings.CommandletExportPath;
	}
	else
	{
		if (Objects.Num() > 1)
		{
			ExportPath = ChooseOmniversePathForAsset("IGNORE_THIS_AND_SELECT_AN_OMNIVERSE_FOLDER", true);
		}
		else
		{
			ExportPath = ChooseOmniversePathForAsset(Objects[0]->GetName(), false);
		}

		if (ExportPath.Len() == 0)
		{
			return true;
		}
	}
	if (!GetDefault<UOmniverseContentManager>()->IsPathUnderOmniverseFolder(ExportPath))
	{
		return false;
	}

	// Check if it's a read-only folder and output a dialog to the user if so
	// Strip the "filename"
	FString ExportFolderPath = FPaths::GetPath(ExportPath);
	if (ReadOnlyFolderCheck(ExportFolderPath))
	{
		return false;
	}

	FScopedSlowTask ExportTask(Objects.Num(), FText::FromString(TEXT("Exporting Assets...")));
	ExportTask.MakeDialog(true);

	FOmniverseExportSettings NewExportSettings = ExportSettings;
	if (!ExportPath.IsEmpty() && FPaths::GetExtension(ExportPath).ToLower() == TEXT("usda"))
	{
		NewExportSettings.bAsciiFormat = true;
	}

	bool bSuccess = true;
	for (auto Object : Objects)
	{
		FString Text = "Exporting " + Object->GetFullName() + "...";
		ExportTask.EnterProgressFrame(1.0f, FText::FromString(Text));

		if (!bSuccess)
		{
			break;
		}

		if (ExportTask.ShouldCancel())
		{
			break;
		}

		if (!IsRunningCommandlet())
		{
			if (Objects.Num() > 1)
			{
				FString BasePath = FPaths::GetPath(ExportPath);
				ExportPath = BasePath / Object->GetName();
			}
		}

		if (Object->IsA<UWorld>())
		{
			auto World = Cast<UWorld>(Object);
			bSuccess = ExportLevelToOmniversePath(World, ExportPath, NewExportSettings);

			if (IsRunningCommandlet())
			{
				GetMutableDefault<UOmniverseContentManager>()->RefreshFolder(FPaths::GetPath(ExportPath), true, true);
			}
		}
		else if (Object->IsA<UTexture>())
		{
			auto Texture = Cast<UTexture>(Object);
			bSuccess = ExportTextureToOmniversePath(Texture, ExportPath, NewExportSettings.MaterialSettings.TextureSettings);
		}
		else if (Object->IsA<UMaterialInterface>())
		{
			auto Material = Cast<UMaterialInterface>(Object);
			bSuccess = ExportMaterialToOmniversePath(Material, ExportPath, NewExportSettings.MaterialSettings);
		}
		else
		{
			bSuccess = ExportObjectToOmniversePath(Object, ExportPath, NewExportSettings);
		}

		if (!bSuccess)
		{
			FString AssetText = "Asset " + Object->GetFullName() + " is not supported to be converted yet.";
			FOmniverseNotificationHelper::ShowInstantNotification(AssetText);
		}
	}

	GetMutableDefault<UOmniverseContentManager>()->RefreshFolder(FPaths::GetPath(ExportPath), false, false);

	return bSuccess;
}

bool FOmniverseEditorExportUtils::ExportObjectToOmniversePath(UObject* Object, const FString& ExportPath, const FOmniverseExportSettings& ExportSettings)
{
	FString MappingLocalPkgPath;
	FString MappingOmniPath;
	if (!GetMappingPaths(ExportPath, ExportSettings.bAsciiFormat ? "usda" : "usd", MappingLocalPkgPath, MappingOmniPath))
	{
		return false;
	}

	FString AssetFolder = FPaths::GetPath(MappingOmniPath);
	bool bSuccess = FOmniverseUSDHelper::ExportObjectAsUSDToPath(Object, MappingOmniPath, AssetFolder, ExportSettings);
	
	// Checkpoint the USD
	FOmniverseConnectionHelper::CreateCheckpointSync(MappingOmniPath);

	GetMutableDefault<UOmniverseContentManager>()->RefreshAsset(MappingLocalPkgPath, true);

	return bSuccess;
}

bool FOmniverseEditorExportUtils::ExportLevelToOmniversePath(UWorld* World, const FString& ExportPath, const FOmniverseExportSettings& ExportSettings)
{
	FString Extension;
	if (ExportSettings.bAddExtraExtension)
	{
		Extension = ExportSettings.bAsciiFormat ? "stage.usda" : "stage.usd";
	}
	else
	{
		Extension = ExportSettings.bAsciiFormat ? "usda" : "usd";
	}

	FString MappingLocalPkgPath;
	FString MappingOmniPath;
	if (!GetMappingPaths(ExportPath, Extension, MappingLocalPkgPath, MappingOmniPath))
	{
		return false;
	}

	// Export world as stage into omniverse first
	if (!FOmniverseUSDHelper::ExportUWorldAsUSDToPath(World, MappingOmniPath, ExportSettings))
	{
		return false;
	}

	GetMutableDefault<UOmniverseContentManager>()->RefreshAsset(MappingLocalPkgPath, true);

	return true;
}

bool FOmniverseEditorExportUtils::ExportActorsToOmniverse(const TArray<AActor*>& SelectedActors, const FOmniverseExportSettings& ExportSettings)
{
	if (SelectedActors.Num() == 0)
	{
		return true;
	}

	FString ChoosedPath;
	if (IsRunningCommandlet())
	{
		ChoosedPath = ExportSettings.CommandletSettings.CommandletExportPath;
	}
	else
	{
		ChoosedPath = ChooseOmniversePathForAsset(SelectedActors[0]->GetName(), false);
	}

	if (ChoosedPath.Len() == 0) // Save path should not be empty
	{
		return false;
	}

	FOmniverseExportSettings NewExportSettings = ExportSettings;
	if (!ChoosedPath.IsEmpty() && FPaths::GetExtension(ChoosedPath).ToLower() == TEXT("usda"))
	{
		NewExportSettings.bAsciiFormat = true;
	}

	FString MappingLocalPkgPath;
	FString MappingOmniPath;
	if (!GetMappingPaths(ChoosedPath, NewExportSettings.bAsciiFormat ? "usda" : "usd", MappingLocalPkgPath, MappingOmniPath))
	{
		return false;
	}

	// Catch here that the folder is read-only
	if (ReadOnlyFolderCheck(FPaths::GetPath(ChoosedPath)))
	{
		return false;
	}

	bool bSuccess = FOmniverseUSDHelper::ExportActorsAsUSDToPath(SelectedActors, MappingOmniPath, NewExportSettings);
	if (bSuccess)
	{
		GetMutableDefault<UOmniverseContentManager>()->RefreshAsset(MappingLocalPkgPath, true);
	}
	return bSuccess;
}

bool FOmniverseEditorExportUtils::AreObjectsFromTheSameClass(const TArray<class UObject*>& Objects)
{
	if (Objects.Num() < 2)
	{
		return true;
	}

	auto StaticClassName = Objects[0]->GetClass()->GetName();
	bool bSameTypeAssets = true;
	for (int32 ObjectIndex = 1; ObjectIndex < Objects.Num(); ObjectIndex++)
	{
		if (Objects[ObjectIndex]->GetClass()->GetName() != StaticClassName)
		{
			bSameTypeAssets = false;
		}
	}

	return bSameTypeAssets;
}

bool FOmniverseEditorExportUtils::ExportTextureToOmniversePath(UTexture* Texture, const FString& ExportPath, const FOmniverseExportTextureSettings& TextureSettings)
{
	FString MappingLocalPkgPath;
	FString MappingOmniPath;
	if (!GetMappingPaths(ExportPath, FPaths::GetExtension(FOmniverseAssetExportHelper::GetTextureFileName(Texture, TextureSettings.bDDSExport)), MappingLocalPkgPath, MappingOmniPath))
	{
		return false;
	}

	return FOmniverseAssetExportHelper::ExportTextureToPath(Texture, MappingOmniPath, TextureSettings);
}

bool FOmniverseEditorExportUtils::ExportMaterialToOmniversePath(UMaterialInterface* Material, const FString& ExportPath, const FOmniverseExportMaterialSettings& MaterialSettings)
{
	FString MappingLocalPkgPath;
	FString MappingOmniPath;
	if (!GetMappingPaths(ExportPath, "mdl", MappingLocalPkgPath, MappingOmniPath))
	{
		return false;
	}

	FString MaterialName = FPaths::GetBaseFilename(ExportPath);

	// Compose new path
	return FOmniverseAssetExportHelper::ExportMaterialToPath(Material, MappingOmniPath, MaterialName, true, true, true/*z-axis*/, false/*landscape*/, MaterialSettings);
}

bool FOmniverseEditorExportUtils::GetMappingPaths(const FString& ExportLocalPath, const FString & Extension, FString& MappingLocalPkgPath, 
	FString& MappingOmniPath)
{
	FString FullLocalPath = ExportLocalPath;
	if (!FullLocalPath.StartsWith(OMNIVERSE_FOLDER))
	{
		FullLocalPath = OMNIVERSE_FOLDER + FullLocalPath;
	}

	// If it's trying to export asset to a non-watched omnvierse folder.
	if (!GetDefault<UOmniverseContentManager>()->IsPathUnderOmniverseFolder(FullLocalPath))
	{
		return false;
	}

	FString PackagePath = FPaths::GetPath(FullLocalPath);
	FString FileName;
	FOmniversePathHelper::UnmanglePath(FPaths::GetBaseFilename(FullLocalPath), FileName, false);
	FString MappingFileName = FileName + "." + Extension;

	FString MappingOmniFolder = GetDefault<UOmniverseContentManager>()->GetOmniServerPath(PackagePath);
	MappingOmniPath = MappingOmniFolder / MappingFileName;
	MappingLocalPkgPath = GetDefault<UOmniverseContentManager>()->GetOmniLocalPath(MappingOmniPath);

	return true;
}

bool FOmniverseEditorExportUtils::GetCheckpointComment(FString& CheckpointComment, bool bLiveCheckpointDialog, LiveModeSetupActionType* LiveModeSetupAction)
{
	const FString DialogCancelledString("<Dialog Cancelled>");

	FString DialogTitle = "Enter Checkpoint Comment";
	TSharedPtr<SWidget> ReloadStageWidget;

	//if (bLiveCheckpointDialog && LiveModeSetupAction != nullptr)
	//{
	//	DialogTitle = FString(TEXT("Enter Checkpoint Comment for Switching to Live Edit Mode"));
	//	ReloadStageWidget =
	//		SNew(SVerticalBox)
	//		+ SVerticalBox::Slot().AutoHeight()
	//		[
	//			SNew(SCheckBox)
	//			.Style(FEditorStyle::Get(), "RadioButton")
	//			.IsChecked_Lambda([LiveModeSetupAction]() {
	//				if (*LiveModeSetupAction == LiveModeSetupActionType::ReloadStageBeforeLive)
	//				{
	//					return ECheckBoxState::Checked;
	//				}
	//				else
	//				{
	//					return ECheckBoxState::Unchecked;
	//				}
	//			})
	//			.OnCheckStateChanged_Lambda([LiveModeSetupAction](ECheckBoxState State) {
	//				if (State == ECheckBoxState::Checked)
	//				{
	//					*LiveModeSetupAction = LiveModeSetupActionType::ReloadStageBeforeLive;
	//				}
	//			})
	//			[
	//				SNew(STextBlock)
	//				.Text(FText::FromString(TEXT("Reload stage to fetch changes from server")))
	//				.ToolTipText(FText::FromString(TEXT("Warning: Unsaved local changes will be destroyed")))
	//			]
	//		]
	//		+ SVerticalBox::Slot().AutoHeight()
	//		[
	//			SNew(SCheckBox)
	//			.Style(FEditorStyle::Get(), "RadioButton")
	//			.IsChecked_Lambda([LiveModeSetupAction]() {
	//				if (*LiveModeSetupAction == LiveModeSetupActionType::SaveLocalChangesBeforeLive)
	//				{
	//					return ECheckBoxState::Checked;
	//				}
	//				else
	//				{
	//					return ECheckBoxState::Unchecked;
	//				}
	//			})
	//			.OnCheckStateChanged_Lambda([LiveModeSetupAction](ECheckBoxState State) {
	//				if (State == ECheckBoxState::Checked)
	//				{
	//					*LiveModeSetupAction = LiveModeSetupActionType::SaveLocalChangesBeforeLive;
	//				}
	//			})
	//			[
	//				SNew(STextBlock)
	//				.Text(FText::FromString(TEXT("Save local changes then enable Live Sync Mode")))
	//				.ToolTipText(FText::FromString(TEXT("Warning: This can be destructive to other live clients")))
	//			]
	//		];
	//}
	//else
	{
		ReloadStageWidget = SNew(SSpacer);
	}

	TSharedPtr<SEditableTextBox> Comment;
	TSharedPtr<SWindow> CommentWnd = SNew(SWindow)
		.Title(FText::FromString(DialogTitle))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.SizingRule(ESizingRule::Autosized)
		.Content()
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot().AutoHeight().Padding(10, 20, 10, 0)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(EVerticalAlignment::VAlign_Center)
				.AutoWidth()
				[
					SNew(STextBlock).Text(FText::FromString("Comment: "))
				]
				+ SHorizontalBox::Slot()
				[
					SAssignNew(Comment, SEditableTextBox)
					.MinDesiredWidth(200)
					.Text(FText::FromString(""))
					.SelectAllTextWhenFocused(true)
				]
			]
			+ SVerticalBox::Slot().AutoHeight().Padding(10, 20, 10, 0)
			[
				ReloadStageWidget.ToSharedRef()
			]
			+ SVerticalBox::Slot().AutoHeight()
			[
				SNew(SUniformGridPanel).SlotPadding(FMargin(10, 20, 10, 0))
				+ SUniformGridPanel::Slot(0, 0)
				[
					SNew(SButton)
					.Text(FText::FromString("Submit"))
					.HAlign(EHorizontalAlignment::HAlign_Center)
					.OnClicked(FOnClicked::CreateLambda(
						[&]()
						{
							CheckpointComment = Comment->GetText().ToString();
							CommentWnd->RequestDestroyWindow();
							return FReply::Handled();
						}
					))
				]
				+ SUniformGridPanel::Slot(1, 0)
				[
					SNew(SButton)
					.Text(FText::FromString("Cancel"))
					.HAlign(EHorizontalAlignment::HAlign_Center)
					.OnClicked(FOnClicked::CreateLambda(
						[&]()
						{
							CheckpointComment = DialogCancelledString;
							CommentWnd->RequestDestroyWindow();
							return FReply::Handled();
						}
					))
				]

			]
		];

	// Set focus to Comment text box
	CommentWnd->SetWidgetToFocusOnActivate(Comment);

	FSlateApplication::Get().AddModalWindow(CommentWnd.ToSharedRef(), FGlobalTabmanager::Get()->GetRootWindow());
	if (DialogCancelledString == CheckpointComment)
	{
		CheckpointComment = TEXT("");
		return false;
	}
	
	return true;
}


// Returns true if folder is read-only on Nucleus server
// ExportFolderPath is an unreal content path - "/Game/Omniverse/server/folder"
bool FOmniverseEditorExportUtils::ReadOnlyFolderCheck(const FString& ExportFolderPath, bool bShowMessageDialog)
{
	FOmniverseListFileResult ListResult;
	FString OmniServerPath = GetDefault<UOmniverseContentManager>()->GetOmniServerPath(ExportFolderPath);
	bool bListSuccess = FOmniverseConnectionHelper::ListFileSync(OmniServerPath, ListResult);
	if (!bListSuccess || ListResult.Status != eOmniClientResult_Ok || !(ListResult.ListItem.Access & fOmniClientAccess_Write))
	{
		// Output a dialog that this location isn't writable
		FText Title = FText::FromString("ERROR: Output folder is read only");
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString("Selected folder is read only: " + OmniServerPath), &Title);
		return true;
	}
	return false;
}
