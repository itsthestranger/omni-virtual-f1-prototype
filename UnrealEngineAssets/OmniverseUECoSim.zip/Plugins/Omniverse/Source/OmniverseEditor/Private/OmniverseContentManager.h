// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.
#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "Engine/EngineTypes.h"
#include "Logging/LogMacros.h"
#include "OmniverseConnectionHelper.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseContentManager.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogOmniverseContentManager, Log, All);

UCLASS()
class UOmniverseContentManager :public UObject
{
	GENERATED_BODY()

public:
	// bForceRefreshNativeAssets is used to force refresh native assets, like umap
	// By default, if native ue4 asset is existed, it will not refresh anymore
	void RefreshFolder(FString FolderPath, bool bWait, bool bForceRefreshNativeAssets = false);

	void RefreshAsset(FString AssetPath, bool bWait);

	void CleanAssets();

	// If this path is under the watched omniverse path.
	bool IsPathUnderOmniverseFolder(const FString& FullLocalPath) const;

	// Gets the local root folder of server. Server is in format like "ov-content".
	// The return path includes prefix /Game/Omniverse also.
	FString GetServerLocalRootFolder(const FString& Server) const;

	// Gets the Omni server path from local mapping path.
	// For example, omni local path is in style /Game/Omniverse/ov-content/Users/test/a.usd
	// will be mapped to omni server path omniverse://ov-content/Users/test/a.usd.
	// By default, if OmniLocalPath does not include /Game/Omniverse prefix, it will assume it's under that 
	// folder by default.
	FString GetOmniServerPath(const FString& OmniLocalPath) const;

	// Gets the local package path of server path. The local package path is full path with /Game/Omniverse prefix.
	FString GetOmniLocalPath(const FString& OmniServerPath) const;

protected:
	enum class EPathChange
	{
		Add,
		Remove,
	};

	UOmniverseContentManager();

	void RefreshAll();
	void OnServerConnectionChanged(const FString& Server, EOmniverseServerConnectionChange ConnectionChange);

	void OnAssetFolderSelected(const FString& Path);
	void DownloadAsset(const FString& LocalPath, bool bFolder, bool bSynchronous, bool bRegisterAssetsAfterMDLDownload, bool bForceRefreshNativeAssets, bool bMonitor);
	void OnAssetRemoved(const struct FAssetData& AssetData);
	void OnPathChanged(const FString& Path, EPathChange PathChange);

	bool RegisterAsset(const FOmniverseListItem& ListItem, const FString& PkgPath);
	void CleanupInvalidAssets(const FString& LocalPath, const TArray<FString>& ValidPkgPaths);
	void WriteContentTo(const FString& OutputPath, void* Content, uint64 Size);
	void AfterDownloadingAsset(const FString& LocalPath, const TArray<struct FOmniverseListItem> ListResults, bool bForceRefreshNativeAssets,
		bool bProgressBar);
	bool CheckAndRegisterAsset(const FOmniverseListItem& ListItem, bool bWait, bool bForceRefreshNativeAssets);
	void CacheAssetThumbnail(const struct FAssetData& AssetData, const FString& OmniPath);
	bool HasAssetThumbnail(const struct FAssetData& AssetData);

	bool bRefreshingContent = false;
	bool bDeletingInvalidServer = false;
	TMap<FString, FString> ServerAssetFolderMap;
	TSharedOmniverseAyncTask ListSubscribeTask = nullptr;

	// Map local package path to omni url
	// Since omni url may include space or other characters
	// that may not convertible locally. This map is used
	// to query the real omni server url of local package path.
	// The key is in format /Game/Omniverse/formated_omni_server_string/other_server_path.
	// The value is in format [domain]://[server:port]/other_server_path.
	mutable TMap<FString, FString> LocalPackagePathToOmniUrlMap;

private:
	void SetMountFolder(const FString& Folder);
	void SetFolderStatus(const FString& Folder, EOmniverseServerConnectionChange Status);
	void StopSubscribe();
	void RemoveAsset(const FString& PackageName, bool bFolder, const FString& Extension = TEXT(""));
};
