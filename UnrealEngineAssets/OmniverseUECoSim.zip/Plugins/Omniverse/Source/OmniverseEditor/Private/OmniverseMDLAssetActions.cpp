// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseMDLAssetActions.h"
#include "Engine/Engine.h"
#include "Editor.h"
#include "Internationalization/Internationalization.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Widgets/SWidget.h"
#include "OmniverseMDL.h"
#include "Brushes/SlateImageBrush.h"
#include "Styling/SlateStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Interfaces/IPluginManager.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Misc/ConfigCacheIni.h"
#include "Widgets/Images/SImage.h"

#define LOCTEXT_NAMESPACE "OmniverseMDLAssetActions"
#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( StyleSet->RootToContentDir( RelativePath, TEXT( ".png" ) ), __VA_ARGS__ )
TSharedPtr<FSlateStyleSet> FMDLAssetTypeActions::StyleSet = nullptr;

FMDLAssetTypeActions::FMDLAssetTypeActions(EAssetTypeCategories::Type InAssetCategory)
	: MyAssetCategory(InAssetCategory)
{
	StyleSet = MakeShareable(new FSlateStyleSet("OmniverseMDLAssetActions"));

	//Content path of this plugin
	FString ContentDir = IPluginManager::Get().FindPlugin("MDL")->GetBaseDir();
	StyleSet->SetContentRoot(ContentDir);

	const FVector2D Icon16x16(16.0f, 16.0f);
	const FVector2D Icon128x128(128.0f, 128.0f);

	StyleSet->Set("OmniverseMDLAssetActions.LockIcon", new IMAGE_BRUSH("Resources/MountLock", Icon16x16));
	StyleSet->Set("ClassThumbnail.OmniverseMDL", new IMAGE_BRUSH("Resources/Icon128", Icon128x128));

	//Register the created style
	FSlateStyleRegistry::RegisterSlateStyle(*StyleSet);
}

FMDLAssetTypeActions::~FMDLAssetTypeActions()
{
	if (StyleSet.IsValid())
	{
		FSlateStyleRegistry::UnRegisterSlateStyle(*StyleSet.Get());
		ensure(StyleSet.IsUnique());
		StyleSet.Reset();
	}
}

FText FMDLAssetTypeActions::GetName() const
{
	return FText::FromString("Omniverse MDL");
}

UClass * FMDLAssetTypeActions::GetSupportedClass() const
{
	return UOmniverseMDL::StaticClass();
}

FColor FMDLAssetTypeActions::GetTypeColor() const
{
	return FColor::White;
}

uint32 FMDLAssetTypeActions::GetCategories()
{
	return MyAssetCategory;
}

TSharedPtr<class SWidget> FMDLAssetTypeActions::GetThumbnailOverlay(const FAssetData& AssetData) const
{
	static const FLinearColor ReadOnlyColor(0.5f, 0.05f, 0.05f);
	FString ColorStr;
	if (StyleSet.IsValid() && GConfig->GetString(TEXT("PathColor"), *AssetData.PackagePath.ToString(), ColorStr, GEditorPerProjectIni))
	{
		FLinearColor Color;
		if (Color.InitFromString(ColorStr) && Color.Equals(ReadOnlyColor, 0.01f))
		{
			return SNew(SBox)
				.HAlign(HAlign_Right)
				.VAlign(VAlign_Bottom)
				.ToolTipText(LOCTEXT("MDLAssetType_LockedFileToolTip", "This file is on a read-only mount"))
				.Padding(FMargin(0))
				[
					SNew(SBox)
					.MinDesiredWidth(16)
					.MinDesiredHeight(16)
					[
						SNew(SImage)
						.Image(StyleSet->GetBrush("OmniverseMDLAssetActions.LockIcon"))
					]
				];

		}
	}

	return nullptr;
}

void FMDLAssetTypeActions::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	if (!Cast<UOmniverseMDL>(InObjects[0]))
	{
		return;
	}

	auto USDAsset = Cast<UOmniverseAsset>(InObjects[0]);
	if (USDAsset == nullptr)
	{
		return;
	}

	FAssetTypeActions_Base::OpenAssetEditor(InObjects, EditWithinLevelEditor);

	if (USDAsset->IsAsset())
	{
		USDAsset->Load();
	}
}

#undef LOCTEXT_NAMESPACE
