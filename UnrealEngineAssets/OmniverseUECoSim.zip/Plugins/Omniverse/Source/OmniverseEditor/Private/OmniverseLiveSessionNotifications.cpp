// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseLiveSessionNotifications.h"
#include "OmniverseNotificationHelper.h"
#include "Framework/Application/SlateApplication.h"
#include "Interfaces/IMainFrameModule.h"
#include "OmniverseUSD.h"
#include "OmniverseMainButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"

FOmniverseLiveSessionNotifications::~FOmniverseLiveSessionNotifications()
{
}

void FOmniverseLiveSessionNotifications::AddUserSlot(const FString& FullUserInfo)
{
	if (UserSlotMap.Find(FullUserInfo) == nullptr)
	{
		TSharedPtr<SImage> UserSlot = nullptr;
		FOmniverseMainButton::GetUserBox()->AddSlot()
		[
			SAssignNew(UserSlot, SImage)
			.Image(FSlateIcon("OmniverseEditorStyle", "OmniverseLiveSessionDialog.User").GetIcon())
			.ColorAndOpacity(FLinearColor(FMath::FRandRange(0.0f, 1.0f), FMath::FRandRange(0.0f, 1.0f), FMath::FRandRange(0.0f, 1.0f)))
			.ToolTipText(FText::FromString(FullUserInfo))
		];
		UserSlotMap.Add(FullUserInfo, UserSlot);
	}
}

void FOmniverseLiveSessionNotifications::RemoveUserSlot(const FString& FullUserInfo)
{
	TSharedPtr<SImage>* UserSlot = UserSlotMap.Find(FullUserInfo);
	if (UserSlot)
	{
		FOmniverseMainButton::GetUserBox()->RemoveSlot((*UserSlot).ToSharedRef());
		UserSlotMap.Remove(FullUserInfo);
	}
}

void FOmniverseLiveSessionNotifications::Start(UOmniverseUSD* InUSD)
{
	if (USDAsset)
	{
		End();
	}

	USDAsset = InUSD;

	UserMergeHandle = IOmniverseCollaboration::Get()->OnMergeStarted.AddRaw(this, &FOmniverseLiveSessionNotifications::MergeStarted);

	UserHelloHandle = IOmniverseCollaboration::Get()->OnUserHelloed.AddLambda([&](const FOmniverseMessage& Message)
	{
		AddUserSlot(Message.from_user_name + TEXT(" (") + Message.app + TEXT(")"));
	});

	UserJoinedHandle = IOmniverseCollaboration::Get()->OnUserJoined.AddLambda([&](const FOmniverseMessage& Message)
	{
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("User %s has joined the session."), *Message.from_user_name));
		AddUserSlot(Message.from_user_name + TEXT(" (") + Message.app + TEXT(")"));
	});

	UserLeftHandle = IOmniverseCollaboration::Get()->OnUserLeft.AddLambda([&](const FOmniverseMessage& Message)
	{
		FOmniverseNotificationHelper::NotifyError(FString::Printf(TEXT("User %s has left the session."), *Message.from_user_name));
		RemoveUserSlot(Message.from_user_name + TEXT(" (") + Message.app + TEXT(")"));
	});

	UnSubscribeHandle = IOmniverseCollaboration::Get()->OnUnsubscribed.AddLambda([&]()
	{
		End();
	});
}
void FOmniverseLiveSessionNotifications::End()
{
	USDAsset = nullptr;
	UserSlotMap.Reset();
	FOmniverseMainButton::GetUserBox()->ClearChildren();
	IOmniverseCollaboration::Get()->OnMergeStarted.Remove(UserMergeHandle);
	IOmniverseCollaboration::Get()->OnUserJoined.Remove(UserJoinedHandle);
	IOmniverseCollaboration::Get()->OnUserLeft.Remove(UserLeftHandle);
	IOmniverseCollaboration::Get()->OnUserHelloed.Remove(UserHelloHandle);
	IOmniverseCollaboration::Get()->OnUnsubscribed.Remove(UnSubscribeHandle);
}

void FOmniverseLiveSessionNotifications::MergeStarted(const FOmniverseMessage& Message)
{
	// Get owner before leave session, usd will be freed then.
	FName SessionOwner = USDAsset->GetSessionOwner();
	USDAsset->LeaveSession();
	TSharedPtr<SWindow> WarningWindow = SNew(SWindow)
		.Title(FText::FromString("Leave Session"))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.SizingRule(ESizingRule::FixedSize)
		.ClientSize(FVector2D(350, 120))
		.HasCloseButton(false)
		.Content()
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(10, 20, 10, 0)
			[
				SNew(STextBlock)
				.WrapTextAt(330.0f)
				.Text(FText::Format(FText::FromString("'{0}' is ending the live session. Stop all work and leave the session."), FText::FromName(SessionOwner)))
			]
			+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(100, 30, 100, 0)
			[
				SNew(SButton)
				.Text(FText::FromString("Leave"))
				.HAlign(EHorizontalAlignment::HAlign_Center)
				.OnClicked(FOnClicked::CreateLambda(
					[&]()
					{
						End();
						WarningWindow->RequestDestroyWindow();
						return FReply::Handled();
					}
				))
			]
		];

	TSharedPtr<SWindow> ParentWindow;
	if( FModuleManager::Get().IsModuleLoaded( "MainFrame" ) )
	{
		IMainFrameModule& MainFrame = FModuleManager::LoadModuleChecked<IMainFrameModule>( "MainFrame" );
		ParentWindow = MainFrame.GetParentWindow();
	}

	FSlateApplication::Get().AddModalWindow(WarningWindow.ToSharedRef(), ParentWindow, false);
}

static TSharedPtr<FOmniverseLiveSessionNotifications> OmniverseLiveSessionNotificationsInst = nullptr;

TSharedRef<FOmniverseLiveSessionNotifications> FOmniverseLiveSessionNotifications::Get()
{
	if (!OmniverseLiveSessionNotificationsInst)
	{
		OmniverseLiveSessionNotificationsInst = MakeShareable(new FOmniverseLiveSessionNotifications());
	}

	return OmniverseLiveSessionNotificationsInst.ToSharedRef();
}