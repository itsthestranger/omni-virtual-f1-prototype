// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once 
#include "CoreMinimal.h"
#include "IOmniverseCollaboration.h"
#include "Widgets/Images/SImage.h"

class FOmniverseLiveSessionNotifications
{
public:
	static TSharedRef<FOmniverseLiveSessionNotifications> Get();
	

	virtual ~FOmniverseLiveSessionNotifications();

	void Start(class UOmniverseUSD* InUSD);

private:
	void End();
	void MergeStarted(const FOmniverseMessage& Message);
	void AddUserSlot(const FString& FullUserInfo);
	void RemoveUserSlot(const FString& FullUserInfo);

private:
	class UOmniverseUSD* USDAsset;
	FDelegateHandle UserMergeHandle;
	FDelegateHandle UserJoinedHandle;
	FDelegateHandle UserLeftHandle;
	FDelegateHandle UserHelloHandle;
	FDelegateHandle UnSubscribeHandle;
	TMap<FString, TSharedPtr<SImage>> UserSlotMap;
};