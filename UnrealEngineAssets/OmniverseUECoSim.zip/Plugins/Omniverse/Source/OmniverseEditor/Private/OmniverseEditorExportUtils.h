// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once

#include "CoreMinimal.h"
#include "OmniversePxr.h"
#include "OmniverseExportSettings.h"

class FOmniverseEditorExportUtils
{
public:
	// bAddExtraExtension: when it's true, it will add extra extension to exported file if exported 
	// object is a world, ie, it will export .stage.usd for root layer, and .prop.usd for props. If it's false, 
	// they will all be exported as .usd only.
	static bool ExportObjectsToOmniverse(const TArray<class UObject*>& Objects, const FOmniverseExportSettings& ExportSettings);

	static bool ExportActorsToOmniverse(const TArray<class AActor*>& SelectedActors, const FOmniverseExportSettings& ExportSettings);

	static bool AreObjectsFromTheSameClass(const TArray<class UObject*>& Objects);

	static FString ChooseOmniversePathForAsset(const FString& DefaultAssetName, bool ChooseFolder, const FString& DefaultPath = TEXT(""));

	static bool GetMappingPaths(const FString& ExportLocalPath, const FString& Extension, FString& MappingLocalPkgPath, FString& MappingOmniPath);

	enum LiveModeSetupActionType
	{
		ReloadStageBeforeLive,
		SaveLocalChangesBeforeLive,
		SaveAsBeforeLive,			// This isn't currently an option
		DoNothingBeforeLive			// This gives undefined behavior and isn't supported
	};

	static bool GetCheckpointComment(FString& Comment, bool bLiveCheckpointDialog, LiveModeSetupActionType* LiveModeSetupAction = nullptr);

	static bool ReadOnlyFolderCheck(const FString& ExportFolderPath, bool bShowMessageDialog = true);

private:
	static bool ExportObjectToOmniversePath(class UObject* Object, const FString& ExportPath, const FOmniverseExportSettings& ExportSettings);

	static bool ExportLevelToOmniversePath(class UWorld* World, const FString& ExportPath, const FOmniverseExportSettings& ExportSettings);

	static bool ExportTextureToOmniversePath(class UTexture* Texture, const FString& ExportPath, const FOmniverseExportTextureSettings& TextureSettings);

	static bool ExportMaterialToOmniversePath(class UMaterialInterface* Material, const FString& ExportPath, const FOmniverseExportMaterialSettings& MaterialSettings);
};