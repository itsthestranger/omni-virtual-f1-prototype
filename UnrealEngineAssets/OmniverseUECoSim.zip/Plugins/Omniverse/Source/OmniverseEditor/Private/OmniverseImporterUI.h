// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once 
#include "CoreMinimal.h"
#include "Animation/Skeleton.h"
#include "UObject/ObjectMacros.h"
#include "UObject/Object.h"

#include "OmniverseImporterUI.generated.h"

UENUM()
enum EOmniSourceType
{
	OST_Local,
	OST_Nucleus,
	OST_Max,
};

UENUM()
enum EOmniImporterType
{
	OIT_Facial,
	OIT_USD,
	OIT_Max,
};

UCLASS(HideCategories=Object, MinimalAPI)
class UOmniverseImporterUI : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	UPROPERTY()
	TEnumAsByte<enum EOmniSourceType> SourceType = OST_Local;

	UPROPERTY()
	TEnumAsByte<enum EOmniImporterType> ImporterType = OIT_Facial;

	UPROPERTY(BlueprintReadOnly, Category = Path)
	FString USDPath;

	UPROPERTY(BlueprintReadOnly, Category = Path)
	FString AssetPath;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = USD, meta = (
		EditCondition = "ImporterType == EOmniImporterType::OIT_USD",
		EditConditionHides))
	bool bImportUnusedReferences = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = USD, meta = (
		EditCondition = "ImporterType == EOmniImporterType::OIT_USD",
		EditConditionHides))
	bool bImportAsBlueprint = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Animation, meta = (
		EditCondition = "ImporterType == EOmniImporterType::OIT_Facial", 
		EditConditionHides))
	TObjectPtr<USkeleton> Skeleton;

	/** Optional name for the facial animation. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Asset, meta = (
		EditCondition = "ImporterType == EOmniImporterType::OIT_Facial",
		EditConditionHides))
	FName Name = NAME_None;

	FString PreUSDPath[OST_Max][OIT_Max];
	FString PreAssetPath[OST_Max][OIT_Max];
};