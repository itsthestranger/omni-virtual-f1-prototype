// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.
#include "OmniverseContentManager.h"
#include "Algo/Count.h"
#include "HAL/FileManager.h"
#include "UObject/UObjectHash.h"
#include "FileHelpers.h"
#include "Misc/FileHelper.h"
#include "Logging/LogMacros.h"
#include "Engine/Engine.h"
#include "Dialogs/Dialogs.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "ContentBrowserModule.h"
#include "Misc/ConfigCacheIni.h"
#include "CoreGlobals.h"
#include "ISourceControlProvider.h"
#include "IOmniverseRuntimeModule.h"
#include "OmniverseEditorExportUtils.h"
#include "OmniverseAsset.h"
#include "OmniverseSettings.h"
#include "OmniversePathHelper.h"
#include "Async/Async.h"
#include "Misc/ScopedSlowTask.h"
#include "Misc/MessageDialog.h"
#include "HAL/PlatformFileManager.h"
#include "OmniverseNotificationHelper.h"
#include "OmniverseEditorPrivate.h"
#include "Runtime/Launch/Resources/Version.h"
#include "IContentBrowserDataModule.h"
#include "ContentBrowserDataSubsystem.h"
#include "OmniverseThumbnailUtils.h"
#include "ObjectTools.h"

DEFINE_LOG_CATEGORY(LogOmniverseContentManager);

extern bool OMNIVERSERUNTIME_API GListingAssetsForEditor;
extern ENGINE_API class UEngine* GEngine;

static TAutoConsoleVariable<int32> CVarOmniverseListSubLayer(
	TEXT("Omniverse.ListSubLayer"),
	0,
	TEXT(""),
	ECVF_Default);

UOmniverseContentManager::UOmniverseContentManager()
{
	static bool bInitialized = false;
	if(bInitialized)
	{
		return;
	}

	bInitialized = true;

	// Monitor folder selecting
	FContentBrowserModule& ContentBrowserModule = FModuleManager::GetModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
	ContentBrowserModule.GetOnAssetPathChanged().AddUObject(this, &UOmniverseContentManager::OnAssetFolderSelected);

	// Refresh on reconnection and register connection change
	RefreshAll();
	IOmniverseRuntimeModule::Get().OnServerWatchListChanged.AddUObject(this, &UOmniverseContentManager::RefreshAll);
	IOmniverseRuntimeModule::Get().OnServerConnectionChanged.AddUObject(this, &UOmniverseContentManager::OnServerConnectionChanged);

	// Monitor asset deleting
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName);
	auto& AssetRegistry = AssetRegistryModule.Get();

	AssetRegistry.OnAssetRemoved().AddUObject(this, &UOmniverseContentManager::OnAssetRemoved);

	// Monitor folder change
	AssetRegistry.OnPathAdded().AddUObject(this, &UOmniverseContentManager::OnPathChanged, EPathChange::Add);
	AssetRegistry.OnPathRemoved().AddUObject(this, &UOmniverseContentManager::OnPathChanged, EPathChange::Remove);
}

void UOmniverseContentManager::OnServerConnectionChanged(const FString& Server, EOmniverseServerConnectionChange ConnectionChange)
{
	if (ConnectionChange == EOmniverseServerConnectionChange::ConnectionError ||
		ConnectionChange == EOmniverseServerConnectionChange::Disconnected)
	{
		const FString& ServerLocalRootFolder = GetServerLocalRootFolder(Server);
		ServerAssetFolderMap.Remove(Server);
		LocalPackagePathToOmniUrlMap.Remove(ServerLocalRootFolder);
		FString PathOnDisk;
		FPackageName::TryConvertLongPackageNameToFilename(ServerLocalRootFolder, PathOnDisk);
		IFileManager::Get().DeleteDirectory(*PathOnDisk, false, true);
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName);
		auto& AssetRegistry = AssetRegistryModule.Get();
		AssetRegistry.RemovePath(ServerLocalRootFolder);
		IOmniverseRuntimeModule::Get().RemoveServer(Server);

		return;
	}

	const FString& ServerLocalRootFolder = GetServerLocalRootFolder(Server);
	// SetFolderStatus(ServerLocalRootFolder, ConnectionChange);
	ServerAssetFolderMap.Add(Server, ServerLocalRootFolder);
	LocalPackagePathToOmniUrlMap.Add(ServerLocalRootFolder, "omniverse://" + Server + "/");
	IOmniverseRuntimeModule::Get().WatchServer(Server);
}

void UOmniverseContentManager::RefreshAll()
{
	static bool bInRefresh = false;
	if (bInRefresh)
	{
		return;
	}

	bDeletingInvalidServer = true;
	ServerAssetFolderMap.Reset();
	const auto& WatchServerList = IOmniverseRuntimeModule::Get().GetWatchList();
	TArray<FString> ServerFolders;
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName);
	auto& AssetRegistry = AssetRegistryModule.Get();
	TArray<FString> PendingRemoveServers;
	for (const auto& WatchServer : WatchServerList)
	{
		if (WatchServer.Address.IsEmpty())
		{
			continue;
		}

		const FString& ServerLocalRootFolder = GetServerLocalRootFolder(WatchServer.Address);
		ServerAssetFolderMap.Add(WatchServer.Address, ServerLocalRootFolder);
		// SetFolderStatus(ServerLocalRootFolder, WatchServer.Status);

		// Add root folder into mapping
		ServerFolders.Add(WatchServer.Address);
		LocalPackagePathToOmniUrlMap.Add(ServerLocalRootFolder, "omniverse://" + WatchServer.Address + "/");
		FString PathOnDisk;
		FPackageName::TryConvertLongPackageNameToFilename(ServerLocalRootFolder, PathOnDisk);
		if (WatchServer.Status == EOmniverseServerConnectionChange::ConnectionError)
		{
			PendingRemoveServers.Add(WatchServer.Address);
			IFileManager::Get().DeleteDirectory(*PathOnDisk, false, true);
			AssetRegistry.RemovePath(ServerLocalRootFolder);
		}
		else if (!FPaths::FileExists(PathOnDisk))
		{
			IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
			PlatformFile.CreateDirectory(*PathOnDisk);
			AssetRegistry.AddPath(ServerLocalRootFolder);
		}
	}

	bInRefresh = true;
	for (const auto& Server : PendingRemoveServers)
	{
		IOmniverseRuntimeModule::Get().RemoveServer(Server);
	}
	bInRefresh = false;

	// If any folders not in WatchServerList appear in the Omniverse folder delete them
	TArray<FString> SubPaths;
	FString OmniverseFolder = FPaths::ProjectContentDir() + FString(TEXT("Omniverse/*"));
	OmniverseFolder = IFileManager::Get().ConvertToAbsolutePathForExternalAppForWrite(*OmniverseFolder);
	IFileManager::Get().FindFiles(SubPaths, *OmniverseFolder, false, true);
	for (const auto& SubPath : SubPaths)
	{
		FString UnmangledSubPath;
		FOmniversePathHelper::UnmanglePath(SubPath, UnmangledSubPath, false);
		if (!UnmangledSubPath.IsEmpty() && ServerFolders.Find(UnmangledSubPath) == INDEX_NONE)
		{
			const FString& PkgPath = GetServerLocalRootFolder(UnmangledSubPath);
			FString PathOnDisk;
			FPackageName::TryConvertLongPackageNameToFilename(PkgPath, PathOnDisk);
			IFileManager::Get().DeleteDirectory(*PathOnDisk, false, true);
			AssetRegistry.RemovePath(PkgPath);
		}
	}

	bDeletingInvalidServer = false;
}

void UOmniverseContentManager::OnAssetFolderSelected(const FString& Path)
{
	// NOTE: Path from ContentBrowser is virtual path now, need to be converted to internal path
	FName InternalPath;
	EContentBrowserPathType ConvertedType = IContentBrowserDataModule::Get().GetSubsystem()->TryConvertVirtualPath(Path, InternalPath);

	// Skip none Omniverse folder
	FString InternalPathStr = ConvertedType == EContentBrowserPathType::Internal ? InternalPath.ToString() : Path;
	if(!IsPathUnderOmniverseFolder(InternalPathStr))
	{
		StopSubscribe();
		return;
	}

	// Convert to Omniverse path
	RefreshFolder(InternalPathStr, false, false);
}

void UOmniverseContentManager::SetMountFolder(const FString& Folder)
{
	static const FLinearColor ReadOnlyColor(0.5f, 0.05f, 0.05f);

	// ListResult.Path will be something like "/NVIDIA/" - we need to prepend "/Game/Omniverse" and remove the trailing "/"
	GConfig->SetString(TEXT("PathColor"), *Folder, *ReadOnlyColor.ToString(), GEditorPerProjectIni);
}

void UOmniverseContentManager::SetFolderStatus(const FString& Folder, EOmniverseServerConnectionChange Status)
{
	static const FLinearColor DisconnectedColor(0.3f, 0.3f, 0.3f);
	static const FLinearColor ConnectingColor(0.5f, 0.5f, 0.05f);
	static const FLinearColor ConnectedColor(0.05f, 0.5f, 0.05f);

	switch (Status)
	{
	case EOmniverseServerConnectionChange::Connecting:
		// ListResult.Path will be something like "/NVIDIA/" - we need to prepend "/Game/Omniverse" and remove the trailing "/"
		GConfig->SetString(TEXT("PathColor"), *Folder, *ConnectingColor.ToString(), GEditorPerProjectIni);
		break;
	case EOmniverseServerConnectionChange::Connected:
		GConfig->SetString(TEXT("PathColor"), *Folder, *ConnectedColor.ToString(), GEditorPerProjectIni);
		break;
	case EOmniverseServerConnectionChange::Disconnected:
	case EOmniverseServerConnectionChange::ConnectionError:
		GConfig->SetString(TEXT("PathColor"), *Folder, *DisconnectedColor.ToString(), GEditorPerProjectIni);
		break;
	default:
		break;
	}
}

FString UOmniverseContentManager::GetServerLocalRootFolder(const FString & Server) const
{
	FString MangledServer;
	FOmniversePathHelper::ManglePath(Server.Replace(TEXT(":"), TEXT("_")), MangledServer, false);
	return OMNIVERSE_FOLDER / MangledServer;
}

FString UOmniverseContentManager::GetOmniServerPath(const FString & OmniLocalPath) const
{
	FString LocalPath = OmniLocalPath;
	LocalPath.RemoveFromEnd("/");

	if (!FPackageName::IsValidLongPackageName(LocalPath))
	{
		UE_LOG(LogOmniverseContentManager, Warning, TEXT("GetOmniServerPath: %s is not a valid package name."), *LocalPath);
	}
	
	if (auto FoundValue = LocalPackagePathToOmniUrlMap.Find(LocalPath))
	{
		return *FoundValue;
	}

	for (const auto& ServerPair : ServerAssetFolderMap)
	{
		if (OmniLocalPath.StartsWith(*ServerPair.Value))
		{
			FString OmniServerPath = OmniLocalPath.Replace(*ServerPair.Value, *ServerPair.Key);
			OmniServerPath = "omniverse://" + OmniServerPath;
			FString UnmangledOmniServerPath;
			FOmniversePathHelper::UnmanglePath(OmniServerPath, UnmangledOmniServerPath);
			LocalPackagePathToOmniUrlMap.Add(LocalPath, UnmangledOmniServerPath);

			return UnmangledOmniServerPath;
		}
	}

	return "";
}

FString UOmniverseContentManager::GetOmniLocalPath(const FString& OmniServerPath) const
{
	FString PackagePath;
	FString AssetName;
	FString Extension;
	Extension = FPaths::GetExtension(OmniServerPath);
	FOmniversePathHelper::ConvertOmniPath(OmniServerPath, PackagePath, AssetName, Extension, true);
	LocalPackagePathToOmniUrlMap.Add(PackagePath, OmniServerPath);

	return PackagePath;
}

void UOmniverseContentManager::DownloadAsset(const FString& LocalPath, bool bFolder, bool bSynchronous, bool bRegisterAssetsAfterDownload,
	bool bForceRefreshNativeAssets, bool bMonitor)
{
	// Don't list empty directory, which may cause deadlock for future api
	if (LocalPath.IsEmpty())
	{
		return;
	}

	FString FullLocalPath = LocalPath;
	if (!FullLocalPath.StartsWith(OMNIVERSE_FOLDER))
	{
		FullLocalPath = OMNIVERSE_FOLDER + FullLocalPath;
	}

	if (bFolder && !FullLocalPath.EndsWith("/"))
	{
		FullLocalPath += '/';
	}

	const FString OmniPath = GetOmniServerPath(FullLocalPath);
	if (OmniPath.IsEmpty())
	{
		UE_LOG(LogOmniverseContentManager, Warning, TEXT("There is no server path found for local path: %s"), *FullLocalPath);
		return;
	}

	if (bSynchronous)
	{
		TArray<FOmniverseListItem> OmniListItems;
		TArray<FOmniverseListItem> OmniListItemsWithoutSublayer;
		if (FOmniverseConnectionHelper::ListFolderSync(OmniPath, OmniListItems))
		{
			for (auto ListItem : OmniListItems)
			{
				if (ListItem.Path.EndsWith(".sublayer.usd") && !CVarOmniverseListSubLayer.GetValueOnGameThread())
				{
					continue;
				}

				OmniListItemsWithoutSublayer.Add(ListItem);

				const FString& PkgPath = GetOmniLocalPath(ListItem.Path);
				if (!FPackageName::IsValidLongPackageName(PkgPath))
				{
					UE_LOG(LogOmniverseContentManager, Warning, TEXT("%s is not a valid package name."), *PkgPath);
					continue;
				}
			}
		}

		if (bRegisterAssetsAfterDownload)
		{
			AfterDownloadingAsset(FullLocalPath, OmniListItemsWithoutSublayer, bForceRefreshNativeAssets, true);
		}
	}
	else
	{
		FOmniverseListFolderCallback ListCallback = FOmniverseListFolderCallback::CreateLambda([this, FullLocalPath,
			bRegisterAssetsAfterDownload, bForceRefreshNativeAssets, bMonitor](const FOmniverseListFolderResult& ListResult)
		{
			TArray<FOmniverseListItem> OmniListItems;
			for (const auto& ListItem : ListResult.ListItems)
			{
				if (ListItem.Path.EndsWith(".sublayer.usd") && !CVarOmniverseListSubLayer.GetValueOnGameThread())
				{
					continue;
				}

				// The latest client library doesn't give paths with a "/", so append one and change how this is done in the future
				// in RegisterAsset()
				FString PathToAdd = ListItem.Path;
				if (ListItem.Flags & fOmniClientItem_CanHaveChildren)
				{
					PathToAdd.Append("/");
				}

				FOmniverseListItem NewListItem = ListItem;
				NewListItem.Path = PathToAdd;
				OmniListItems.Add(NewListItem);
			}

			// Sort
			OmniListItems.Sort([](const FOmniverseListItem& Item1, const FOmniverseListItem& Item2) {
				return Item1.Path > Item2.Path;
				});

			if (bRegisterAssetsAfterDownload)
			{
				AfterDownloadingAsset(FullLocalPath, OmniListItems, bForceRefreshNativeAssets, false);
			}
		});

		FOmniverseSubscribeCallback SubscribeCallback = FOmniverseSubscribeCallback::CreateLambda([this, FullLocalPath, bRegisterAssetsAfterDownload, bForceRefreshNativeAssets, bMonitor](const FOmniverseSubscribeResult& SubscribeResult)
		{
			switch(SubscribeResult.ListEvent)
			{
			case OmniClientListEvent::eOmniClientListEvent_Created:
			{
				auto ListItem = SubscribeResult.ListItem;
				if (ListItem.Path.EndsWith(".sublayer.usd") && !CVarOmniverseListSubLayer.GetValueOnGameThread())
				{
					break;
				}

				// The latest client library doesn't give paths with a "/", so append one and change how this is done in the future
				// in RegisterAsset()
				FString PathToAdd = ListItem.Path;
				if (ListItem.Flags & fOmniClientItem_CanHaveChildren)
				{
					PathToAdd.Append("/");
				}

				FOmniverseListItem NewListItem = ListItem;
				NewListItem.Path = PathToAdd;
					
				if (bRegisterAssetsAfterDownload)
				{
					CheckAndRegisterAsset(NewListItem, false, bForceRefreshNativeAssets);
				}
				break;
			}
			case OmniClientListEvent::eOmniClientListEvent_Deleted:
			{
				const FString& PkgPath = GetOmniLocalPath(SubscribeResult.ListItem.Path);
				RemoveAsset(PkgPath, SubscribeResult.ListItem.Flags & fOmniClientItem_CanHaveChildren, ".uasset");		
				break;
			}
			}
		});

		StopSubscribe();
		ListSubscribeTask = FOmniverseConnectionHelper::ListFolderSubscribe(OmniPath, ListCallback, SubscribeCallback);
	}
}

bool UOmniverseContentManager::HasAssetThumbnail(const FAssetData& AssetData)
{
	const FObjectThumbnail* CachedThumbnail = ThumbnailTools::FindCachedThumbnail(*AssetData.GetFullName());
	if (CachedThumbnail != NULL)
	{
		// There is a cached thumbnail for this asset, we should render it
		return !CachedThumbnail->IsEmpty();
	}

	// Unloaded blueprint or asset that may have a custom thumbnail, check to see if there is a thumbnail in the package to render
	FString PackageFilename;
	if (FPackageName::DoesPackageExist(AssetData.PackageName.ToString(), &PackageFilename))
	{
		TSet<FName> ObjectFullNames;
		FThumbnailMap ThumbnailMap;

		FName ObjectFullName = FName(*AssetData.GetFullName());
		ObjectFullNames.Add(ObjectFullName);

		ThumbnailTools::LoadThumbnailsFromPackage(PackageFilename, ObjectFullNames, ThumbnailMap);

		const FObjectThumbnail* ThumbnailPtr = ThumbnailMap.Find(ObjectFullName);
		if (ThumbnailPtr)
		{
			const FObjectThumbnail& ObjectThumbnail = *ThumbnailPtr;
			return ObjectThumbnail.GetImageWidth() > 0 && ObjectThumbnail.GetImageHeight() > 0 && ObjectThumbnail.GetCompressedDataSize() > 0;
		}
	}

	return false;
}

void UOmniverseContentManager::CacheAssetThumbnail(const FAssetData& AssetData, const FString& OmniPath)
{
	const FString PackageName = AssetData.PackageName.ToString();
	if (!HasAssetThumbnail(AssetData))
	{
		FOmniverseThumbnailUtils::CacheThumbnailFromServer(OmniPath, AssetData.GetFullName(), PackageName);
	}
}

bool UOmniverseContentManager::RegisterAsset(const FOmniverseListItem& ListItem, const FString& PkgPath)
{
	// Set refreshing flag
	bRefreshingContent = true;
	TSharedPtr<void> OnReturn = MakeShareable<void>(nullptr,
		[&](auto)
		{
			bRefreshingContent = false;
		}
	);

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(
		AssetRegistryConstants::ModuleName);
	auto& AssetRegistry = AssetRegistryModule.Get();
	FString OmniPath = ListItem.Path;
	if (OmniPath.EndsWith("/")) // If it's folder
	{
		// Update Color of Mount
        if (ListItem.Flags & fOmniClientItem_IsMount || ListItem.Flags & fOmniClientItem_IsInsideMount)
        {
            SetMountFolder(PkgPath);
        }

		// Create folder
		FString NewPathOnDisk;
		if (FPackageName::TryConvertLongPackageNameToFilename(PkgPath, NewPathOnDisk) && IFileManager::Get().MakeDirectory(*NewPathOnDisk, true))
		{
			// Update content browser
			AssetRegistry.AddPath(PkgPath);
		}

		return true;
	}

	// Check if asset is already existed
	TArray<FAssetData> ExistingAssets;
	AssetRegistry.GetAssetsByPackageName(*PkgPath, ExistingAssets, true);
	if (ExistingAssets.Num() > 0)
	{
		CacheAssetThumbnail(ExistingAssets[0], OmniPath);
		return true;
	}

	// Engine would not have finished scanning. So we scan it here and check again.
	FString PathOnDisk;
	FPackageName::TryConvertLongPackageNameToFilename(PkgPath, PathOnDisk);

	TArray<FString> Files = { PathOnDisk };
	AssetRegistry.ScanFilesSynchronous(Files);
	AssetRegistry.GetAssetsByPackageName(*PkgPath, ExistingAssets, true);
	if (ExistingAssets.Num())
	{
		CacheAssetThumbnail(ExistingAssets[0], OmniPath);
		return true;
	}

	// Create asset
	GListingAssetsForEditor = true;
	auto Asset = UOmniverseAsset::LoadAsset(OmniPath, true);
	GListingAssetsForEditor = false;

	// Save asset
	if (!Asset)
	{
		return false;
	}

	// NOTE: Can't cache thumb directly here because AssetData hasn't been registered to AssetRegistry in another thread
	FString PkgLongName, AssetName, Extension;
	FOmniversePathHelper::ConvertOmniPath(OmniPath, PkgLongName, AssetName, Extension);

	FString ObjectFullName = Asset->GetClass()->GetName() + TEXT(" ") + PkgPath + TEXT(".") + AssetName;
	TSharedPtr<FDelegateHandle> DelHandle = MakeShared<FDelegateHandle>();
	*DelHandle = FCoreDelegates::OnBeginFrame.AddWeakLambda(this,
		[DelHandle, OmniPath, ObjectFullName, PkgPath]()
		{
			FOmniverseThumbnailUtils::CacheThumbnailFromServer(OmniPath, ObjectFullName, PkgPath);
			FCoreDelegates::OnBeginFrame.Remove(*DelHandle);
		}
	);

	AssetRegistry.ScanFilesSynchronous(Files, true);	// We have scanned before asset loading. So we must use force scan.

	// Delete asset in memory
	TArray<UObject*> AllObjects;
	GetObjectsWithOuter(Asset->GetOuter(), AllObjects);
	AllObjects.AddUnique(Asset->GetOuter());

	for (auto Object : AllObjects)
	{
		if (Object->IsAsset())
		{
			AssetRegistry.AssetCreated(Object);	// To call RemoveEmptyPackage()
		}

		Object->ClearFlags(EObjectFlags::RF_Standalone);
	}

	GEngine->ForceGarbageCollection(true);

	return true;
}

void UOmniverseContentManager::RemoveAsset(const FString& PackageName, bool bFolder, const FString& Extension)
{
	// Set refreshing flag
	bRefreshingContent = true;
	TSharedPtr<void> OnReturn = MakeShareable<void>(nullptr,
		[&](auto)
		{
			bRefreshingContent = false;
		}
	);

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(AssetRegistryConstants::ModuleName);
	auto& AssetRegistry = AssetRegistryModule.Get();

	FString PathOnDisk;
	FPackageName::TryConvertLongPackageNameToFilename(PackageName, PathOnDisk);

	if (bFolder)
	{
		if (IFileManager::Get().DeleteDirectory(*PathOnDisk, false, true))
		{
			AssetRegistry.RemovePath(PackageName);
		}
	}
	else
	{
		if (IFileManager::Get().Delete(*(PathOnDisk + Extension), true, true))
		{
			return;
		}

		// Loaded assets cannot be deleted. So instead we remove asset flags.
		auto Pkg = FindObject<UPackage>(nullptr, *PackageName);
		if (!Pkg)
		{
			return;
		}

		TArray<UObject*> AllObjects;
		GetObjectsWithOuter(Pkg, AllObjects);
		AllObjects.AddUnique(Pkg);

		for (auto Object : AllObjects)
		{
			Object->ClearFlags(EObjectFlags::RF_Standalone);
			Object->ClearFlags(EObjectFlags::RF_Public);
		}

		// Remove from content browser
		extern bool OMNIVERSERUNTIME_API GListingAssetsForEditor;
		GListingAssetsForEditor = true;
		AssetRegistry.PackageDeleted(Pkg);
		GListingAssetsForEditor = false;
	}
}

void UOmniverseContentManager::CleanupInvalidAssets(const FString& LocalPath, const TArray<FString>& ValidPkgPaths)
{
	FString ListFolder(LocalPath);
	ListFolder.RemoveFromEnd("/");

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(
		AssetRegistryConstants::ModuleName);
	auto& AssetRegistry = AssetRegistryModule.Get();

	TArray<FString> SubPaths;
	AssetRegistry.GetSubPaths(ListFolder, SubPaths, false);
	for (const auto& SubPath : SubPaths)
	{
		if (ValidPkgPaths.Find(SubPath) != INDEX_NONE)
		{
			continue;
		}

		RemoveAsset(SubPath, true);
	}

	// Remove assets
	TArray<FAssetData> Assets;
	AssetRegistry.GetAssetsByPath(*ListFolder, Assets);

	for (auto AssetData : Assets)
	{
		FString PackageName = AssetData.PackageName.ToString();
		
		//Remove branch and checkpoint postfix
		int32 SearchIndex = PackageName.Find(OMNIVERSE_BRANCH);
		if (SearchIndex != INDEX_NONE)
		{
			PackageName = PackageName.Left(SearchIndex);
		}

		SearchIndex = PackageName.Find(OMNIVERSE_CHECKPOINT);
		if (SearchIndex != INDEX_NONE)
		{
			PackageName = PackageName.Left(SearchIndex);
		}

		if (ValidPkgPaths.Find(PackageName) != INDEX_NONE)
		{
			continue;
		}

		FString Extension;
		if (AssetData.AssetClassPath.ToString().Equals("World"))
		{
			Extension = ".umap";
		}
		else
		{
			Extension = ".uasset";
		}

		RemoveAsset(AssetData.PackageName.ToString(), false, Extension);
	}
}

void UOmniverseContentManager::RefreshFolder(FString FolderPath, bool bWait, bool bForceRefreshNativeAssets)
{
	// Don't list empty directory, which may cause hang for future api
	if (FolderPath.IsEmpty() || !IsPathUnderOmniverseFolder(FolderPath))
	{
		return;
	}

	FString UnmanglePath;
	FOmniversePathHelper::UnmanglePath(FolderPath, UnmanglePath);

	FString ListingText = FString::Printf(TEXT("Refreshing Folder %s..."), *UnmanglePath);
	FScopedSlowTask ListingAssets(1.0f, FText::FromString(ListingText));
	ListingAssets.MakeDialog(false);

	// Download Asset if it's a deep refresh
	DownloadAsset(FolderPath, true, bWait, true, bForceRefreshNativeAssets, false);
}

void UOmniverseContentManager::RefreshAsset(FString AssetPath, bool bWait)
{
	if (AssetPath.IsEmpty() || !IsPathUnderOmniverseFolder(AssetPath))
	{
		return;
	}

	FString UnmanglePath;
	FOmniversePathHelper::UnmanglePath(AssetPath, UnmanglePath);

	FString ListingText = FString::Printf(TEXT("Refreshing Asset %s..."), *UnmanglePath);
	FScopedSlowTask ListingAssets(1.0f, FText::FromString(ListingText));
	ListingAssets.MakeDialog(false);

	DownloadAsset(AssetPath, false, bWait, true, true, false);
}

void UOmniverseContentManager::OnAssetRemoved(const FAssetData& AssetData)
{
	if (bDeletingInvalidServer)
	{
		return;
	}

	// Skip listing
	extern bool OMNIVERSERUNTIME_API GListingAssetsForEditor;
	if(GListingAssetsForEditor)
	{
		return;
	}

	// Skip
	if(!GPumpingMessages || bRefreshingContent)
	{
		return;
	}

	if(!UPackage::IsEmptyPackage(AssetData.GetPackage(), AssetData.GetAsset()))
	{
		return;
	}

	// Check if already handled
	static EAppReturnType::Type UserChoice = EAppReturnType::No;
	static TMap<FString, bool> DeleteList;

	auto OmniAsset = StaticCast<UOmniverseAsset*>(FindObjectWithOuter(AssetData.GetPackage(), UOmniverseAsset::StaticClass()));
	if(!OmniAsset)
	{
		return;
	}

	if(DeleteList.Find(OmniAsset->GetOmniPath()))
	{
		return;
	}

	// Check YesAll and NoAll choice
	switch(UserChoice)
	{
	case EAppReturnType::YesAll:
		DeleteList.Add(OmniAsset->GetOmniPath(), true);
		return;
		break;
	case EAppReturnType::NoAll:
		return;
		break;
	}

	// Ask user choice
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 24
	UserChoice = OpenMsgDlgInt(EAppMsgType::YesNoYesAllNoAll, EAppReturnType::NoAll, FText::FromString(L"Also delete in Omniverse?\n" + OmniAsset->GetOmniPath()), FText::FromString(L"Omniverse"));
#else
	FText Title = FText::FromString(L"Omniverse");
	UserChoice = FMessageDialog::Open(EAppMsgType::YesNoYesAllNoAll, EAppReturnType::NoAll, FText::FromString(L"Also delete in Omniverse?\n" + OmniAsset->GetOmniPath()), &Title);
#endif

	// Add to delete list
	switch(UserChoice)
	{
	case EAppReturnType::Yes:
	case EAppReturnType::YesAll:
		DeleteList.Add(OmniAsset->GetOmniPath(), true);
		break;
	case EAppReturnType::No:
		DeleteList.Add(OmniAsset->GetOmniPath(), false);
		break;
	}

	// Bind delegate
	static FDelegateHandle DelegateHandle;
	if(!DelegateHandle.IsValid())
	{
		DelegateHandle = FCoreDelegates::OnBeginFrame.AddLambda(
			[this]()
			{
				// Delete Omniverse assets
				TArray<FString> Paths;

				FScopedSlowTask DeletingAssets(DeleteList.Num(), FText::FromString(TEXT("Deleting Assets...")));
				DeletingAssets.MakeDialog(false);
				for(auto Pair : DeleteList)
				{
					if(Pair.Value)
					{
						FString DeleteText = FString::Printf(TEXT("Deleting Asset %s..."), *Pair.Key);
						DeletingAssets.EnterProgressFrame(1.0f, FText::FromString(DeleteText));
						FOmniverseConnectionHelper::DeleteSync(Pair.Key);
						Paths.AddUnique(Pair.Key);
					}
				}

				// Clear delete list
				DeleteList.Reset();

				// Reset user choice
				UserChoice = EAppReturnType::No;

				// Broadcast event
				IOmniverseRuntimeModule::Get().OnAssetDeleted.Broadcast(Paths);

				// Unbind delegate
				FCoreDelegates::OnBeginFrame.Remove(DelegateHandle);
				DelegateHandle.Reset();
			}
		);
	}
}

void UOmniverseContentManager::OnPathChanged(const FString& Path, EPathChange PathChange)
{
	if (bDeletingInvalidServer)
	{
		return;
	}

	if (!IsPathUnderOmniverseFolder(Path))
	{
		return;
	}

	const FString& OmniPath = GetOmniServerPath(Path);
	if (OmniPath.IsEmpty())
	{
		FString UnmanglePath;
		FOmniversePathHelper::UnmanglePath(Path, UnmanglePath);

		UE_LOG(LogOmniverseContentManager, Warning, TEXT("Local path %s has no mapping omni one."), *UnmanglePath);
		return;
	}

	if(!GPumpingMessages || bRefreshingContent)
	{
		return;
	}

	switch(PathChange)
	{
	case EPathChange::Add:
	{
		FOmniverseConnectionHelper::CreateFolderSync(OmniPath);
		break;
	}
	case EPathChange::Remove:
		{
			// Ask user choice
			static EAppReturnType::Type UserChoice = EAppReturnType::No;
#if ENGINE_MAJOR_VERSION <= 4 && ENGINE_MINOR_VERSION <= 24
			UserChoice = OpenMsgDlgInt(EAppMsgType::YesNo, EAppReturnType::No, FText::FromString(L"Also delete in Omniverse?\n" + OmniPath), FText::FromString(L"Omniverse"));
#else
			FText Title = FText::FromString(L"Omniverse");
			UserChoice = FMessageDialog::Open(EAppMsgType::YesNo, EAppReturnType::No, FText::FromString(L"Also delete in Omniverse?\n" + OmniPath), &Title);
#endif
			if (UserChoice == EAppReturnType::Yes)
			{
				FOmniverseConnectionHelper::DeleteAsync(OmniPath, nullptr);
			}
		}
		break;
	}
}

void UOmniverseContentManager::WriteContentTo(const FString & OutputPath, void* Content, uint64 Size)
{
	if (Size > 0 && Content)
	{
		IFileManager* FileManager = &IFileManager::Get();
		FArchive* Ar = FileManager->CreateFileWriter(*OutputPath);
		if (Ar)
		{
			Ar->Serialize(Content, Size);
			delete Ar;
		}
	}
}

bool UOmniverseContentManager::CheckAndRegisterAsset(const FOmniverseListItem& ListItem, bool bWait, bool bForceRefreshNativeAssets)
{
	const FString& PkgPath = GetOmniLocalPath(ListItem.Path);
	if (!FPackageName::IsValidLongPackageName(PkgPath))
	{
		return false;
	}

	return RegisterAsset(ListItem, PkgPath);
}

void UOmniverseContentManager::AfterDownloadingAsset(const FString& LocalPath, const TArray<FOmniverseListItem> ListResults, bool bForceRefreshNativeAssets,
	bool bProgressBar)
{
	FScopedSlowTask RegisterAssets(ListResults.Num(), FText::FromString(TEXT("Registering Assets...")));
	if (bProgressBar)
	{
		RegisterAssets.MakeDialog(false);
	}

	TArray<FString> ValidPkgPaths;
	for (auto ListResult : ListResults)
	{
		if (bProgressBar)
		{
			FString RegisterText = FString::Printf(TEXT("Registering Asset %s..."), *ListResult.Path);
			RegisterAssets.EnterProgressFrame(1.0f, FText::FromString(RegisterText));
		}

		if (CheckAndRegisterAsset(ListResult, false, bForceRefreshNativeAssets))
		{
			ValidPkgPaths.Add(GetOmniLocalPath(ListResult.Path));
		}
	}

	CleanupInvalidAssets(LocalPath, ValidPkgPaths);
}

bool UOmniverseContentManager::IsPathUnderOmniverseFolder(const FString& FullLocalPath) const
{
	bool FoundServer = false;
	for (const auto& ServerPair : ServerAssetFolderMap)
	{
		if (FullLocalPath.StartsWith(ServerPair.Value))
		{
			FoundServer = true;
			break;
		}
	}

	return FoundServer;
}

void UOmniverseContentManager::CleanAssets()
{
	// Set refreshing flag
	bRefreshingContent = true;
	TSharedPtr<void> OnReturn = MakeShareable<void>(nullptr,
		[&](auto)
		{
			bRefreshingContent = false;
		}
	);

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(
		AssetRegistryConstants::ModuleName);
	{
		// Delete everything in the entire Omniverse folder
		{
			FString LongPackageName;
			FPackageName::TryConvertLongPackageNameToFilename(OMNIVERSE_FOLDER, LongPackageName);

			IFileManager::Get().DeleteDirectory(*LongPackageName, false, true);
			AssetRegistryModule.Get().RemovePath(OMNIVERSE_FOLDER);
		}

		// Recreate the empty root folders for the conencted servers
		for (const auto& item : ServerAssetFolderMap)
		{
			FString LongPackageName;
			FPackageName::TryConvertLongPackageNameToFilename(item.Value, LongPackageName);

			// Recreate an empty root folder
			IFileManager::Get().MakeDirectory(*LongPackageName, true);
			AssetRegistryModule.Get().AddPath(item.Value);
		}
	}

	FString MDLFolder = "/Game/MDL";
	// Don't require to recreate
	{
		FString LongPackageName;
		FPackageName::TryConvertLongPackageNameToFilename(MDLFolder, LongPackageName);

		IFileManager::Get().DeleteDirectory(*LongPackageName, false, true);
		AssetRegistryModule.Get().RemovePath(MDLFolder);
	}
}

void UOmniverseContentManager::StopSubscribe()
{
	if (ListSubscribeTask)
	{
		ListSubscribeTask->Stop();
		ListSubscribeTask = nullptr;
	}
}