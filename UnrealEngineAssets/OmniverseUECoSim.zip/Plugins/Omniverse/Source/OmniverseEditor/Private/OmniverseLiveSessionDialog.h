// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#pragma once 

#include "CoreMinimal.h"
#include "OmniverseUSD.h"
#include "Widgets/SWindow.h"
#include "Widgets/Input/SComboBox.h"
#include "Widgets/Views/SListView.h"

namespace ELiveSessionChoices
{
	enum Type
	{
		JoinSession,
		CreateSession
	};
}


class SOmniverseLiveSessionDialog : public SWindow
{
public:
	SLATE_BEGIN_ARGS(SOmniverseLiveSessionDialog)
	{}

	SLATE_END_ARGS()

	//~SOmniverseLiveSessionDialog();

	/** 
	 * Constructs a new exporter dialog. 
	 *
	 * @param InArgs Slate arguments. 
	 */
	void Construct(const FArguments& InArgs, class UOmniverseUSD* USD);
	
	void AddSessionToComboBox(const FName& Session);
	void RemoveSessionFromComboBox(const FName& Session);
	void AddUserToListView(const FName& User);
	void RemoveUserFromListView(const FName& User);

	// Show the dialog
	static void ShowDialog(class UOmniverseUSD* USD);

	static void AddSession(const FName& Session);
	static void RemoveSession(const FName& Session);

	static void AddUser(const FName& User);
	static void RemoveUser(const FName& User);

private:
	void SetSession(const FName& Session);
	FString GetUserDisplayName(const FString& User, const FString& App);
	void Destroy();
	FReply Confirm();
	void OutputWarning(UOmniverseUSD::ESessionResult Result);

private:
	TArray<TSharedPtr<FName>> SessionList;
	TArray<TSharedPtr<FName>> DisplayUserList;
	TSet<FName>				JoinedUserList;

	FDelegateHandle GetUsersHandle;
	FDelegateHandle JoinHandle;
	FDelegateHandle LeftHandle;
	FDelegateHandle SessionAddedHandle;
	FDelegateHandle SessionRemovedHandle;
	FDelegateHandle TickDelegateHandle;

	TSharedPtr<SComboBox<TSharedPtr<FName>>> SessionCombobox;
	TSharedPtr<SListView<TSharedPtr<FName>>> UserListView;

	ELiveSessionChoices::Type LiveSessionChoices;
	class UOmniverseUSD* USDAsset;
	FString InputSession;
	FString SessionOwner;
	FString WarningMessage;

	static TWeakPtr<class SOmniverseLiveSessionDialog> DialogPtr;
	static FName LastSelectSession;
};