// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.
#pragma once

#include "CoreMinimal.h"
#include "Widgets/SWidget.h"
#include "Widgets/SBoxPanel.h"
#include "Textures/SlateIcon.h"
#include "Types/SlateEnums.h"

class FOmniverseMainButton:public TSharedFromThis<FOmniverseMainButton>
{
public:
	void Initialize();

	static TSharedPtr<SHorizontalBox> GetUserBox();

protected:
	FText GetTooltip();
	FText GetButtonText();
	FSlateIcon GetButtonIcon();
	TSharedRef<SWidget> GetMenu();
	void ShowConnectionDialog();
	void ServerTextCommitted(const FText& NewText, ETextCommit::Type CommitType);
	void ExportCurrentLevelToOmniverse();
	void CleanLocalAssets();
	void About();
	void OnWatch(FText Server);

	TSharedPtr<SWindow> ConnectionWnd;
};