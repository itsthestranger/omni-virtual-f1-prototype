// Copyright(c) 2020, NVIDIA CORPORATION. All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#include "OmniverseConnectionNotification.h"
#include "OmniverseConnectionHelper.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
#include "OmniverseSettings.h"

UOmniverseConnectionNotification::UOmniverseConnectionNotification()
{
	if(!HasAllFlags(EObjectFlags::RF_ClassDefaultObject))
	{
		return;
	}

	// Disable connection notification when executing the commandlet.
	if(IsRunningCommandlet())
	{
		return;
	}

	IOmniverseRuntimeModule& OmniRuntimeModule = IOmniverseRuntimeModule::Get();
	OmniRuntimeModule.OnServerConnectionChanged.AddUObject(this, &UOmniverseConnectionNotification::OnConnectionChanged);

	/*if(!FOmniverseConnectionHelper::GetMainConnection())
	{
		OnConnectionChanged(IOmniverseRuntimeModule::EConnectionChange::ConnectionLost);
	}*/
}

void UOmniverseConnectionNotification::OnConnectionChanged(const FString& Server, EOmniverseServerConnectionChange ConnectionChange)
{
	if (!NotificationItem.IsValid())
	{
		// Pop up notification
		FNotificationInfo Info(FText::GetEmpty());
		Info.bFireAndForget = false;
		Info.ExpireDuration = 0;
		Info.FadeOutDuration = 0.5f;
		Info.ButtonDetails.Add(FNotificationButtonInfo(
			FText::FromString("Dismiss"),
			FText(),
			FSimpleDelegate::CreateUObject(this, &UOmniverseConnectionNotification::OnDismiss),
			SNotificationItem::CS_Fail
		));

		NotificationItem = FSlateNotificationManager::Get().AddNotification(Info);
	}

	switch(ConnectionChange)
	{
	case EOmniverseServerConnectionChange::ConnectionError:
	case EOmniverseServerConnectionChange::Disconnected:
		// Notification already created, set state to fail
		if (NotificationItem.IsValid())
		{
			NotificationItem->SetCompletionState(SNotificationItem::CS_Fail);
			FString Message;
			if (ConnectionChange == EOmniverseServerConnectionChange::ConnectionError)
			{
				Message = FString::Printf(TEXT("Omniverse Server %s failed to be connected."), *Server);
			}
			else
			{
				Message = FString::Printf(TEXT("Omniverse Server %s is disconnected."), *Server);
			}
			NotificationItem->SetText(FText::FromString(Message));
		}
		break;
	case EOmniverseServerConnectionChange::Connecting:
		if(NotificationItem.IsValid())
		{
			// Set state to pending
			FString Message = FString::Printf(TEXT("Omniverse Server %s is Connecting."), *Server);
			NotificationItem->SetText(FText::FromString(Message));
			NotificationItem->SetCompletionState(SNotificationItem::ECompletionState::CS_Pending);
		}
		break;
	case EOmniverseServerConnectionChange::Connected:
		if(NotificationItem.IsValid())
		{
			// Shut down notification
			NotificationItem->SetExpireDuration(2);
			FString Message = FString::Printf(TEXT("Omniverse Server %s is connected."), *Server);
			NotificationItem->SetText(FText::FromString(Message));
			NotificationItem->SetCompletionState(SNotificationItem::ECompletionState::CS_Success);
			NotificationItem->ExpireAndFadeout();
			NotificationItem.Reset();
		}
		break;
	}
}

void UOmniverseConnectionNotification::OnDismiss()
{
	if(NotificationItem.IsValid())
	{
		NotificationItem->ExpireAndFadeout();
		NotificationItem.Reset();

		auto& OmniSettings = *GetMutableDefault<UOmniverseSettings>();
		OmniSettings.bUserWantsToConnect = false;
		OmniSettings.TryUpdateDefaultConfigFile();
	}
}
