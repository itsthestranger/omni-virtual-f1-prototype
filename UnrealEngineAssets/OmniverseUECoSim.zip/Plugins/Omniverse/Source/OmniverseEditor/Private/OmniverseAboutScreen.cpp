// Copyright(c) 2020, NVIDIA CORPORATION.All rights reserved.
//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

// Modified from AboutScreen.cpp
// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "OmniverseAboutScreen.h"
#include "OmniverseEditorStyle.h"
#include "IOmniverseRuntimeModule.h"
#include "Fonts/SlateFontInfo.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Misc/Paths.h"
#include "Misc/EngineVersion.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SOverlay.h"
#include "Widgets/SWindow.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SEditableText.h"
#include "Widgets/Input/SHyperlink.h"
#include "Widgets/Text/SMultiLineEditableText.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Views/STableViewBase.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/Views/SListView.h"
#include "Styling/CoreStyle.h"
#include "EditorStyleSet.h"
#include "UnrealEdMisc.h"
#include "IDocumentation.h"
#include "Interfaces/IPluginManager.h"

#define LOCTEXT_NAMESPACE "OmniverseAboutScreen"

static const TCHAR* UnrealForumURL = TEXT("https://forums.developer.nvidia.com/c/omniverse/391");
static const TCHAR* OmniversePlatformURL = TEXT("https://developer.nvidia.com/nvidia-omniverse-platform");
static const TCHAR* OmniverseUnrealConnectorDocsURL = TEXT("https://docs.omniverse.nvidia.com/con_connect/con_connect/ue4.html");

void SOmniverseAboutScreen::Construct(const FArguments& InArgs)
{
	FText Version = FText::Format( LOCTEXT("VersionLabel", "Version: {0}"), FText::FromString( FEngineVersion::Current().ToString( ) ) );

	ChildSlot
		[
			SNew(SOverlay)
			+SOverlay::Slot()
			[
				SNew(SImage).Image(FSlateIcon("OmniverseEditorStyle", "OmniverseAboutScreen.Background").GetIcon())
			]

			+SOverlay::Slot()
			[
				SNew(SVerticalBox)
				+SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SHorizontalBox)
					+SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Top)
					.Padding(FMargin(10.f, 10.f, 0.f, 0.f))
					[
						SAssignNew(OmniverseButton, SButton)
						.ButtonStyle( FAppStyle::Get(), "NoBorder" )
						.ToolTipText (FText::FromString("Open Omniverse Platform and Documentation Pages"))
						.OnClicked(this, &SOmniverseAboutScreen::OnOmniverseButtonClicked)
						[
							SNew(SImage).Image(this, &SOmniverseAboutScreen::GetOmniverseButtonBrush)
						]
					]
				]
				+SVerticalBox::Slot()
				.Padding(FMargin(5.f, 5.f, 5.f, 5.f))
				.VAlign(VAlign_Center)
				[
					SNew(SMultiLineEditableText)
					.IsReadOnly(true)
					.Text(GetOmniVersionText())
				] 
				+SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SHorizontalBox)
					+SHorizontalBox::Slot()
					.FillWidth(2.0f)
					.HAlign(HAlign_Left)
					.Padding(FMargin(5.f, 0.f, 5.f, 5.f)) 
					[
						SNew(SButton)
						.HAlign(HAlign_Right)
						.VAlign(VAlign_Center)
						.Text(LOCTEXT("CopyToClipboard", "Copy To Clipboard"))
						.ButtonColorAndOpacity(FLinearColor(0.6f, 0.6f, 0.6f))
						.OnClicked(this, &SOmniverseAboutScreen::OnCopyToClipboard)
					]
					+SHorizontalBox::Slot()
					.FillWidth(3.0f)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Padding(2.0f, 0.0f, 0.0f, 0.0f)
					[
						SNew(SHyperlink)
						.Text(LOCTEXT("OmniverseForumLinkText", "Get Support"))
						.ToolTipText(LOCTEXT("OmniverseForumLinkToolTip", "Get support on the Omniverse forums"))
						.OnNavigate_Lambda([=]() { FPlatformProcess::LaunchURL(UnrealForumURL, nullptr, nullptr); })
					]
					+SHorizontalBox::Slot()
					.FillWidth(2.0f)
					.HAlign(HAlign_Right)
					.VAlign(VAlign_Bottom)
					.Padding(FMargin(5.f, 0.f, 5.f,5.f))
					[
						SNew(SButton)
						.HAlign(HAlign_Right)
						.VAlign(VAlign_Center)
						.Text(LOCTEXT("Close", "Close"))
						.ButtonColorAndOpacity(FLinearColor(0.6f, 0.6f, 0.6f))
						.OnClicked(this, &SOmniverseAboutScreen::OnClose)
					]
				]
			]
		];
}

const FSlateBrush* SOmniverseAboutScreen::GetOmniverseButtonBrush() const
{
	if (OmniverseButton->IsHovered())
	{
		return FSlateIcon("OmniverseEditorStyle", "OmniverseAboutScreen.LogoFlat").GetIcon();
	}
	else
	{
		return FSlateIcon("OmniverseEditorStyle", "OmniverseAboutScreen.Logo").GetIcon();
	}
}

FReply SOmniverseAboutScreen::OnOmniverseButtonClicked()
{
	FPlatformProcess::LaunchURL(OmniversePlatformURL, nullptr, nullptr);
	FPlatformProcess::LaunchURL(OmniverseUnrealConnectorDocsURL, nullptr, nullptr);
	return FReply::Handled();
}

FText SOmniverseAboutScreen::GetOmniVersionText(bool bIncludeHeader)
{
	FString VersionString;

	if (bIncludeHeader)
	{
		VersionString.Append("The Omniverse USD and MDL Plugins are provided by the NVIDIA Coproration\n\n");
	}

	// MDL and Omniverse Plugin versions
	IPluginManager& PluginManager = IPluginManager::Get();
	TSharedPtr<IPlugin> OmniversePlugin = PluginManager.FindPlugin("Omniverse");
	if (OmniversePlugin)
	{
		const FPluginDescriptor& Descriptor = OmniversePlugin->GetDescriptor();
		VersionString.Append(FString::Printf(TEXT("Omniverse Plugin Version: %s"), *Descriptor.VersionName));
	}
	VersionString.Append(FString::Printf(TEXT("\nOmniverse USD Resolver Plugin Version: %s"), *IOmniverseRuntimeModule::Get().GetOmniResolverVersion()));
	VersionString.Append(FString::Printf(TEXT("\nOmniverse Client Library Version: %s"), *IOmniverseRuntimeModule::Get().GetOmniClientVersion()));
	VersionString.Append(FString::Printf(TEXT("\nUSD Version: %s"), *IOmniverseRuntimeModule::Get().GetUsdVersion()));
	VersionString.Append(FString::Printf(TEXT("\nBuild Date: %s"), UTF8_TO_TCHAR(__DATE__)));

	return FText::FromString(VersionString);
}

FReply SOmniverseAboutScreen::OnCopyToClipboard()
{
	FPlatformApplicationMisc::ClipboardCopy(*GetOmniVersionText(false).ToString());
	return FReply::Handled();
}

FReply SOmniverseAboutScreen::OnClose()
{
	TSharedRef<SWindow> ParentWindow = FSlateApplication::Get().FindWidgetWindow( AsShared() ).ToSharedRef();
	FSlateApplication::Get().RequestDestroyWindow( ParentWindow );
	return FReply::Handled();
}

#undef LOCTEXT_NAMESPACE
