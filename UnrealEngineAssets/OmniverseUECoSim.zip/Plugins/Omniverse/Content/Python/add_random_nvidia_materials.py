###############################################################################
#
# Copyright 2020 NVIDIA Corporation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of
# this software and associated documentation files (the "Software"), to deal in
# the Software without restriction, including without limitation the rights to
# use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
# the Software, and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
# FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
# IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
###############################################################################

# This script will traverse the stage and apply some random materials from the NVIDIA material library 
# to any UsdGeom.Mesh prims it finds

from pxr import Usd, Sdf, UsdLux, UsdGeom, UsdShade
import argparse
import random

# This function will creates an MDL material from the NVIDIA material library and binds it to a mesh
def add_mdl_material(mesh_prim, material_folder, material_name):
    # Get the stage from the prim
    stage = mesh_prim.GetPrim().GetStage()

    # Create a Materials scope
    default_prim_path = stage.GetDefaultPrim().GetPath().pathString
    looks_path = default_prim_path + "/Looks"
    looks_prim = stage.GetPrimAtPath(looks_path)
    if (not looks_prim):
        UsdGeom.Scope.Define(stage, default_prim_path + "/Looks")
    
    # Create a material prim for this in USD (if it doesn't already exist)
    mat_prim_path = looks_path + "/" + material_name
    mat_prim = stage.GetPrimAtPath(mat_prim_path)
    if (not mat_prim):
        mat_prim = UsdShade.Material.Define(stage, mat_prim_path)
    else:
        mat_prim = UsdShade.Material(mat_prim)

    # This is where NVIDIA hosts the Omnvierse MDL material library
    base_mat_path = "http://omniverse-content-production.s3-us-west-2.amazonaws.com/Materials/Base"
    mat_asset_path = base_mat_path + "/" + material_folder + "/" + material_name + ".mdl"

    # Create the MDL shader
    mdl_shader = UsdShade.Shader.Define(stage, mat_prim_path + "/" + material_name)
    mdl_shader.CreateIdAttr("mdlMaterial")
    mdl_shader.SetSourceAsset(mat_asset_path, "mdl")
    mdl_shader.GetPrim().CreateAttribute("info:mdl:sourceAsset:subIdentifier", Sdf.ValueTypeNames.Token, True).Set(material_name)
    mdlOutput = mat_prim.CreateSurfaceOutput("mdl")

    # This code changes depending on the USD version, so handle both old and new ways
    if hasattr(mdl_shader, "ConnectableAPI"):
        mdlOutput.ConnectToSource(mdl_shader.ConnectableAPI(), "out")
    else:
        mdlOutput.ConnectToSource(mdl_shader, "out")

    UsdShade.MaterialBindingAPI.Apply(mesh_prim.GetPrim()).Bind(mat_prim)


# This function will traverse the stage and assign random materials to meshes
def apply_material_to_all_meshes(stageUrl):
    # Open the stage
    stage = Usd.Stage.Open(stageUrl)
    if not stage:
        print(f"Could not open {stageUrl}, exiting")
        return

    # This list of (folder, material) is just a sampling of some of the materials in the library
    material_list = [
        ("Masonry", "Adobe_Brick"),
        ("Masonry", "Brick_Pavers"),
        ("Masonry", "Concrete_Polished"),
        ("Natural", "Asphalt"),
        ("Natural", "Dirt"),
        ("Natural", "Water_Opaque"),
        ("Stone", "Terracotta"),
        ("Stone", "Slate"),
        ("Stone", "Stone_Wall"),
        ("Wood", "Ash_Planks"),
        ("Wood", "Birch"),
        ("Wood", "Walnut_Planks"),
    ]
    random.seed()
    for node in stage.Traverse():
        if node.IsA(UsdGeom.Mesh):
            mat_index = random.randrange(len(material_list))
            mat_desc = material_list[mat_index]
            print(f"Adding {mat_desc[0]}/{mat_desc[1]} to {node.GetPath()}")
            add_mdl_material(UsdGeom.Mesh(node), mat_desc[0], mat_desc[1])

    stage.Save()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Apply random materials from the NVIDIA material library to any UsdGeom.Mesh prims in the stage')
    parser.add_argument('root_layer_path', type=str,
                        help='Full path to the root layer of the stage to update e.g. "omniverse://localhost/Projects/stage.usd"')
    args = parser.parse_args()

    apply_material_to_all_meshes(args.root_layer_path)
